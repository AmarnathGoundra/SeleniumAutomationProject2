package SOURCE_CODE.SFDC;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;

public class DemoListAllMethodsOfClass {
    
	public static void main(String[] args) {
      
		/*
		Method[] methods = MemberOfRL_LUI.class.getDeclaredMethods();
        int nMethod = 1;
        //System.out.println("1. List of all methods of Person class");
        for (Method method : methods) {
            System.out.printf("%s", method);
            System.out.println();
        }
        //System.out.printf("%d. End - all  methods of Person class", ++nMethod);
    	*/
		System.out.println(System.getProperty("user.dir"));
		
		try (BufferedReader br = new BufferedReader(new FileReader("D:\\WS_PHOTON_NOV_17\\UAF_JIRAWIP\\src\\test\\java\\com\\mop\\qa\\test\\bvt\\TC_CreateOpp_Classic_01.java")))
		{

			String sCurrentLine;

			while ((sCurrentLine = br.readLine()) != null)
			{
				//System.out.println(sCurrentLine.toString().trim());
				
			}

		} catch (IOException e) {
			e.printStackTrace();
		} 
    
    }
    
}