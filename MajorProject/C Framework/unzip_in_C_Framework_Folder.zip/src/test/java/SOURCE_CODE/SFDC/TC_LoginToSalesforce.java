package SOURCE_CODE.SFDC;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.mop.qa.testbase.PageBase;
import com.mop.qa.testbase.TestBase;

import SOURCE_CODE.SFDC.DB;
import SOURCE_CODE.SFDC.ExitUponTestScriptStepFails;
import SOURCE_CODE.SFDC.SFDCAutomationFW;
import USER_SPACE.BusinessComponent.BC;
import USER_SPACE.ObjectRepository.LeadScreen;
import USER_SPACE.TestPrerequisite.DataSetup;

public class TC_LoginToSalesforce extends TestBase {

	SFDCAutomationFW sfdc = null;
	
		
	//@Test
	public void LoginToSFDC() throws Exception{

		//new GUIFORFRAMEWORK();   
		
		String TCName = "TC_LoginToSalesforce";
		sfdc = new SFDCAutomationFW(remoteDriver, TCName);
		
		DB DB = new DB();
		
		BC BC = new BC(remoteDriver);
		DataSetup DataSetup = new DataSetup();

		System.out.println("-----------Begin of TestScript-------------");

		try {
			String NickNameofUser = "Sourav Mukherjee"; // Added

			DB.Connect(DataSetup.Logininfo);
			System.out.println("remotedriver in TC_LoginToSalesforce class"+remoteDriver);
			sfdc.LoginToSFDC("Sourav Mukherjee");
			
			 new GUI_ScreenRecorder(this.getSFDCInstanceforOR());
			

		} catch (ExitUponTestScriptStepFails e) {
			e.printStackTrace();
			System.out.println("Exception(ExitUponTestScriptStepFails) in main");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception(Exception) in main");
		} finally {

			System.out.println("-----------End of Login TestScript-------------");

		}

	}
	
	public SFDCAutomationFW getSFDCInstanceforOR() {
		
		return sfdc;
	}
	public SFDCAutomationFW getSFDCInstanceforCreateTC() {
		String TCName = "TC_CreateTC";
		if (toolName.equalsIgnoreCase("Selenium")) {
			sfdc = new SFDCAutomationFW(remoteDriver, TCName);
			
		} else if (toolName.equalsIgnoreCase("Appium")) {
			sfdc = new SFDCAutomationFW(appiumDriver, TCName);
			
		}
		DB DB = new DB();
		BC BC = new BC(remoteDriver);
		DataSetup DataSetup = new DataSetup();
		
		return sfdc;
	}
}
