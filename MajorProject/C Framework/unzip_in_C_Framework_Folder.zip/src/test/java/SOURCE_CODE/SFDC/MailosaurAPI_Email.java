package SOURCE_CODE.SFDC;


import org.junit.Test;
import static org.junit.Assert.*;
import com.mailosaur.MailosaurClient;
import com.mailosaur.MailosaurException;
import com.mailosaur.models.*;
import java.io.IOException;

public class MailosaurAPI_Email {
	
  @Test public void testExample() throws IOException, MailosaurException {
    // Available in the API tab of a server
    String apiKey = "PAkUpWIiFASWaAl3yRO7xnrADBv9yCDu";
    String serverId = "5pu52uey";
    String serverDomain = "5pu52uey.mailosaur.net";

    MailosaurClient mailosaur = new MailosaurClient(apiKey);

    MessageSearchParams params = new MessageSearchParams();
    params.withServer(serverId);

    SearchCriteria criteria = new SearchCriteria();
    criteria.withSentTo("anything@" + serverDomain);

    Message message = mailosaur.messages().get(params, criteria);

    assertNotNull(message);
    assertEquals("My email subject", message.subject());
  }
}
