package SOURCE_CODE.SFDC;

import io.appium.java_client.AppiumDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;
import ru.yandex.qatools.ashot.coordinates.WebDriverCoordsProvider;
import ru.yandex.qatools.ashot.shooting.RotatingDecorator;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;
import ru.yandex.qatools.ashot.shooting.ShootingStrategy;
import ru.yandex.qatools.ashot.shooting.ViewportPastingDecorator;
import ru.yandex.qatools.ashot.shooting.cutter.CutStrategy;
import ru.yandex.qatools.ashot.shooting.cutter.VariableCutStrategy;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

import org.apache.maven.shared.invoker.SystemOutHandler;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import USER_SPACE.TestPrerequisite.DataSetup;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.testbase.PageBase;
import com.mop.qa.testbase.TestBase;
import com.relevantcodes.extentreports.LogStatus;
import com.zapi.Utilities.AddTestsToCycle;

public class SFDCAutomationFW extends PageBase {

	public String TCName;
	public WebDriver myWD;
	public WebElement button;
	public MemberOfButton mb = null;
	public MemberOfLink ml = null;
	public MemberOfTab mt = null;
	public MemberOfField mf = null;
	public MemberOfCustom_LUI mc = null;
	public MemberOfHealthCloud_LUI mhc = null;
	
	public MemberOfSEC ms = null;
	public MemberOfRL rl = null;
	public MemberOfRelatedList rll = null;

	public MemberOfLV lv = null;

	public MemberOfField_LUI mf_lui = null;
	public CustomMemberOfField_LUI mf_cu = null;
	public CustomMemberOfButton_LUI mb_cu = null;
	
	public MemberOfLV_LUI mlv_lui = null;
	public MemberOfRL_LUI mrl_lui = null;
	public MemberOfButton_LUI mb_lui = null;
	public MemberOfTab_LUI mt_lui = null;
	public MemberOfAllApps_LUI maa_lui = null;

	public DataSetup DataSetup = null;
	public DB DB = null;
	String xpath = null;
	public static String obj_lv;
	public static String obj_vd;
	public static String ObjectName_classic;
	public static String ObjectNameAllTabs;
	public static String ObjectNameListView;
	public static ArrayList<String> al_rlSecName_FName,al_rlSecName_plus_FName;
	public static ArrayList<String> al_all_apps,al_all_tabs,al_buttons,al_lv_col_names,al_lv_buttons,al_rl_names,al_rl_col_names,al_rl_buttons,al_dv_fields,al_dv_buttons,al_rlname_plus_col,al_rlname_plus_buttons;
	
	
	//public static ArrayList<String> al_custom_table,al_custom_table_col_names;
	public static ArrayList<String> al_edit_fields = new ArrayList<>();
	public static String xp_lui_common_part = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]";


	
	//This constructor is only used for OR creation of DotNext
	public SFDCAutomationFW() {

		String callerClassName = new Exception().getStackTrace()[1].getClassName();

		System.out.println("Caller class is: "+callerClassName);

		if(!callerClassName.toString().contains("GUI_FOR_TESTSCRIPT_CREATION"))
		{	
			
			System.setProperty("webdriver.edge.driver","msedgedriver.exe");
			EdgeOptions options = new EdgeOptions();
			
			options.setBinary("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe");
			options.addArguments("--profile-directory=Default");
			options.addArguments("--allow-http-screen-capture");
			options.addArguments("--disable-extensions");
			options.addArguments("--test-type");
			options.addArguments("start-maximized");
			WebDriverManager.edgedriver().setup();
			
			this.myWD = new EdgeDriver(options);
		}

		DB = new DB();
		DataSetup = new DataSetup();
	}

	public SFDCAutomationFW(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
		ml = new MemberOfLink(remoteDriver);
		mb = new MemberOfButton(remoteDriver);
		mt = new MemberOfTab(remoteDriver);
		mf = new MemberOfField(remoteDriver);
		ms = new MemberOfSEC(remoteDriver);
		mc = new MemberOfCustom_LUI(remoteDriver);
		mhc = new MemberOfHealthCloud_LUI(remoteDriver);
		rl = new MemberOfRL(remoteDriver);
		rll = new MemberOfRelatedList(remoteDriver);

		lv = new MemberOfLV(remoteDriver);
		DataSetup = new DataSetup();
		DB = new DB();

		//below instantiation are for LUI
		mf_lui = new MemberOfField_LUI(remoteDriver);
		mf_cu=new CustomMemberOfField_LUI(remoteDriver);
		mlv_lui = new MemberOfLV_LUI(remoteDriver);
		mrl_lui = new MemberOfRL_LUI(remoteDriver);
		mb_lui = new MemberOfButton_LUI(remoteDriver);
		mt_lui = new MemberOfTab_LUI(remoteDriver);
		maa_lui = new MemberOfAllApps_LUI(remoteDriver);
		mb_cu = new CustomMemberOfButton_LUI(remoteDriver);
	}

	public SFDCAutomationFW(AppiumDriver appiumDriver) {
		super(appiumDriver);
		ml = new MemberOfLink(appiumDriver);
		mb = new MemberOfButton(appiumDriver);
		mt = new MemberOfTab(appiumDriver);
		mf = new MemberOfField(appiumDriver);
		mc = new MemberOfCustom_LUI(appiumDriver);
		mhc = new MemberOfHealthCloud_LUI(appiumDriver);
		ms = new MemberOfSEC(appiumDriver);
		rl = new MemberOfRL(appiumDriver);
		rll = new MemberOfRelatedList(appiumDriver);
		lv = new MemberOfLV(appiumDriver);
		DataSetup = new DataSetup();
		DB = new DB();

		//below instantiation are for LUI
		mf_lui = new MemberOfField_LUI(appiumDriver);
		mf_cu=new CustomMemberOfField_LUI(appiumDriver);
		mlv_lui = new MemberOfLV_LUI(appiumDriver);
		mrl_lui = new MemberOfRL_LUI(appiumDriver);
		mb_lui = new MemberOfButton_LUI(appiumDriver);
		mt_lui = new MemberOfTab_LUI(appiumDriver);
		maa_lui = new MemberOfAllApps_LUI(appiumDriver);
		mb_cu = new CustomMemberOfButton_LUI(appiumDriver);
	}

	public SFDCAutomationFW(RemoteWebDriver remoteDriver, String TCName) {
		// TODO Auto-generated constructor stub
		super(remoteDriver);
		System.out.println("Remotedriver is:"+remoteDriver.toString());
		this.TCName = TCName;
		
		ml = new MemberOfLink(remoteDriver);
	
		mb = new MemberOfButton(remoteDriver);
		
		mt = new MemberOfTab(remoteDriver);
		
		mf = new MemberOfField(remoteDriver);
	
		mc = new MemberOfCustom_LUI(remoteDriver);
		
		mhc = new MemberOfHealthCloud_LUI(remoteDriver);
		
		ms = new MemberOfSEC(remoteDriver);
		
		rl = new MemberOfRL(remoteDriver);
		
		rll = new MemberOfRelatedList(remoteDriver);
		
		lv = new MemberOfLV(remoteDriver);
		
		DataSetup = new DataSetup();
		
		DB = new DB();
		

		//below instantiation are for LUI
		mf_lui = new MemberOfField_LUI(remoteDriver);
		
		mlv_lui = new MemberOfLV_LUI(remoteDriver);
		
		mrl_lui = new MemberOfRL_LUI(remoteDriver);
		
		maa_lui = new MemberOfAllApps_LUI(remoteDriver);
	
		mb_lui = new MemberOfButton_LUI(remoteDriver);
		
		mt_lui = new MemberOfTab_LUI(remoteDriver);
		
	}

	public SFDCAutomationFW(AppiumDriver appiumDriver, String TCName) {
		// TODO Auto-generated constructor stub
		super(appiumDriver);
		this.TCName = TCName;
		ml = new MemberOfLink(appiumDriver);
		mb = new MemberOfButton(appiumDriver);
		mt = new MemberOfTab(appiumDriver);
		mf = new MemberOfField(appiumDriver);
		mc = new MemberOfCustom_LUI(appiumDriver);
		mhc = new MemberOfHealthCloud_LUI(appiumDriver);
		ms = new MemberOfSEC(appiumDriver);
		rl = new MemberOfRL(appiumDriver);
		rll = new MemberOfRelatedList(appiumDriver);
		lv = new MemberOfLV(appiumDriver);
		DataSetup = new DataSetup();
		DB = new DB();

		//below instantiation are for LUI
		mf_lui = new MemberOfField_LUI(appiumDriver);
		mlv_lui = new MemberOfLV_LUI(appiumDriver);
		mrl_lui = new MemberOfRL_LUI(appiumDriver);
		mb_lui = new MemberOfButton_LUI(appiumDriver);
		mt_lui = new MemberOfTab_LUI(appiumDriver);
		maa_lui = new MemberOfAllApps_LUI(appiumDriver);
	}

	public MemberOfLink Link(String link) throws Exception {
		ml.Link = link;
		return ml;
	}

	public MemberOfButton Button(String buttonName) throws Exception {
		mb.xpath = mb.generateXpath(buttonName);
		System.out.println("XPATH-" + mb.xpath);
		mb.button = getElement(mb.xpath);
		mb.ButtonName = buttonName;
		return mb;
	}

	public MemberOfTab Tab(String TabName) throws Exception {
        mt.xpath = mt.generateXpath(TabName);
        //mt.tab = getElement(mt.xpath);
        mt.TabName = TabName;
        return mt;
 }


	public MemberOfField Field(String FieldName) throws Exception {
		// mf.xpath = mf.generateXpath(FieldName);
		// mf.field = getElement(mf.xpath);
		// System.out.println(mf.field);
		mf.fieldname = FieldName;
		return mf;

	}
	public MemberOfField_LUI Field_LUI(String FieldName) throws Exception {
		// mf.xpath = mf.generateXpath(FieldName);
		// mf.field = getElement(mf.xpath);
		// System.out.println(mf.field);
		mf_lui.fieldname = FieldName;
		return mf_lui;

	}

	// ********************************** Below Components are created for HealthCloud *****************************
	
		//For Custom Fields
	
		/*public MemberOfHealthCloud_LUI MemberOfHealthCloud_LUI(String FieldName) throws Exception {
			mhc.fieldname = FieldName;
			return mhc;
		}*/
		
	public MemberOfHealthCloud_LUI HealthCloudField_LUI(String FieldName) throws Exception {
		mhc.fieldname = FieldName;
		return mhc;
	}
	
	public MemberOfHealthCloud_LUI HealthCloudButton_LUI(String Button) throws Exception {
		mhc.ButtonName = Button;
		return mhc;
	}
	// ********************************** Above Components are created for HealthCloud *****************************
	
		
	
// ********************************** Below Components are created for CloudSense *****************************
	
	//For Custom Fields
	public MemberOfCustom_LUI CustomField_LUI(String FieldName) throws Exception {
		mc.fieldname = FieldName;
		return mc;
	}
	
	//For Custom Button
	public MemberOfCustom_LUI CustomButton_LUI(String buttonName) throws Exception {
		
		mc.ButtonName = buttonName;
		
		return mc;
	}
	
	//For Custo JTree
	public MemberOfCustom_LUI CustomJTree_LUI(String FieldName) throws Exception {
		mc.fieldname = FieldName;
		return mc;
	}
	
		
	//For Custom Table Cell
	public MemberOfCustom_LUI CustomTableCell_LUI(String TableCellName) throws Exception {
		mc.TableCellName = TableCellName;
		return mc;
	}
	

	//For Custom Related List
	public MemberOfCustom_LUI CustomRelatedList_LUI(String RelatedList_ColumnName) throws Exception {
		mc.RelatedList_ColumnName = RelatedList_ColumnName;
		return mc;
	}
	
	
//***************************************  Above Components are created for CloudSense *****************************
	
	//For Custom
		public MemberOfCustom_LUI RL_Custom_LUI(String RelatedListName,String ColumnName,String TargetColumnValue) throws Exception {


			mc.RelatedList = RelatedListName;
			mc.TargetColumnName = ColumnName;
			mc.TargetColumnValue = TargetColumnValue;
			mc.xpath_common = mc.generateXpath(RelatedListName);		
			return mc;
		}
		//For Custom 
		public MemberOfCustom_LUI RL_Custom_LUI(String RelatedListName,String ColumnName) throws Exception {


			mc.RelatedList = RelatedListName;
			mc.TargetColumnName = ColumnName;
			mc.xpath_common = mc.generateXpath(RelatedListName);		
			return mc;
		}
			
	
	//this is added for custom Field
	public CustomMemberOfField_LUI Field_Custom(String FieldName) throws Exception {
		
		mf_cu.fieldname = FieldName;
		return mf_cu;

	}
	
	
	
	public MemberOfSEC Section(String SectionName,String FieldName) throws Exception {

		System.out.println("FieldName: "+FieldName);
		System.out.println("SECName:"+SectionName);
		ms.FieldName = FieldName;
		ms.SectionName = SectionName;
		return ms;
	}
	public MemberOfRL RL(String RelatedListName,String ColumnName,int RowIndex) throws Exception {


		rl.RelatedList = RelatedListName;
		rl.ColumnName = ColumnName;
		rl.RowIndex = RowIndex;

		return rl;
	}
	public MemberOfRL RL(String RelatedListName,String ColumnName) throws Exception {


		rl.RelatedList = RelatedListName;
		rl.ColumnName = ColumnName;

		return rl;
	}
	
	public MemberOfLV LV(String ColumnName,int RowIndex) throws Exception {

		//		rl.RelatedList = RelatedListName;
		lv.ColumnName = ColumnName;
		lv.RowIndex = RowIndex;

		return lv;
	}
	public MemberOfLV LV(String ColumnName) throws Exception {


		//		rl.RelatedList = RelatedListName;
		lv.ColumnName = ColumnName;

		return lv;
	}
	//Sangeetha
	public MemberOfRelatedList RelatedList(String RelatedListName) throws Exception {	

		rll.RelatedList = RelatedListName;

		return rll;
	}

	//Lightning Member Function below
	public MemberOfLV_LUI LV_LUI(String ObjectName,String TargetColumnName,String TargetColumnValue) throws Exception {


		mlv_lui.ObjectName = ObjectName;
		mlv_lui.TargetColumnName = TargetColumnName;
		mlv_lui.TargetColumnValue = TargetColumnValue;

		return mlv_lui;
	}

	public MemberOfLV_LUI LV_LUI(String ObjectName,String TargetColumnName) throws Exception {


		mlv_lui.ObjectName = ObjectName;
		mlv_lui.TargetColumnName = TargetColumnName;

		return mlv_lui;
	}

	public MemberOfRL_LUI RL_LUI(String RelatedListName,String ColumnName,String TargetColumnValue) throws Exception {


		mrl_lui.RelatedList = RelatedListName;
		mrl_lui.TargetColumnName = ColumnName;
		mrl_lui.TargetColumnValue = TargetColumnValue;
		mrl_lui.xpath_common = mrl_lui.generateXpath(RelatedListName);		
		return mrl_lui;
	}
	public MemberOfRL_LUI RL_LUI(String RelatedListName,String ColumnName) throws Exception {


		mrl_lui.RelatedList = RelatedListName;
		mrl_lui.TargetColumnName = ColumnName;
		mrl_lui.xpath_common = mrl_lui.generateXpath(RelatedListName);		
		return mrl_lui;
	}
	
	
	
	public MemberOfButton_LUI Button_LUI(String buttonName) throws Exception {
		mb_lui.xpath = mb_lui.generateXpath(buttonName);
		System.out.println("XPATH-" + mb_lui.xpath);
		//mb_lui.button = getElement(mb_lui.xpath);
		mb_lui.ButtonName = buttonName;
		return mb_lui;
	}

	public CustomMemberOfButton_LUI Button_Custom(String buttonName)throws Exception {
		mb_cu.xpath = mb_cu.generateXpath(buttonName);
		System.out.println("XPATH-" + mb_cu.xpath);
		//mb_lui.button = getElement(mb_lui.xpath);
		mb_cu.ButtonName = buttonName;
		return mb_cu;
		
	}
	public MemberOfTab_LUI Tab_LUI(String TabName) throws Exception {
		//mt_lui.xpath = mt_lui.generateXpath(TabName);
		//mt_lui.tab = getElement(mt_lui.xpath);
		mt_lui.TabName = TabName;
		return mt_lui;
	}
	public MemberOfAllApps_LUI AllApps_LUI(String AppName) throws Exception {
		
		maa_lui.AppName = AppName;
		return maa_lui;
	}
	synchronized public boolean LoginToSFDC(String TestUserName) throws Exception {
		
		try {
			DB DB = new DB();
			Thread.sleep(2000L);

			//DB.Connect(DataSetup.Logininfo);
			ReadDataSheet rds = new ReadDataSheet();
			
			String URL = rds.getValue("LoginInfo", TestUserName, "URL");
			String UserName = rds.getValue("LoginInfo", TestUserName, "Username");
			String Password = rds.getValue("LoginInfo", TestUserName, "Password");
			String Name =  rds.getValue("LoginInfo", TestUserName, "Name");

			System.out.println("username"+UserName+"Password"+Password);

			String xpath_UserName = "//input[normalize-space(@type)='email' and normalize-space(@id)='username'][1]";
			String xpath_Password = "//input[normalize-space(@type)='password' and normalize-space(@id)='password'][1]";

			String xpath_LoginButton = "//input[contains(@class,'button') and @type='submit'][1]";

			System.out.println("URL:"+URL);
			enterUrl(URL);

			Thread.sleep(3000L);
			WebElement username = getElement(xpath_UserName);
			WebElement password = getElement(xpath_Password);
			username.clear();
			enterText(username, UserName, "User Name");

			password.clear();
			enterText(password, Password, "Password");

			click(xpath_LoginButton, "Login Button");

			
			WaitForPageToLoad(300);
			Thread.sleep(15000L);
			
			//PressESCKey();
			if(!getCurrentUrl().toString().contains("lightning"))
			{
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
				
				/*
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSecond(15));
				if(remoteDriver.findElements(By.xpath("//*[@id='tryLexDialogX']")).size() > 0)
				{
					remoteDriver.findElement(By.xpath("//*[@id='tryLexDialogX']")).click();
					System.out.println("The dialog window is closed.");
				}
				*/
				
				// WebDriverWaitForElement("//a[contains(normalize-space(text()),'Home')]", 30);
				
				Tab("Home").Click();
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
				if(remoteDriver.findElements(By.xpath("//*[@id='tryLexDialogX']")).size() > 0)
				{
					remoteDriver.findElement(By.xpath("//*[@id='tryLexDialogX']")).click();
					System.out.println("The dialog window is closed.");
				}
				WebElement home = getElement("//a[contains(normalize-space(text()),'Home')]");
				if (home.isDisplayed()) {
					System.out.println("The user (" + TestUserName + ") is able to login successfully.");
					AddLogToCustomReport("The user (" + TestUserName + ") is able to login successfully.", "Pass");
					// Adding Profile name to the Exe_Logs sheet in GlobalData.xls
					System.out.println("DataSetup.Logininfo--" + DataSetup.Logininfo);
					//DB.Connect(DataSetup.Logininfo);
					//DB.UpdateXLCellWithApend(DataSetup.SheetNameofTestLogSummary,DB.ReadXLData(DataSetup.SheetNameofTestUsers, "Profiles", "Name", Name), "Profiles","TestCase", this.TCName);
					//Thread.sleep(15000L);
					return true;
				} else {
					AddLogToCustomReport("The user (" + Name + ") is unable to login.", "Fail");
					System.out.println("The user (" + Name + ") is unable to login.");
					return false;
				}

			}
			
			WaitForPageToLoad(60);
			Thread.sleep(5000L);
			PressESCKey();
			System.out.println("The user (" + Name + ") is able to login in Salesforce successfully.");
			AddLogToCustomReport("The user (" + Name + ") is able to login in Salesforce successfully.", "Pass");
			return true;

		} catch (Exception e) {
			System.out.println("The user (" + TestUserName + ") is unable to login.");
			e.printStackTrace();
			AddLogToCustomReport("The user (" + TestUserName + ") is unable to login.", "Fail");
			return false;
		}

	}

	/**
	 * @param ApplicationName
	 * @return
	 * @throws Exception
	 */
	public synchronized boolean SelectApplication_LUI(String ApplicationName) throws Exception
	{
		try
		{
			
			String xp_app_launcher = "(//div[contains(@class,'appLauncher')]/button[contains(@class,'AppLauncher')]/descendant::div[contains(@class,'slds-icon')])[1]";
			WaitForElement(xp_app_launcher, 30);
			Thread.sleep(5000L);
			remoteDriver.findElement(By.xpath(xp_app_launcher)).click();
			String xp = "(//button[@type='button'][text()='View All'])[1]";
			WaitForElement(xp,30);
			Thread.sleep(5000L);
			
			remoteDriver.findElement(By.xpath(xp)).click();
			//xp = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::div[contains(@class,'app-launcher')]/descendant::p[contains(@class,'slds-truncate')]/descendant-or-self::*[normalize-space(text())='"+ApplicationName+"'][1]";
			String xp1 = "(//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::div[contains(@class,'app-launcher')]/descendant::p[contains(@class,'slds-truncate')]/descendant-or-self::*[normalize-space(text())='"+ApplicationName+"'][1]/ancestor::div[contains(@class,'slds-truncate')])[1]";
			if(WaitForElement(xp1, 30))
			{
				Thread.sleep(5000L);
				WebElement elm = remoteDriver.findElement(By.xpath(xp1));
				ScrollToElement(elm);
				Thread.sleep(1000L);
				elm.click();				
				System.out.println("Selected the app ("+ApplicationName+") successfully.");
				AddLogToCustomReport("Selected the app ("+ApplicationName+") successfully.", "Pass");
			}
			else
			{
				System.out.println("Unable to select the app ("+ApplicationName+").");
				AddLogToCustomReport("Unable to select the app ("+ApplicationName+").", "Fail");
				
			}
			
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to select the application ("+ApplicationName+")");
			AddLogToCustomReport("Unable to select the application ("+ApplicationName+")", "Fail");
			return false;
		}


	}

	/**
	 * @param ApplicationName
	 * 
	 * @throws Exception
	 */
	public void SelectApplication(String ApplicationName) throws Exception
	{
		try {
			String label = getText(getElement("//*[@id='tsidLabel']"));
			if (label.equals(ApplicationName.trim()))
			{
				System.out.println("The application ("+ApplicationName+") is selected successfully.");
			}
			else
			{
				click("//*[@id='tsid-arrow']", " Arrow");
				Thread.sleep(1000L);
				if (getElement("//*[contains(@class,'menuButtonMenuLink') and contains(text(), '"+ApplicationName+"')]").isDisplayed())
				{
					click(getElement("//*[contains(@class,'menuButtonMenuLink') and contains(text(), '"+ApplicationName+"')]"), ApplicationName);
					System.out.println("The application ("+ApplicationName+") is selected successfully.");
					AddLogToCustomReport("The application ("+ApplicationName+") is selected successfully.", "Pass");
				}
				else
				{
					System.out.println("Unable to select the application for ("+ApplicationName+"). Please check the related xpaths or application name properly.");
					AddLogToCustomReport("Unable to select the application for ("+ApplicationName+"). Please check the related xpaths or application name properly.", "Fail");
				}

			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to select the application for ("+ApplicationName+"). Please check the related xpaths or application name properly.");
			AddLogToCustomReport("Unable to select the application for ("+ApplicationName+"). Please check the related xpaths or application name properly.", "Fail");

		}

	}

	public void LoginToSFDCWithDotNextInstance(String NickName) throws Exception
	{
		try {


			//DB.Connect(DataSetup.Logininfo);
			
			ReadDataSheet rds = new ReadDataSheet();			
			String URL = rds.getValue("LoginInfo", NickName, "URL");
			String UserName = rds.getValue("LoginInfo", NickName, "Username");
			String Password = rds.getValue("LoginInfo", NickName, "Password");
			
			
			String xpath_UserName = "//input[normalize-space(@type)='email' and normalize-space(@id)='username'][1]";
			String xpath_Password = "//input[normalize-space(@type)='password' and normalize-space(@id)='password'][1]";

			String xpath_LoginButton = "//input[contains(@class,'button') and @type='submit'][1]";
			myWD.navigate().to(URL);

			myWD.manage().window().maximize();
			myWD.findElement(By.xpath(xpath_UserName)).clear();
			myWD.findElement(By.xpath(xpath_UserName)).sendKeys(UserName);

			myWD.findElement(By.xpath(xpath_Password)).clear();
			myWD.findElement(By.xpath(xpath_Password)).sendKeys(Password);

			myWD.findElement(By.xpath(xpath_LoginButton)).click();

			remoteDriver = (RemoteWebDriver)myWD;

			Thread.sleep(5000L);
			
			
			
			if(!myWD.getCurrentUrl().contains("lightning"))
			{
				//click("", " Close Pop-Up");
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
				Thread.sleep(3000L);
				remoteDriver.findElement(By.xpath("//li/a[contains(@title,'Tab') and contains(@title,'Home')][1]")).click();
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
				remoteDriver.findElement(By.xpath("//*[@id='tryLexDialogX']")).click();
				/*
			myWD.findElement(By.xpath("//input[@title='No Thanks' and @type='button'][1]")).click();
			Thread.sleep(2000L);
			myWD.findElement(By.xpath("//label[@for='lex-checkbox-7'][1]/span[1]")).click();
			Thread.sleep(2000L);
			myWD.findElement(By.xpath("//input[@title='Send to Salesforce'][1]")).click();
			WebDriverWaitForElement("//a[contains(normalize-space(text()),'Home')]", 30);
				 */
			}


		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	
	/**
	 * 
	 * @throws Exception
	 */
	public void SwitchToClassic() throws Exception {
		try {
			Thread.sleep(4000L);
			if(remoteDriver.getCurrentUrl().contains("lightning"))
			{
				String xp = "(//img[@alt='User'])[1]";
				Thread.sleep(1000L);
				//click(xp, "User");
				WaitForElement(xp, 30);
				
				remoteDriver.findElement(By.xpath(xp)).click();
				Thread.sleep(2000L);
				remoteDriver.findElement(By.xpath("(//a[contains(text(),'Switch to Salesforce Classic')])")).click();

				System.out.println("Successfully Switched to Salesforce Classic");
				//AddLogToCustomReport("Successfully Switched to Salesforce Classic", "Pass");
			}
			else
			{
				System.out.println("Salesforce Classic version is found.");
				//AddLogToCustomReport("Salesforce Classic version is found.", "Pass");
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to switch to classic version of Salesforce");
		}
	}

	//Clicks on Setup Gear and then clicks on Setup to to move to Admin view 
	public void OpenSalesforceSetup() throws Exception {
		try {
			Thread.sleep(4000L);
			if(remoteDriver.getCurrentUrl().contains("lightning"))
			{
				String xp = "//div[@role='button'][contains(@class,'setup')][contains(@class,'Gear')][1]//*[@data-key='setup'][1]";
				Thread.sleep(1000L);
				//click(xp, "User");
				WaitForElement(xp, 30);

				remoteDriver.findElement(By.xpath(xp)).click();
				Thread.sleep(2000L);
				remoteDriver.findElement(By.xpath("(//div[contains(@class,'menu')][contains(@class,'visible')]//ul//li//*[normalize-space(text())='Setup'])[1]")).click();

				System.out.println("Successfully navigated to Salesforce Setup");
				
			}
			else
			{
				System.out.println("Salesforce Classic version is found.");

			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to open Salesforce Setup");
		}
	}
	
	//Finds any text in Quick Find search box in Setup of Salesforce Lightning 
	public void QuickFind_In_SalesforceSetup(String SearchString) throws Exception {
		try 
		{
			
			String xp1 = "//input[@placeholder='Quick Find'][1]";
			String xp2 = "(//a//mark[@class='highlight'])[1]";
			
			remoteDriver.findElement(By.xpath(xp1)).clear();
			remoteDriver.findElement(By.xpath(xp1)).sendKeys(SearchString);
			WebElement wel = remoteDriver.findElement(By.xpath(xp1));
			wel.sendKeys(Keys.ENTER);
			Thread.sleep(4000L);
			remoteDriver.findElement(By.xpath(xp2)).click();
			
			//AddLogToCustomReport("Successfully searched ("+SearchString+") in Quick Find search box", "Pass");
			
		} catch (Exception e) 
		{
			e.printStackTrace();
			//AddLogToCustomReport("Unable to search ("+SearchString+") in Quick Find search box", "Fail");
		}
	}


	/**
	 * @Description Switching the application to lightning version
	 * @throws Exception
	 */
	public void SwitchToLightning() throws Exception {
		try {
			if(remoteDriver.getCurrentUrl().contains("lightning"))
			{
				System.out.println("Salesforce lightning version is found.");
				//AddLogToCustomReport("Salesforce lightning version is found.", "Pass");

			}
			else
			{
				Thread.sleep(2000L);
				System.out.println("remotedriver:"+remoteDriver.toString());
				//WaitForElement("(//a[@title='Close' and normalize-space(text())='Close'])[1]", 30);
				//remoteDriver.findElement(By.xpath("(//a[@title='Close' and normalize-space(text())='Close'])[1]")).click();
				//Thread.sleep(4000L);
				remoteDriver.findElement(By.linkText("Switch to Lightning Experience")).click();
				//this.Link("Switch to Lightning Experience").Click();

				System.out.println("Successfully Switched to Salesforce Lightning");
				//AddLogToCustomReport("Successfully Switched to Salesforce Classic", "Pass");

			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to switch to Lightning version of Salesforce");
		}
	}


	/**
	 * @Description This method logs out from Salesforce classic / lightning both
	 * @throws Exception
	 */
	public void LogOff() throws Exception {
		try {
			if(remoteDriver.getCurrentUrl().contains("lightning"))
			{
				String xp = "//button[contains(@class,'userProfile')][1]";
				Thread.sleep(3000L);
				remoteDriver.findElement(By.xpath(xp)).click();
				Thread.sleep(5000L);
				remoteDriver.findElement(By.xpath("(//a[text()='Log Out'])[1]")).click();
				AddLogToCustomReport("Logging out from salesforce Lightning", "Pass");
				System.out.println("Logging out from salesforce Lightning");	
			}
			else
			{
				String xp = "//div[contains(@class,'menuButton') and contains(@title,'User') and contains(@title,'menu')][1]/descendant::span[text()][1]";
				Thread.sleep(3000L);
				click(xp, "User");
				Thread.sleep(1000L);
				click("(//a[@title='Logout' and normalize-space(text())='Logout'])[1]","Log Out");
				AddLogToCustomReport("Logging out from salesforce Classic", "Pass");

			}

		} catch (Exception e) {
			e.printStackTrace();
			AddLogToCustomReport("Unable to logout from Salesforce", "Fail");
			System.out.println("Unable to Logout from Salesforce");
		}
	}


	/**
	 * @description Closes all the browser window
	 * @throws Exception
	 */
	public void Quit() throws Exception
	{
		try {
			
			remoteDriver.quit();
			System.out.println("Closed all browser window");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}


	/**
	 * @author Cognizant
	 * @param UserName by which you want to login
	 * @return true if Login is Successful else return false
	 * @Description login to Salesforce with single sign on feature. 
	 * @throws Exception
	 */
	public boolean LoginAsUser(String UserName) throws Exception
	{
		try
		{
						
			remoteDriver.findElement(By.xpath("(//div[@class='menuButtonButton']/span[@class='menuButtonLabel'])[1]")).click();
			Thread.sleep(2000L);
			remoteDriver.findElement(By.xpath("(//div[contains(@class,'mbrMenuItems')])[1]/a[@title='Setup'][1]")).click();
		    
			WaitForElement("(//input[contains(@title,'Quick Find / Search') and @type='text'])[1]", 20);
			
			remoteDriver.findElement(By.xpath("(//input[contains(@title,'Quick Find / Search') and @type='text'])[1]")).sendKeys(UserName);
			remoteDriver.findElement(By.xpath("(//input[contains(@class,'setupSearchButton') and @type='submit'])[1]")).click();
			if (WaitForElement("((//th[contains(@class,'Column') and text()='Name'])[1]/ancestor::thead[1]/following-sibling::tbody[1]/tr/td/a[normalize-space(text())='"+UserName.trim()+"'])[1]", 20)) 
			{
				remoteDriver.findElement(By.xpath("((//th[contains(@class,'Column') and text()='Name'])[1]/ancestor::thead[1]/following-sibling::tbody[1]/tr/td/a[normalize-space(text())='"+UserName.trim()+"'])[1]")).click();
				Thread.sleep(3000L);
				Button("Login").Click();
				AddLogToCustomReport("The user ("+UserName+") has successfully logged into the application.", "Pass");
				System.out.println("The user ("+UserName+") has successfully logged into the application.");
				
			}
			else
			{
				AddLogToCustomReport("Unable to login as ("+UserName+"). Please check the xpaths in LoginAsUser function business component.","Fail");
				System.out.println("Unable to login as ("+UserName+"). Please check the xpaths in LoginAsUser function business component.");
				
			}
	    
	     
			
/*
			//LoginToSFDC(DataSetup.SYSTEM_ADMIN_USERNAME);
			GlobalSearch("People", UserName);
			Thread.sleep(2000L);
			WaitForPageToLoad(15);
			WaitForElement("//a[contains(normalize-space(@class),'zen-trigger') and contains(normalize-space(@title),'User Action Menu')]", 20);
			remoteDriver.findElement(By.xpath("//a[contains(normalize-space(@class),'zen-trigger') and contains(normalize-space(@title),'User Action Menu')]")).click();
			//			sfdc.remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='profileHeader']/div[1]/div[1]/a[1]")).click();
			//sfdc.HighLight(sfdc.WebDriverWaitForElement("//div[normalize-space(@class)='profileHeader']/div[1]/div[1]/a[1]/b[@class='zen-selectArrow']", 10));
			//sfdc.WebDriverWaitForElement("//div[normalize-space(@class)='profileHeader']/div[1]/div[1]/a[1]/b[@class='zen-selectArrow']", 10).click();
			Thread.sleep(1000L);
			WaitForElement("//span[normalize-space(text())='User Detail']", 20);			
			remoteDriver.findElement(By.xpath("//span[normalize-space(text())='User Detail']")).click();
			Thread.sleep(2000L);
			//Button("Login").WaitForElement(10);

			Button("Login").Click();
			WaitForPageToLoad(20);*/
			//AddLogToCustomReport("The user ("+UserName+") has successfully logged into the application.", "Pass");
			//System.out.println("The user ("+UserName+") has successfully logged into the application.");

			return true;
		}
		catch(Exception e)
		{
			AddLogToCustomReport("Unable to login as ("+UserName+"). Please check the xpaths in LoginAsUser function business component.","Fail");
			System.out.println("Unable to login as ("+UserName+"). Please check the xpaths in LoginAsUser function business component.");
			e.printStackTrace();
			return false;

		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param Name of 1. SFDC Object like Accounts,Leads,Contacts 2. SearchText
	 * @return boolean
	 * @throws Exception
	 * @Description Searches any sfdc record from SFDC GlobalSearch option
	 * @Date Aug 7, 2014
	 */
	public boolean GlobalSearch(String Object,String SearchItem) throws Exception
	{
		WaitForPageToLoad(15);
		xpath = "//input[contains(@title,'Search') or contains(@id,'Search') or contains(@name,'Search')]";
		try
		{
			remoteDriver.findElement(By.xpath(xpath)).clear();
			remoteDriver.findElement(By.xpath(xpath)).sendKeys(SearchItem.trim());
			//Thread.sleep(1000L);
			//remoteDriver.findElement(By.xpath(xpath)).sendKeys(Keys.ENTER);
			remoteDriver.findElement(By.xpath("//input[normalize-space(@id)='phSearchButton' and normalize-space(@type)='button' and normalize-space(@value)='Search'][1]")).click();
			WaitForPageToLoad(15);
			Thread.sleep(1000L);
			xpath = "//*[(contains(normalize-space(text()),'"+ Object + "')) and (local-name()='h3' or (local-name()='span' and contains(@class,'searchFirstCell')))]//ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::a[contains(normalize-space(text()),'"+SearchItem+"')]";
			WebDriverWaitForElement(xpath, 20).click();
			//remoteDriver.findElement(By.xpath(xpath)).click();
			System.out.println("Successfully searched "+Object+" record ("+SearchItem+")");
			AddLogToCustomReport("Successfully searched "+Object+" record ("+SearchItem+")", "Pass");
			return true;
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			xpath = "//div[@class='messageText' and contains(normalize-space(text()),'No matches found')]";
			try
			{
				if (remoteDriver.findElement(By.xpath(xpath)).isDisplayed())
				{
					System.out.println("Search could not find any result for "+Object+" record ("+SearchItem+"). The search result message displayed as (No matches found)");
					AddLogToCustomReport("Search could not find any result for "+Object+" record ("+SearchItem+"). The search result message displayed as (No matches found)", "Fail");
					throw new MPException("Search could not find any result for "+Object+" record ("+SearchItem+"). The search result message displayed as (No matches found)");
					//				return false;
				}
				else
				{
					System.out.println("Unable to search the "+Object+" record ("+SearchItem+")");
					AddLogToCustomReport("Unable to search the "+Object+" record ("+SearchItem+")", "Fail");
					throw new MPException("Unable to search the "+Object+" record ("+SearchItem+")");
					//				return false;
				}
			}
			catch(Exception e1)
			{
				System.out.println("Unable to search the "+Object+" record ("+SearchItem+") when xpath is:"+xpath);
				AddLogToCustomReport("Unable to search the "+Object+" record ("+SearchItem+") when xpath is:"+xpath, "Fail");
				e1.printStackTrace();
				throw new MPException("Unable to search the "+Object+" record ("+SearchItem+") when xpath is:"+xpath);
				//				return false;
			}

		}
	}
	
	public void ScrollToElement(WebElement element) throws Exception
	{
		
		try
		{
			((JavascriptExecutor)remoteDriver).executeScript("arguments[0].scrollIntoView();", element);
			
			 
			//((JavascriptExecutor)remoteDriver).executeScript("return document.all");
			
			System.out.println("Successfully scrolled untill element.");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to scroll until elemnt");
		}
	}
	
	/**
	 * 
	 * Author: 185584 
	 * Description: Searches any Salesforce Objects records in Global Search in Lightning version. 
	 * @param Object
	 * @param SearchItem
	 * @return
	 * @throws Exception
	 */
	public boolean GlobalSearch_LUI(String Object,String SearchItem) throws Exception
	{
		WaitForPageToLoad(15);
		//xpath = "//*[contains(@class,'item--search') and contains(@class,'slds-global-header')]/descendant::input[contains(@class,'combobox')][1]";
		xpath = "(//button[@aria-label='Search'][text()='Search...'])[1]";
		try
		{
			sfdc.PressESCKey();
			WaitForElement(xpath, 30);
			/*
			remoteDriver.findElement(By.xpath(xpath)).sendKeys(Keys.DELETE);;
			Thread.sleep(2000L);
			remoteDriver.findElement(By.xpath(xpath)).sendKeys(Object.trim());
			Thread.sleep(5000L);
			remoteDriver.findElement(By.xpath("//div[contains(@class,'slds-global-header') and contains(@class,'item--search')]/descendant::div[contains(@class,'slds-listbox_vertical')][1]/descendant::span[contains(@class,'slds-media__body')]/descendant::lightning-base-combobox-formatted-text[1]")).click();
			*/
			WebElement getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
			//ScrollToElement(getsingleWebelement);
			Thread.sleep(1000L);		
			getsingleWebelement.click();
			xpath = "(//input[@role='combobox'][contains(@data-value,'Search')])[1]";
			getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
			getsingleWebelement.click();
		
			String xp = "(//div[contains(@class,'combobox') or contains(@class,'dropdown')][contains(@class,'is-open')]//*[@role='option']//*[text()='"+Object.trim()+"'])[1]";
			WebElement obj_text = remoteDriver.findElement(By.xpath(xp));
			ScrollToElement(obj_text);
			Thread.sleep(2000);
			HighLight(obj_text);
			ClickByJSFocus(obj_text);
			Thread.sleep(2000L);

			//xpath = "//div[contains(@class,'slds-global-header') and contains(@class,'item--search')]/descendant::input[contains(@placeholder,'Search')][1]"; 
			xpath = "(//input[@placeholder='Search...'])[1]";
			//System.out.println("----------->"+remoteDriver.findElements(By.xpath(xpath)).size());
			remoteDriver.findElement(By.xpath(xpath)).click();
			remoteDriver.findElement(By.xpath(xpath)).sendKeys(SearchItem);
			
			Thread.sleep(3000L);
			
			//remoteDriver.findElement(By.xpath("//a[contains(@class,'SEARCH_OPTION')]/descendant::span[contains(@class,'mruSearchLabel')][1]")).click();
				
			
			sfdc.PressENTERKeyOnWindowAlert();
			//Thread.sleep(3000L);
			
			//remoteDriver.findElement(By.xpath("(//a[@title='Top Results'])[2]/ancestor::li[1]/following-sibling::li/descendant::a[@title='"+Object.trim()+"'][1]/descendant::span[normalize-space(text())='"+Object.trim()+"'][1]")).click();
			//Thread.sleep(2000L);
			//remoteDriver.findElement(By.xpath("(//ul[contains(@class,'lookup') and contains(@class,'list') and contains(@class,'visible')]/descendant::a/descendant::span[@title='"+SearchItem.trim()+"']/descendant::div[contains(@class,'OutputRichText')])[1]")).click();
			
			xpath = "(//div[contains(@class,'oneContent')][contains(@class,'active')]//tr//a//descendant-or-self::*[text()='"+SearchItem+"'])[1]";
			Thread.sleep(3000L);
			remoteDriver.findElement(By.xpath(xpath)).click();
			System.out.println("Successfully searched "+Object+" record ("+SearchItem+")");
			AddLogToCustomReport("Successfully searched "+Object+" record ("+SearchItem+")", "Pass");
			return true;
		}
		catch(Exception e1)
		{
				System.out.println("Unable to search the "+Object+" record ("+SearchItem+") when xpath is:"+xpath);
				AddLogToCustomReport("Unable to search the "+Object+" record ("+SearchItem+") when xpath is:"+xpath, "Fail");
				e1.printStackTrace();
				return false;
		}

		
	}
	

	
	/**
	 * @param RecordType_Text
	 * @return
	 * @Description Selects a radio button option in small OOB record type layout for LUI
	 * @throws Exception
	 */
	public boolean SelectRecordType_LUI(String RecordType_Text) throws Exception 
	{

		try
		{                    
			xpath = "//legend[text()='Select a record type'][1]/../following-sibling::div[1]/descendant::*[(local-name()='div' or local-name()='span') and contains(normalize-space(text()),'"+RecordType_Text+"')][1]";
			remoteDriver.findElement(By.xpath(xpath)).click();
			System.out.println("Selected the record type ("+RecordType_Text+") as supplied");
			AddLogToCustomReport("Selected the record type ("+RecordType_Text+") as supplied", "Pass");
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to select the record type ("+RecordType_Text+"). please check xpath("+xpath+")","Fail");
			System.out.println("Unable to select the record type ("+RecordType_Text+"). please check xpath("+xpath+")");
			return false;
		}
	}



	public void PressCTRL_T_Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_T);
			robot.keyRelease(KeyEvent.VK_T);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			System.out.println("Pressed Control+T Key.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to press CTRL+T");           

		}

	}
	public void PressCTRL_TAB_Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			System.out.println("Pressed Control+TAB Key.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to press CTRL+TAB");           

		}

	}
	
	//Index Starts with 0, 1 , so on
	public void Switch_To_Window_By_Index(int Index) throws Exception
	{
		try 
		{
			ArrayList<String> tabs2 = new ArrayList<String> (remoteDriver.getWindowHandles());
			remoteDriver.switchTo().window(tabs2.get(Index));

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to switch to window.");      

		}

	}


	/**
	 * @author Cognizant
	 * @param Object
	 * @param SearchItem
	 * @return true if search result is found else return false
	 * @Description Search any salesforce record from Sidebar search
	 * @throws Exception
	 */
	public boolean SideBarSearch(String Object,String SearchItem) throws Exception
	{
		WaitForPageToLoad(15);
		xpath = "//select[contains(@title,'Search')][1]";
		try
		{

			Select s = new Select(remoteDriver.findElement(By.xpath(xpath)));
			s.selectByVisibleText(Object);
			remoteDriver.findElement(By.xpath("//input[contains(@class,'search') and @type='text'][1]")).clear();
			remoteDriver.findElement(By.xpath("//input[contains(@class,'search') and @type='text'][1]")).sendKeys(SearchItem);
			Thread.sleep(1000L);
			remoteDriver.findElement(By.xpath("//input[contains(@class,'search') and @type='text'][1]")).sendKeys(Keys.ENTER);
			Thread.sleep(3000L);
			//WaitForPageToLoad(30);
			xpath = "//*[(contains(normalize-space(text()),'"+ Object + "')) and (local-name()='h3' or (local-name()='span' and contains(@class,'searchFirstCell')))]//ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::a[contains(normalize-space(text()),'"+SearchItem+"')]";
			WebDriverWaitForElement(xpath, 20).click();
			System.out.println("Successfully searched "+Object+" record ("+SearchItem+")");
			AddLogToCustomReport("Successfully searched "+Object+" record ("+SearchItem+")", "Pass");
			return true;
		}
		catch(Exception e)
		{
			AddLogToCustomReport("Unable to search the item ("+SearchItem+") against object ("+Object+") from Sidebar Search.", "Fail");
			System.out.println("Unable to search the item ("+SearchItem+") against object ("+Object+") from Sidebar Search.");
			return false; 
		}
	}


	/**
	 * @author 185584
	 * @Description When search results could be more than one with exact match
	 * @param ObjectName
	 * @param SearchItem
	 * @param TargetColumn
	 * @param KeyColumn
	 * @param KeyColumnValue
	 * @return true if search result is found, else return flase
	 * @throws Exception
	 */
	public boolean SideBarSearch(String ObjectName,String SearchItem, String TargetColumn,String KeyColumn,String KeyColumnValue) throws Exception
	{

		try
		{
			xpath = "//select[contains(@title,'Search')][1]";
			Select s = new Select(remoteDriver.findElement(By.xpath(xpath)));
			s.selectByVisibleText(ObjectName);
			remoteDriver.findElement(By.xpath("//input[contains(@class,'search') and @type='text'][1]")).clear();
			remoteDriver.findElement(By.xpath("//input[contains(@class,'search') and @type='text'][1]")).sendKeys(SearchItem);
			Thread.sleep(1000L);
			remoteDriver.findElement(By.xpath("//input[contains(@class,'search') and @type='text'][1]")).sendKeys(Keys.ENTER);
			Thread.sleep(3000L);
			//WaitForPageToLoad(30);
			xpath = "//*[(contains(normalize-space(text()),'"+ ObjectName + "')) and (local-name()='h3' or (local-name()='span' and contains(@class,'searchFirstCell')))]//ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::a[contains(normalize-space(text()),'"+SearchItem+"')]";
			Thread.sleep(2000L);        

			String xpath_KeyColumnPosition ="",xpath_TargetColumnPosition="";

			//System.out.println("TagName is: "+remoteDriver.findElement(By.xpath("//*[normalize-space(text())='"+ObjectName+"'][local-name()='h3' or local-name()='h1'][1]")).getTagName());
			//WebElement test = remoteDriver.findElement(By.xpath("//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]"));
			//System.out.println(test.getText());

			//System.out.println("TagName is: "+remoteDriver.findElement(By.xpath("//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]")).getTagName());


			if (remoteDriver.findElement(By.xpath("//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]")).getTagName().equalsIgnoreCase("h3"))
			{
				xpath = "//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]";
				xpath_TargetColumnPosition = xpath + "//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]/ancestor-or-self::div[@class='pbHeader'][1]/following-sibling::div[@class='pbBody'][1]/descendant-or-self::tr[@class='headerRow'][1]/descendant-or-self::*[normalize-space(text())='"+TargetColumn+"']/ancestor-or-self::th[1]/preceding-sibling::th";
				xpath_KeyColumnPosition = xpath +"//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]/ancestor-or-self::div[@class='pbHeader'][1]/following-sibling::div[@class='pbBody'][1]/descendant-or-self::tr[@class='headerRow'][1]/descendant-or-self::*[normalize-space(text())='"+KeyColumn+"']/ancestor-or-self::th[1]/preceding-sibling::th";

			}
			else if (remoteDriver.findElement(By.xpath("//*[normalize-space(text())='"+ObjectName+"'][local-name()='h3' or local-name()='h1'][1]")).getTagName().equalsIgnoreCase("h1"))
			{
				//need to update for Go To List page if there is any

			}	

			//System.out.println("xpath is: "+xpath);	
			//System.out.println("xpath_KeyColumnPosition is: "+xpath_KeyColumnPosition);
			//System.out.println("xpath_TargetColumnPosition is: "+xpath_TargetColumnPosition);


			Integer KeyColumnPosition = remoteDriver.findElements(By.xpath(xpath_KeyColumnPosition)).size()+1; 

			//System.out.println("KeyColumnPosition:"+KeyColumnPosition);



			Integer CountOfSearchItems =  remoteDriver.findElements(By.xpath("//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]/ancestor-or-self::div[@class='pbHeader'][1]/following-sibling::div[@class='pbBody'][1]/descendant-or-self::tr")).size() - 1;  
			//System.out.println("Count Of Search Result Items:"+CountOfRLItems);
			Integer TargetColumnPosition = remoteDriver.findElements(By.xpath(xpath_TargetColumnPosition)).size() + 1;
			System.out.println("TargetColumnPosition:"+TargetColumnPosition);

			System.out.println("KeyColumnPosition"+KeyColumnPosition +" CountOfRLItems:"+CountOfSearchItems +" TargetColumnPosition:"+TargetColumnPosition);
			Integer RowPositionOfKeyColumnValue;

			for(int i=2;i<=CountOfSearchItems;i++)
			{
				if (remoteDriver.findElement(By.xpath("//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]/ancestor-or-self::div[@class='pbHeader'][1]/following-sibling::div[@class='pbBody'][1]/descendant-or-self::tr["+i+"]/descendant-or-self::*[local-name()='th' or local-name()='td']["+KeyColumnPosition+"]")).getText().trim().equals(KeyColumnValue))
				{

					remoteDriver.findElement(By.xpath("//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]/ancestor-or-self::div[@class='pbHeader'][1]/following-sibling::div[@class='pbBody'][1]/descendant-or-self::tr["+i+"]/descendant-or-self::*[local-name()='th' or local-name()='td']["+TargetColumnPosition+"]")).click();

					System.out.println("Successfully clicked on ("+TargetColumn+") for related list item ("+KeyColumnValue+") in the ("+ObjectName+")related list");
					AddLogToCustomReport("Successfully clicked on ("+remoteDriver.findElement(By.xpath("//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]//span[contains(normalize-space(text()),'"+ObjectName+"')][1]/ancestor-or-self::*[local-name()='h3' or local-name()='h1'][1]/ancestor-or-self::div[@class='pbHeader'][1]/following-sibling::div[@class='pbBody'][1]/descendant-or-self::tr["+i+"]/descendant-or-self::*[local-name()='th' or local-name()='td']["+TargetColumnPosition+"]")).getText().trim()+") for related list item ("+KeyColumnValue+") in the ("+ObjectName+")related list", "Pass");
					return true;
					//RowPositionOfKeyColumnValue = 
				}
				System.out.println("No Match");
			}

			/* 
 	    Integer KeyColumnValueRowPosition = remoteDriver.findElements(By.xpath(xpath_KeyColumnPosition)).size() + 1;
 		System.out.println("KeyColumnPosition:"+KeyColumnPosition);
 		System.out.println("CountOfRLItems"+CountOfRLItems);
			 */

			System.out.println("Unable to click on the element in the ("+ObjectName+") related list.");
			AddLogToCustomReport("Unable to click on the element in the ("+ObjectName+") related list.", "Fail");
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Unable to click on the element in the ("+ObjectName+") related list when xpath is:"+xpath);
			AddLogToCustomReport("Unable to click on the element in the ("+ObjectName+") related list when xpath is:"+xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @param NameListView
	 * @Description Choose a view in any view for any object in Lightning UI
	 * @throws Exception
	 */
	public void ChooseView_LUI(String NameListView) throws Exception
	{
		try {
			remoteDriver.findElement(By.xpath("//a[@title='Select List View'][1]")).click();
			Thread.sleep(1000L);
			remoteDriver.findElement(By.xpath("(//a[@role='option'][1]/descendant::span[text()='"+NameListView+"'])[1]")).click();
			AddLogToCustomReport("Selected the view ("+NameListView+") successfully.", "Pass");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to select the view ("+NameListView+")");
			AddLogToCustomReport("Unable to select the view ("+NameListView+")", "Fail");
		}

	}

	/**
	 * @param NameListView
	 * @Description Choose a view in any view for any object in Classic
	 * @throws Exception
	 */
	public void ChooseView(String NameListView) throws Exception
	{
		try {
			Select s = new Select(remoteDriver.findElement(By.xpath("(//select[@title='View:'])[1]")));
			s.selectByVisibleText(NameListView);

			Thread.sleep(1000L);
			AddLogToCustomReport("Selected the view ("+NameListView+") successfully.", "Pass");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to select the view ("+NameListView+")");
			AddLogToCustomReport("Unable to select the view ("+NameListView+")", "Fail");
		}

	}

	/**
	 * @author Cognizant
	 * @Description Clicking on Details tab against the record in Lightning. 
	 * @throws Exception
	 */
	synchronized public void ClickONSubTab(String SubTabName) throws Exception
	{
		try
		{
			Thread.sleep(1000L);
			String xp = xp_lui_common_part + "//*[local-name()='ul' or local-name()='div'][@role='tablist']/descendant::li/descendant-or-self::*[local-name()='a' or local-name()='span'][normalize-space(text())='"+SubTabName.trim()+"'][1]";
			WaitForElement(xp, 30);
			System.out.println("xp:"+xp);
			Thread.sleep(1000L);
			remoteDriver.findElement(By.xpath(xp)).click();
			AddLogToCustomReport("Clicked on Sub tab ("+SubTabName+") against the record.", "Pass");
			System.out.println("Clicked on Sub tab ("+SubTabName+") against the record.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to find the Sub Tab ("+SubTabName+") for clicking.", "Fail");
			System.out.println("Unable to find the Sub Tab ("+SubTabName+") for clicking.");

		}
	}

	/**
	 * @param wheelAmt
	 * @Description positive value scrolls down, negative value scrolls up. example value 1,2,3. This is useful to handle picklist and lookup in inline edit page of lightening ui
	 * @throws Exception
	 */
	public void ScrollMouseWheelByRobot(int wheelAmt, WebElement elm) throws Exception
	{
		try {

			Robot robot = new Robot();

			Point coordinates = elm.getLocation();
			//Robot robot = new Robot();
			robot.mouseMove(coordinates.getX(),coordinates.getY());
			robot.mouseWheel(wheelAmt);
			

		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void PressPageUPKey() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_PAGE_UP);
			robot.keyRelease(KeyEvent.VK_PAGE_UP);

		}
		catch(Exception e)
		{
			e.printStackTrace();

		}

	}

	public void PressPageDownKey() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);

		}
		catch(Exception e)
		{
			e.printStackTrace();

		}

	}
	/**
	 * @param TabName
	 * @Description This is for clicking on any tab Details/Related/Activity tab in LUI
	 * @throws Exception
	 */
	public void ClickONStandardTab_LUI(String TabName) throws Exception
	{
		try
		{
			Thread.sleep(1000L);
			//WaitForElement("//ul[normalize-space(@class)='optionContainer'][1]/li[2]/a[1]", 30);
			//remoteDriver.executeScript("arguments[0].scrollIntoView();", remoteDriver.findElement(By.xpath("//span[@class='title' and text()='"+TabName+"'][1]")));
			scrollPage("Up", 1);

			remoteDriver.findElement(By.xpath("//span[@class='title' and text()='"+TabName+"'][1]")).click();
			AddLogToCustomReport("Clicked on "+TabName+" tab against the record.", "Pass");
			System.out.println("Clicked on Details tab against the record.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to find the "+TabName+" tab for clicking.", "Fail");
			System.out.println("Unable to find the "+TabName+" tab for clicking.");

		}
	}


	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @DisplayMode Edit page
	 * @return Entire text of the Error message displayed on the edit page
	 * @throws Exception
	 * @Description Reads the entire text of the error message displayed on the edit page and returns the same on success and returns blank value on failure
	 * @Date Aug 7, 2014
	 */
	public String GetPageLevelErrorMessage() throws Exception 
	{
		String errorMessage = "";
		try
		{
			errorMessage = remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep']")).getText().trim();
			AddLogToCustomReport("The page level error message displayed as ("+errorMessage+")", "Pass");
			System.out.println("The page level error message displayed as ("+errorMessage+")");
			return errorMessage;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Could not find any page level error message", "Fail");
			System.out.println("Could not find any page level error message");
			return errorMessage;
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param Expected partial string of the page level error message to be verified
	 * @return boolean
	 * @DisplayMode Edit page 
	 * @throws Exception
	 * @Description Verifies if the text message/error message displayed on the page level error message contains the partial text specified in the parameter 
	 * @Date Aug 7, 2014
	 */
	public boolean VerifyPageLevelErrorMessage(String ErrorMessage) throws Exception 
	{
		//xpath = "//div[normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep']";
		xpath = "//div[(normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep') or (normalize-space(@class)='messageText')]";
		//xpath = "//div[contains(@class,'pageLevelErrors')][1]/descendant::li[text()='"+ErrorMessage+"'][1]";
		try
		{
			WebDriverWaitForElement(xpath,15);
			if (remoteDriver.findElement(By.xpath(xpath)).getText().trim().contains(ErrorMessage.trim()))
			{
				AddLogToCustomReport("Successfully verified the page level error message ("+ErrorMessage+")", "Pass");
				System.out.println("Successfully verified the page level error message ("+ErrorMessage+")");
				return true;
			}
			else
			{
				AddLogToCustomReport("Unable to verify the page level error message when actual message is ("+remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep']")).getText().trim()+") and expected message is ("+ErrorMessage+")", "Fail");
				System.out.println("Unable to verify the page level error message when actual message is ("+remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep']")).getText().trim()+") and expected message is ("+ErrorMessage+")");
				return false;
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to verify the page level error message when actual message is ("+remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep']")).getText().trim()+") and expected message is ("+ErrorMessage+")", "Fail");
			System.out.println("Unable to verify the page level error message when actual message is ("+remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep']")).getText().trim()+") and expected message is ("+ErrorMessage+")");
			return false;
		}
	}

	/**
	 * @param ErrorMessage
	 * @return
	 * @Description Verifies the page level errors that appears on top of the page
	 * @throws Exception
	 */
	public boolean VerifyPageLevelErrorMessage_LUI(String ErrorMessage) throws Exception 
	{
		//xpath = "//div[normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep']";
		//xpath = "//div[(normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep') or (normalize-space(@class)='messageText')]";
		//xpath = "(//div[contains(@class,'error')][@role='dialog']//strong[text()])[1]";
		xpath = "//div[contains(@class,'fieldLevelErrors')][1]//strong[text()][1]";
		try
		{
			WebDriverWaitForElement(xpath,15);
			if (remoteDriver.findElement(By.xpath(xpath)).getText().trim().contains(ErrorMessage.trim()))
			{
				
				//This is just to close the error dialog
				String xp = "(//div[contains(@class,'')][contains(@class,'open')][contains(@class,'active')][contains(@class,'popover')]//*[@data-key='close'][contains(@class,'icon')])[1]";
				remoteDriver.findElement(By.xpath(xp)).click();
				Thread.sleep(2000L);
				AddLogToCustomReport("Successfully verified the page level error message ("+ErrorMessage+")", "Pass");
				System.out.println("Successfully verified the page level error message ("+ErrorMessage+")");
				
				return true;
			}
			else
			{
				AddLogToCustomReport("Unable to verify the page level error message when actual message is ("+remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep']")).getText().trim()+") and expected message is ("+ErrorMessage+")", "Fail");
				System.out.println("Unable to verify the page level error message when actual message is ("+remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep']")).getText().trim()+") and expected message is ("+ErrorMessage+")");
				return false;
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to verify the page level error message when actual message is ("+remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep']")).getText().trim()+") and expected message is ("+ErrorMessage+")", "Fail");
			System.out.println("Unable to verify the page level error message when actual message is ("+remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='pbError' and normalize-space(@id)='errorDiv_ep']")).getText().trim()+") and expected message is ("+ErrorMessage+")");
			return false;
		}
	}


	/**
	 * @return
	 * @Description Read the page level error message from Lightning UI and return the value
	 * @throws Exception
	 */
	public String GetPageLevelErrorMessage_LUI() throws Exception 
	{
		xpath = "//div[contains(@class,'pageLevelErrors')][1]/descendant::li[text()][1]";
		try
		{
			WebDriverWaitForElement(xpath,15);
			String message = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
			AddLogToCustomReport("Successfully read the page level error message ("+message+")", "Pass");
			System.out.println("Successfully read the page level error message ("+message+")");
			return message;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to read the page level error message.", "Fail");
			System.out.println("Unable to verify the page level error message");
			return "";
		}
	}

	/**
	 * @author Cognizant
	 * @Description Select the parent when there is only one window opened.This is very useful when you opened multiple window like popup and upon selection of the value in the lookup the popup gets closed. And now you want to switch back to the parent window. 
	 * @return true when successfully selected the parent window else return false.
	 * @throws Exception
	 */
	public  boolean SelectParentWindow() throws Exception
	{

		try
		{
			Set<String> s = remoteDriver.getWindowHandles(); 
			Iterator<String> ite = s.iterator(); 
			while(ite.hasNext()) 
			{ 
				String popup = ite.next(); 
				System.out.println("popup"+popup);
				remoteDriver.switchTo().window(popup); 
				System.out.println("Window Title is: "+remoteDriver.getTitle());
				if(remoteDriver.getTitle().length()>0)
					return true;
				else
					return false;

			}

			return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to Select the parent window.", "Fail");
			System.out.println("Exception in SelectParentWindow function.");
			return false;
		}
	}

	/**
	 * @author Cognizant
	 * @Description Selects popup window. This is best in use when there are just two open window including main window. If you have more than two window then this function will not work. Please use SelectWindow function in such scenario
	 * @return Boolean
	 * @throws Exception
	 */
	public  boolean SelectPopupWindow() throws Exception
	{		
		try
		{
			int c=0;
			String mainwindow = remoteDriver.getWindowHandle();   
			System.out.println("mainwindow:"+mainwindow);

			Set<String> s = remoteDriver.getWindowHandles(); 
			Iterator<String> ite = s.iterator(); 
			while(ite.hasNext()) 
			{ 
				String popup = ite.next(); 
				System.out.println("inside SelectWindow:"+popup);
				if(!popup.equalsIgnoreCase(mainwindow))
				{ 
					remoteDriver.switchTo().window(popup); 
					System.out.println("Window Title is: "+remoteDriver.getTitle());
					System.out.println("window id:"+remoteDriver.getWindowHandle());
					if(remoteDriver.getWindowHandle().trim().equalsIgnoreCase(popup.trim()))
					{
						return true;

					}
					else
					{
						c = c + 1;
					}
				}
			}
			if (c>0)
			{
				AddLogToCustomReport("Unable to find the popup window", "Fail");
				System.out.println("Unable to find the popup window");
				return false;
			}
			else
			{
				AddLogToCustomReport("Successfully selected the popup window","Pass");
				System.out.println("Successfully selected the popup window");
				return true;

			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Exception:SelectPopupWindow");
			AddLogToCustomReport("Unable to select the popup window", "Fail");
			return false;
		}
	}


	/**
	 * @author Sourav Mukherjee
	 * @Param UniqueStringinWindowTitle
	 * @return boolean
	 * @throws Exception
	 * @Description Selects the window opened by Selenium Webdriver.
	 * @Date Aug 7, 2014
	 */
	public  boolean SelectWindow(String UniqueStringinWindowTitle) throws Exception
	{

		try
		{
			int c=0;
			String mainwindow = remoteDriver.getWindowHandle();   
			System.out.println("mainwindow:"+mainwindow);

			Set<String> s = remoteDriver.getWindowHandles(); 
			Iterator<String> ite = s.iterator(); 
			while(ite.hasNext()) 
			{ 
				String popup = ite.next(); 
				System.out.println("inside SelectWindow:"+popup);
				if(!popup.equalsIgnoreCase(mainwindow))
				{ 
					remoteDriver.switchTo().window(popup); 
					System.out.println("Window Title is: "+remoteDriver.getTitle());
					if(remoteDriver.getWindowHandle().contains(popup))
					{
						//mainwindow = null;
						//s=null;
						return true;

					}
					else
					{
						c = c + 1;
					}
				}
			}
			if (c>0)
			{
				AddLogToCustomReport("Unable to find the window containing title ("+UniqueStringinWindowTitle+")", "Fail");
				System.out.println("Unable to find the window containing title ("+UniqueStringinWindowTitle+")");
				return false;
			}
			else
			{
				AddLogToCustomReport("Successfully selected the window containing title ("+UniqueStringinWindowTitle+")", "Pass");
				System.out.println("Successfully selected the window containing title ("+UniqueStringinWindowTitle+")");
				return true;

			}
			/*	
		Set <String> handles = remoteDriver.getWindowHandles();
		Iterator<String> it = handles.iterator();
		//iterate through your windows
		while (it.hasNext())
		{
			//String parent = it.next();
			String win = it.next();
			System.out.println("win:"+win);
			remoteDriver.switchTo().window(win);
			if (remoteDriver.getTitle().contains(UniqueStringinWindowTitle))
			{
				System.out.println("The title of the Selected window is:"+remoteDriver.getTitle());
				return true;
			}

		}
		System.out.println("Could not find the window with title containing "+UniqueStringinWindowTitle);
		return false;
			 */
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Exception in SelectWindow Function while trying to select the window having title containing  "+UniqueStringinWindowTitle);
			return false;
		}
	}


	/*
	 * @Author: Sourav
	 * 
	 * Whenever you call this function CloseWindow(), You must call SelectWindow() 
	 * function after this function call to continue working on the next window, 
	 * otherwise the focus to the next workable window will be lost. 
	 * 
	 */
	/**
	 * @author Sourav Mukherjee
	 * @Param UniqueStringinWindowTitle
	 * @return boolean
	 * @throws Exception
	 * @Description Whenever you call this function CloseWindow(), You must call SelectWindow() function after this function call to continue working on the next window, otherwise the focus to the next workable window will be lost.  
	 * @Date Aug 7, 2014
	 */
	public boolean CloseWindow(String UniqueStringinWindowTitle) throws Exception
	{
		try
		{

			String AlreadySelectedWindow = remoteDriver.getWindowHandle();   
			System.out.println("AlreadySelectedWindow:"+AlreadySelectedWindow);

			Set<String> s = remoteDriver.getWindowHandles(); 
			Iterator<String> ite = s.iterator(); 
			while(ite.hasNext()) 
			{ 
				String popup = ite.next(); 
				System.out.println("inside closewindow:"+popup);
				if(popup.equalsIgnoreCase(AlreadySelectedWindow))
				{ 
					remoteDriver.switchTo().window(popup).close(); 
					return true;
				}

			}
			System.out.println("Could not find the window with title containing "+UniqueStringinWindowTitle+" while trying to close.");
			return false;
		}catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Exception in CloseWindow Function while trying to close the window having title containing  "+UniqueStringinWindowTitle);
			return false;
		}
	}

	public void SwitchToChildTab() throws Exception
	{
		try
		{
			new Actions(remoteDriver).sendKeys(remoteDriver.findElement(By.tagName("html")), Keys.CONTROL).sendKeys(remoteDriver.findElement(By.tagName("html")),Keys.NUMPAD2).build().perform();
			System.out.println("Swithing to child tab is successful");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Swithing of Tab is unsuccessful");
		}
	}

	public void SwitchToParentTab() throws Exception
	{
		try
		{
			new Actions(remoteDriver).sendKeys(remoteDriver.findElement(By.tagName("html")), Keys.CONTROL).sendKeys(remoteDriver.findElement(By.tagName("html")),Keys.NUMPAD1).build().perform();
			System.out.println("Swithing to Parent tab is successful");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Swithing to Parent Tab is unsuccessful");
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param Partial text of the Title Of The Frame
	 * @return void
	 * @throws Exception
	 * @Description Selects the Frame by partial text of the title in a window opened by WebDriver
	 * @Date Aug 7, 2014
	 */
	public void SelectFrame(String TitleOfTheFrame) throws Exception
	{
		try 
		{
			remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("//frame[contains((@title),'"+TitleOfTheFrame+"')]")));

			System.out.println("Successfully selected the Frame having title ("+TitleOfTheFrame+")");
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Unable to select the Frame with title ("+TitleOfTheFrame+")");
		}
	}

	/**
	 * @author Cognizant
	 * @param TitleOfTheiFrame
	 * @Description Selects the iFrame by partial text of the title in a window opened by WebDriver
	 * @throws Exception
	 */
	public void SelectiFrame(String TitleOfTheiFrame) throws Exception
	{
		try 
		{
			remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("//iframe[contains((@title),'"+TitleOfTheiFrame+"')]")));

			System.out.println("Successfully selected the Frame having title ("+TitleOfTheiFrame+")");
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Unable to select the Frame with title ("+TitleOfTheiFrame+")");
		}
	}
	
	public void SwitchToDefaultContent() throws Exception
	{
		try 
		{
			remoteDriver.switchTo().defaultContent();

			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			
		}
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param FrameIndex to be selected. FrameIndex starts from zero.
	 * @return void
	 * @throws Exception
	 * @Description Selects the Frame by Index in a window opened by WebDriver
	 * @Date Aug 7, 2014
	 */
	public void SelectFrameByIndex(int FrameIndexStartsWithZero) throws Exception
	{
		try 
		{
			remoteDriver.switchTo().frame(FrameIndexStartsWithZero);

			System.out.println("Successfully selected the Frame by Index ("+FrameIndexStartsWithZero+")");
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Unable to select the Frame by inder ("+FrameIndexStartsWithZero+")");
		}
	}

	/**
	 * @Description Switches context to active iframe in any Ligntning page, please note defaultcontent should be used seperately in test case level once iframe actions are completed 
	 * @throws Exception
	 */
	public void SwitchToActiveLightningiFrame() throws Exception
	{
		try 
		{
			
			waitForVisibilityOfElement("//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::iframe");
			remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::iframe")));

			System.out.println("Successfully switched to active iframe of ligntning page.");
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Unable to switch to active iframe of ligntning page.");
		}
	}
	
	//Switching to iFrame when @name property contains a value vfFrameId
	public void SwitchTovFFrameID_SalesforceLightning() throws Exception
	{
		try 
		{
			String xp = "//iframe[contains(@name,'vfFrameId')]";
			WebDriverWaitForElement(xp,10);
			remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath(xp)));

			System.out.println("Successfully switched to iframe of ligntning page.");
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Unable to switch to vfFrameId in ligntning page.");
		}
	}

	//Switching to iFrame when @name property contains a value as supplied
		public void SwitchToiFrameID_NameContains(String NameContains) throws Exception
		{
			try 
			{
				String xp = "//iframe[contains(@name,'"+NameContains+"')]";
				WebDriverWaitForElement(xp,10);
				remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath(xp)));

				System.out.println("Successfully switched to iframe of ligntning page.");
			}
			catch(Exception e) 
			{
				e.printStackTrace();
				System.out.println("Unable to switch to iFrame in ligntning page.");
			}
		}

		
		//Switching to iFrame when @title property contains a value as supplied
		public void SwitchToiFrame_TitleContains(String TitleContains) throws Exception
		{
			try 
			{
				String xp = "//iframe[contains(@title,'"+TitleContains+"')]";
				WebDriverWaitForElement(xp,10);
				remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath(xp)));

				System.out.println("Successfully switched to iframe of ligntning page.");
			}
			catch(Exception e) 
			{
				e.printStackTrace();
				System.out.println("Unable to switch to iframe in ligntning page.");
			}
		}

		
	/**
	 * @author Cognizant
	 * @param RowIndex starts from 1
	 * @StartScreen The Queue details page showing added user list should be displayed before invoking this function
	 * @EndScreen User Details page is shown.
	 * @throws Exception if there is no user present/associated in requested rowindex inside the Queue
	 * @Description Clicks on the user name present inside the Queue as per requested row index
	 */
	public void ClickONQueueMember(int RowIndex) throws Exception  
	{
		try
		{
			remoteDriver.findElement(By.xpath("//th[normalize-space(text())='Name'][1]/ancestor-or-self::tr[1]/following-sibling::tr["+RowIndex+"]/th[1]/a[1]")).click();
			AddLogToCustomReport("Clicked on the user link ("+remoteDriver.findElement(By.xpath("//th[normalize-space(text())='Name'][1]/ancestor-or-self::tr[1]/following-sibling::tr["+RowIndex+"]/th[1]/a[1]")).getText()+") being a Queue member.", "Pass");
			System.out.println("Clicked on the user link ("+remoteDriver.findElement(By.xpath("//th[normalize-space(text())='Name'][1]/ancestor-or-self::tr[1]/following-sibling::tr["+RowIndex+"]/th[1]/a[1]")).getText()+") being a Queue member.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to click on the user link present in row ("+RowIndex+") inside the Queue","Pass");
			System.out.println("Unable to click on the user link present in row ("+RowIndex+") inside the Queue");

		}
	}

	/**
	 * @author Cognizant
	 * @param RowIndex starts from 1
	 * @return the name of the user present inside Queue 
	 * @StartScreen The Queue details page showing added user list should be displayed before invoking this function
	 * @EndScreen Same as startscreen, no navigation happens by the automation
	 * @throws Exception if there is no user present/associated in requested rowindex inside the Queue
	 * @Description Copies the user name present inside the Queue as per requested row index
	 */
	public String GetQueueMember(int RowIndex) throws Exception  
	{
		String QMember = "";
		try
		{
			QMember = remoteDriver.findElement(By.xpath("//th[normalize-space(text())='Name'][1]/ancestor-or-self::tr[1]/following-sibling::tr["+RowIndex+"]/th[1]/a[1]")).getText().trim();
			AddLogToCustomReport("Copied the user name present in row ("+RowIndex+") inside the Queue.","Pass");
			System.out.println("Clicked on the user link ("+remoteDriver.findElement(By.xpath("//th[normalize-space(text())='Name'][1]/ancestor-or-self::tr[1]/following-sibling::tr["+RowIndex+"]/th[1]/a[1]")).getText()+") being a Queue member.");
			return QMember;

		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to copy the username present inside Queue","Pass");
			System.out.println("Unable to copy the username present inside Queue");
			return QMember;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return void
	 * @throws Exception
	 * @Description Clicks on Yes button on the Alert opened by WebDriver
	 * @Date Aug 7, 2014
	 */
	public void AlertClickYes() throws Exception
	{
		try 
		{
			Alert alert = remoteDriver.switchTo().alert();
			alert.accept();	
			AddLogToCustomReport("Clicked on Yes button in the alert.", "Pass");
			System.out.println("Clicked on Yes button in the alert.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to click on Yes button in the Alert", "Fail");
			System.out.println("Unable to click on Yes button in the Alert");
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return void
	 * @throws Exception
	 * @Description Clicks on No button on the Alert opened by WebDriver
	 * @Date Aug 7, 2014
	 */
	public void AlertClickNo() throws Exception
	{
		try 
		{
			Alert alert = remoteDriver.switchTo().alert();
			alert.dismiss();

			alert.accept();
			alert.dismiss();
			alert.sendKeys("abcd");
			alert.getText();
			AddLogToCustomReport("Clicked on No button in the alert.", "Pass");
			System.out.println("Clicked on No button in the alert.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to click on No button in the Alert", "Fail");
			System.out.println("Unable to click on No button in the Alert");
		}

	}


	/**
	 * @author Sourav Mukherjee
	 * @Param NA
	 * @return void
	 * @throws Exception
	 * @Description Press TAB Key using Robot Class
	 * @Date Jan, 2015
	 */
	public void PressTABKeyOnWindowAlert() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			AddLogToCustomReport("Pressed Tab Key on Window Alert.", "Pass");
			System.out.println("Pressed Tab Key on Window Alert.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to press Tab key on Window Alert", "Fail");
			System.out.println("Unable to press Tab key on Window Alert");
		}

	}
	public void PressF12Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_F12);
			robot.keyRelease(KeyEvent.VK_F12);

		}
		catch(Exception e)
		{
			e.printStackTrace();

		}

	}

	public void PressCTRL_SHIFT_CKey() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SHIFT);
			robot.keyPress(KeyEvent.VK_C);

			robot.keyRelease(KeyEvent.VK_C);
			robot.keyRelease(KeyEvent.VK_SHIFT);
			robot.keyRelease(KeyEvent.VK_CONTROL);

		}
		catch(Exception e)
		{
			e.printStackTrace();

		}

	}
	public void PressCTRL_P_Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_P);
			robot.keyRelease(KeyEvent.VK_P);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			System.out.println("Pressed Control+P Key.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to press CTRL+P");		

		}

	}


	public void PressALT_P_Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_ALT);
			robot.keyPress(KeyEvent.VK_P);
			robot.keyRelease(KeyEvent.VK_P);
			robot.keyRelease(KeyEvent.VK_ALT);
			System.out.println("Pressed ALT+P Key.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to press ALT+P");		

		}

	}


	public void PressALT_S_Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_ALT);
			robot.keyPress(KeyEvent.VK_S);
			robot.keyRelease(KeyEvent.VK_S);
			robot.keyRelease(KeyEvent.VK_ALT);
			System.out.println("Pressed ALT+S Key.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to press ALT+S");		

		}

	}

	public void PressALT_N_Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_ALT);
			robot.keyPress(KeyEvent.VK_N);
			robot.keyRelease(KeyEvent.VK_N);
			robot.keyRelease(KeyEvent.VK_ALT);
			System.out.println("Pressed ALT+N Key.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to press ALT+N");		

		}

	}
	/**
	 * @author Sourav Mukherjee
	 * @Param NA
	 * @return void
	 * @throws Exception
	 * @Description Press ENTER Key using Robot Class
	 * @Date Jan, 2015
	 */
	public void PressENTERKeyOnWindowAlert() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			AddLogToCustomReport("Pressed ENTER Key on Window Alert.", "Pass");
			System.out.println("Pressed ENTER Key on Window Alert.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to press ENTER key on Window Alert", "Fail");
			System.out.println("Unable to press ENTER key on Window Alert");
		}

	}


	/**
	 * @throws Exception
	 */
	public void PressESCKey() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_ESCAPE);
			robot.keyRelease(KeyEvent.VK_ESCAPE);
			//AddLogToCustomReport("Pressed ESCAPE Key.", "Pass");
			System.out.println("Pressed ESCAPE Key.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//AddLogToCustomReport("Unable to press ESCAPE key on Window Alert", "Fail");
			System.out.println("Unable to press ESCAPE key.");
		}

	}

	/**
	 * @author Sourav Mukherjee
	 * @Param message to be verified 
	 * @return String
	 * @throws Exception
	 * @Description Verifies the text message displayed in the standard alert message
	 * @Date Jan, 2015
	 */
	public String VerifyAlertMessage(String message) throws Exception
	{
		try 
		{
			Alert alert = remoteDriver.switchTo().alert();
			String retrievedMessage = alert.getText().trim();
			if(retrievedMessage.contains(message.trim()))
			{
				AddLogToCustomReport("Successfully verified the message in the alert", "Pass");
				System.out.println("Successfully verified the message in the alert.");
				return "Pass";
			}
			AddLogToCustomReport("Unable to retrieve the message from the alert", "Fail");
			System.out.println("Unable to retrieve the message from the alert");
			return "Fail";
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to retrieve the message from the alert", "Fail");
			System.out.println("Unable to retrieve the message from the alert");
			return "Fail";
		}

	}

	/**
	 * @author Sourav Mukherjee
	 * @Param RelatesLisName 
	 * @DisplayMode View Details page showing related list
	 * @return Entire "Pass" if Go to list hyperlink is clicked successfully and returns blank if the hyperlink is absent.
	 * @throws Exception
	 * @Description Clicks on the Go to list hyperlink which is present under a particular related list.
	 * @Date Jan 13, 2015
	 */
	public String ClickOnGoToListLink(String RelatedListName) throws Exception 
	{

		try
		{
			remoteDriver.findElement(By.xpath("//h3[normalize-space(text())='"+RelatedListName+"']/ancestor-or-self::div[normalize-space(@class)='pbHeader']/following-sibling::div[normalize-space(@class)='pbBody'][1]/div[normalize-space(@class)='pShowMore'][1]/a[contains(normalize-space(text()),'Go to list')]")).click();
			System.out.println("Successfully clicked on Go to List hyperlink.");
			return "Pass";
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find the (Go to List) hyperlink.");
			return "";

		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param WebElement
	 * @return void
	 * @throws Exception
	 * @Description Clicks on the WebElement by using JavaScript
	 * @Date Aug 7, 2014
	 */
	public void ClickWebElementByJS(WebElement weElement) 
	{

		// Scroll the browser to the element's Y position
		((JavascriptExecutor) remoteDriver).executeScript("window.scrollTo(0,"
				+ weElement.getLocation().y + ")");
		// Click the element
		int iAttempts = 0;
		while (iAttempts < 5) {
			try {
				weElement.click();
				break;
			} catch (Exception e) {
			}
			iAttempts++;
		}

	}

	/**
	 * @author Sourav Mukherjee
	 * @Param 1. xpath of the element. 2. Waiting Time in Second
	 * @return boolean
	 * @throws Exception
	 * @Description Waits for the specified time until the webelemnt is available to WebDriver
	 * @Date Aug 7, 2014
	 */
	public boolean WaitForElement(String xpath, long waitingTimeinsec) throws Exception
	{
		try {
			
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
			List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
			if (myDynamicElement.size() > 0)
			{
				System.out.println("Success: WaitForElement->Number of Element present is: "+myDynamicElement.size() +"Xpath is:"+xpath);
				return true;
			}
			else
			{
				System.out.println("Unsuccess: WaitForElement->Number of Element present is: "+myDynamicElement.size()+"Xpath is:"+xpath);
				return false;
			} 
		}
		catch(NoSuchElementException e)
		{
			e.printStackTrace();
			System.out.println("Exception inside WaitForElement:"+xpath);
			return false;
		}
	}
	
	public void WaitForElementToDisappear(String xpath, long TimeOutinSec) throws Exception
	{
		try {
			
			boolean flag = true;
			int time = 0;
			
			while(flag)
			{
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2)); //This is just to wait for 2 sec for findElements method for a match
				List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
				if (myDynamicElement.size() > 0)
				{
					Thread.sleep(2000L);
					time = time + 2;
					System.out.println("Element still found. waiting to disappear...");
					if(time > TimeOutinSec)
					{
						System.out.println("The element did not disappear within the specified time. Exit from Waiting time...");
						break;
					}
					
				
				}
				else
				{
					System.out.println("Element disapeared successfully");
					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
			e.printStackTrace();
			System.out.println("Exception inside WaitForElementToDisappear:"+xpath);
			
		}
	}
	
	
	/**
	 * @author Sourav Mukherjee
	 * @Param 1. xpath of the element, 2. Time specified in second
	 * @return WebElement
	 * @throws Exception
	 * @Description Waits for the specified time until the webelemnt is available to WebDriver. This uses WebDriverWait class 
	 * @Date Aug 7, 2014
	 */
	public WebElement WebDriverWaitForElement(String xpath, long waitingTimeinsec) throws Exception
	{
		WebElement element=null;
		try {
			if(remoteDriver==null)
			{
				remoteDriver = (RemoteWebDriver)myWD;
			} 
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
			return remoteDriver.findElement(By.xpath(xpath));
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec");
			AddLogToCustomReport("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec", "Fail");
			return null;

		}
	}
	
	//Waits for the element for approximately 60 second.
	//This will never throw NoSuchElementException even though element is not found after 1 minute
	public WebElement WebDriverWaitForElement(String xpath) throws Exception
	{
		WebElement element=null;
		try {
			if(remoteDriver==null)
			{
				remoteDriver = (RemoteWebDriver)myWD;
			} 
			long localtimecounter = 0;
			while (true)
			{
				if (remoteDriver.findElements(By.xpath(xpath)).size() > 0)
				{
					return element;					
				}
				else if (localtimecounter == 100)
				{
					System.out.println("Count not find the element after waiting for Approx 1 minute");
					return null;
				}
				else
				{
					Thread.sleep(1000L);
					localtimecounter = localtimecounter + 1;
				}
				
			}
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Got an unception! Please check...");
			return null;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param WebElement
	 * @return void
	 * @throws Exception
	 * @Description The expected webelemnt is highlights in green color
	 * @Date Aug 7, 2014
	 */
	public void HighLight(WebElement webe) throws Exception
	{
		remoteDriver.executeScript("arguments[0].setAttribute('style', arguments[1]);", webe, "color: green; border: 2px solid green;");
	}
	
	
	

	/**
	 * @author Sourav Mukherjee
	 * @Param timeOutInSeconds
	 * @return void
	 * @throws Exception
	 * @Description Waits for the page to reach ready state 
	 * @Date Aug 7, 2014
	 */
	public synchronized void WaitForPageToLoad(int timeOutInSeconds) throws Exception
	{ 

		String command = "return document.readyState"; 

		try
		{
			for (int i=0; i<timeOutInSeconds; i++)
			{ 
				try
				{
					Thread.sleep(1000L);
				}
				catch (InterruptedException e)
				{
					System.out.println("Unable to load the webpage");				

				} 

				if (remoteDriver.executeScript(command).toString().equals("complete"))
				{ 
					//System.out.println("Inside WaitForPageToLoad(Success)");
					break; 
				} 


			} 
		}catch(Exception e) 
		{
			e.printStackTrace();
		}
	}


	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return void
	 * @throws Exception
	 * @Description Creates the Repository for all the SFDC TabNames from All Tabs
	 * @Date Aug 7, 2014
	 */

	//	public static ArrayList<String> al_fieldname,al_sectionname,al_relatedlistname;
	public static ArrayList<String> allvcolnames,alrlcolnames;
	public static ArrayList al_tabnames,al_tabnames_var;
	//	public static ArrayList<String> al_fieldname_fn, al_sectionname_fn,al_relatedlistname_fn;
	//	public static ArrayList<String> al_tab,al_tab_fn;
	public static SFDCAutomationFW sfdc;
	public static String contentofscreenfile,screenname;

	public static String path_alm_xl;
	//	public static ArrayList< String > uniquebuttons;
	public static String ip_address;


	public static ArrayList<String> al_fieldname = new ArrayList();
	public static ArrayList<String> al_sectionname = new ArrayList();
	public static ArrayList<String> al_relatedlistname = new ArrayList();
	public static ArrayList<String> uniquebuttons = new ArrayList< String >();
	public static ArrayList<String> al_fieldname_fn = new ArrayList();
	public static ArrayList<String> al_sectionname_fn = new ArrayList();
	public static ArrayList<String> al_relatedlistname_fn = new ArrayList();
	public static ArrayList<String> al_lv_c_col_names = new ArrayList();
	public static ArrayList<String> al_rl_c_col_names = new ArrayList();
	public static ArrayList<String> al_rlname_c_plus_col = new ArrayList();
	public static ArrayList<String> al_rlSecName_c_plus_FName =new ArrayList();
	public static ArrayList<String> al_rlSecName_c_FName =new ArrayList();
	public static ArrayList<String> al_tab =new ArrayList();
	public static ArrayList<String>	al_tab_fn =new ArrayList();
	public static ArrayList<String> local_secnameArray;
	public static ArrayList<String> al_custom_table = new ArrayList();
	
	
	
	
	// Health cloud
	public static ArrayList<String> al_HC_dv_fields = new ArrayList();
	public static ArrayList<String> al_HC_buttons = new ArrayList();
	//custom 
	public static ArrayList<String> al_cus_dv_fields = new ArrayList();
	public static ArrayList<String> al_cus_buttons = new ArrayList();
	public static ArrayList<String> al_cus_rl_names = new ArrayList();
	public static ArrayList<String> al_cus_rl_col_names = new ArrayList();
	public static ArrayList<String> al_cus_rlname_plus_col = new ArrayList();
	public static ArrayList<String> al_custom_JTreeText = new ArrayList();
	public static ArrayList<String> al_custom_tablecell_col_names = new ArrayList();
	
	public void CreateAUTRepository_TabNames() throws Exception
	{
		al_tabnames = new ArrayList();
		al_tabnames_var = new ArrayList();
		contentofscreenfile = "";

		contentofscreenfile = "package USER_SPACE.ObjectRepository;  \n"
				+ "\n \n \n"
				+ "public class TabNames { \n \n \n";

		try{

			Integer countofrows= remoteDriver.findElements(By.xpath("//table[contains(@class,'detailList tabs')]/tbody[1]/tr")).size();
			System.out.println("countofrows:"+countofrows);
			List<WebElement> Tabs = remoteDriver.findElements(By.xpath("//table[contains(@class,'detailList tabs')]/tbody[1]/descendant::a[text()]"));		
			for(WebElement eachTab: Tabs)
			{
				//System.out.println("The Tab Name is:"+eachTab.getText().trim());

				String s = eachTab.getText().trim().replace("+", "").replace("&", "")
						.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
						.replace("-", "").replace(" ", "").replace("*", "")
						.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
						.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
						.replace("$", "").replace(".", "").replace("!", "");

				al_tabnames_var.add(s);
				al_tabnames.add(eachTab.getText().trim());
				
				//s="";

				//contentofscreenfile = contentofscreenfile + "} \n";

				//

			}

			for(int p=0;p<al_tabnames.size();p++)
			{
				System.out.println(al_tabnames_var.get(p) + ":" +al_tabnames.get(p));
				contentofscreenfile = contentofscreenfile + "public String "+al_tabnames_var.get(p)+" = \""+al_tabnames.get(p)+"\"; \n";
			}
			contentofscreenfile = contentofscreenfile + "} \n";
			screenname = "TabNames";
			_CreateScreenFile();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to create the TabNames repository");

		}

	}


	/**
	 * @author Sourav Mukherjee
	 * @Param ObjectName. The .java file will get generated with this name.
	 * @return void
	 * @throws Exception
	 * @Description Creates the repository file for an object. This function identifies all the field labels, section, fields under each sections, related lists and its columns, SFDC buttons. The view details page must be displayed to the respective SFDC record.  
	 * @Date Aug 7, 2014
	 */	
	public void _CreateAUTRepository() throws Exception
	{
		if(remoteDriver==null)
		{
			remoteDriver = (RemoteWebDriver) myWD;
		}

		local_secnameArray= new ArrayList();
		contentofscreenfile = "";

		
			
		try
		{


			Integer countoffieldslabel = 0;
			String s;
			
			System.out.println("remoteDriver url is:"+remoteDriver.getCurrentUrl());
			
			
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
			//Detecting All Tabs Page
			if(remoteDriver.getCurrentUrl().contains("AllTabs"))
			{
				
				ObjectNameAllTabs="AllTabs";
				System.out.println("ObjectNameAllTabs"+ObjectNameAllTabs);
				
				List<WebElement> cTabs = remoteDriver.findElements(By.xpath("//table[contains(@class,'detailList tabs')]/tbody[1]/descendant::a[text()]"));		
				for(WebElement eachTab: cTabs)
				{
				
					HighLight(eachTab);
					s = eachTab.getText().trim().replace("+", "").replace("&", "")
							.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
							.replace("-", "").replace(" ", "").replace("*", "")
							.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
							.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
							.replace("$", "").replace(".", "").replace("!", "");

					al_tab_fn.add(s);
					al_tab.add(eachTab.getText().trim());

				}
				sfdc.al_tab = (ArrayList) sfdc.al_tab.stream().distinct().collect(Collectors.toList());
				sfdc.al_tab_fn = (ArrayList) sfdc.al_tab_fn.stream().distinct().collect(Collectors.toList());

				for(int tab=0;tab<al_tab.size();tab++)
				{
					System.out.println(al_tab_fn.get(tab) + ":" +al_tab.get(tab));

					
				}
			} 			
			//Below condition is for list view page
			if(remoteDriver.getCurrentUrl().trim().contains("?fcf"))
			{  
				
				ObjectNameListView = "undefined";
				System.out.println("ObjectNameListView"+ObjectNameListView);

				// ********************************* Begin of Section and Related List ******************************************
				List<WebElement> sec = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')][1]"));

				_ReadAllColumnsUnderListView();

				_ReadAllButtons();

			}
			//Detecting View Details / Edit Page in Classic
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
			if(
					( (remoteDriver.findElements(By.xpath("//div[contains(@class,'Detail') and contains(@class,'Palette') and contains(@class,'Page')][1]")).size()>0) || (remoteDriver.findElements(By.xpath("//h2[contains(@class,'mainTitle')][1]")).size()>0) )
													&&
					!(remoteDriver.getCurrentUrl().contains("AllTabs"))
													&&
					!(remoteDriver.getCurrentUrl().trim().contains("?fcf"))
													&&
					!(remoteDriver.getCurrentUrl().trim().contains("/o"))
					
			  )
			{
				System.out.println("inside1");
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
				List<WebElement> pageType = remoteDriver.findElements(By.xpath("(//a[contains(@title,'Tab - Selected')][text()])[1]"));
				System.out.println("inside2:"+pageType.size());
				for(WebElement we1: pageType)
				{
						
						ObjectName_classic= remoteDriver.findElement(By.xpath("(//a[contains(@title,'Tab - Selected')][text()])[1]")).getText().trim();
														
						// ******************************************** Begin of Field Names *********************************************************
						remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
						List<WebElement> ml = remoteDriver.findElements(By.xpath("//*[contains(@class,'label') and (local-name()='td' or local-name()='th' or local-name()='div' or local-name()='label')]"));
						for(WebElement we: ml) 
						{
							if(we.getText().trim().length()>0)
							{
								countoffieldslabel++;
							
								HighLight(we);

								al_fieldname.add(we.getText().trim().replace("*", "").replaceAll("\\r", "").replaceAll("\\n", ""));

								s = we.getText().trim().replace("+", "").replace("&", "")
										.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
										.replace("-", "").replace(" ", "").replace("*", "")
										.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
										.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
										.replace("$", "").replace(".", "").replace("\\", "");
								if (Character.isDigit(s.charAt(0)))
								{
									s = s.replaceFirst(s.substring(0, 1),"_");
								}

								al_fieldname_fn.add(s);
							}

						}
						
						// ******************************************** End of Field Names *********************************************************
						String local_rlname = "";
						String local_secname = "";
						
						// ********************************* Begin of Section and Related List ******************************************
						remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
						List<WebElement> sec = remoteDriver.findElements(By.xpath("//*[(contains(@class,'mainTitle') and local-name()='h2') or (local-name()='h3')]"));
						for(WebElement we: sec) 
						{
							if((we.getAttribute("id").trim().length()==0) && (we.getText().trim().length()!=0))
							{
								HighLight(we);
								al_sectionname.add(we.getText().trim());
								local_secnameArray.add(we.getText().trim());
								local_secname=we.getText().trim();
								System.out.println("local_secname:"+local_secname);
							}
							else if ((we.getAttribute("id").trim().length()>0) && (we.getText().trim().length()!=0))
							{
								HighLight(we);
								if(!we.getText().trim().equals("")){
									al_relatedlistname.add(we.getText().trim());
									local_rlname = we.getText().trim();
									System.out.println("local_rlname"+local_rlname);
								}
							}
							else
							{
								System.out.println("Please investigate this element as this is not in the defined criteria of Section/Related List.");
							}

						}
						
						for(int j=0;j<al_fieldname.size();j++)
						{
							System.out.println("Field Name: "+al_fieldname.get(j));
							System.out.println("Field Name for function: "+al_fieldname_fn.get(j));

						}
						System.out.println("Total Count of Fields:"+al_fieldname.size());

						for(int j=0;j<local_secnameArray.size();j++)
						{
							System.out.println("Section Name: "+local_secnameArray.get(j));

							_ReadAllFieldsUnderASection(local_secnameArray.get(j).toString());
							
						}
						System.out.println("Total Count of Section Name:"+al_sectionname.size());

						for(int j=0;j<al_relatedlistname.size();j++)
						{
							System.out.println("Related List Name: "+al_relatedlistname.get(j));
							s = al_relatedlistname.get(j).toString().replace("+", "").replace("&", "")
									.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
									.replace("-", "").replace(" ", "").replace("*", "")
									.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
									.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
									.replace("$", "").replace(".", "").replace("\\", "");
							
							
							//updated sangeetha
							List<WebElement> RL_Cols = remoteDriver.findElements(By.xpath("(//*[normalize-space(text())='"+al_relatedlistname.get(j).toString()+"'])/ancestor::div[1]/following-sibling::div[1]/descendant::tr[contains(@class,'headerRow')][1]/descendant::th[text()]"));
							for(WebElement we: RL_Cols) 
							{
								if((we.getText().trim().length()>0) && !(we.getText().trim().equalsIgnoreCase("No records to display")))
								{
									HighLight(we);

									if(!we.getText().trim().equals("")|| !we.getText().trim().equals(null))
									{
										al_rl_c_col_names.add(we.getText().trim());
										sfdc.al_rlname_c_plus_col.add(al_relatedlistname.get(j)+":"+we.getText().trim());
										System.out.println(al_relatedlistname.get(j)+":"+we.getText().trim());
									}
								}
							}
						}
						System.out.println("Total Count of Related List Name:"+al_relatedlistname.size());

						_ReadAllButtons();

						if(remoteDriver.getCurrentUrl().trim().contains("?fcf"))
						{
						
							_ReadAllColumnsUnderListView();

						}
						

					}

				}

			
			/*
			if(remoteDriver.findElements(By.xpath("(//iframe[@id])[1]")).size() == 1)
			{
				List<WebElement> l_we_frm = remoteDriver.findElements(By.xpath("//iframe"));
				for(WebElement el:l_we_frm)
				{
					if(el.getAttribute("id") != null)
					{
						System.out.println("Checking ID of Iframe: ---------->"+el.getAttribute("id").trim());
						remoteDriver.switchTo().frame(el);
						
						//Below code runs within iframe
						
						if(remoteDriver.findElements(By.xpath("//h1[normalize-space(@class)]")).size()>0)
						{
							List<WebElement> pageType = remoteDriver.findElements(By.xpath("//h1[normalize-space(@class)]"));

							for(WebElement we1: pageType)
							{
								if(we1.getAttribute("class").equals("pageType"))
								{
									System.out.println("pagename"+remoteDriver.findElement(By.xpath("//h1[normalize-space(@class)='pageType'][1]")).getText());

									if(!remoteDriver.findElement(By.xpath("//h1[normalize-space(@class)='pageType'][1]")).getText().contains("Edit"))
									{
										ObjectName_classic= remoteDriver.findElement(By.xpath("//h1[normalize-space(@class)='pageType'][1]")).getText();
									}

									// ******************************************** Begin of Field Names *********************************************************
									List<WebElement> ml = remoteDriver.findElements(By.xpath("//*[contains(@class,'label') and (local-name()='td' or local-name()='th' or local-name()='div' or local-name()='label')]"));
									for(WebElement we: ml) 
									{
										if(we.getText().trim().length()>0)
										{
											countoffieldslabel++;
										
											HighLight(we);

											al_fieldname.add(we.getText().trim().replace("*", "").replaceAll("\\r", "").replaceAll("\\n", ""));

											s = we.getText().trim().replace("+", "").replace("&", "")
													.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
													.replace("-", "").replace(" ", "").replace("*", "")
													.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
													.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
													.replace("$", "").replace(".", "").replace("\\", "");
											if (Character.isDigit(s.charAt(0)))
											{
												s = s.replaceFirst(s.substring(0, 1),"_");
											}

											al_fieldname_fn.add(s);
										}

									}
									
									// ******************************************** End of Field Names *********************************************************
									String local_rlname = "";
									String local_secname = "";
									
									// ********************************* Begin of Section and Related List ******************************************
									List<WebElement> sec = remoteDriver.findElements(By.xpath("//*[(contains(@class,'mainTitle') and local-name()='h2') or (local-name()='h3')]"));
									for(WebElement we: sec) 
									{
										if((we.getAttribute("id").trim().length()==0) && (we.getText().trim().length()!=0))
										{
											HighLight(we);
											al_sectionname.add(we.getText().trim());
											local_secnameArray.add(we.getText().trim());
											local_secname=we.getText().trim();
											System.out.println("local_secname:"+local_secname);
										}
										else if ((we.getAttribute("id").trim().length()>0) && (we.getText().trim().length()!=0))
										{
											HighLight(we);
											if(!we.getText().trim().equals("")){
												al_relatedlistname.add(we.getText().trim());
												local_rlname = we.getText().trim();
												System.out.println("local_rlname"+local_rlname);
											}
										}
										else
										{
											System.out.println("Please investigate this element as this is not in the defined criteria of Section/Related List.");
										}

									}
									
									for(int j=0;j<al_fieldname.size();j++)
									{
										System.out.println("Field Name: "+al_fieldname.get(j));
										System.out.println("Field Name for function: "+al_fieldname_fn.get(j));

									}
									System.out.println("Total Count of Fields:"+al_fieldname.size());

									for(int j=0;j<local_secnameArray.size();j++)
									{
										System.out.println("Section Name: "+local_secnameArray.get(j));

										_ReadAllFieldsUnderASection(local_secnameArray.get(j).toString());
										
									}
									System.out.println("Total Count of Section Name:"+al_sectionname.size());

									for(int j=0;j<al_relatedlistname.size();j++)
									{
										System.out.println("Related List Name: "+al_relatedlistname.get(j));
										s = al_relatedlistname.get(j).toString().replace("+", "").replace("&", "")
												.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
												.replace("-", "").replace(" ", "").replace("*", "")
												.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
												.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
												.replace("$", "").replace(".", "").replace("\\", "");
										
										
										//updated sangeetha
										List<WebElement> RL_Cols = remoteDriver.findElements(By.xpath("(//*[normalize-space(text())='"+al_relatedlistname.get(j).toString()+"'])/ancestor::div[1]/following-sibling::div[1]/descendant::tr[contains(@class,'headerRow')][1]/descendant::th[text()]"));
										for(WebElement we: RL_Cols) 
										{
											if((we.getText().trim().length()>0) && !(we.getText().trim().equalsIgnoreCase("No records to display")))
											{
												HighLight(we);

												if(!we.getText().trim().equals("")|| !we.getText().trim().equals(null))
												{
													al_rl_c_col_names.add(we.getText().trim());
													sfdc.al_rlname_c_plus_col.add(al_relatedlistname.get(j)+":"+we.getText().trim());
													System.out.println(al_relatedlistname.get(j)+":"+we.getText().trim());
												}
											}
										}
									}
									System.out.println("Total Count of Related List Name:"+al_relatedlistname.size());

									_ReadAllButtons();

									if(remoteDriver.getCurrentUrl().trim().contains("?fcf"))
									{
									
										_ReadAllColumnsUnderListView();

									}
									

								}

							}

						}
						
						
						
						remoteDriver.switchTo().defaultContent();
						//break; //no need to break as there is one iframe element only
					}
				}
			}
			
			*/
			JOptionPane.showMessageDialog(null, "Please Move to Next Capture");
		}
		catch(Exception e)
		{
			System.out.println("Inside catch in CreateAUTRepository");
			e.printStackTrace();
		}
	}

	public void _ReadAllFieldsUnderASection(String SectionName) throws Exception
	{
		//Getting all fields under a section
		String s;
		String SectionName_remove_spcl_char = "";
		String local_name;
		System.out.println("section name"+SectionName);
		remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
		if(remoteDriver.findElement(By.xpath("(//*[normalize-space(text())='"+SectionName+"'])/ancestor::div[1]")).getAttribute("class").contains("pbHeader"))
		{
			System.out.println("highlighted");
			SectionName_remove_spcl_char = SectionName.toString().replace("+", "").replace("&", "")
					.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
					.replace("-", "").replace(" ", "").replace("*", "")
					.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
					.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
					.replace("$", "").replace(".", "").replace("\\", "");
			local_name=SectionName;
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
			List<WebElement> sec_fields = remoteDriver.findElements(By.xpath("(//*[normalize-space(text())='"+SectionName+"'])/ancestor::div[1]/following-sibling::div[1]/descendant::div[contains(@class,'pbSubsection')][1]/descendant::*[contains(@class,'label') and (local-name()='td' or local-name()='th')]"));
			for(WebElement we: sec_fields) 
			{
				if(we.getText().trim().length()>0)
				{
					HighLight(we);
					System.out.println("highlighted firstloop");
					sfdc.al_rlSecName_c_FName.add(we.getText().trim());
					sfdc.al_rlSecName_c_plus_FName.add(local_name+"SEC_:"+we.getText().trim());
					System.out.println("Field Name under Section: "+we.getText().trim());
					s = we.getText().trim().replace("+", "").replace("&", "")
							.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
							.replace("-", "").replace(" ", "").replace("*", "").replace("!", "")
							.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
							.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
							.replace("$", "").replace(".", "").replace("\\", "").replace("?", "");
					if (Character.isDigit(s.charAt(0)))
					{
						s = s.replaceFirst(s.substring(0, 1),"_");
					}	
					//					contentofscreenfile = contentofscreenfile + "public MemberOfSEC SEC_"+SectionName_remove_spcl_char+"_"+s+"Field() throws Exception { \n";
					//					contentofscreenfile = contentofscreenfile + "return sfdc.Section(\""+SectionName+"\", \""+we.getText().trim()+"\"); \n";
					//					contentofscreenfile = contentofscreenfile + "}\n";
				}

			}
		}
		else if (remoteDriver.findElement(By.xpath("(//*[normalize-space(text())='"+SectionName+"'])/ancestor::div[1]")).getAttribute("class").contains("pbSubheader"))
		{
			local_name=SectionName;
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
			List<WebElement> sec_fields = remoteDriver.findElements(By.xpath("(//*[normalize-space(text())='"+SectionName+"'])/ancestor::div[1]/following-sibling::div[1]/descendant::*[contains(@class,'label') and (local-name()='td' or local-name()='th')]"));
			for(WebElement we: sec_fields) 
			{
				if(we.getText().trim().length()>0)
				{
					HighLight(we);
					System.out.println("highlighted secondloop");
					sfdc.al_rlSecName_c_FName.add(we.getText().trim());



					System.out.println("Field Name under Section: "+we.getText().trim());

					s = we.getText().trim().replace("+", "").replace("&", "")
							.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
							.replace("-", "").replace(" ", "").replace("*", "").replace("!", "")
							.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
							.replace("%", "").replace(")", "").replace(",", "").replace("#", "")
							.replace("$", "").replace(".", "").replace("\\", "").replace("\\n", "").replace("\\r", "");
					if (Character.isDigit(s.charAt(0)))
					{
						s = s.replaceFirst(s.substring(0, 1),"_");
					}
					sfdc.al_rlSecName_c_plus_FName.add(s);
					//					contentofscreenfile = contentofscreenfile + "public MemberOfSEC "+s+"() throws Exception \n";
					//					contentofscreenfile = contentofscreenfile + "{ \n";
					//					contentofscreenfile = contentofscreenfile + "return sfdc._SEC(SecName,\""+we.getText().trim()+"\");\n";
					//					contentofscreenfile = contentofscreenfile + "}\n";

				}
			}
		}
		else
		{
			System.out.println("Unable to read the fields under the section "+SectionName);
		}
	}

	public void _ReadAllColumnsUnderARelatedList(String RelatedListName) throws Exception
	{
		String s;
		//Getting all columns under a related list
		remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
		List<WebElement> RL_Cols = remoteDriver.findElements(By.xpath("(//*[normalize-space(text())='"+RelatedListName+"'])/ancestor::div[1]/following-sibling::div[1]/descendant::tr[contains(@class,'headerRow')][1]/descendant::th[text()]"));
		for(WebElement we: RL_Cols) 
		{
			if((we.getText().trim().length()>0) && !(we.getText().trim().equalsIgnoreCase("No records to display")))
			{
				HighLight(we);

				if(!we.getText().trim().equals("")|| !we.getText().trim().equals(null))
				{
					System.out.println("inside"+we.getText().trim());
					//					al_rl_col_names.add(we.getAttribute("title").toString().trim());
					al_rl_c_col_names.add(we.getText().trim());
					System.out.println(we.getText().trim());
				}

				System.out.println("Columns under the RL: "+we.getText().trim());
				s = we.getText().trim().replace("+", "").replace("&", "")
						.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
						.replace("-", "").replace(" ", "").replace("*", "").replace("!", "")
						.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
						.replace("%", "").replace(")", "").replace(",", "").replace("#", "")
						.replace("$", "").replace(".", "").replace("\\", "");
				if (Character.isDigit(s.charAt(0)))
				{
					s = s.replaceFirst(s.substring(0, 1),"_");
				}
				//				contentofscreenfile = contentofscreenfile + "public MemberOfRL "+s+"(Integer RowIndex) throws Exception \n";
				//				contentofscreenfile = contentofscreenfile + "{ \n";
				//
				//				contentofscreenfile = contentofscreenfile +	"return sfdc.RL(RList,\""+we.getText().trim()+"\",RowIndex); \n";
				//				contentofscreenfile = contentofscreenfile + "}\n";
				//
				//				//******************** Below statements Newly Added *************************
				//
				//				contentofscreenfile = contentofscreenfile + "public MemberOfRL "+s+"() throws Exception \n";
				//				contentofscreenfile = contentofscreenfile + "{ \n";
				//
				//				contentofscreenfile = contentofscreenfile +	"return sfdc.RL(RList,\""+we.getText().trim()+"\"); \n";
				//				contentofscreenfile = contentofscreenfile + "}\n\n";
			}

		}

	}
	//sangeetha

	public void _ReadAllColumnsUnderListView() throws Exception
	{
		String s;
		remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
		List<WebElement> RL_Cols = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::td[contains(@class,'cell')]/descendant::div[text()]"));
		System.out.println("fetched"+remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::td[contains(@class,'cell')]/descendant::div[text()][1]")).getText());
		//			System.out.println("fetched"+remoteDriver.findElement(By.xpath("(//*[normalize-space(text())='"+RelatedListName+"'])/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::td[contains(@class,'cell')]/descendant::div[text()]")).getText());
		for(WebElement we: RL_Cols) 
		{
			System.out.println("fetched"+remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::td[contains(@class,'cell')]/descendant::div[text()]")).getText());
			if((we.getText().trim().length()>0) && !(we.getText().trim().equalsIgnoreCase("No records to display")))
			{
				HighLight(we);
				String colname = we.getText().trim();
				////					al_lv_col_names.add(we.getText().trim());
				System.out.println("Columns under the RL: "+colname);
				if(!we.getText().trim().equals("") || !we.getText().trim().equals(null))
				{
					//						al_rl_col_names.add(we.getAttribute("title").toString().trim());
					al_lv_c_col_names.add(we.getText().trim());
				}

				/*if(!we.getText().trim().equals(""))
					{
//						al_lv_col_names.add(we.getAttribute("title").toString().trim());
						al_lv_col_names.add(we.getText().trim());
					}*/

				s = we.getText().trim().replace("+", "").replace("&", "")
						.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
						.replace("-", "").replace(" ", "").replace("*", "").replace("!", "")
						.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
						.replace("%", "").replace(")", "").replace(",", "").replace("#", "")
						.replace("$", "").replace(".", "").replace("\\", "");
				if (Character.isDigit(s.charAt(0)))
				{
					s = s.replaceFirst(s.substring(0, 1),"_");
				}


				//					contentofscreenfile = contentofscreenfile + "public MemberOfLV "+s+"(Integer RowIndex) throws Exception \n";
				//					contentofscreenfile = contentofscreenfile + "{ \n";
				//
				//					contentofscreenfile = contentofscreenfile +	"return sfdc.LV(\""+we.getText().trim()+"\",RowIndex); \n";
				//					contentofscreenfile = contentofscreenfile + "}\n";
				//
				//					//******************** Below statements Newly Added *************************
				//
				//					contentofscreenfile = contentofscreenfile + "public MemberOfLV "+s+"() throws Exception \n";
				//					contentofscreenfile = contentofscreenfile + "{ \n";
				//
				//					contentofscreenfile = contentofscreenfile +	"return sfdc.LV(\""+we.getText().trim()+"\"); \n";
				//					contentofscreenfile = contentofscreenfile + "}\n\n";
			}
		}
	}

	//Getting all columns under a related list
	/*List<WebElement> RL_Cols = remoteDriver.findElements(By.xpath("(//*[normalize-space(text())='"+RelatedListName+"'])/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::td[contains(@class,'cell')]/descendant::div[text()]"));
		System.out.println("fetched"+remoteDriver.findElement(By.xpath("(//*[normalize-space(text())='"+RelatedListName+"'])/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::td[contains(@class,'cell')]/descendant::div[text()]")).getText());
		for(WebElement we: RL_Cols) 
		{
			if((we.getText().trim().length()>0) && !(we.getText().trim().equalsIgnoreCase("No records to display")))
			{
				HighLight(we);
				System.out.println("Columns under the RL: "+we.getText().trim());
				s = we.getText().trim().replace("+", "").replace("&", "")
						.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
						.replace("-", "").replace(" ", "").replace("*", "").replace("!", "")
						.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
						.replace("%", "").replace(")", "").replace(",", "").replace("#", "")
						.replace("$", "").replace(".", "").replace("\\", "");
				if (Character.isDigit(s.charAt(0)))
				{
					s = s.replaceFirst(s.substring(0, 1),"_");
				}
				contentofscreenfile = contentofscreenfile + "public MemberOfRL "+s+"(Integer RowIndex) throws Exception \n";
				contentofscreenfile = contentofscreenfile + "{ \n";

				contentofscreenfile = contentofscreenfile +	"return sfdc.RL(RList,\""+we.getText().trim()+"\",RowIndex); \n";
				contentofscreenfile = contentofscreenfile + "}\n";

				//******************** Below statements Newly Added *************************

				contentofscreenfile = contentofscreenfile + "public MemberOfRL "+s+"() throws Exception \n";
				contentofscreenfile = contentofscreenfile + "{ \n";

				contentofscreenfile = contentofscreenfile +	"return sfdc.RL(RList,\""+we.getText().trim()+"\"); \n";
				contentofscreenfile = contentofscreenfile + "}\n\n";
			}
		}*/


	/**
	 * @param xpath
	 * @Description To right click on any element when xpath is passed as a parameter
	 * @throws Exception
	 */
	public void RightCLickOnElement(String xpath) throws Exception
	{
		try{
			
			Actions action = new Actions(remoteDriver);
			WebElement elmnt = remoteDriver.findElement(By.xpath(xpath));
			action.contextClick(elmnt).perform();
			AddLogToCustomReport("Right Clicked on the element", "Pass");
			System.out.println("Right Clicked on the element");
			
		}catch(Exception e)
		{
			AddLogToCustomReport("Unable to right click on the element", "Fail");
			System.out.println("Unable to right click on the element");
			e.printStackTrace();
		}
	}
	
	
	/**
	 * @param xpath
	 * @Description To double click on any element when xpath is passed as a parameter
	 * @throws Exception
	 */
	public void DoubleCLickOnElement(String xpath) throws Exception
	{
		try{
			
			Actions action = new Actions(remoteDriver);
			WebElement elmnt = remoteDriver.findElement(By.xpath(xpath));
			action.doubleClick(elmnt).perform();
			AddLogToCustomReport("Double Clicked on the element", "Pass");
			System.out.println("Double Clicked on the element");
			
		}catch(Exception e)
		{
			AddLogToCustomReport("Unable to Double click on the element", "Fail");
			System.out.println("Unable to Double click on the element");
			e.printStackTrace();
		}
	}
	
	
	//sangeetha
	public void _ReadAllButtons() throws Exception
	{
		//Getting all button in a page
		String s;
		//List<WebElement> all_buttons = sfdc.remoteDriver.findElements(By.xpath("//input[contains(@class,'btn')]"));
		remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
		List<WebElement> all_buttons = remoteDriver.findElements(By.xpath("//*[(local-name()='input' or local-name()='div') and (contains(@class,'btn') or @class='menuButton')]"));

		//		contentofscreenfile = contentofscreenfile + "\n \n \n";

		for(WebElement we: all_buttons) 
		{
			if(we.getAttribute("value") != null && we.getAttribute("value").trim().length()>0)
			{
				HighLight(we);
				//System.out.println("Button Name: "+we.getAttribute("value").trim());
				uniquebuttons.add(we.getAttribute("value").trim());
			}
			else
			{
				HighLight(we);
				//System.out.println("Button Name: "+we.getAttribute("value").trim());
				uniquebuttons.add(we.getText().trim());
			}

		}
		for (String h : uniquebuttons) {
			System.out.println("Button Name: "+h);
			s = h.trim().replace("+", "").replace("&", "")
					.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
					.replace("-", "").replace(" ", "").replace("*", "").replace("!", "")
					.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
					.replace("%", "").replace(")", "").replace(",", "").replace("#", "")
					.replace("$", "").replace(".", "").replace("\\", "");

			//			contentofscreenfile = contentofscreenfile + "public MemberOfButton "+s+"Button() throws Exception{ \n";
			//			contentofscreenfile = contentofscreenfile +  "return sfdc.Button(\""+h.trim()+"\"); \n";
			//			contentofscreenfile = contentofscreenfile + "} \n";

		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return void
	 * @throws Exception
	 * @Description Creates the ScreenFiles.java in the repository
	 * @Date Aug 7, 2014
	 */
	public void _CreateScreenFile() throws Exception
	{
		try
		{
			String myCurrentDir = System.getProperty("user.dir");
			System.out.println("myCurrentDir:"+myCurrentDir);
			System.out.println(myCurrentDir+"\\src\\test\\java\\USER_SPACE\\ObjectRepository\\" + screenname	+ ".java");
			File file = new File(myCurrentDir+"\\src\\test\\java\\USER_SPACE\\ObjectRepository\\" + screenname	+ ".java");
			file.getCanonicalFile().createNewFile();
			BufferedWriter wr = new BufferedWriter(new FileWriter(file.getCanonicalFile()));
			wr.write(contentofscreenfile);
			wr.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();

		}
	}

	public void waitForInvisibilityOfElement(String xpath) throws Exception {

		try {
			switch (toolName) {

			case "Appium":
				WebDriverWait wait = new WebDriverWait(appiumDriver, Duration.ofSeconds(10));
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpath)));
				break;
			case "Selenium":
				WebDriverWait waitSelenium = new WebDriverWait(remoteDriver, Duration.ofSeconds(10));
				waitSelenium.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpath)));
				break;
			}

		} catch (Exception exc) {
			exc.printStackTrace();
			ExtentUtility.getTest().log(LogStatus.FAIL, "Exception on waiting for webelement",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			throw new Exception(exc + "Exception on waiting for webelement");

		}
	}
	
	
	public void waitForInvisibilityOfElement(String xpath, long sec) throws Exception {

		try {
			switch (toolName) {

			case "Appium":
				WebDriverWait wait = new WebDriverWait(appiumDriver, Duration.ofSeconds(sec));
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpath)));
				break;
			case "Selenium":
				WebDriverWait waitSelenium = new WebDriverWait(remoteDriver,Duration.ofSeconds(sec));
				waitSelenium.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpath)));
				break;
			}

		} catch (Exception exc) {
			exc.printStackTrace();
			ExtentUtility.getTest().log(LogStatus.FAIL, "Exception on waiting for webelement",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			throw new Exception(exc + "Exception on waiting for webelement");

		}
	}
	
	public void _CreateAUTRepository_LU() throws Exception
	{
		try
		{


			//String obj_rlv = "";
			//String obj_ev = "";
			//String xpath_button = "//div[@class='active oneContent'][1]/descendant::li[contains(@class,'button')]/descendant::*[@title=normalize-space(text())]";
			//String xpath_button =	xp_lui_common_part + "/descendant::li[contains(@class,'slds-button')]/descendant::a[1]/descendant::div[@title=normalize-space(text())]";
			String xpath_button =	xp_lui_common_part + "/descendant::li[contains(@class,'slds-button') or contains(@class,'visible')]/descendant-or-self::*[(local-name()='div' and @title=normalize-space(text())) or (local-name()='button' and not(text()=''))]";
			
			String xpath_button_icon =	xp_lui_common_part + "/descendant::li[contains(@class,'button--icon') or contains(@class,'button_last')]";
			
			//This section of code runs in every type of page like list view, detail view, edit page, inline edit page, related list, custom page
			System.out.println("--------- BUTTONS -----------");
			List<WebElement> buttons_elmnt = remoteDriver.findElements(By.xpath(xpath_button));
			for(WebElement each_button: buttons_elmnt) 
			{
				HighLight(each_button);

				if(!each_button.getText().trim().equals(""))
				{
					System.out.println("BUTTONS:"+each_button.getText());
					al_buttons.add(each_button.getText().trim());
				}

			}
			
			//Finding buttons on Edit page from footer toolbar
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1)); 
			String xpath_button1 = "//div[contains(@class,'-footer')]/button[contains(@class,'slds-button')]/span[text()]";
			List<WebElement> buttons_elmnt1 = remoteDriver.findElements(By.xpath(xpath_button1));
			for(WebElement each_button: buttons_elmnt1) 
			{
				HighLight(each_button);

				if(!each_button.getText().trim().equals(""))
				{
					System.out.println("BUTTONS ON EDIT PAGE:"+each_button.getText());
					al_buttons.add(each_button.getText().trim());
				}

			}
			
			
			
			//Clicking on menu button icon and getting all button names
			if(!remoteDriver.findElement(By.xpath("(//body[contains(normalize-space(@class),'desktop')])[1]")).getAttribute("style").toString().contains("hidden")){
					try
					{
						List<WebElement> all_menu_buttons_img = remoteDriver.findElements(By.xpath(xpath_button_icon));
						System.out.println("size of button_menu:"+all_menu_buttons_img.size());
						for(WebElement each_menu_buttons_img: all_menu_buttons_img) 
						{
							Thread.sleep(2000L);
							System.out.println("---------->each_menu_buttons_img.isDisplayed()"+each_menu_buttons_img.isDisplayed());
							System.out.println("---------->each_menu_buttons_img.isEnabled()"+each_menu_buttons_img.isEnabled());
							if(each_menu_buttons_img.isDisplayed())
							{
							each_menu_buttons_img.click();
							System.out.println("Clicked on button image");
							Thread.sleep(2000L);
							//List<WebElement> buttons_elmnt_from_menu_button = remoteDriver.findElements(By.xpath("//div[contains(@class,'default visible') and contains(@class,'uiMenuList')][1]/descendant::li[contains(@class,'uiMenuItem')]/descendant::a[@title]/descendant-or-self::*[text()][1]"));
							List<WebElement> buttons_elmnt_from_menu_button = remoteDriver.findElements(By.xpath("//*[(contains(@class,'menu-button-item') and contains(@class,'is-open')) or (contains(@class,'visible') and contains(@class,'MenuList'))]//div[@role='menu']//*[@role='menuitem']/descendant-or-self::*[text()]"));
							
							for(WebElement each_button_label_menu_button: buttons_elmnt_from_menu_button) 
							{
								HighLight(each_button_label_menu_button);
								System.out.println("BUTTONS:"+each_button_label_menu_button.getText());

								if(!each_button_label_menu_button.getText().trim().equals(""))
								{
									al_buttons.add("MenuButton:"+each_button_label_menu_button.getText().trim());
								}
							}
							each_menu_buttons_img.click();
						}
						
						
						}      
					}
					catch(Exception e1)
					{
						e1.printStackTrace();

					}
			}
			
			
			
			if((remoteDriver.getCurrentUrl().trim().contains("list?") || remoteDriver.getCurrentUrl().trim().contains("related") )&& !remoteDriver.findElement(By.xpath("(//body[contains(normalize-space(@class),'desktop')])[1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------LIST VIEW-----------");
				String xp = "/descendant::*[contains(@aria-label,'Breadcrumbs') or contains(@class,'breadcrumb')][1]/descendant::span[text()][1]";
				obj_lv = remoteDriver.findElement(By.xpath(xp_lui_common_part+xp)).getText().trim();
				HighLight(remoteDriver.findElement(By.xpath(xp_lui_common_part+xp)));
				System.out.println("LV OBJECT:"+obj_lv);


				//Getting List View Column Names
				List<WebElement> columns_listview_elmnt = remoteDriver.findElements(By.xpath(xp_lui_common_part + "/descendant::div[@class='centerRegion' or 'displayArea']/descendant::div[contains(@class,'listViewContent')]/descendant::table[@data-aura-class='uiVirtualDataTable' or 'uiVirtualDataGrid'][1]/descendant::tr[1]/th[@title]"));
				for(WebElement each_column_listview_elmnt: columns_listview_elmnt) 
				{
					HighLight(each_column_listview_elmnt);
					System.out.println("LV COLUMNS:"+each_column_listview_elmnt.getAttribute("title").toString().trim());
					if(!each_column_listview_elmnt.getAttribute("title").toString().trim().equals(""))
					{
						al_lv_col_names.add(each_column_listview_elmnt.getAttribute("title").toString().trim());
					}

				}

			}
			if((remoteDriver.getCurrentUrl().trim().contains("/view")||remoteDriver.getCurrentUrl().trim().contains("/home")) && !remoteDriver.getCurrentUrl().trim().contains("rlName") &&!remoteDriver.findElement(By.xpath("(//body[contains(normalize-space(@class),'desktop')])[1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------VIEW DETAILS-----------");
				String xp = "/descendant::h1/*[contains(@class,'entityNameTitle')][1]";		
				if(remoteDriver.findElements(By.xpath(xp_lui_common_part + xp)).size() > 0)
				{
					obj_vd = remoteDriver.findElement(By.xpath(xp_lui_common_part + xp)).getText().trim();
				
					HighLight(remoteDriver.findElement(By.xpath(xp_lui_common_part + xp)));

					System.out.println("VD OBJECT:"+obj_vd);


				//********************** Reading the field labels from left/right side
				WaitForPageToLoad(30);  
				Thread.sleep(4000L);

				//List<WebElement> all_field_label_elmnts = sfdc.GetWebDriver().findElements(By.xpath("//div[normalize-space(@class)='active oneContent'][1]/descendant::div[@class='row row-main'][1]/descendant::form[contains(@class,'forceDetailPanel')][1]/descendant::div[contains(@class,'label')]"));
				//List<WebElement> all_field_label_elmnts = sfdc.GetWebDriver().findElements(By.xpath("//div[contains(@class,'oneContent') and contains(@class,'active')][1]/descendant::div[contains(@class,'row row-main')][1]/descendant::form[contains(@class,'forceDetailPanel')][1]/descendant::div[contains(@class,'label')]"));
				//List<WebElement> all_field_label_elmnts = sfdc.GetWebDriver().findElements(By.xpath(xp_lui_common_part + "/descendant::div[contains(@class,'row row-main')][1]/descendant::div[contains(@class,'forceDetailPanel')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]"));
				//List<WebElement> all_field_label_elmnts = sfdc.GetWebDriver().findElements(By.xpath(xp_lui_common_part + "/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion')][1]/descendant::div[contains(@class,'forceDetailPanel') or contains(@role,'list')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]")); //including task page, need to test
				//List<WebElement> all_field_label_elmnts = remoteDriver.findElements(By.xpath(xp_lui_common_part + "/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]")); //including task page, need to test
				List<WebElement> all_field_label_elmnts = remoteDriver.findElements(By.xpath(xp_lui_common_part + "/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion') or contains(@class,'main-container')or contains(@class,'HomeFlexipage')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]")); //Tested for OOB Lightning, CloudSense,nCino, HealthCloud tested 
				//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion')][1]/descendant::div[contains(@class,'forceDetailPanel') or contains(@role,'list')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]
				for(WebElement each_field_label: all_field_label_elmnts) 
				{
					if(!each_field_label.getText().trim().equals(""))
					{
						HighLight(each_field_label);
						System.out.println("DV FIELD:"+each_field_label.getText().trim());
						al_dv_fields.add(each_field_label.getText().trim());

					}
				}



				//Getting related list from anywhere in the page when URL contains /View, Modified on 18th Sep 2017, Sourav
				String local_rlname = "";
				List<WebElement> rl_name_elmnt_region_all = remoteDriver.findElements(By.xpath(xp_lui_common_part + "/descendant::h2/descendant::a[contains(@class,'header-link')]/descendant::span[@title=normalize-space(text())][2]/preceding-sibling::span[text()]")); //only checking 2nd span because only second span has (4) pattern
				System.out.println("Xpath:->"+xp_lui_common_part + "/descendant::h2/descendant::a[contains(@class,'header-link')]/descendant::span[@title=normalize-space(text())][2]/preceding-sibling::span[text()]");
				////div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::h2/descendant::a[contains(@class,'header-link')]/descendant::span[@title=normalize-space(text())][2]/preceding-sibling::span[text()]
				//xp_lui_common_part + ""/descendant::b[text()]""
				System.out.println("rl_name_elmnt_region_all.size(): "+rl_name_elmnt_region_all.size());
				for(int p=0;p<rl_name_elmnt_region_all.size();p++)
				{
					try{
						WebElement rl_name_elmnt_region = rl_name_elmnt_region_all.get(p);
						HighLight(rl_name_elmnt_region);
						
						//System.out.println("RL_NAME->:"+rl_name_elmnt_region.getAttribute("text").trim());
						System.out.println("RL_NAME title->:"+rl_name_elmnt_region.getAttribute("title").trim());
						System.out.println("RL_NAME textContent:"+rl_name_elmnt_region.getAttribute("textContent").trim());
						System.out.println("RL_NAME innerHTML:"+rl_name_elmnt_region.getAttribute("innerHTML").trim());
						System.out.println("RL_NAME:"+rl_name_elmnt_region.getText().trim());
						
						
						if(!rl_name_elmnt_region.getAttribute("textContent").trim().trim().equals(""))
						{
							al_rl_names.add(rl_name_elmnt_region.getAttribute("textContent").trim());
							local_rlname = rl_name_elmnt_region.getAttribute("textContent").trim();
						}



						String url = remoteDriver.getCurrentUrl();
						//Thread.sleep(6000L);
						//al_rl_names.add(e)
						// ScrollToElement(rl_name_elmnt_region);
						//Thread.sleep(4000L);
						//rl_name_elmnt_region.click();
						//ClickWebElementByJS(rl_name_elmnt_region);
						ClickByJSFocus(rl_name_elmnt_region);
						WaitForPageToLoad(30);
						Thread.sleep(3000L);

						//Getting all the columns after clicking on each related list link
						//List<WebElement> columns_rl_view_elmnt_all = GetWebDriver().findElements(By.xpath("//descendant::tr[contains(@class,'slds-text-title--caps')]/descendant::span[text()]"));
						
						//List<WebElement> columns_rl_view_elmnt_all = remoteDriver.findElements(By.xpath("//th[normalize-space(@class)='errorColumnHeader'][1]/ancestor::tr[1]/descendant::span[text()][@class='slds-truncate']"));
						//List<WebElement> columns_rl_view_elmnt_all = remoteDriver.findElements(By.xpath("//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::table[contains(@class,'table--header')]/descendant::th/descendant::a/descendant::*[text()]"));
						List<WebElement> columns_rl_view_elmnt_all = remoteDriver.findElements(By.xpath("//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::table[contains(@class,'table--header') or contains(@class,'table_header')]/descendant::th/descendant::span[contains(@class,'truncate')][text()]"));
						
						for(WebElement columns_rl_view_elmnt: columns_rl_view_elmnt_all) 
						{
							String COL_NM = "";   
							COL_NM = remoteDriver.executeScript("return arguments[0].textContent;",columns_rl_view_elmnt).toString().trim();
							System.out.println("RL COLMN:"+COL_NM);
							//System.out.println("RL COLUMN:"+columns_rl_view_elmnt.getText().toString().trim());
							if(!COL_NM.equals(""))
							{
								HighLight(columns_rl_view_elmnt);
								al_rl_col_names.add(COL_NM);
								sfdc.al_rlname_plus_col.add(local_rlname+":"+COL_NM);
							}

						}
						Thread.sleep(1000L);

						//********************** Reading the name of buttons from list view, related list view and view details page.
						WaitForPageToLoad(30);  
						Thread.sleep(2000L);
						buttons_elmnt = remoteDriver.findElements(By.xpath(xpath_button));
						for(WebElement each_button: buttons_elmnt) 
						{
							HighLight(each_button);
							System.out.println("RLV_BUTTONS:"+each_button.getText());
							if(!each_button.getText().trim().equals(""))
							{
								al_rl_buttons.add(each_button.getText().trim());
								sfdc.al_rlname_plus_buttons.add(local_rlname+":"+each_button.getText().trim());
							}

						}      

						//Clicking on button icon and getting all button names
						List<WebElement> all_menu_buttons_img = remoteDriver.findElements(By.xpath(xpath_button_icon));
						//System.out.println("size of button_menu:"+all_menu_buttons_img.size());
						for(WebElement each_menu_buttons_img: all_menu_buttons_img) 
						{
							
							each_menu_buttons_img.click();
							//System.out.println("Clicked on button image");
							Thread.sleep(2000L);
							List<WebElement> buttons_elmnt_from_menu_button = remoteDriver.findElements(By.xpath("//div[contains(@class,'default visible') and contains(@class,'uiMenuList')][1]/descendant::li[contains(@class,'uiMenuItem')]/descendant::a[@title]/descendant-or-self::*[text()][1]"));
							for(WebElement each_button_label_menu_button: buttons_elmnt_from_menu_button) 
							{
								HighLight(each_button_label_menu_button);
								System.out.println("BUTTONS:"+each_button_label_menu_button.getText());
								if(!each_button_label_menu_button.getText().trim().equals(""))
								{
									al_rl_buttons.add(each_button_label_menu_button.getText().trim());
									sfdc.al_rlname_plus_buttons.add(local_rlname+":MenuButton:"+each_button_label_menu_button.getText().trim());
								}
							}
						}      


						//OpenSFDCRecordAsperURL(url);
						//	
						//myWD.findElement(By.xpath("(//button[@class='slds-button slds-button--icon-x-small slds-button--icon-container'])[2]")).click();	
						
						remoteDriver.navigate().back();
						
						Thread.sleep(2000L);
						//PressF5Key();
						//Thread.sleep(4000L);
						//myWD.findElement(By.xpath("//span[text()='Related'][1]")).click();
						// Thread.sleep(4000L);
						//OpenSFDCRecordAsperURL(url);
						//sfdc.PressF5Key();
						//System.out.println("Pressing F5");
						WaitForPageToLoad(30);
						//Thread.sleep(15000L);
						//since the page gets refreshed so geeting refilled the arraylist with elements
						//rl_name_elmnt_region_all = myWD.findElements(By.xpath(xp_lui_common_part + "/descendant::h2/descendant::a[contains(@class,'header-link')]/descendant::span[@title=normalize-space(text())][2]/preceding-sibling::span[text()]"));
						System.out.println("The size of the elements after F5:"+rl_name_elmnt_region_all.size());
					}catch(Exception e){
						System.out.println("Getting exception.");
						e.printStackTrace();}
				}
				}

			}
			if(remoteDriver.getCurrentUrl().trim().contains("rlName") && !remoteDriver.findElement(By.xpath("(//body[contains(normalize-space(@class),'desktop')])[1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------RELATED LIST VIEW-----------");


				List<WebElement> columns_rl_col_elmnt = remoteDriver.findElements(By.xpath(xp_lui_common_part+"/descendant::div[@class='centerRegion' or 'displayArea']/descendant::div[contains(@class,'listViewContent')]/descendant::table[@data-aura-class='uiVirtualDataTable' or 'uiVirtualDataGrid'][1]/descendant::tr[1]/th[@title]"));
				for(WebElement each_columns_rl_col_elmnt: columns_rl_col_elmnt) 
				{
					HighLight(each_columns_rl_col_elmnt);
					System.out.println("Columns are:"+each_columns_rl_col_elmnt.getAttribute("title").toString().trim());

					if(!each_columns_rl_col_elmnt.getAttribute("title").toString().trim().equals(""))
					{
						al_rl_col_names.add(each_columns_rl_col_elmnt.getAttribute("title").toString().trim());
					}
				}
			}
			if(remoteDriver.findElement(By.xpath("(//body[contains(normalize-space(@class),'desktop')])[1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				String xp_all_editpage_fields = "//*[local-name()='input' or local-name()='textarea']/ancestor::*[contains(local-name(),'lightning')]//label/descendant-or-self::*[text()]";
				List<WebElement> all_edit_field_label_elmnts = remoteDriver.findElements(By.xpath(xp_all_editpage_fields));
				//List<WebElement> all_edit_field_label_elmnts = remoteDriver.findElements(By.xpath("//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/*[normalize-space(text())][1]")); 
				//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion')][1]/descendant::div[contains(@class,'forceDetailPanel') or contains(@role,'list')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]
				for(WebElement each_edit_field_label: all_edit_field_label_elmnts) 
				{
					if(!each_edit_field_label.getText().trim().equals(""))
					{
						HighLight(each_edit_field_label);
						System.out.println("FIELD:"+each_edit_field_label.getText().trim());
						al_dv_fields.add(each_edit_field_label.getText().trim());
					}
				}

				String xpath_edit_button =	"//div[contains(@class,'windowViewMode') and contains(@class,'isModal active')]/descendant::div[contains(@class,'Footer')]/descendant::button/span[text()]";
				System.out.println("--------- BUTTONS IN EDIT VIEW-----------");
				List<WebElement> edit_buttons_elmnt = remoteDriver.findElements(By.xpath(xpath_edit_button));
				for(WebElement each_button: edit_buttons_elmnt) 
				{
					HighLight(each_button);

					if(!each_button.getText().trim().equals(""))
					{
						System.out.println("BUTTONS IN EDIT VIEW:"+each_button.getText());
						al_buttons.add(each_button.getText().trim());
					}
				}    
				
				/* Author: Sourav, Date: 19th Mar 2020			
				Adding below LOC for capturing elements of App Launchers i.e Objects and Apps
				
				**/ 			 
				String xpath_Apps_Tabs =	"//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::div[contains(@class,'app-launcher')]/descendant::p[contains(@class,'slds-truncate')]/descendant-or-self::*[text()]";
				System.out.println("--------- APPS AND TABS IN APP LAUNCHER -----------");
				List<WebElement> apps_tabs_elmnt = remoteDriver.findElements(By.xpath(xpath_Apps_Tabs));
				for(WebElement each_apps_tabs_elmnt: apps_tabs_elmnt) 
				{
					HighLight(each_apps_tabs_elmnt);

					if(!each_apps_tabs_elmnt.getText().trim().equals(""))
					{
						System.out.println("APPS AND OBJECT NAMES IN APP LAUNCHER:"+each_apps_tabs_elmnt.getText());
						al_all_apps.add(each_apps_tabs_elmnt.getText().trim());
					}
				}    
				
				//Adding below LOC for capturing elements of Tabs from App Launcher i.e Tabs 	
				String xpath_Tabs =	"//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::div[contains(@class,'accordion__content')]/descendant::span[contains(@class,'label-display')]/descendant::p[text()]";
				System.out.println("--------- TABS IN APP LAUNCHER -----------");
				List<WebElement> all_tabs_elmnt = remoteDriver.findElements(By.xpath(xpath_Tabs));
				for(WebElement each_all_tabs_elmnt: all_tabs_elmnt) 
				{
					HighLight(each_all_tabs_elmnt);

					if(!each_all_tabs_elmnt.getText().trim().equals(""))
					{
						System.out.println("OBJECT NAMES IN APP LAUNCHER:"+each_all_tabs_elmnt.getText());
						al_all_tabs.add(each_all_tabs_elmnt.getText().trim());
					}
				}    

				

			}
			
			
			// ******************** Begin Health Cloud Enablement ***********************
			System.out.println("---------Health Cloud Enablement-----------");

			//List<WebElement> all_field_label_HealthCloud_PatientEnroll_elmnts = remoteDriver.findElements(By.xpath("//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()]"));
			List<WebElement> all_field_label_HealthCloud_PatientEnroll_elmnts = remoteDriver.findElements(By.xpath("//label[(contains(@class,'label') and contains(@class,'slds-form')) or contains(@class,'label') or  contains(@class,'slds-checkbox') ]/descendant-or-self::*[text()]"));
			
			//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion')][1]/descendant::div[contains(@class,'forceDetailPanel') or contains(@role,'list')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]
			for(WebElement all_field_label_HealthCloud_PatientEnroll_elmnts_each: all_field_label_HealthCloud_PatientEnroll_elmnts) 
			{
				if(!all_field_label_HealthCloud_PatientEnroll_elmnts_each.getText().trim().equals(""))
				{
					HighLight(all_field_label_HealthCloud_PatientEnroll_elmnts_each);
					System.out.println("FIELD:"+all_field_label_HealthCloud_PatientEnroll_elmnts_each.getText().trim());
					al_HC_dv_fields.add(all_field_label_HealthCloud_PatientEnroll_elmnts_each.getText().trim());
				}
			}
			// ******************** End Health Cloud Enablement ***********************
			
			// ******************** Begin Health Cloud Enablement for button***********************
						
			   String xpath_HC_button =     "//button[contains(@class,'slds-button_brand') or contains(@class,'buttonClassCustom')]";
               System.out.println("--------- BUTTONS HC -----------");
               List<WebElement> buttons_elmnt_HC = remoteDriver.findElements(By.xpath(xpath_HC_button));
               for(WebElement each_button: buttons_elmnt_HC)
               {
                     HighLight(each_button);
                     if(!each_button.getText().trim().equals(""))
                     {
                            System.out.println("BUTTONS in EDIT:"+each_button.getText());
                            al_HC_buttons.add(each_button.getText().trim());
                     }

               }
             
			// ******************** End Health Cloud Enablement for button ***********************
			
			//Creating nexted function call to find elements within iframes
			_Get_and_Store_All_Elements_From_Nested_iFrame();
			
				


			JOptionPane.showMessageDialog(null, "Please Move to Next Capture");

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	
	public void _Get_and_Store_All_Elements_From_Nested_iFrame() throws Exception
	{
		try
		{
			
			int iframeCount = remoteDriver.findElements(By.tagName("iframe")).size();
			System.out.println("iframeCount: -------->"+iframeCount);
			
			for(int i=0;i<iframeCount;i++)
			{
				remoteDriver.switchTo().frame(i);
				_Collect_All_Elements_Labels_and_Store_to_AL();
				_Get_and_Store_All_Elements_From_Nested_iFrame();
				remoteDriver.switchTo().parentFrame();
				
			}
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void _Collect_All_Elements_Labels_and_Store_to_AL() throws Exception

    {

           try{

                                  

                  //-------------- Field Label 0-------------------
                  List<WebElement> all_edit_field_label_elmnts = remoteDriver.findElements(By.xpath("//div[contains(@class,'section-expandable ng-isolate-scope expanded')]/ancestor-or-self::div[1]/descendant::div/descendant::div/descendant::div/descendant::div/descendant::div/descendant::label[text()]"));
                  //div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion')][1]/descendant::div[contains(@class,'forceDetailPanel') or contains(@role,'list')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]
                  for(WebElement each_edit_field_label: all_edit_field_label_elmnts)
                  {

                        if(!each_edit_field_label.getText().trim().equals(""))
                        {
                               HighLight(each_edit_field_label);
                               System.out.println("FIELD:"+each_edit_field_label.getText().trim());
                               al_cus_dv_fields.add(each_edit_field_label.getText().trim());
                        }
                  }
               

                  //-------------- Field Label 1-------------------
                  List<WebElement> all_edit_field_label_elmnts_1 = remoteDriver.findElements(By.xpath("//table[contains(@class,'detailList')]/descendant::label[contains(@class,'label')][text()]")); //Edit Product Configuration Page Field
                  //div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion')][1]/descendant::div[contains(@class,'forceDetailPanel') or contains(@role,'list')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]
                  for(WebElement each_edit_field_label: all_edit_field_label_elmnts_1)
                  {
                        if(!each_edit_field_label.getText().trim().equals(""))
                        {
                               HighLight(each_edit_field_label);
                               System.out.println("FIELD:"+each_edit_field_label.getText().trim());
                               al_cus_dv_fields.add(each_edit_field_label.getText().trim());
                        }
                  }

                 
                

                  //-------------- Field Label 2-------------------
                  List<WebElement> all_field_label_elmnts_2 = remoteDriver.findElements(By.xpath("//label[@for][text()]")); //Edit Product Configuration Page Field
                  //div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion')][1]/descendant::div[contains(@class,'forceDetailPanel') or contains(@role,'list')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]
                  for(WebElement each_edit_field_label: all_field_label_elmnts_2)
                  {
                        if(!each_edit_field_label.getText().trim().equals(""))
                        {
                               HighLight(each_edit_field_label);
                               System.out.println("FIELD:"+each_edit_field_label.getText().trim());
                               al_cus_dv_fields.add(each_edit_field_label.getText().trim());
                        }
                  }
               
                  //String xpath_edit_button =     "//div[contains(@class,'slds-form-element__row')]/descendant::div[1]/descendant::div[2]/descendant::a[text()]";
             
                  //-------------- Button Label 0-------------------
                  String xpath_edit_button = "//button[@type='button' or contains(@class,'btn')]/descendant::*[contains(@class,'btn')][text()]";
                  System.out.println("--------- BUTTONS -----------");
                  List<WebElement> edit_buttons_elmnt = remoteDriver.findElements(By.xpath(xpath_edit_button));
                  for(WebElement each_button: edit_buttons_elmnt)
                  {
                        HighLight(each_button);
                        if(!each_button.getText().trim().equals(""))
                        {
                               System.out.println("BUTTONS in EDIT:"+each_button.getText());
                               al_cus_buttons.add(each_button.getText().trim());
                        }

                  }

             
                  //-------------- Button Label 1-------------------
                  String xpath_button =     "//button[contains(@class,'slds-button-')][text()]";
                  System.out.println("--------- BUTTONS -----------");
                  List<WebElement> buttons_elmnt = remoteDriver.findElements(By.xpath(xpath_button));
                  for(WebElement each_button: buttons_elmnt)
                  {
                        HighLight(each_button);
                        if(!each_button.getText().trim().equals(""))
                        {
                               System.out.println("BUTTONS in EDIT:"+each_button.getText());
                               al_cus_buttons.add(each_button.getText().trim());
                        }

                  }
                

                  //-------------- Button Label 2-------------------
                  String xpath_button2 =    "//input[contains(@class,'slds-button')][@value]";
                  System.out.println("--------- BUTTONS -----------");
                  List<WebElement> buttons_elmnt2 = remoteDriver.findElements(By.xpath(xpath_button2));
                  for(WebElement each_button2: buttons_elmnt2)
                  {
                        HighLight(each_button2);
                        if(!each_button2.getAttribute("value").trim().equals(""))
                        {
                               System.out.println("BUTTONS in EDIT:"+each_button2.getAttribute("value").trim());
                               al_cus_buttons.add(each_button2.getAttribute("value").trim());

                        }

                  }

                  //-------------- Table Cell Text Label 0 -------------------

                  //Getting custom table cell text from active iframe
                  List<WebElement> columns_al_custom_table_col_names_elmnts = remoteDriver.findElements(By.xpath("//div[contains(@class,'table') and contains(@class,'header')]/descendant::*[contains(@class,'cell')][text()]"));
                  //int no_of_custom_table = remoteDriver.findElements(By.xpath("//div[contains(@class,'table') and contains(@class,'header')]/descendant::*[contains(@class,'cell')][text()]")).size();
                  for(WebElement each_columns_al_custom_table_col_names_elmnts: columns_al_custom_table_col_names_elmnts)
                  {
                        HighLight(each_columns_al_custom_table_col_names_elmnts);

                        System.out.println("Columns are:"+each_columns_al_custom_table_col_names_elmnts.getAttribute("title").trim());

                         if(!each_columns_al_custom_table_col_names_elmnts.getAttribute("title").trim().equals(""))

                        {

                        al_custom_tablecell_col_names.add(each_columns_al_custom_table_col_names_elmnts.getAttribute("title").trim());

                        }

                  }

                 

                  //-------------- Table Cell Text Label 1 -------------------

                  //Getting custom table cell text from active iframe

                  List<WebElement> columns_al_custom_table_col_names_elmnts1 = remoteDriver.findElements(By.xpath("//div[@class='slds-box']/descendant::table/descendant-or-self::*[local-name()='th' or local-name()='div'][text()]"));

                  //int no_of_custom_table = remoteDriver.findElements(By.xpath("//div[contains(@class,'table') and contains(@class,'header')]/descendant::*[contains(@class,'cell')][text()]")).size();

                  for(WebElement each_columns_al_custom_table_col_names_elmnts1: columns_al_custom_table_col_names_elmnts1)

                  {

                        HighLight(each_columns_al_custom_table_col_names_elmnts1);

                        System.out.println("Columns are:"+each_columns_al_custom_table_col_names_elmnts1.getAttribute("innerHTML").trim());
                      
                        
                         if(!each_columns_al_custom_table_col_names_elmnts1.getAttribute("innerHTML").trim().equals(""))

                        {

                        	 al_custom_tablecell_col_names.add(each_columns_al_custom_table_col_names_elmnts1.getAttribute("innerHTML").trim());

                        }

                  }

                 

                  //-------------- JSTree Label -------------------

                  List<WebElement> al_custom_text_elmnts = remoteDriver.findElements(By.xpath("//a[contains(@class,'jstree')][text()]"));

                  for(WebElement each_al_custom_text_elmnts: al_custom_text_elmnts)

                  {

                        HighLight(each_al_custom_text_elmnts);

                        System.out.println("Text are:"+each_al_custom_text_elmnts.getText().trim());

                        if(!each_al_custom_text_elmnts.getText().trim().equals(""))

                        {

                               al_custom_JTreeText.add(each_al_custom_text_elmnts.getText().trim());

                        }

                  }

                 

                  //-------------- Custom Tab link  -------------------

                  List<WebElement> al_custom_tab_elmnts = remoteDriver.findElements(By.xpath("//a[contains(@class,'slds-tabs') and @role='tab'][text()]/ancestor::li[@title]"));

                  for(WebElement each_al_custom_tab_elmnts: al_custom_tab_elmnts)

                  {

                        HighLight(each_al_custom_tab_elmnts);

                        System.out.println("Text are:"+each_al_custom_tab_elmnts.getAttribute("title").trim());

                        if(!each_al_custom_tab_elmnts.getAttribute("title").trim().equals(""))

                        {

                               al_custom_JTreeText.add(each_al_custom_tab_elmnts.getAttribute("title").trim());

                        }

                  }         

                 

                  //-------------- Custom Related List -------------------

                  String rl_name_temp = "";

                  List<WebElement> al_cus_rl_names_elmnt = remoteDriver.findElements(By.xpath("//h2/descendant::span[contains(@class,'definition')][text()]"));

                  System.out.println("Count of custom RL:"+al_cus_rl_names_elmnt.size());

                 

                  for(WebElement al_cus_rl_names_each: al_cus_rl_names_elmnt)

                  {
                        HighLight(al_cus_rl_names_each);
                        System.out.println("custom RL are:"+al_cus_rl_names_each.getText().trim());
                        if(!al_cus_rl_names_each.getText().trim().equals(""))
                        {
                               al_cus_rl_names.add(al_cus_rl_names_each.getText().trim()); //will not use but just storing for can be useful for any enhancements
                               rl_name_temp = al_cus_rl_names_each.getText().trim();
                               System.out.println("rl_name_temp:"+rl_name_temp);
                               //Getting column within each custom RL
                               //List<WebElement> al_cus_rlname_plus_col_elmnt = remoteDriver.findElements(By.xpath("//h2/descendant::span[contains(@class,'definition')][normalize-space(text())='"+rl_name_temp+"']/ancestor::div[contains(@class,'header')][1]/following-sibling::*[1]/descendant::thead/descendant::th[text()]")); //We noticed strange behaviour in DOM, sometimes following sibling element is div and sometimes it is table

                               List<WebElement> al_cus_rlname_plus_col_elmnt = remoteDriver.findElements(By.xpath("//h2/descendant::span[contains(@class,'definition')][normalize-space(text())='"+rl_name_temp+"']/ancestor::div[contains(@class,'header')][1]/following-sibling::*[1]/descendant::thead/descendant-or-self::*[local-name()='div' or local-name()='th'][not(descendant::*)][text()]")); //We noticed strange behaviour in DOM, sometimes following sibling element is div and sometimes it is table
                               System.out.println("column no:->"+al_cus_rlname_plus_col_elmnt.size());

                               for(WebElement al_cus_rlname_plus_col_each: al_cus_rlname_plus_col_elmnt)
                               {
                                      HighLight(al_cus_rlname_plus_col_each);
                                      //System.out.println("Custom RL Column Name are:"+al_cus_rlname_plus_col_each.getText().trim());
                                      if(!al_cus_rlname_plus_col_each.getAttribute("innerHTML").trim().equals(""))
                                      {
                                             al_cus_rlname_plus_col.add(rl_name_temp + "_" +al_cus_rlname_plus_col_each.getAttribute("innerHTML").trim());
                                             System.out.println("Custom RL+CoLUMN: "+rl_name_temp + "_" +al_cus_rlname_plus_col_each.getAttribute("innerHTML").trim());

                                      }

                               }

                        }

                  }

                 

                 

           }catch(Exception e)

           {

                  e.printStackTrace();

           }

    }
	
	public void _CreateAUTRepository_LU_Custome() throws Exception
	{

		al_dv_fields = new ArrayList();
		al_rl_names = new ArrayList();
		al_rl_col_names = new ArrayList();
		al_rlname_plus_col = new ArrayList();
		al_buttons = new ArrayList();
		//System.out.println("size of all number of fields: "+remoteDriver.switchTo().frame("(//iframe[contains(@id,'vfFrameId_')])[2]").switchTo().frame("//iframe[contains(@src,'ConfigureProduct')][1]").findElements(By.xpath("//table[contains(@class,'detailList')]/tbody/tr/td/label[text()]")).size());
		//		System.out.println("size of all number of fields: "+remoteDriver.switchTo().frame(0).switchTo().frame().findElements(By.xpath("//table[contains(@class,'detailList')]/tbody/tr/td/label[text()]")).size());

		//		System.out.println("no Of Elements in a frame:"+remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("(//iframe[contains(@id,'vfFrameId_')])[2]"))).switchTo().frame(remoteDriver.findElement(By.xpath("//iframe[contains(@src,'ConfigureProduct')][1]"))).findElements(By.xpath("//table[contains(@class,'detailList')]/tbody/tr/td/label[text()]")).size());

		//		if(remoteDriver.findElements(By.xpath("//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::iframe")).size()>=1){
		if(remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::iframe"))).findElements(By.xpath("//div[contains(@class,'section-expandable ng-isolate-scope expanded')]/ancestor-or-self::div[1]/descendant::div/descendant::div/descendant::div/descendant::div/descendant::div/descendant::label[text()]")).size()>0){
			System.out.println("iframe identified");
			System.out.println("switched to iframe identified");
			//			System.out.println(remoteDriver.findElement(By.xpath("//*[@id='oppSingleServicePgID:mainOpp:pgblkid']/div[1]/div/fieldset/div/label[1]")).getText());

			System.out.println("---------iframe Elements-----------");


			//expand

			//div/div/div[1]/div[contains(@class,'section-expandable ng-isolate-scope')]/div[1]

			sfdc.obj_vd= remoteDriver.findElement(By.xpath("//h4[text()]")).getText();
			System.out.println("sfdc.obj_vd"+sfdc.obj_vd);

			if(remoteDriver.findElements(By.xpath("//div/div/div/div[contains(@class,'section-expandable ng-isolate-scope')]/div[1]")).size()>0){
				for(int i =1;i<=remoteDriver.findElements(By.xpath("//div/div/div/div[contains(@class,'section-expandable ng-isolate-scope')]/div[1]")).size();i++){
					if(!remoteDriver.findElement(By.xpath("//div/div/div["+i+"]/div[contains(@class,'section-expandable ng-isolate-scope')]")).getAttribute("class").contains("expanded")){
						System.out.println("--------True-----------");
						remoteDriver.findElement(By.xpath("//div/div/div["+i+"]/div[contains(@class,'section-expandable ng-isolate-scope')]/div[1]")).click();
					}
				}
			}

			List<WebElement> all_edit_field_label_elmnts = remoteDriver.findElements(By.xpath("//div[contains(@class,'section-expandable ng-isolate-scope expanded')]/ancestor-or-self::div[1]/descendant::div/descendant::div/descendant::div/descendant::div/descendant::div/descendant::label[text()]")); //including task page, need to test
			//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion')][1]/descendant::div[contains(@class,'forceDetailPanel') or contains(@role,'list')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]
			for(WebElement each_edit_field_label: all_edit_field_label_elmnts) 
			{
				if(!each_edit_field_label.getText().trim().equals(""))
				{
					HighLight(each_edit_field_label);
					System.out.println("FIELD:"+each_edit_field_label.getText().trim());
					al_dv_fields.add(each_edit_field_label.getText().trim());
				}
			}
			
			//button
			//descendant::div/*[local-name()='div' or local-name()='span']/descendant::div[contains(@class,'btn-group-wrapper')]/button[text()]
			String xpath_edit_button =	"//button[contains(@ng-class,'button.cssClass')][text()]";

			System.out.println("--------- BUTTONS -----------");
			List<WebElement> edit_buttons_elmnt = remoteDriver.findElements(By.xpath(xpath_edit_button));
			for(WebElement each_button: edit_buttons_elmnt) 
			{
				HighLight(each_button);

				if(!each_button.getText().trim().equals(""))
				{
					System.out.println("BUTTONS:"+each_button.getText());
					al_buttons.add(each_button.getText().trim());
				}
			}  
			
			//Related List
			//Related List

			//div[@class='page-block']/descendant::h4[text()]

			String local_rlname = "";
			List<WebElement> rl_name_elmnt_region_all = remoteDriver.findElements(By.xpath("//div[@class='page-block']/descendant::h4[text()]")); //only checking 2nd span because only second span has (4) pattern
			////div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::h2/descendant::a[contains(@class,'header-link')]/descendant::span[@title=normalize-space(text())][2]/preceding-sibling::span[text()]
			//xp_lui_common_part + ""/descendant::b[text()]""
			System.out.println("rl_name_elmnt_region_all.size(): "+rl_name_elmnt_region_all.size());
			for(int p=0;p<rl_name_elmnt_region_all.size();p++)
			{
				try{

					WebElement rl_name_elmnt_region = rl_name_elmnt_region_all.get(p);
					HighLight(rl_name_elmnt_region);
					System.out.println("RL_NAME:"+rl_name_elmnt_region.getText().toString().trim());
					if(!rl_name_elmnt_region.getText().toString().trim().equals(""))
					{
						al_rl_names.add(rl_name_elmnt_region.getText().toString().trim());
						local_rlname = rl_name_elmnt_region.getText().toString().trim();
					}


					//Getting all the columns after clicking on each related list link
					//List<WebElement> columns_rl_view_elmnt_all = GetWebDriver().findElements(By.xpath("//descendant::tr[contains(@class,'slds-text-title--caps')]/descendant::span[text()]"));

					List<WebElement> columns_rl_view_elmnt_all = remoteDriver.findElements(By.xpath("//div[normalize-space(@class)='table-header expanded'][1]/descendant::div[text()]"));
//					List<WebElement> columns_rl_view_elmnt_all = remoteDriver.findElements(By.xpath("//div[contains(@class,'table-header')][1]/descendant::div[text()]"));
					
					for(WebElement columns_rl_view_elmnt: columns_rl_view_elmnt_all) 
					{
						String COL_NM = "";   
						COL_NM = remoteDriver.executeScript("return arguments[0].textContent;",columns_rl_view_elmnt).toString().trim();
						System.out.println("RL COLMN:"+COL_NM);
						//System.out.println("RL COLUMN:"+columns_rl_view_elmnt.getText().toString().trim());
						if(!COL_NM.equals(""))
						{
							HighLight(columns_rl_view_elmnt);
							al_rl_col_names.add(COL_NM);
							sfdc.al_rlname_plus_col.add(local_rlname+":"+COL_NM);
						}
					}
					
					
					Thread.sleep(1000L);
					System.out.println("The size of the elements after F5:"+rl_name_elmnt_region_all.size());

				}catch(Exception e){
					System.out.println("Getting exception.");
					e.printStackTrace();}
			}
			
			//-------------------------//
			
			if(remoteDriver.findElements(By.xpath("//ul/li/a[contains(@class,'tab')][text()]")).size()>0){
				List<WebElement> alltabs = remoteDriver.findElements(By.xpath("//ul/li/a[contains(@class,'tab')][text()]"));
				for(int i=1;i<=alltabs.size();i++) 
				{
					if(remoteDriver.findElement(By.xpath("//ul/li["+i+"]/a[contains(@class,'tab')][text()]")).getText().equals("RELATED")){
						ClickByJSFocus(remoteDriver.findElement(By.xpath("//ul/li["+i+"]/a[contains(@class,'tab')][text()]")));
						WaitForPageToLoad(30);
//						remoteDriver.findElement(By.xpath("//ul/li["+i+"]/a[contains(@class,'tab')][text()]")).click();

						String local_rlname_Related = "";
						List<WebElement> rl_name_elmnt_region_all_Related = remoteDriver.findElements(By.xpath("//div[@class='page-block']/descendant::h4[text()]")); //only checking 2nd span because only second span has (4) pattern
						////div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::h2/descendant::a[contains(@class,'header-link')]/descendant::span[@title=normalize-space(text())][2]/preceding-sibling::span[text()]
						//xp_lui_common_part + ""/descendant::b[text()]""
						System.out.println("rl_name_elmnt_region_all_Related.size(): "+rl_name_elmnt_region_all_Related.size());
						for(int p=0;p<rl_name_elmnt_region_all_Related.size();p++)
						{
							try{

								WebElement rl_name_elmnt_region_Related = rl_name_elmnt_region_all_Related.get(p);
								HighLight(rl_name_elmnt_region_Related);
								System.out.println("RL_NAME:"+rl_name_elmnt_region_Related.getText().toString().trim());
								if(!rl_name_elmnt_region_Related.getText().toString().trim().equals(""))
								{
									al_rl_names.add(rl_name_elmnt_region_Related.getText().toString().trim());
									local_rlname_Related = rl_name_elmnt_region_Related.getText().toString().trim();
								}
								//Related Links
								List<WebElement> columns_rl_view_elmnt_all_related = remoteDriver.findElements(By.xpath("//div[normalize-space(@class)='table-header'][1]/descendant::div[text()]"));
								//				List<WebElement> columns_rl_view_elmnt_all = remoteDriver.findElements(By.xpath("//div[contains(@class,'table-header')][1]/descendant::div[text()]"));
								for(WebElement columns_rl_view_elmnt_related: columns_rl_view_elmnt_all_related) 
								{
									String COL_NM = "";   
									COL_NM = remoteDriver.executeScript("return arguments[0].textContent;",columns_rl_view_elmnt_related).toString().trim();
									System.out.println("RL COLMN:"+COL_NM);
									//System.out.println("RL COLUMN:"+columns_rl_view_elmnt.getText().toString().trim());
									if(!COL_NM.equals(""))
									{
										HighLight(columns_rl_view_elmnt_related);
										al_rl_col_names.add(COL_NM);
										sfdc.al_rlname_plus_col.add(local_rlname_Related+":"+COL_NM);
									}
								}
							}catch (Exception e) {
								// TODO: handle exception
							}
						}
					}
				}
			}
			//-------------------------//
		}
		remoteDriver.switchTo().defaultContent();
		remoteDriver.switchTo().defaultContent();
		
		//		System.out.println("no Of Elements in a frame:"+remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("(//iframe[contains(@id,'vfFrameId_')])[2]"))).switchTo().frame(remoteDriver.findElement(By.xpath("//iframe[contains(@src,'ConfigureProduct')][1]"))).findElements(By.xpath("//table[contains(@class,'detailList')]/tbody/tr/td/label[text()]")).size());
		if(!sfdc.obj_vd.equals("Product Basket")){
			if(remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("(//iframe[contains(@id,'vfFrameId_')])[2]"))).switchTo().frame(remoteDriver.findElement(By.xpath("//iframe[contains(@src,'ConfigureProduct')][1]"))).findElements(By.xpath("//table[contains(@class,'detailList')]/tbody/tr/td/label[text()]")).size()>0){
				
				sfdc.obj_vd= remoteDriver.findElement(By.xpath("//h1[text()]")).getText();
				System.out.println("inside"+sfdc.obj_vd);
				/*List<WebElement> edit_obj_vd = remoteDriver.findElements(By.xpath("//h4[text()]")); //including task page, need to test
				//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion')][1]/descendant::div[contains(@class,'forceDetailPanel') or contains(@role,'list')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]
				for(WebElement obj_vd: edit_obj_vd) 
				{
					if(obj_vd.getText().trim().equals("EditProductConfiguration")
							|| obj_vd.getText().trim().equals("Edit Product Configuration"))
					{
						System.out.println("FIELD:"+obj_vd.getText().trim());
						sfdc.obj_vd=obj_vd.getText().trim();
					}
				}*/
				
				System.out.println("sfdc.obj_vd"+sfdc.obj_vd);
				//				System.out.println("no Of Elements in a frame:"+remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("(//iframe[contains(@id,'vfFrameId_')])[2]"))).switchTo().frame(remoteDriver.findElement(By.xpath("//iframe[contains(@src,'ConfigureProduct')][1]"))).findElements(By.xpath("//table[contains(@class,'detailList')]/tbody/tr/td/label[text()]")).size());
				//				remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("(//iframe[contains(@id,'vfFrameId_')])[2]"))).switchTo().frame(remoteDriver.findElement(By.xpath("//iframe[contains(@src,'ConfigureProduct')][1]")));
				List<WebElement> all_CU_edit_field_label_elmnts = remoteDriver.findElements(By.xpath("//table[contains(@class,'detailList')]/tbody/tr/td/label[text()]")); //including task page, need to test
				//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'row row-main')  or contains(@class,'row centerRegion')][1]/descendant::div[contains(@class,'forceDetailPanel') or contains(@role,'list')][1]/descendant::div[contains(@class,'field-label')]/span[contains(@class,'field-label')][1]
				for(WebElement each_cu_edit_field_label: all_CU_edit_field_label_elmnts) 
				{
					if(!each_cu_edit_field_label.getText().trim().equals(""))
					{
						HighLight(each_cu_edit_field_label);
						System.out.println("FIELD:"+each_cu_edit_field_label.getText().trim());
						al_dv_fields.add(each_cu_edit_field_label.getText().trim());
					}
				}
				
				//button
				//div[contains(@class,'btn-group-wrapper')]/button[text()]
				String xpath_edit_button =	"//div[contains(@class,'slds-button-group finishButtons')]/button[text()]";

				System.out.println("--------- BUTTONS -----------");
				List<WebElement> edit_buttons_elmnt = remoteDriver.findElements(By.xpath(xpath_edit_button));
				for(WebElement each_button: edit_buttons_elmnt) 
				{
					HighLight(each_button);

					if(!each_button.getText().trim().equals(""))
					{
						System.out.println("BUTTONS in EDIT:"+each_button.getText());
						al_buttons.add(each_button.getText().trim());
					}
				}  
				
				remoteDriver.switchTo().defaultContent();
			}
		}
		//start of create file//
		sfdc.al_rl_names = (ArrayList) sfdc.al_rl_names.stream().distinct().collect(Collectors.toList());
		
		for(String s:sfdc.al_rl_names)
		{
			System.out.println("al_rl_names---->"+s);
		}
		sfdc.al_rl_col_names = (ArrayList) sfdc.al_rl_col_names.stream().distinct().collect(Collectors.toList());
		for(String s:sfdc.al_rl_col_names)
		{
			System.out.println("al_rl_col_names---->"+s);
		}
		sfdc.al_rlname_plus_col = (ArrayList) sfdc.al_rlname_plus_col.stream().distinct().collect(Collectors.toList());
		for(String s:sfdc.al_rlname_plus_col)
		{
			System.out.println("---->"+s);
		}
		sfdc.al_dv_fields = (ArrayList) sfdc.al_dv_fields.stream().distinct().collect(Collectors.toList());			
		for(String s:sfdc.al_dv_fields)
		{
			System.out.println("al_dv_fields---->"+s);
		}
		sfdc.al_buttons = (ArrayList) sfdc.al_buttons.stream().distinct().collect(Collectors.toList());
		for(String s:sfdc.al_buttons)
		{
			System.out.println("al_buttons---->"+s);
		}
		
			
		/*************** Generic Part of the Content of Screen File ******************/
		String classname = sfdc.obj_vd.trim().replace("+", "").replace("&", "")
				.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
				.replace("-", "").replace(" ", "").replace("*", "")
				.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
				.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
				.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
		
		sfdc.screenname = classname;
		sfdc.contentofscreenfile = "package USER_SPACE.ObjectRepository; \n"
				+ "import SOURCE_CODE.SFDC.*; \n"
				+ "import org.openqa.selenium.remote.RemoteWebDriver; \n"
				+ "import io.appium.java_client.AppiumDriver;  \n"
				+ "import USER_SPACE.TestPrerequisite.*; \n"
				+ "\n \n \n"
				+ "public class "
				+ classname
				+" extends SFDCAutomationFW{ \n"
				+ "SFDCAutomationFW sfdc; \n"
				+ "String RList = \"\"; \n\n\n\n"
				+ "public "+classname+"(RemoteWebDriver remoteDriver) { \n"
				+ "super(remoteDriver); \n"
				+ "sfdc = new SFDCAutomationFW(remoteDriver); \n"
				+ "} \n\n\n"
				+ "public "+classname+"(AppiumDriver appiumDriver) { \n"
				+ "super(appiumDriver); \n"
				+ "sfdc = new SFDCAutomationFW(appiumDriver); \n"
				+ "}\n\n"
				+ "// ************************ Functions for Fields ************************************** \n \n ";
			String sub= "";
				for(String s:sfdc.al_dv_fields)
				{
					sub = s.trim();
					sfdc.contentofscreenfile = sfdc.contentofscreenfile 
							+ "public CustomMemberOfField_LUI "+s.trim().replace("+", "").replace("&", "")
							.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
							.replace("-", "").replace(" ", "").replace("*", "")
							.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
							.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
							.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "")
							+"Field() throws Exception{  \n" 
							+ "return sfdc.Field_Custom(\""+sub+"\"); \n" 
							+  "} \n \n"; 						
				
				}
				
				sfdc.contentofscreenfile = sfdc.contentofscreenfile 

						+ "// ************************ Functions and Static Classes for Related Lists ************************************** \n \n ";
				
				String sub_each_rlname = "";
				String each_rlname_changed = "";
				String each_rlname_plus_col = "";
				String each_col_asperapp = "";
				String each_col_changed = "";
				String each_rl_button_asperapp = "";
				String each_rl_button_changed = "";
				
				for(String each_rlname:sfdc.al_rl_names)
				{
					
					sub_each_rlname = each_rlname.trim();
					each_rlname_changed = each_rlname.trim().replace("+", "").replace("&", "")
							.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
							.replace("-", "").replace(" ", "").replace("*", "")
							.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
							.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
							.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
							
					sfdc.contentofscreenfile = sfdc.contentofscreenfile 
							
					+ "public Columns_"+each_rlname_changed+" RL_"+each_rlname_changed+"() throws Exception{ \n" 
					+ "return new Columns_"+each_rlname_changed+"(\""+sub_each_rlname+"\"); \n" 
					+ "} \n" 
							
					+ "public class Columns_"+each_rlname_changed+" \n"
					+ "{ \n"
					+ "Columns_"+each_rlname_changed+"(String RL) \n"
					+ "{ \n"
					+ "RList = RL;  \n"
					+ "}  \n";
					
					for(String s:sfdc.al_rlname_plus_col)
					{
						if(s.trim().startsWith(sub_each_rlname+":"))
						{
							each_col_asperapp = s.trim().replace(sub_each_rlname+":", "").trim();
							each_rlname_changed = each_col_asperapp.trim().replace("+", "").replace("&", "")
									.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
									.replace("-", "").replace(" ", "").replace("*", "")
									.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
									.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
									.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
							
							sfdc.contentofscreenfile = sfdc.contentofscreenfile 
									
									+ "public MemberOfRL_LUI "+each_rlname_changed+"() throws Exception \n"
									+ "{ \n"
									+ "return sfdc.RL_LUI(RList,\""+each_col_asperapp+"\"); \n"
									+ "} \n"
									+ "public MemberOfRL_LUI "+each_rlname_changed+"(String TargetCOlumnValue) throws Exception \n"
									+ "{ \n"
									+ "return sfdc.RL_LUI(RList,\""+each_col_asperapp+"\",TargetCOlumnValue); \n"
									+ "} \n";
						}
					}
					
					for(String s:sfdc.al_rlname_plus_buttons)
					{
						if(s.trim().startsWith(sub_each_rlname+":"))
						{
							each_rl_button_asperapp = s.trim().replace(sub_each_rlname+":", "").replace("Button:", "").trim();
							each_rl_button_changed = each_rl_button_asperapp.replace("+", "").replace("&", "")
									.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
									.replace("-", "").replace(" ", "").replace("*", "")
									.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
									.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
									.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
							
							sfdc.contentofscreenfile = sfdc.contentofscreenfile 
									
									+ "public MemberOfRL_LUI "+each_rl_button_changed+"Button() throws Exception  \n"
									+ "{ \n"
									+ "return sfdc.RL_LUI(RList,\""+each_rl_button_asperapp+"Button\");  \n"
									+ "} \n";
						}
					}
					sfdc.contentofscreenfile = sfdc.contentofscreenfile 
									
									+ "public MemberOfRL_LUI RelatedListLink() throws Exception  \n"
									+ "{ \n"
									+ "return sfdc.RL_LUI(RList,\"RelatedListLink\"); \n"
									+ "} \n"
									+ "public MemberOfRL_LUI RelatedListItem() throws Exception  \n"
									+ "{ \n"
									+ "return sfdc.RL_LUI(RList,\"RelatedListItem\");  \n"
									+ "} \n } \n";
									
				}
				
				String each_button_asperapp = "";
				String each_button_changed = "";
				
				sfdc.contentofscreenfile = sfdc.contentofscreenfile
				+ "//************************* Functions for Buttons List ***************************** // \n \n";
				
				for(String s:sfdc.al_buttons)
				{
					each_button_asperapp = s.trim();
					each_button_changed = s.trim().replace("+", "").replace("&", "")
					.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
					.replace("-", "").replace(" ", "").replace("*", "")
					.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
					.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
					.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
					
					sfdc.contentofscreenfile = sfdc.contentofscreenfile 
							
					
					+ "public CustomMemberOfButton_LUI "+each_button_changed+"Button() throws Exception{ \n" 
					+ "return sfdc.Button_Custom(\""+each_button_asperapp+"\"); \n"
					+ "} \n";
											
				}
				
				sfdc.contentofscreenfile = sfdc.contentofscreenfile 
						+ "} \n \n";
							
							
//				_CreateScreenFile();
						
				
		//end of file
		

		JOptionPane.showMessageDialog(null, "Please Move to Next Capture");
	}
	public void ClickByJSFocus(WebElement we) 
	{
		try{

			remoteDriver.executeScript("arguments[0].focus();", we);
			Thread.sleep(2000L);
			remoteDriver.executeScript("arguments[0].click();", we);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return On Success it returns the entire URL of the WebDriver browser window, on Failure it returns blank value
	 * @throws Exception
	 * @Description Copies the Current URL of the WebDriver browser window, on Failure it returns blank value
	 * @Date Aug 7, 2014
	 */
	public String GetCurrentURL() throws Exception
	{
		WaitForPageToLoad(30);
		try 
		{

			return remoteDriver.getCurrentUrl();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "";
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param URL
	 * @return void
	 * @throws Exception
	 * @Description Opens page in already opened browser as per supplied URL
	 * @Date Aug 7, 2014
	 */
	public void OpenSFDCRecordAsperURL(String URL) throws Exception
	{
		WaitForPageToLoad(15);
		try 
		{
			remoteDriver.get(URL);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return The datevalue in String type as per format ddMMyyHHmmss 
	 * @throws Exception
	 * @Description 
	 * @Date Aug 7, 2014
	 */
	public String GetCurrentDateTimeStamp() throws Exception
	{

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyHHmmss");
		return (sdf.format(cal.getTime()));                     

	}


	/**
	 * @author Cognizant
	 * @param Year
	 * @param Month
	 * @param Date
	 * @return true of the date is selected successfully else return false
	 * @Description You should click on the date lookup field to enable the OOB date lookup, then only you can call this function to select any specific date by year,month and date
	 * @throws Exception
	 */
	public synchronized boolean SelectFromDateLookup(String Year,String Month,String Date) throws Exception
	{
		try
		{
			//remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='datePicker' and contains(normalize-space(@style),'block')][1]/descendant-or-self::td[contains(normalize-space(@class),'selectedDate')][1]")).click();

			//Selecting the Year as supplied
			Year = Year.replace(".0", "").replace(".00", "");
			Date = Date.replace(".0", "").replace(".00", "");
			//WebElement getsingleWebelement = remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='datePicker' and contains(normalize-space(@style),'block')][1]/descendant-or-self::select[@title='Year'][1]"));
			WebElement getsingleWebelement = remoteDriver.findElement(By.xpath("//div[contains(@class,'datepicker')][@role='dialog'][contains(@aria-label,'picker')]//select[1]"));
			
			Select s = new Select(getsingleWebelement);
			s.selectByVisibleText(Year);

			System.out.println("Month is:"+Month);
			//Selecting the Month as supplied
			getsingleWebelement = remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='datePicker' and contains(normalize-space(@style),'block')][1]/descendant-or-self::select[@title='Month'][1]"));
			s = new Select(getsingleWebelement);
			s.selectByVisibleText(Month);


			//Selecting the Date as supplied
			if(Date.substring(0, 1).equals("0"))
			{
				Date = Date.replace("0", "");
			}
			remoteDriver.findElement(By.xpath("//div[normalize-space(@class)='datePicker' and contains(normalize-space(@style),'block')][1]/descendant-or-self::table[normalize-space(@class)='calDays'][1]/descendant-or-self::td[normalize-space(text())='"+Date+"'][1]")).click();


			System.out.println("Supplied date value ("+Date+" "+Month+" "+Year+") is selected from date lookup.");
			AddLogToCustomReport("Supplied date value ("+Date+" "+Month+" "+Year+") is selected from date lookup.", "Pass");
			return true;

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println();
			AddLogToCustomReport("Unable to select the supplied date from SFDC Date lookup.", "Fail");
			return false;
		}

	}

	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return WebDriver
	 * @throws Exception
	 * @Description Returns the WebDriver instance
	 * @Date Aug 7, 2014
	 */
	public RemoteWebDriver GetWebDriver() throws Exception
	{

		if(remoteDriver==null)
		{
			remoteDriver = (RemoteWebDriver) myWD;
		}
		return remoteDriver;
	}

	//Selects todays date from date lookup.
	//param nextdaycount starts from 0,1,2 i.e. today,tomorrow,day after tomorrow so on.
	public void SelectFromDateLookupByIndex(int nextdaycount) throws Exception
	{
		try
		{
			//selecting any other days than today
			if(nextdaycount != 0)
			{
				String xp_today = "//*[contains(@class,'is-today')][1]//*[text()][1]";
				String todayis = remoteDriver.findElement(By.xpath(xp_today)).getText();
				
				
				String xp_all_days = "((//td[contains(@class,'is-today')]/ancestor::tbody)[1]//td//*[text()])";
				List<WebElement> all_days_e = remoteDriver.findElements(By.xpath(xp_all_days));
				int i=0;
				for(WebElement each_day:all_days_e)
				{
					i=i+1;
					if (each_day.getText().equalsIgnoreCase(todayis))
					{
						System.out.println("The index for todays date is:"+i);
						break;					
					}
					
				}
				i = i + nextdaycount;
				String xp = "((//td[contains(@class,'is-today')]/ancestor::tbody)[1]//td//*[text()])["+i+"]";	
				remoteDriver.findElement(By.xpath(xp)).click();
				AddLogToCustomReport("Successfully clicked on selected date...", "Pass");
			}
			else
			{
				String xp_today = "//*[contains(@class,'is-today')][1]//*[text()][1]";
				remoteDriver.findElement(By.xpath(xp_today)).click();
				AddLogToCustomReport("Successfully clicked on todays date...", "Pass");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to select todays date", "Fail");
		}
	}
	
	/**

	 */
	/**
	 * @author Cognizant
	 * @Description This function selects a date from Salesforce date lookup as per supplied parameter.
	 * @param nextdaycount starts from 0,1,2 i.e. today,tomorrow,day after tomorrow so on.
	 * @return
	 * @throws Exception
	 */
	public boolean SelectFromDateLookup(int nextdaycount) throws Exception
	{
		try
		{
			//selecting today's date
			if(nextdaycount == 0)
			{
				Calendar cal = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
				String D = sdf.format(cal.getTime()).toString().substring(0, sdf.format(cal.getTime()).toString().indexOf(" ")).trim();
				List<String> DMY = new ArrayList();
				for (String val: sdf.format(cal.getTime()).toString().split(" ", 3))
				{
					DMY.add(val);

				}
				for(int i=0;i<DMY.size();i++)
				{
					System.out.println(DMY.get(i));
				}

				sfdc.SelectFromDateLookup(DMY.get(2),DMY.get(1),DMY.get(0));


			}
			//Selecting today + nextdaycount 
			if (nextdaycount > 0)
			{
				String DAY="",mon="";
				Calendar cal = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
				String D = sdf.format(cal.getTime()).toString().substring(0, sdf.format(cal.getTime()).toString().indexOf(" ")).trim();
				List<String> DMY = new ArrayList();
				for (String val: sdf.format(cal.getTime()).toString().split(" ", 3))
				{
					DMY.add(val);

				}
				String month = DMY.get(1);
				int totaldaycount = Integer.valueOf(DMY.get(0)).intValue() + nextdaycount;
				System.out.println("totaldaycount");
				//Calculating 31 day month and the related day
				if (DMY.get(1).contains("Jan") ||DMY.get(1).contains("Mar")||DMY.get(1).contains("May")||DMY.get(1).contains("Jul")||DMY.get(1).contains("Aug")||DMY.get(1).contains("Oct")||DMY.get(1).contains("Dec"))
				{
					if(totaldaycount>31)
					{
						Calendar currentMonth = Calendar.getInstance();
						SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM");
						currentMonth.add(Calendar.MONTH, 1);
						mon = dateFormat.format(currentMonth.getTime());
						int day = totaldaycount - 31;
						DAY = Integer.toString(day);

					}
					else
					{
						Calendar currentMonth = Calendar.getInstance();
						SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM");
						mon = dateFormat.format(currentMonth.getTime());
						int day = totaldaycount;
						DAY = Integer.toString(day);

					}
				}
				//Calculating 30 day month and the related day
				if (DMY.get(1).contains("Apr") ||DMY.get(1).contains("Jun")||DMY.get(1).contains("Sep")||DMY.get(1).contains("Nov")) 
				{
					if(totaldaycount>30) 
					{
						Calendar currentMonth = Calendar.getInstance();
						SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM");
						currentMonth.add(Calendar.MONTH, 1);
						mon = dateFormat.format(currentMonth.getTime());
						int day = totaldaycount - 30;
						DAY = Integer.toString(day);

					}
					else
					{
						Calendar currentMonth = Calendar.getInstance();
						SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM");
						//currentMonth.add(Calendar.MONTH, 1);
						mon = dateFormat.format(currentMonth.getTime());
						int day = totaldaycount;
						DAY = Integer.toString(day);
					}
				}
				//Calculating 28 day month and the related day
				if (DMY.get(1).contains("Feb")  && (totaldaycount>28) ) 
				{
					Calendar currentMonth = Calendar.getInstance();
					SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM");
					currentMonth.add(Calendar.MONTH, 1);
					mon = dateFormat.format(currentMonth.getTime());
					int day = totaldaycount - 28;
					DAY = Integer.toString(day);

				}
				//Calculating 28 day month and the related day
				if (DMY.get(1).contains("Feb")  && (totaldaycount<28) ) 
				{
					Calendar currentMonth = Calendar.getInstance();
					SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM");
					currentMonth.add(Calendar.MONTH, 1);
					mon = dateFormat.format(currentMonth.getTime());
					int day = totaldaycount;
					DAY = Integer.toString(day);

				}
				System.out.println("Date Value Selected was: "+DMY.get(2)+" "+mon+" "+DAY);
				sfdc.SelectFromDateLookup(DMY.get(2),mon,DAY);
			}
			return true;

		}
		catch(Exception e)
		{

			return false;
		}
	}
	
	/**
		 * @author Cognizant
		 * @Description This function selects a specific day in the date look up calendar in Salesforce Lightning date lookup.
		 * @param DayInCalendar is the displayed Day showing in calendar
		 * @throws Exception
	*/	
	public void SelectFromDateLookup_LU(String DayInCalendar) throws Exception
	{
		
		String xp_date_lookup = "(//div[contains(@class,'datepicker')][@role='dialog'][contains(@aria-label,'picker')])[1]";
		String xp_my_target_day_element = xp_date_lookup + "//tr//td//*[contains(@class,'day')][normalize-space(text())='"+DayInCalendar+"'][1]";
		try {
			remoteDriver.findElement(By.xpath(xp_my_target_day_element)).click();					
			
			AddLogToCustomReport("Successfully able to select the day ("+DayInCalendar+") from date lookup", "Pass");
		}catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to pick the date from date lookup", "Fail");
			
		}
	}
	
	public void copy(String text) {
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();

		StringSelection selection = new StringSelection(text);
		clipboard.setContents(selection, null);
	}

	public void paste() {
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		DataFlavor flavor = DataFlavor.stringFlavor;
		if (clipboard.isDataFlavorAvailable(flavor)) {
			try {
				String text = (String) clipboard.getData(flavor);
				System.out.println(text);
			} catch (UnsupportedFlavorException e) {
				System.out.println(e);
			} catch (IOException e) {
				System.out.println(e);
			}
		}
	}

	/**
	 * @param pathoffile
	 * @Description csv file needs to be kept in D drive, need to improvise this part of code
	 * @return
	 * @throws Exception
	 */
	public boolean Browse(String pathoffile) throws Exception
	{
		try 
		{
			remoteDriver.findElement(By.xpath("//input[@type='file' and @name='file'][1]")).click();
			Thread.sleep(2000L);

			//Keyboard keyboard = new Keyboard();

			copy(pathoffile);

			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(1000L);;
			PressENTERKeyOnWindowAlert();


			//Robot robot = new Robot(); 
			//robot.keyPress(KeyEvent.VK_C);
			//robot.keyRelease(KeyEvent.VK_C);

			//robot.keyPress(KeyEvent.);
			//robot.keyRelease(KeyEvent.VK_C);



			AddLogToCustomReport("Browsing file selection is successful.", "Pass");
			System.out.println("Browsing file selection is successful.");
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to browse and select the file" ,"Fail");
			System.out.println("Unable to browse and select the file");
			return false;
		}

	}
	
	//Reloaded the web page successfully
	public void ReloadWebPage() throws Exception
	{
		try {
			
			String s = sfdc.GetWebDriver().getCurrentUrl();
			sfdc.OpenSFDCRecordAsperURL(s);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {

			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}

	}
	
	/**
	 * 
	 * Author: 185584 
	 * Description: Adds a Screenshot validation steps  for element / screen shot comparison
	 * @param Element
	 * @throws Exception
	 */
	public void AddToLayoutVerificationPoint(WebElement Element) throws Exception{
		try {
			if(getAppProperties("VISUAL_AUTOMATION").equalsIgnoreCase("ON"))
			{
				String ss_name = "";
				System.out.println("RUNNING_TEST_NAME:"+TestBase.RUNNING_TEST_NAME);
				TestBase.TEST_STEP_NO_FOR_LAYOUT = TestBase.TEST_STEP_NO_FOR_LAYOUT + 1;
				String PATH_TC_VT_FOLDER = System.getProperty("user.dir")+"\\LayoutStorage\\"+TestBase.RUNNING_TEST_NAME;
				
				if (getAppProperties("CREATE_BASELINE").equalsIgnoreCase("ON"))
				{
					SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyHHmmss");
					Calendar cal = Calendar.getInstance();
					long randno = cal.getTimeInMillis();
					ss_name = sdf.format(cal.getTime())+"_"+randno;
					
					
					File directory = new File(PATH_TC_VT_FOLDER);
			        boolean directoryCreated = directory.mkdirs();
			        if (directoryCreated) {
			            System.out.println("Directory created successfully!");
			        } else {
			            System.out.println("Directory already exists!");
			        }
			        
			        //Deleting all the screen shots as Create Baseline flag is ON
			        //Deleting only for initial invocation of this function just before taking screen shot
			        if (TestBase.TEST_STEP_NO_FOR_LAYOUT == 1) 
			        {
			        	
			        	Path folderPath = Paths.get(PATH_TC_VT_FOLDER);

			            // Get all the files in the folder
			            Files.walk(folderPath)
			                    .sorted(Comparator.reverseOrder())
			                    .map(Path::toFile)
			                    .filter(item -> !item.getPath().equals(folderPath))
			                    .forEach(File::delete);
			        							
					}
			        
			        directory = new File(PATH_TC_VT_FOLDER);
			        directoryCreated = directory.mkdirs();
			        if (directoryCreated) {
			            System.out.println("Directory created successfully!");
			        } else {
			            System.out.println("Directory already exists!");
			        }
			        
			        String path_of_vt_ss_post_taking_screenshot = Capture_Visual_Test_ScreenShot_By_Element(ss_name,"_EXP",Element);
			        System.out.println("The screen shot path:"+path_of_vt_ss_post_taking_screenshot);
				}
				else
				{
					SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyHHmmss");
					Calendar cal = Calendar.getInstance();
					long randno = cal.getTimeInMillis();
					ss_name = sdf.format(cal.getTime())+"_"+randno;
					
					
					File directory = new File(PATH_TC_VT_FOLDER);
			        boolean directoryCreated = directory.mkdirs();
			        if (directoryCreated) {
			            System.out.println("Directory created successfully!");
			        } else {
			            System.out.println("Directory already exists!");
			        }
			        String path_of_vt_ss_post_taking_screenshot = Capture_Visual_Test_ScreenShot_By_Element(ss_name,"_ACT",Element);
			        System.out.println("The screen shot path:"+path_of_vt_ss_post_taking_screenshot);
				    
			        String path_of_act_ss = path_of_vt_ss_post_taking_screenshot;
			        String path_of_exp_ss = path_of_vt_ss_post_taking_screenshot.replace("ACT", "EXP");
			        
					////Comparison
					BufferedImage expectedImage = ImageIO.read(new File(path_of_exp_ss));
					BufferedImage actualImage = ImageIO.read(new File(path_of_act_ss));
			      	ImageDiffer imgDiff = new ImageDiffer();
					ImageDiff diff = imgDiff.makeDiff(actualImage, expectedImage);
					System.out.println("Has Diff ? "+diff.hasDiff());
					if (diff.hasDiff())
					{
						System.out.println("This step has failed:"+TestBase.TEST_STEP_NO_FOR_LAYOUT);
						ImageDiffer imgdiffer = new ImageDiffer();
						ImageDiff imgdiff = imgdiffer.makeDiff(expectedImage, actualImage);
						BufferedImage markedImage = imgdiff.getMarkedImage();
						String diff_image_path = System.getProperty("user.dir")+"\\LayoutStorage\\"+TestBase.RUNNING_TEST_NAME+"\\"+TestBase.TEST_STEP_NO_FOR_LAYOUT+"_diff.png";
						ImageIO.write(markedImage, "PNG", new File(diff_image_path));
						BufferedImage imageDiff = ImageIO.read(new File(diff_image_path));
						compareImages(imageDiff,expectedImage,actualImage);
						
						
						//Code to highli

						
					} 
					else
					{
						System.out.println("All Screenshot Matched for this step");

					}
					
					
					
					//					Assert.assertFalse(diff.hasDiff(),"Result of Image comparsion");
					//					System.out.println("Images Compared Sucesfully");
					//			        
	
				}
				
		        
		     }
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}

	}

	
	
	//Capture ScreenShots as per Visual Automation Test and stores into the path supplied
	public String Capture_Visual_Test_ScreenShot_By_Element(String ss_name,String EXP_ACT,WebElement Element) throws Exception
	{
		try {
			
			//String img_file_path = System.getProperty("user.dir")+"\\LayoutStorage\\"+TestBase.RUNNING_TEST_NAME+"\\"+TestBase.TEST_STEP_NO_FOR_LAYOUT+EXP_ACT+ss_name+".png";
			String img_file_path = System.getProperty("user.dir")+"\\LayoutStorage\\"+TestBase.RUNNING_TEST_NAME+"\\"+TestBase.TEST_STEP_NO_FOR_LAYOUT+EXP_ACT+".png";
			///********** Taking Screen Shot of Specific Element ******************
			//Screenshot ImageScreenshot = new AShot().coordsProvider(new WebDriverCoordsProvider()).takeScreenshot(remoteDriver, Element);
			
			//******************* Taking Full  Page Screen Shot
			//Screenshot ImageScreenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(100)).takeScreenshot(remoteDriver);
			
			//**************** Takes screen shot of individual elements / sections and also scrolls until end of the page and takes the screen shot of the element that appears below. This is very useful when any element is not visible within the viewport area and we need to scroll down to make the element visible and take screen shots
			//Screenshot ImageScreenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(100)).coordsProvider(new WebDriverCoordsProvider()).takeScreenshot(remoteDriver,Element);
			
			//***************** Takes screen shots by using built-in strategies in ShootingStrategies ***********
//			CutStrategy cutting = new VariableCutStrategy(0,100, 10);
//			ShootingStrategy rotating = new RotatingDecorator(cutting, ShootingStrategies.simple());
//			ShootingStrategy pasting = new ViewportPastingDecorator(rotating).withScrollTimeout(15);   
//			Screenshot ImageScreenshot = new AShot().shootingStrategy(pasting).takeScreenshot(remoteDriver);
//			
			WaitForPageToLoad(30);
			waitForVisibilityOfElement(Element);
			
			Screenshot ImageScreenshot = new AShot().coordsProvider(new WebDriverCoordsProvider()).takeScreenshot(remoteDriver, Element);
			BufferedImage actualImage = ImageScreenshot.getImage();  
			ImageIO.write(actualImage,"png",new File(img_file_path));
	        
	        //BufferedImage expectedImage = ImageIO.read(new File(System.getProperty("user.dir") +"\\LayoutStorage\\Menu.png"));
			
			
			return img_file_path;
		}catch(Exception e)
		{
			e.printStackTrace();
			return "";
		}
	}
	
	//Compares between two image files
	public boolean compareImages(BufferedImage diffImage, BufferedImage expectedImage, BufferedImage actualImage) throws Exception
	{
		int width_act = actualImage.getWidth(); 
		int height_act = actualImage.getHeight(); 
		int width_exp = expectedImage.getWidth(); 
		int height_exp = expectedImage.getHeight(); 

		boolean isImageHaveDifference = false;
		long counter = 0;
		java.util.Date dateTime;
		try{
			Graphics graphics = diffImage.getGraphics();
			graphics.setColor(Color.BLUE);
			dateTime = new java.util.Date();
			System.out.println("Comparison Started at :  "+dateTime.getHours()+" : "+dateTime.getMinutes()+" : "+dateTime.getSeconds());
			String comparisonSummary = "";
			comparisonSummary = comparisonSummary+"Comparison Started at :"+dateTime.getHours()+":"+dateTime.getMinutes()+":"+dateTime.getSeconds()+"<BR>";
			dateTime = null;
			for (int y = 0; y < height_act; y++) 
			{ 
				for (int x = 0; x < width_act; x++) 
				{ 
					long difference = 0; 
	
					int rgbA = actualImage.getRGB(x, y); 
					int redA = (rgbA >> 16) & 0xff; 
					int greenA = (rgbA >> 8) & 0xff; 
					int blueA = (rgbA) & 0xff;

					int rgbB = expectedImage.getRGB(x, y); 
					int redB = (rgbB >> 16) & 0xff; 
					int greenB = (rgbB >> 8) & 0xff; 
					int blueB = (rgbB) & 0xff;

					difference += Math.abs(redA - redB); 
					difference += Math.abs(greenA - greenB); 
					difference += Math.abs(blueA - blueB); 
					if(difference !=0 )
					{
						counter = counter+1;
   						graphics.drawLine(x,y,x+1,y+1);
					}
				} 
			} 
			dateTime = new java.util.Date();
			System.out.println("Comparison Ended at  :  "+dateTime.getHours()+" : "+dateTime.getMinutes()+" : "+dateTime.getSeconds());
			comparisonSummary = comparisonSummary+"Comparison Ended at :"+dateTime.getHours()+":"+dateTime.getMinutes()+":"+dateTime.getSeconds()+"<BR>";
			comparisonSummary = comparisonSummary+"Pixels Compared :"+height_act*width_act+" Pixels "+"<BR>";
			System.out.println("Total Pixels compared :  "+height_act*width_act+" pixels");
			dateTime = null;
			if(counter<=0)
			{
				System.out.println("Image doesnot have any difference in pixels");
				comparisonSummary = comparisonSummary+"Image doesnot have any difference in pixels"+"<BR>";
				//graphics.setFont(graphics.getFont().deriveFont(30f));
				//graphics.setColor(Color.GREEN);
				//graphics.drawString("Image doesnot have any difference pixels",width1/5,(height1-(height1/5)));
				isImageHaveDifference = false;
			}
			else
			{
				isImageHaveDifference = true;
				System.out.println("Image have difference in "+counter+" pixels");
				//graphics.setFont(graphics.getFont().deriveFont(30f));
				//graphics.setColor(Color.RED);
				//Need to write the difference in the difference Image ...
				//graphics.drawString("Image have difference in "+counter+" pixels",width1/5,(height1-(height1/5)));
				comparisonSummary = comparisonSummary+"Image have difference in "+counter+" pixels"+"<BR>";
				isImageHaveDifference = true;
			}
			graphics =null;
			//writeTestResults(resultFilePath, resultFilename,comparisonSummary, false, false);
			comparisonSummary="";
		}
		catch(Exception e){
			System.out.println("Inside : compareImage"); 
			System.out.println(e); 
		}
		return isImageHaveDifference;
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return void
	 * @throws Exception
	 * @Description Creates the Repository for all the SFDC TabNames from All Tabs
	 * @Date Aug 7, 2014
	 */
	public void _CreateTestScriptFile(String ModuleName,String TestScriptName) throws Exception
	{

		String LOC = "";


		/*************** Creating content of the testcase.java file ******************/


		LOC = "package com.mop.qa.test.bvt; \n \n \n" 

				+ "import org.testng.annotations.Test; \n"
				+ "import com.mop.qa.testbase.TestBase; \n"
				+ "import SOURCE_CODE.SFDC.DB; \n"
				+ "import USER_SPACE.BusinessComponent.BC; \n"
				+ "import SOURCE_CODE.SFDC.SFDCAutomationFW; \n"
				+ "import USER_SPACE.TestPrerequisite.DataSetup; \n"								
				+ "import USER_SPACE.ObjectRepository.LeadScreen; \n\n\n"

				+ "/* \n"
				+ "* \n"
				+ "* @Author: <Name of Test Script Creator> \n"
				+ "* @Description: <Please mention the scope of this test script> \n"
				+ "* @General Guidelines: Every Test Script must begin from Launching \n"
				+ "* URL of login screen and must end with browser closed \n"
				+ "*/ \n\n"

				+ "public class "+TestScriptName+" extends TestBase { \n\n\n"				
				+ "@Test \n"
				+ "public void createMyTest() { \n\n"
				+ "SFDCAutomationFW sfdc = null; \n"
				+ "LeadScreen leadScreen = null; \n\n"
				+ "String TCName = \""+TestScriptName+"\"; \n"
				+ "if (toolName.equalsIgnoreCase(\"Selenium\")) { \n"
				+ "sfdc = new SFDCAutomationFW(remoteDriver, TCName);\n"
				+ "leadScreen = new LeadScreen(remoteDriver); \n"
				+ "} else if (toolName.equalsIgnoreCase(\"Appium\")) {\n"
				+ "sfdc = new SFDCAutomationFW(appiumDriver, TCName);\n"
				+ "leadScreen = new LeadScreen(appiumDriver); \n"
				+ "}\n"
				+ "DB DB = new DB();\n"				
				+ "BC BC = new BC(remoteDriver);\n"
				+ "DataSetup DataSetup = new DataSetup();\n\n"
				+ "System.out.println(\"-----------Begin of TestScript-------------\");\n\n\n\n"
				+ "try { \n"
				+ "String NickNameofUser = \"TestUser1\"; \n"
				+ "// Login to SFDC \n"
				+ "sfdc.LoginToSFDC(NickNameofUser); \n"
				+ "// Selecting application \n"
				+ "BC.SelectApplication(\"Sales\"); \n"
				+ "Thread.sleep(5000L); \n"
				+ "// Clicking on Leads Tab \n"
				+ "sfdc.Link(\"Leads\").Click(); \n"
				+ "leadScreen.NewButton().Click(); \n"
				+ "leadScreen.FirstNameField().Type(sfdc.GetCurrentDateTimeStamp()); \n"
				+ "} \n"
				+ "catch (Exception e) { \n"
				+ "e.printStackTrace(); \n"
				+ "System.out.println(\"Exception(Exception) in main\"); \n"
				+ "} finally { \n"
				+ "System.out.println(\"-----------End of TestScript-------------\"); \n"
				+ "} \n"
				+ "} \n"
				+ "} \n";



		_CreateTestScriptFileFromTemplate(ModuleName, TestScriptName, LOC);
	}

	public void _CreateTestScriptFileFromTemplate(String ModuleName,String TestScriptName,String LineOfCode) throws Exception
	{
		try
		{
			//DB.Connect(DataSetup.Logininfo);
			String myCurrentDir = System.getProperty("user.dir");
			System.out.println("myCurrentDir:"+myCurrentDir);
			System.out.println(myCurrentDir+"\\src\\test\\java\\com\\mop\\qa\\test\\bvt\\");

			File file1 = new File(myCurrentDir+"\\src\\test\\java\\com\\mop\\qa\\test\\bvt\\");
			file1.getCanonicalFile().mkdirs();
			file1 = null;	





			File file = new File(myCurrentDir+"\\src\\test\\java\\com\\mop\\qa\\test\\bvt\\" + TestScriptName
					+ ".java");
			file.createNewFile();
			BufferedWriter wr = new BufferedWriter(new FileWriter(file.getCanonicalPath()));
			wr.write(LineOfCode);
			wr.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();

		}
	}
	public void expandLinks() throws InterruptedException{
		if(remoteDriver.findElements(By.xpath("//div/div/div/div[contains(@class,'section-expandable ng-isolate-scope')]/div[1]")).size()>0){
			for(int i =1;i<=remoteDriver.findElements(By.xpath("//div/div/div/div[contains(@class,'section-expandable ng-isolate-scope')]/div[1]")).size();i++){
				if(!remoteDriver.findElement(By.xpath("//div/div/div["+i+"]/div[contains(@class,'section-expandable ng-isolate-scope')]")).getAttribute("class").contains("expanded")){
					System.out.println("--------True-----------");
					remoteDriver.findElement(By.xpath("//div/div/div["+i+"]/div[contains(@class,'section-expandable ng-isolate-scope')]/div[1]")).click();
					Thread.sleep(2000);
				}
			}
		}
	}
	
	
	
	
}
