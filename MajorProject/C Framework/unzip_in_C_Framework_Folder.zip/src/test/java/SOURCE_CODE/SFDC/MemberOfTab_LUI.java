package SOURCE_CODE.SFDC;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class MemberOfTab_LUI extends PageBase {

	//WebDriver myWD;
	//SFDCAutomationFW autoFW;
	WebElement tab;
	String TabName;
	String xpath;
	
	public MemberOfTab_LUI(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
		
	}

	public MemberOfTab_LUI(AppiumDriver appiumDriver) {
		super(appiumDriver);
		
	}
	
	public String generateXpath(String TabName) {
		xpath = ".//*[@title='"+ TabName+"' or @title='"+TabName+" Tab - Selected' or @title='"+TabName+" Tab'][1]";
		return xpath;
	}
	
	
	
	/*
	MemberOfTab_LUI(String TN)
	{
		TabName = TN;
		xpath = ".//*[@title='"+ TabName+"' or @title='"+TabName+" Tab - Selected' or @title='"+TabName+" Tab'][1]";
		myWD = SFDCAutomationFW.myWD;
	}
	*/
	
	
	/**
	 * @param element
	 * @author 185584
	 * @Description Scrolls to the specific element
	 * @throws Exception
	 */
	public void ScrollToElement(WebElement element) throws Exception
	{
		
		try
		{
			((JavascriptExecutor)remoteDriver).executeScript("arguments[0].scrollIntoView();", element);
			
			System.out.println("Successfully scrolled untill element.");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to scroll until elemnt");
		}
	}
	
	
	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return boolean
	 * @throws Exception
	 * @Description Clicks on the Tab Name displayed on SFDC menu 
	 * @Date Aug 7, 2014
	 */
	public synchronized boolean Click() throws Exception
	{
		try
		{		
			Thread.sleep(1000L);
			String xp = "(//div[contains(@class,'appLauncher')]/descendant::button/descendant::div[contains(@class,'icon-waffle')])[1]";
			WaitForElement(xp, 30);
			Thread.sleep(500L);
			remoteDriver.findElement(By.xpath(xp)).click();
			xp = "(//div[contains(@class,'appLauncherMenu')][contains(@class,'open')][contains(@class,'active')]//button[@type='button'][text()='View All'])[1]";
			WaitForElement(xp,60);
			Thread.sleep(3000L);
			//clickByJse(remoteDriver.findElementByXPath(xp), "View All");
			click(xp,"View All");
			
			String xp1 = "(//section[contains(@class,'is-open')]/descendant::ul/descendant::li/descendant::a/descendant::p[normalize-space(text())='"+TabName.trim()+"'])[1]";
			if(WaitForElement(xp1, 20))
			{
				Thread.sleep(3000L);
				WebElement elm = remoteDriver.findElement(By.xpath(xp1));
				ScrollToElement(elm);
				Thread.sleep(1000L);
				elm.click();				
				System.out.println("Selected the tab ("+TabName+") successfully.");
				AddLogToCustomReport("Selected the app ("+TabName+") successfully.", "Pass");
			}
			else
			{
				System.out.println("Unable to select the app ("+TabName+").");
				AddLogToCustomReport("Unable to select the app ("+TabName+").", "Fail");
				
			}
			
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to select the application ("+TabName+")");
			AddLogToCustomReport("Unable to select the application ("+TabName+")", "Fail");
			return false;
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return true if tab name displayed return false if Tab Name is not displayed 
	 * @throws Exception
	 * @Description Verified if a TabName is displayed
	 * @Date Aug 7, 2014
	 */
	public boolean IsDisplayed() throws Exception
	{
		try
		{
			if(isElementDisplayed(xpath))
			{
				System.out.println("The tab ("+TabName+") is displayed.");
				remoteDriver.findElement(By.xpath(xpath)).click();
				AddLogToCustomReport("The tab ("+TabName+") is displayed.", "Pass");
				return true;
			}
			else
			{
				System.out.println("Unable to find tab ("+TabName+") when xpath is :"+xpath);
				AddLogToCustomReport("Unable to find tab ("+TabName+") when xpath is :"+xpath, "Fail");
				return false;
			}
							
		}
		catch(Exception e)
		{
			System.out.println("Unable to find tab ("+TabName+") when xpath is :"+xpath);
			AddLogToCustomReport("Unable to find tab ("+TabName+") when xpath is :"+xpath, "Fail");
			return false;
		}
	}
	
	
	/**
	 * @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
				
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
			
		}
	}
	
	
	/**
	 * @author 185584
	 * @param xpath
	 * @Description "Waits for element to appear"
	 * @param waitingTimeinsec
	 * @return
	 * @throws Exception
	 */
	public boolean WaitForElement(String xpath, long waitingTimeinsec) throws Exception
	{
		try {
			
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
			List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
			if (myDynamicElement.size() > 0)
			{
				System.out.println("Success: WaitForElement->Number of Element present is: "+myDynamicElement.size() +"Xpath is:"+xpath);
				return true;
			}
			else
			{
				System.out.println("Unsuccess: WaitForElement->Number of Element present is: "+myDynamicElement.size()+"Xpath is:"+xpath);
				return false;
			} 
		}
		catch(NoSuchElementException e)
		{
			e.printStackTrace();
			System.out.println("Exception inside WaitForElement:"+xpath);
			return false;
		}
	}
	
}
