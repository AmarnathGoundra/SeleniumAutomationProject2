package SOURCE_CODE.SFDC;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.mop.qa.testbase.PageBase;

import io.appium.java_client.AppiumDriver;

public class MemberOfButton extends PageBase {

	public String ButtonName;
	public WebElement button;
	public String xpath;

	public MemberOfButton(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
		xpath = "(//input[(@value=' " + ButtonName + " ' or normalize-space(@value)='" + ButtonName + "' or @value='  "
				+ ButtonName + "  ') and contains(normalize-space(@class),'btn')])[1]";
	}

	public MemberOfButton(AppiumDriver appiumDriver) {
		super(appiumDriver);
		xpath = "(//input[(@value=' " + ButtonName + " ' or normalize-space(@value)='" + ButtonName + "' or @value='  "
				+ ButtonName + "  ') and contains(normalize-space(@class),'btn')])[1]";
	}
	public void Click() {
		try {
			System.out.println("Click-" + this.button);
			click(this.button, ButtonName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void Click_ByIndex(int Index) {
		this.xpath = this.xpath.replace("[1]", "[" + Index + "]");
		try {
			System.out.println("Click index " + Index + " -" + this.button);
			click(this.button, ButtonName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean isDisplayed() {
		return isElementDisplayed(this.xpath);
	}

	public boolean VerifyIfDisplayed(String YesORNo) throws Exception {
		boolean flag = isDisplayed();
		if (YesORNo.trim().equalsIgnoreCase("Yes") && flag) {
			flag = true;
			return flag;
		} else if (YesORNo.trim().equalsIgnoreCase("No") && flag) {
			flag = false;
		} else {
			System.out.println("VerifyIfButtonDisplayed-" + YesORNo + " not equals " + flag);
			flag = false;
		}
		return flag;
	}

	public String generateXpath(String ButtonName) {
		xpath = "(//input[(@value=' " + ButtonName + " ' or normalize-space(@value)='" + ButtonName + "' or @value='  "
				+ ButtonName + "  ') and contains(normalize-space(@class),'btn')])[1]";
		return xpath;
	}

	public boolean WaitForElement(long waitingTimeinsec) throws Exception
	{
		try {
			
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
			List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
			if (myDynamicElement.size() > 0)
			{
				System.out.println("Success: WaitForElement->Number of Element present is: "+myDynamicElement.size());
				return true;
			}
			else
			{
				System.out.println("Unsuccess: WaitForElement->Number of Element present is: "+myDynamicElement.size());
				return false;
			} 
		}
		catch(NoSuchElementException e)
		{
			e.printStackTrace();
			System.out.println("Exception inside WaitForElement:"+xpath);
			return false;
		}
	}
	
}
