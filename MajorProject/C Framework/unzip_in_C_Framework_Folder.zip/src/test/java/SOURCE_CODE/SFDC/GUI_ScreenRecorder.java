package SOURCE_CODE.SFDC;

import javax.imageio.ImageIO;
import javax.swing.*;

import org.apache.commons.lang3.StringUtils;
//import org.jboss.netty.util.internal.SystemPropertyUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import USER_SPACE.TestPrerequisite.DataSetup;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.stream.Collectors;

public class GUI_ScreenRecorder extends JFrame implements ActionListener 
{ 

	JTextField tf1, tf2, tf3, tf4;
	JButton btn1, btn2,btn3,btn4;
	ArrayList al_sfdcloginurl,al_sysadmin,al_sfdcobject,al_sfdcrecordurl;
	ArrayList al_all_window_id;
	SFDCAutomationFW sfdc;

	GUI_ScreenRecorder(SFDCAutomationFW sfdc) throws Exception
	{	
		//sfdc = new SFDCAutomationFW();
		this.sfdc = sfdc;
		al_all_window_id = new ArrayList<String>();
		//setSize(50, 100);

		setBounds(1000, 30, 100, 50);
		//setLocation(900, 10);
		//setLayout(manager);(null);

		//setResizable(true);       

		//setLocationRelativeTo(null);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setUndecorated(true);
		setTitle("REC");

		/*btn1 = new JButton("REC",new ImageIcon(ImageIO.read(new File("Record_OR.png"))));


		btn1.addActionListener(this);

		btn1.setBounds(5, 5, 40, 40);
		btn1.setMargin(new Insets(0, 0, 0, 0));
		btn1.setBackground(new Color(64,64,64));
		btn1.setForeground(new Color(255,255,255));
		// btn1.setFont(new Font("Serif", Font.BOLD, 15));


		add(btn1);

		getContentPane().setBackground(new Color(102,178,255));*/

		//getContentPane().setPreferredSize(new Dimension(800, 240));
		btn1 = new JButton("REC",new ImageIcon(ImageIO.read(new File("Record_OR.png"))));
		//btn1 = new JButton(new ImageIcon(ImageIO.read(new File("Record_OR.png"))));
		btn2 = new JButton(new ImageIcon(ImageIO.read(new File("Record_Stop.png"))));

		btn1.setToolTipText("Start Recorder button must be clicked each time when you want to capture List View, Detail View/Related List screen.");

		btn2.setToolTipText("Stop Recorder button must be clicked only once per object. Once List View, Detail View / Related List screen recording is done then only this button needs to be clicked to generate the OR file for that particular object.");

		btn1.addActionListener(this);
		btn2.addActionListener(this);


		//btn1.setBounds(10, 10, 30, 30);


		//btn1.setMargin(new Insets(0, 0, 30, 30));
		//btn1.setAlignmentX(LEFT_ALIGNMENT);
		//btn1.setAlignmentX(RIGHT_ALIGNMENT);

		btn1.setBackground(new Color(51,171,215));
		//btn1.setForeground(new Color(255,255,255));


		//btn2.setBounds(5, 0, 30, 40);
		//btn2.setMargin(new Insets(40, 5, 30, 40));
		btn2.setBackground(new Color(51,171,215));
		//btn2.setForeground(new Color(255,255,255));


		// btn1.setFont(new Font("Serif", Font.BOLD, 15));


		add(btn1,BorderLayout.WEST);
		add(btn2,BorderLayout.EAST);

		//this.setPreferredSize(new Dimension(320, 240));
		//		setBackground(new Color(102,178,255));
		setVisible(true);

	}

	public void actionPerformed(ActionEvent e) 
	{

		try
		{

			if (e.getSource() == btn1)
			{

				//Getting total number of window opened.
				System.out.println("sfdc.GetWebDriver():"+sfdc.GetWebDriver());
				Set<String> all_win_count = sfdc.GetWebDriver().getWindowHandles();
				Iterator<String> ite_count = all_win_count.iterator(); 
				int cnt = 0;
				while(ite_count.hasNext()) 
				{ 
					String win = ite_count.next().toString();
					al_all_window_id.add(win); //index starts from 0
					System.out.println(""+win);
					cnt = cnt + 1;

				}
				System.out.println("Total Window Opened is:"+cnt);

				//Set<String> s = sfdc.GetWebDriver().getWindowHandles();
				//Iterator<String> ite = s.iterator(); 

				//System.out.println(al_all_window_id.get(0));
				//System.out.println(al_all_window_id.get(1));
				//System.out.println(al_all_window_id.get(2));

				sfdc.GetWebDriver().switchTo().window(al_all_window_id.get(al_all_window_id.size()-1).toString());
				System.out.println("Title is:"+sfdc.GetWebDriver().getCurrentUrl());
				WebElement we = null;
				//				String ObjectName;

				//				if(sfdc.GetWebDriver().getCurrentUrl().contains("AllTabs")){
				//					//        		we = sfdc.GetWebDriver().findElement(By.xpath("//h1[normalize-space(@class)='noSecondHeader pageType'][1]"));
				//					ObjectName="AllTabs";
				//				}else if(sfdc.GetWebDriver().getCurrentUrl().trim().contains("?fcf")){
				//					//else if(sfdc.GetWebDriver().findElement(By.xpath("(//div[normalize-space(@class)='individualPalette listViewportWrapper'][1]/descendant::select[contains(@title,'View')])[1]")).getAttribute("class").contains("individualPalette")){
				//					System.out.println("true");
				//					ObjectName="Undefined";
				//				}else{
				//					we = sfdc.GetWebDriver().findElement(By.xpath("//h1[normalize-space(@class)='pageType'][1]"));
				//					//        		we = sfdc.GetWebDriver().findElement(By.xpath("//h2[normalize-space(@class)='mainTitle'][1]"));
				//					ObjectName = we.getText().trim().replace("+", "").replace("&", "")
				//							.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
				//							.replace("-", "").replace(" ", "").replace("*", "")
				//							.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
				//							.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
				//							.replace("$", "").replace(".", "").replace("!", "").replace(" ", "");
				//					//h1[normalize-space(@class)='pageType'][1]
				//				}

				//				System.out.println("ObjectName"+ObjectName);

				sfdc._CreateAUTRepository();
				//sfdc.GetScreenShotONsuccess();
				//				JOptionPane.showMessageDialog(null, "Object Repository created for ("+ObjectName+")");
				/*
        	while(ite.hasNext()) 
	        { 
	            String window = ite.next(); 

	            System.out.println("Window is:"+window);
	            if()
	            {
	            	sfdc.GetWebDriver().switchTo().window(window);
	            }
	        }
				 */
			}
			if (e.getSource() == btn2)
			{

				//Printing Array List content
				System.out.println("------------------------------------------------------------------------");

				sfdc.al_fieldname = (ArrayList) sfdc.al_fieldname.stream().distinct().collect(Collectors.toList());

				for(String s:sfdc.al_fieldname)
				{
					System.out.println("al_fieldname---->"+s);
				}

				sfdc.al_sectionname = (ArrayList) sfdc.al_sectionname.stream().distinct().collect(Collectors.toList());
				for(String s:sfdc.al_sectionname)
				{
					System.out.println("al_sectionname---->"+s);
				}
				sfdc.al_tab_fn = (ArrayList) sfdc.al_tab_fn.stream().distinct().collect(Collectors.toList());
				for(String s:sfdc.al_tab_fn)
				{
					System.out.println("al_tab_fn---->"+s);
				}
				sfdc.al_tab = (ArrayList) sfdc.al_tab.stream().distinct().collect(Collectors.toList());
				for(String s:sfdc.al_tab)
				{
					System.out.println("al_tab---->"+s);
				}

				sfdc.uniquebuttons = (ArrayList) sfdc.uniquebuttons.stream().distinct().collect(Collectors.toList());
				for(String s:sfdc.uniquebuttons)
				{
					System.out.println("uniquebuttons---->"+s);
				}

				sfdc.al_lv_c_col_names = (ArrayList) sfdc.al_lv_c_col_names.stream().distinct().collect(Collectors.toList());

				for(String s:sfdc.al_lv_c_col_names)
				{
					System.out.println("al_lv_c_col_names---->"+s);
				}
				sfdc.al_rl_c_col_names = (ArrayList) sfdc.al_rl_c_col_names.stream().distinct().collect(Collectors.toList());

				for(String s:sfdc.al_rl_c_col_names)
				{
					System.out.println("al_rl_c_col_names---->"+s);
				}
				sfdc.al_relatedlistname = (ArrayList) sfdc.al_relatedlistname.stream().distinct().collect(Collectors.toList());

				for(String s:sfdc.al_relatedlistname)
				{
					System.out.println("al_relatedlistname---->"+s);
				}

				sfdc.al_rlSecName_c_plus_FName = (ArrayList) sfdc.al_rlSecName_c_plus_FName.stream().distinct().collect(Collectors.toList());

				for(String s:sfdc.al_rlSecName_c_plus_FName)
				{
					System.out.println("al_rlSecName_c_plus_FName---->"+s);
				}

				sfdc.al_rlname_c_plus_col = (ArrayList) sfdc.al_rlname_c_plus_col.stream().distinct().collect(Collectors.toList());

				for(String s:sfdc.al_rlname_c_plus_col)
				{
					System.out.println("al_rlname_c_plus_col---->"+s);
				}


				System.out.println("------------------------------------------------------------------------");

				String sub= "";

				
				if(sfdc.ObjectName_classic!=null){
					sfdc.screenname = (StringUtils.capitalize(sfdc.ObjectName_classic.replace(" ", "")) + "Screen"); 
				}else if(sfdc.ObjectNameAllTabs!=null){
					sfdc.screenname = (StringUtils.capitalize(sfdc.ObjectNameAllTabs.replace(" ", "")) + "Screen"); 
				}else{
					sfdc.screenname = "Undefined" + "Screen";
				}

				System.out.println("sfdc.screenname"+sfdc.screenname);
				
				String classname = sfdc.screenname.trim().replace("+", "").replace("&", "")
						.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
						.replace("-", "").replace(" ", "").replace("*", "")
						.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
						.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
						.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");

				sfdc.screenname = classname;
				/*************** Generic Part of the Content of Screen File ******************/

				sfdc.contentofscreenfile = "package USER_SPACE.ObjectRepository; \n"
						+ "import SOURCE_CODE.SFDC.*; \n"
						+ "import org.openqa.selenium.remote.RemoteWebDriver; \n"
						+ "import io.appium.java_client.AppiumDriver; \n"

						+ "\n \n \n"
						+ "public class "+classname+" extends SFDCAutomationFW { \n\n"
						+ "public SFDCAutomationFW sfdc; \n"
						+ "public String RList = \"\"; \n"
						+ "public String SecName = \"\"; \n\n\n"
						+ "public "+classname+"(RemoteWebDriver remoteDriver) { \n"
						+ "super(remoteDriver); \n"
						+ "sfdc = new SFDCAutomationFW(remoteDriver); \n"
						+ "} \n\n"
						+ "public "+classname+"(AppiumDriver appiumDriver) { \n"
						+ "super(appiumDriver); \n"
						+ "sfdc = new SFDCAutomationFW(appiumDriver); \n"
						+ "} \n\n\n";

				/*************** Functions for All Tabs Screen ******************/
					if(sfdc.al_tab.size()>0){

						for(int tab=0;tab<sfdc.al_tab.size();tab++)
						{
							System.out.println(sfdc.al_tab_fn.get(tab) + ":" +sfdc.al_tab.get(tab));

							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "public MemberOfTab "+sfdc.al_tab_fn.get(tab)+"Tab() throws Exception{ \n";
							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "	return sfdc.Tab(\""+sfdc.al_tab.get(tab)+"\"); \n";
							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "} \n";
						}
						
					}

				String each_col_lv_asperapp = "";
				String each_lvname_changed = "";

				// ************************ Functions for List View Fields ************************************** 
				sfdc.contentofscreenfile = sfdc.contentofscreenfile
						+ "//************************* Functions for List Views***************************** // \n \n";

				if(sfdc.al_lv_c_col_names.size()>0){

					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "\n\n public Columns_"+"ListView"+" "+"ListView"+"() throws Exception{ \n";

					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "return new Columns_"+"ListView"+"(); \n";
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "} \n";
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "public class Columns_"+"ListView"+"{ \n";

					for(String s:sfdc.al_lv_c_col_names)
					{
						each_col_lv_asperapp = s.trim();
						each_lvname_changed = each_col_lv_asperapp.trim().replace("+", "").replace("&", "")
								.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
								.replace("-", "").replace(" ", "").replace("*", "")
								.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
								.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
								.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");

						sfdc.contentofscreenfile = sfdc.contentofscreenfile ;

						sfdc.contentofscreenfile = sfdc.contentofscreenfile + "public MemberOfLV "+each_lvname_changed+"(Integer RowIndex) throws Exception \n";
						sfdc.contentofscreenfile = sfdc.contentofscreenfile + "{ \n";

						sfdc.contentofscreenfile = sfdc.contentofscreenfile +	"return sfdc.LV(\""+each_col_lv_asperapp+"\",RowIndex); \n";
						sfdc.contentofscreenfile = sfdc.contentofscreenfile + "}\n";

						//******************** Below statements Newly Added *************************

						sfdc.contentofscreenfile = sfdc.contentofscreenfile + "public MemberOfLV "+each_lvname_changed+"() throws Exception \n";
						sfdc.contentofscreenfile = sfdc.contentofscreenfile + "{ \n";

						sfdc.contentofscreenfile = sfdc.contentofscreenfile +	"return sfdc.LV(\""+each_col_lv_asperapp+"\"); \n";
						sfdc.contentofscreenfile = sfdc.contentofscreenfile + "}\n\n";
					}
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "}\n\n";
				}

				sfdc.contentofscreenfile = sfdc.contentofscreenfile
						+ "//************************* Functions for Buttons***************************** // \n \n";

				//update

				String each_button_asperapp = "";
				String each_button_changed = "";

				for(String s:sfdc.uniquebuttons)
				{
					each_button_asperapp = s.trim();
					each_button_changed = s.trim().replace("+", "").replace("&", "")
							.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
							.replace("-", "").replace(" ", "").replace("*", "")
							.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
							.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
							.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
					System.out.println(each_button_changed);
					if(!each_button_changed.equals("")){
							sfdc.contentofscreenfile = sfdc.contentofscreenfile 

							+ "public MemberOfButton "+each_button_changed+"Button() throws Exception{ \n" 
							+ "return sfdc.Button(\""+each_button_asperapp+"\"); \n"
							+ "} \n";
					}
				}

				sfdc.contentofscreenfile = sfdc.contentofscreenfile
						+ "//************************* Functions for Field Names ***************************** // \n \n";

				String each_field_asperapp = "";
				String each_field_changed = "";

				for(String s:sfdc.al_fieldname)
				{
					each_field_asperapp = s.trim().replace("*", "").replaceAll("\\r", "").replaceAll("\\n", "");
					
					each_field_changed = each_field_asperapp.trim().replace("+", "").replace("&", "")
							.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
							.replace("-", "").replace(" ", "").replace("*", "")
							.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
							.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
							.replace("$", "").replace(".", "").replace("\\", "").replaceAll("\\r", "").replaceAll("\\n", "");


					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "public MemberOfField "+each_field_changed+"Field() throws Exception{ \n";

					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "	return sfdc.Field(\""+each_field_asperapp+"\"); \n";
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "} \n";
				}
				// ************************* Functions & Static Classes for Sections ***************************** // 

				//
				sfdc.contentofscreenfile = sfdc.contentofscreenfile
						+ "//************************* Functions for Section Name***************************** // \n \n";

				String sub_each_secname = "";
				String each_secname_changed = "";
				String each_secname_plus_field = "";
				String each_secfield_asperapp = "";
				String each_secfield_changed = "";


				for(String each_secname:sfdc.al_sectionname){

					sub_each_secname = each_secname.trim();
					each_secname_changed = each_secname.trim().replace("+", "").replace("&", "")
							.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
							.replace("-", "").replace(" ", "").replace("*", "")
							.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
							.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
							.replace("$", "").replace(".", "").replace("\\", "");

					for(String i: sfdc.al_rlSecName_c_plus_FName){

						//						System.out.println("name"+i.trim().startsWith(sub_each_secname+"SEC_:"));

						if(i.trim().startsWith(sub_each_secname+"SEC_:"))
						{
							each_secfield_asperapp = i.trim().replace(sub_each_secname+"SEC_:", "").trim();
							each_secfield_changed = each_secfield_asperapp.trim().replace("+", "").replace("&", "")
									.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
									.replace("-", "").replace(" ", "").replace("*", "").replace("!", "")
									.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
									.replace("%", "").replace(")", "").replace(",", "").replace("#", "")
									.replace("$", "").replace(".", "").replace("\\", "");
							if (Character.isDigit(i.charAt(0)))
							{
								i = i.replaceFirst(i.substring(0, 1),"_");
							}

							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "public MemberOfSEC SEC_"+each_secname_changed+"_"+each_secfield_changed+"Field() throws Exception { \n";
							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "return sfdc.Section(\""+sub_each_secname+"\", \""+each_secfield_asperapp+"\"); \n";
							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "}\n";
						}
					}
					
				}
				
				//sangeetha

				sfdc.contentofscreenfile = sfdc.contentofscreenfile
						+ "//************************* Functions for Related List***************************** // \n \n";

				String sub_each_rlname = "";
				String each_rlname_changed = "";
				String each_rlname_plus_col = "";
				String each_col_asperapp = "";
				String each_col_changed = "";

				for(String each_rlname:sfdc.al_relatedlistname){

					sub_each_rlname = each_rlname.trim();
					each_rlname_changed = each_rlname.trim().replace("+", "").replace("&", "")
							.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
							.replace("-", "").replace(" ", "").replace("*", "")
							.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
							.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
							.replace("$", "").replace(".", "").replace("\\", "");
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "\n\n public Columns_"+each_rlname_changed+" RL_"+each_rlname_changed+"() throws Exception{ \n";

					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "return new Columns_"+each_rlname_changed+"(\""+sub_each_rlname+"\"); \n";
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "} \n";
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "public class Columns_"+each_rlname_changed+"{ \n";
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "Columns_"+each_rlname_changed+"(String RL) \n";
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "{ \n";
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "RList = RL; \n";
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "} \n\n";

					for(String i: sfdc.al_rlname_c_plus_col){
						
						if(i.trim().startsWith(sub_each_rlname+":"))
						{
							each_col_asperapp = i.trim().replace(sub_each_rlname+":", "").trim();
							each_rlname_changed = each_col_asperapp.trim().replace("+", "").replace("&", "")
									.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
									.replace("-", "").replace(" ", "").replace("*", "").replace("!", "")
									.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
									.replace("%", "").replace(")", "").replace(",", "").replace("#", "")
									.replace("$", "").replace(".", "").replace("\\", "");
							if (Character.isDigit(i.charAt(0)))
							{
								i = i.replaceFirst(i.substring(0, 1),"_");
							}

							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "public MemberOfRL "+each_rlname_changed+"(Integer RowIndex) throws Exception \n";
							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "{ \n";

							sfdc.contentofscreenfile = sfdc.contentofscreenfile +	"return sfdc.RL(RList,\""+each_col_asperapp+"\",RowIndex); \n";
							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "}\n";

							//******************** Below statements Newly Added *************************

							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "public MemberOfRL "+each_rlname_changed+"() throws Exception \n";
							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "{ \n";

							sfdc.contentofscreenfile = sfdc.contentofscreenfile +	"return sfdc.RL(RList,\""+each_col_asperapp+"\"); \n";
							sfdc.contentofscreenfile = sfdc.contentofscreenfile + "}\n\n";
							
						}
					}
					sfdc.contentofscreenfile = sfdc.contentofscreenfile + "}\n\n";
				}

				sfdc.contentofscreenfile = sfdc.contentofscreenfile + "}\n\n";

				sfdc._CreateScreenFile();
				
				
				//nullifying the arraylists
				
				sfdc.al_fieldname = null;
				sfdc.al_sectionname= null;
				sfdc.al_tab_fn= null;
				sfdc.al_tab= null;
				sfdc.uniquebuttons= null;
				sfdc.al_lv_c_col_names= null;
				sfdc.al_rl_c_col_names= null;
				sfdc.al_relatedlistname= null;
				sfdc.al_rlSecName_c_plus_FName= null;
				sfdc.al_rlname_c_plus_col= null;
			
				
				sfdc.al_fieldname = new ArrayList();
				sfdc.al_sectionname = new ArrayList();
				sfdc.al_relatedlistname = new ArrayList();
				sfdc.uniquebuttons = new ArrayList< String >();
				sfdc.al_fieldname_fn = new ArrayList();
				sfdc.al_sectionname_fn = new ArrayList();
				sfdc.al_relatedlistname_fn = new ArrayList();
				sfdc.al_lv_c_col_names = new ArrayList();
				sfdc.al_rl_c_col_names = new ArrayList();
				sfdc.al_rlname_c_plus_col = new ArrayList();
				sfdc.al_rlSecName_c_plus_FName =new ArrayList();
				sfdc.al_rlSecName_c_FName =new ArrayList();
				sfdc.al_tab =new ArrayList();
				sfdc.al_tab_fn =new ArrayList();
				
				
			}

		}
		catch(Exception e1)
		{
			e1.printStackTrace();

		}
	} 

}