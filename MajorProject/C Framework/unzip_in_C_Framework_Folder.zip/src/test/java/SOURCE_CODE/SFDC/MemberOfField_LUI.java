package SOURCE_CODE.SFDC;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.peer.ScrollPanePeer;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.docx4j.org.xhtmlrenderer.util.SystemPropertiesUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;
import com.zapi.Utilities.AddTestsToCycle;

import io.appium.java_client.AppiumDriver;


/**
 * @author Cognizant
 *
 */
/**
 * @author Cognizant
 *
 */
public class MemberOfField_LUI extends PageBase{

	String fieldname;
	//WebDriver remoteDriver;
	//SFDCAutomationFW autoFW;
	String xpath;
	List<WebElement> allposblefieldelements;
	WebElement getsingleWebelement;
	String xp_desktop_contains_style = "(//body[contains(normalize-space(@class),'desktop')])[1]";
	String xp_common_vd = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]";
	String xp_common_sales_or_service_console_create_page = "//div[contains(@class,'active') and contains(@class,'windowViewMode') and contains(@class,'maximized')]";
	String url_service_console_createpage="new?";
	
	//String xp_common_in_ed_and_vd = "//div[contains(@class,'test-id__record-layout-container riseTransitionEnabled')][1]/following-sibling::div[contains(@class,'riseTransitionEnabled test-id__inline-edit-record-layout-container')][1]";
	
	String xp_common_in_ed_and_vd = "(//div[contains(@class,'footer-visible')])[1]";
	
	//String xp_common_in_ed = "//div[contains(@class,'test-id__record-layout-container riseTransitionEnabled')][1]/following-sibling::div[contains(@class,'riseTransitionEnabled test-id__inline-edit-record-layout-container')][1]";
	//This is for Edit page, not for in line edit page. the variable need to be changed later
	String xp_common_in_ed = "(//div[contains(@class,'windowViewMode') and contains(@class,'isModal active') and contains(@class,'active')])[1]";
	String xp_common_in_ed_inline = "(//div[contains(@class,'footer-visible')][contains(@class,'slds-card')])[1]";
	
	String xp_ncino_edit_common_part = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]";
	
	
	public MemberOfField_LUI(RemoteWebDriver remoteDriver) {
		super(remoteDriver);	
		
	}
	
	public MemberOfField_LUI(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}
	
	

	
	/**
	 * @return
	 * @throws Exception
	 * @Description: Reads the value(text,link) of view only field from 1. Detail View Layout 2. Edit Layout 3. Inline Edit Layout and returns the same 
	 */
	public String GetViewOnlyValue() throws Exception
	{
				
		try{
									
						
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
				if(remoteDriver.findElements(By.xpath(xp_common_in_ed_and_vd)).size() >0)
				{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[normalize-space(text())='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					//xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1])/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a' or local-name()='lightning-formatted-text'][text()][1]";
				}
				}
				else
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]//*[contains(@class,'field')]//*[text()][1]";
					//xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a' or local-name()='lightning-formatted-text'][text()][1]";
				}
				
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";	
			}
			
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
			//Getting the value from field
			String Value = "";
			Value = remoteDriver.findElement(By.xpath(xpath)).getText();
			System.out.println("Read the value("+Value+") of field ("+fieldname+") ");
			AddLogToCustomReport("Read the value("+Value+") of field ("+fieldname+") ", "Pass");
			
			return Value;
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to read the value from field ("+fieldname+") .");
			AddLogToCustomReport("Unable to read the value from field ("+fieldname+") from view detail.", "Fail");
			return "";
			
		}
		
	}
	
	
	
	/**
	 * @return
	 * @throws Exception
	 * @Page Layout: Support of Lightening UI in below two layout 1. Edit Page Layout 2. Inline Edit Page  
	 * @Description Can read the value from TextField, TextArea, DateLookup from record edit page and inline edit page. It cannot read from lookup field, Single Select Picklist, Multiselect picklist and checkbox values. There are separate methods
	 */
	public String GetEditFieldValue() throws Exception
	{
					
			try{
								
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline +"/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
								
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";								
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::input[1]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String Value = "";
				Value = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value");
				System.out.println("Read the value("+Value+") of field ("+fieldname+") ");
				AddLogToCustomReport("Read the value("+Value+") of field ("+fieldname+") ", "Pass");
				return Value;
						
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to read the value from field ("+fieldname+").");
				AddLogToCustomReport("Unable to read the value from field ("+fieldname+").", "Fail");
				return "";
				
			}
		
	}		
	
	/**
	 * 
	 * @Description Reads the picklist value from 1. Edit page Layout 2. Inline Edit page layout and returns the value as a String
	 * @throws Exception
	 * @return String, the value present in the pick list field in edit page.
	 * 
	 */
	public String GetPLDefaultValue() throws Exception
	{

		try
		{
			WaitForPageToLoad(60);
			
			//Identifying the page type
			/*
			if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
			{
				System.out.println("INLINE EDIT PAGE");
				xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";
			}				
			else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
			{
				System.out.println("DETAIL VIEW PAGE");	
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";							
			}
			*/
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed_inline ++ "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";
					String xp1 = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][@role='combobox'][1]";
					String xp2 = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/../following-sibling::*[1]/descendant::*[contains(@class,'select')][1]";
					
					//Getting the correct element
					remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
		            List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xp1));
		            if (myDynamicElement.size() > 0)
		            {
		            	xpath = xp1;
		            }
		            else if(remoteDriver.findElements(By.xpath(xp2)).size()>0)
		            {	
		            	xpath = xp2;
		            }
		            System.out.println("xpath:"+xpath);
				
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";								
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");

				String xp1 = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][@role='combobox'][1]";
				String xp2 = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/../following-sibling::*[1]/descendant::*[contains(@class,'select')][1]";
				
				//Getting the correct element
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
	            List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xp1));
	            if (myDynamicElement.size() > 0)
	            {
	            	xpath = xp1;
	            }
	            else if(remoteDriver.findElements(By.xpath(xp2)).size()>0)
	            {	
	            	xpath = xp2;
	            }
	            System.out.println("xpath:"+xpath);
				
				
			}
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
		if (WaitForElement(xpath,30))
		{
			
			String Value = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value").trim();
			AddLogToCustomReport("The default value in picklist field ("+fieldname+"). is ("+Value+")", "Pass");
			System.out.println("The default value in picklist field ("+fieldname+"). is ("+Value+")");
			return Value;
		}
		else
		{
			System.out.println("Unable to read the value of picklist field ("+fieldname+") as xpath does not result any element.");
			AddLogToCustomReport("Unable to read the value of picklist field ("+fieldname+") as xpath does not result any element.", "Fail");
			return "";
		}
		}
		catch(Exception e)
		{
			AddLogToCustomReport("Unable to read the value of pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
			System.out.println("Unable to read the value of pick list field ("+fieldname+") when xpath is ("+xpath+")");
			return "";	
		}
		
	}

	//below functions need to be tested 11/2/17 12:35PM
	/**
	 * @return
	 * @throws Exception
	 * @Description Reads the value of lookup field from Inline Edit page as well as Edit page
	 * 
	 */
	public String GetLookupEditValue() throws Exception
	{

		try
		{
			WaitForPageToLoad(30);
			/*
			//Identifying the page type
			if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
			{
				System.out.println("INLINE EDIT PAGE");
				xpath = xp_common_in_ed_inline ++ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::span[@class='pillText'][1]";
								
			}				
			else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
			{
				System.out.println("DETAIL VIEW PAGE");	
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::span[@class='pillText'][1]";						
			}
				*/
		
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
				
					xpath = xp_common_in_ed_inline +"/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::span[@class='pillText'][1]";								
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant::span[contains(@class,'pillText')][text()]";
				xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				
				
			}
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
		if (WaitForElement(xpath,30))
		{
			
			String Value = remoteDriver.findElement(By.xpath(xpath)).getAttribute("placeholder").trim();
			AddLogToCustomReport("The value in lookup field ("+fieldname+"). is ("+Value+")", "Pass");
			System.out.println("The value in lookup field ("+fieldname+"). is ("+Value+")");
			return Value;
		}
		else
		{
			System.out.println("Unable to read the value of lookup field ("+fieldname+") as xpath does not result any element.");
			AddLogToCustomReport("Unable to read the value of lookup field ("+fieldname+") as xpath does not result any element.", "Fail");
			return "";
		}
		}
		catch(Exception e)
		{
			AddLogToCustomReport("Unable to read the value of lookup field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
			System.out.println("Unable to read the value of lookup field ("+fieldname+") when xpath is ("+xpath+")");
			return "";	
		}
		
	}
	
	/**
	 * @Description Reads the value of check box from 1. Detail View page, 2. Edit Page Layout 3. Inline Edit Page Layout  
	 * @return Returns the value True/False as a String.
	 * @throws Exception
	 */
	public String GetCheckBoxValue() throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
				if(remoteDriver.findElements(By.xpath(xp_common_in_ed_and_vd)).size() >0)
				{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed_inline ++ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
					
					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor-or-self::label[contains(@class,'checkbox')]/following-sibling::*[1]//*[@type='checkbox'][1]";
					System.out.println("xpath:"+xpath);
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
					{
						
						System.out.println("The checkbox field ("+fieldname+") is not checked.");
						AddLogToCustomReport("The checkbox field ("+fieldname+") is not checked.", "Pass");
						return "True";
					}
					else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
					{
						System.out.println("The Checkbox field ("+fieldname+") is checked.");
						AddLogToCustomReport("The Checkbox field ("+fieldname+") is checked.", "Pass");
						return "True";
					}
					else
					{
						System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
						AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
						return "";
					}
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::div[1]/descendant::img[1]";
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					System.out.println("The Checkbox field ("+fieldname+") is "+remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt").toString().trim());
					AddLogToCustomReport("The Checkbox field ("+fieldname+") is "+remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt").toString().trim(), "Pass");
				
					return (remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt")).toString().trim();								
				}	
				}
				else
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::div[1]/descendant::img[1]";
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					System.out.println("The Checkbox field ("+fieldname+") is "+remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt").toString().trim());
					AddLogToCustomReport("The Checkbox field ("+fieldname+") is "+remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt").toString().trim(), "Pass");
				
					return (remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt")).toString().trim();
				}
				
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				//xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
				xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor-or-self::label[contains(@class,'checkbox')]/following-sibling::*[1]//*[@type='checkbox'][1]";
				System.out.println("xpath:"+xpath);
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
				{
					
					System.out.println("The checkbox field ("+fieldname+") is not checked.");
					AddLogToCustomReport("The checkbox field ("+fieldname+") is not checked.", "Pass");
					return "True";
				}
				else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
				{
					System.out.println("The Checkbox field ("+fieldname+") is checked.");
					AddLogToCustomReport("The Checkbox field ("+fieldname+") is checked.", "Pass");
					return "True";
				}
				else
				{
					System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
					AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
					return "";
				}
				
				
			}
			System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
			AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
			return "";
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
			AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
			return "";
			
		}
		
	}
	
	/**
	 * @param Value
	 * @return Returns true on success else false
	 * @Description Verifies the value of view only (Any Text/Link) value from 1. Detail View 2. Inline Edit 3. Edit Layout page 
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueEquals(String Value) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
			//Thread.sleep(3000L);
			String xpath="",xp="";
			String aValue = "";
			
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
				if(remoteDriver.findElements(By.xpath(xp_common_in_ed_and_vd)).size() >0)
				{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
					
					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
						
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					//xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";					
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]//*[contains(@class,'field')]//*[text()][1]";
					
				}			
				}
				else
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
				}
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");

				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
				
			}
			if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
			{
				System.out.println("SERVICE/SALES CONSOLE CREATE PAGE");	
				xpath = xp_common_vd+"//descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
			}
			System.out.println("ready xpath-->"+xpath);
			//Scrolling to element
			//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			Thread.sleep(1000L);
			//Getting the value from field
			System.out.println("text-->"+remoteDriver.findElement(By.xpath(xpath)).getAttribute("text"));
			System.out.println("getText() return is:"+remoteDriver.findElement(By.xpath(xpath)).getText());
			WebElement element = remoteDriver.findElement(By.xpath(xpath));
			aValue = element.getText();
			System.out.println("textContent is:" + aValue);
			
			//aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("textContent").trim();
			if(aValue.equals(Value.trim()))
			{
				System.out.println("Successfully verified the view only value("+Value+") of field ("+fieldname+").");
				AddLogToCustomReport("Successfully verified the view only value("+Value+") of field ("+fieldname+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
				AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
				return false;
			}
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
			AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
		
	}
	

	
	/**
	 * @param Value
	 * @return Returns true on success else false
	 * @Description Verifies the value of view only (Any Text/Link) value from 1. Detail View 2. Inline Edit 3. Edit Layout page 
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueEquals_Lookup(String Value) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
			//Thread.sleep(3000L);
			String xpath="";			
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
				if(remoteDriver.findElements(By.xpath(xp_common_in_ed_and_vd)).size() >0)
				{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
					
					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
						
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					//xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";					
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]//*[contains(@class,'field')]//*[text()][1]";
					
				}			
				}
				else
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
				}
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");

				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]//*[contains(@class,'Label')][1]";
			}
			if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
			{
				System.out.println("SERVICE CONSOLE CREATE PAGE");	
				xpath = xp_common_vd+"//descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
			}
			System.out.println("ready xpath-->"+xpath);
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			Thread.sleep(1000L);
			//Getting the value from field
			String aValue = "";
			System.out.println("value-->"+remoteDriver.findElement(By.xpath(xpath)).getText());
			aValue = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
			if(aValue.equals(Value.trim()))
			{
				System.out.println("Successfully verified the view only value("+Value+") of field ("+fieldname+").");
				AddLogToCustomReport("Successfully verified the view only value("+Value+") of field ("+fieldname+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
				AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
				return false;
			}
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
			AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
		
	}
	

	
	/**
	 * @param Value
	 * @return Returns true on success else false
	 * @Description Verifies the value of view only (Any Text/Link) value from 1. Detail View 2. Inline Edit 3. Edit Layout page 
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueContains(String Value) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
						
			//Identifying the page type
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
				if(remoteDriver.findElements(By.xpath(xp_common_in_ed_and_vd)).size() >0)
				{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
					//xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";
					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]//*[contains(@class,'field')]//*[text()][1]";
					
				
				}
				}
				else
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[contains(text(),'"+Value.trim()+"')][1]";
				}
				
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");

				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
				
			}
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
			//Getting the value from field
			String aValue = "";
			aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("textContent").trim();
			if(aValue.contains(Value.trim()))
			{
				System.out.println("Successfully verified the view only value("+Value+") of field ("+fieldname+").");
				AddLogToCustomReport("Successfully verified the view only value("+Value+") of field ("+fieldname+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
				AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
				return false;
			}
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
			AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
		
	}
	
	/**
	 * @param ValueDoesNotContain
	 * @return
	 * @Description Verifies that view only value does not contain supplied value for (Text value/Link value) of fields.  
	 * @Page Layout Acts on 1. Detail View 2. Edit Page 3. Inline Edit page
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueDoesNotContain(String ValueDoesNotContain) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
						
			
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
				if(remoteDriver.findElements(By.xpath(xp_common_in_ed_and_vd)).size() >0)
				{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
				
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]//*[contains(@class,'field')]//*[text()][1]";
					
				}			
				}
				else
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[contains(text(),'"+ValueDoesNotContain.trim()+"')][1]";
				}
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
				
			}
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
			//Getting the value from field
			WebElement element = remoteDriver.findElement(By.xpath(xpath));
			String aValue = "";
			aValue = element.getAttribute("textContent");
			System.out.println("textContent is:" + aValue);
			if(!aValue.contains(ValueDoesNotContain.trim()))
			{
				System.out.println("Verified successfully that view only value of field ("+fieldname+") does not contain ("+ValueDoesNotContain+").");
				AddLogToCustomReport("Verified successfully that view only value of field ("+fieldname+") does not contain ("+ValueDoesNotContain+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("Field Verification failed on fieldname ("+fieldname+") while checking does not contain ("+ValueDoesNotContain+")");
				AddLogToCustomReport("Field Verification failed on fieldname ("+fieldname+") while checking does not contain ("+ValueDoesNotContain+")", "Fail");
				return false;
			}
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Field Verification failed on fieldname ("+fieldname+") while checking does not contain ("+ValueDoesNotContain+")");
			AddLogToCustomReport("Field Verification failed on fieldname ("+fieldname+") while checking does not contain ("+ValueDoesNotContain+")", "Fail");
			return false;
		}
		
	}
	
	/**
	 * @param Value
	 * @return Returns true on success else false
	 * @Description Verifies the value of view only (Any Text/Link) value from 1. Detail View 2. Inline Edit 3. Edit Layout page 
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueStartsWith(String Value) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
						
			//Identifying the page type
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
				if(remoteDriver.findElements(By.xpath(xp_common_in_ed_and_vd)).size() >0)
				{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
					//xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";
					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[contains(text(),'"+Value.trim()+"')][1]";							
				}		
				}
				else
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]//*[contains(@class,'field')]//*[text()][1]";
				}
				
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");

				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
				
			}
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
			//Getting the value from field
			String aValue = "";
			aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("textContent").trim();
			if(aValue.startsWith(Value.trim()))
			{
				System.out.println("Successfully verified the view only value("+Value+") of field ("+fieldname+").");
				AddLogToCustomReport("Successfully verified the view only value("+Value+") of field ("+fieldname+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
				AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
				return false;
			}
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
			AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
		
	}
	
	/**
	 * @param Value
	 * @return Returns true on success else false
	 * @Description Verifies the value of view only (Any Text/Link) value from 1. Detail View 2. Inline Edit 3. Edit Layout page 
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueEndsWith(String Value) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
						
			//Identifying the page type
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
				if(remoteDriver.findElements(By.xpath(xp_common_in_ed_and_vd)).size() >0)
				{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
					//xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";
					xpath = xp_common_in_ed_inline +"/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[contains(text(),'"+Value.trim()+"')][1]";								
				}
				}
				else
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]//*[contains(@class,'field')]//*[text()][1]";
				}
				
				
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");

				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
				
			}
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
			//Getting the value from field
			String aValue = "";
			aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("textContent").trim();
			if(aValue.endsWith(Value.trim()))
			{
				System.out.println("Successfully verified the view only value("+Value+") of field ("+fieldname+").");
				AddLogToCustomReport("Successfully verified the view only value("+Value+") of field ("+fieldname+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
				AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
				return false;
			}
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
			AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
		
	}
	
	
	
	
	/**
	 * @return
	 * @Page Layout: Support of Lightening UI in below two layout 1. Edit Page Layout 2. Inline Edit Page  
	 * @Description Can read the value from TextField, TextArea, DateLookup from record edit page and inline edit page. It cannot verify from lookup field, Single Select Picklist, Multiselect picklist and checkbox values. There are separate methods to accomplish these tyles of elements
	 * @throws Exception
	 */
	public boolean VerifyEditFieldValueEquals(String Value) throws Exception
	{
			try{
				
				WaitForPageToLoad(60);
				
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						//Not applicable in this logic			
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");

					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String aValue = "";
				aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value").trim();
				if(aValue.equals(Value.trim()))
				{
					System.out.println("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").");
					AddLogToCustomReport("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").", "Pass");
					return true;
				}
				else
				{
					System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
					AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
					return false;
				}							
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
				AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
				
			}
		
	}		
	
	/**
	 * @param ValueDoesNotContain
	 * @return
	 * @Description Verifies Edit field value does not contain supplied value
	 * @PageLayout 1. Inline Edit Layout 2. Edit Layout   
	 * @FieldType Text Box, Text Area, Date type  
	 * @throws Exception
	 */
	public boolean VerifyEditFieldValueDoesNotContain(String ValueDoesNotContain) throws Exception
	{
			try{
				
				WaitForPageToLoad(60);
				
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String aValue = "";
				aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value").trim();
				if(!aValue.contains(ValueDoesNotContain.trim()))
				{
					System.out.println("Successfully verified that Edit field ("+fieldname+") does not contain ("+ValueDoesNotContain+").");
					AddLogToCustomReport("Successfully verified that Edit field ("+fieldname+") does not contain ("+ValueDoesNotContain+").", "Pass");
					return true;
				}
				else
				{
					System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+") while checking doesnot contain ("+ValueDoesNotContain+")");
					AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") while checking doesnot contain ("+ValueDoesNotContain+")", "Fail");
					return false;
				}							
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+") while checking doesnot contain ("+ValueDoesNotContain+")");
				AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") while checking doesnot contain ("+ValueDoesNotContain+")", "Fail");
				return false;
				
			}
		
	}		
	
	
	/**
	 * @return
	 * @Page Layout: Support of Lightening UI in below two layout 1. Edit Page Layout 2. Inline Edit Page  
	 * @Description Can read the value from TextField, TextArea, DateLookup from record edit page and inline edit page. It cannot verify from lookup field, Single Select Picklist, Multiselect picklist and checkbox values. There are separate methods to accomplish these tyles of elements
	 * @throws Exception
	 */
	public boolean VerifyEditFieldValueContains(String Value) throws Exception
	{
			try{
				
				WaitForPageToLoad(60);
				
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
				}
				System.out.println("xpath:"+xpath);
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String aValue = "";
				aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value").trim();
				System.out.println("value is:"+aValue);
							
				if(aValue.contains(Value.trim()))
				{
					System.out.println("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").");
					AddLogToCustomReport("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").", "Pass");
					return true;
				}
				else
				{
					System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
					AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
					return false;
				}							
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
				AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
				
			}
		
	}	
	/**
	 * @return
	 * @Page Layout: Support of Lightening UI in below two layout 1. Edit Page Layout 2. Inline Edit Page  
	 * @Description Can read the value from TextField, TextArea, DateLookup from record edit page and inline edit page. It cannot verify from lookup field, Single Select Picklist, Multiselect picklist and checkbox values. There are separate methods to accomplish these tyles of elements
	 * @throws Exception
	 */
	public boolean VerifyEditFieldValueStartsWith(String Value) throws Exception
	{
			try{
				
				WaitForPageToLoad(60);
				
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String aValue = "";
				aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value").trim();
				if(aValue.startsWith(Value.trim()))
				{
					System.out.println("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").");
					AddLogToCustomReport("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").", "Pass");
					return true;
				}
				else
				{
					System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
					AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
					return false;
				}							
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
				AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
				
			}
		
	}	
	/**
	 * @return
	 * @Page Layout: Support of Lightening UI in below two layout 1. Edit Page Layout 2. Inline Edit Page  
	 * @Description Can read the value from TextField, TextArea, DateLookup from record edit page and inline edit page. It cannot verify from lookup field, Single Select Picklist, Multiselect picklist and checkbox values. There are separate methods to accomplish these tyles of elements
	 * @throws Exception
	 */
	public boolean VerifyEditFieldValueEndsWith(String Value) throws Exception
	{
			try{
				
				WaitForPageToLoad(60);
				
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline +"/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String aValue = "";
				aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value").trim();
				if(aValue.endsWith(Value.trim()))
				{
					System.out.println("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").");
					AddLogToCustomReport("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").", "Pass");
					return true;
				}
				else
				{
					System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
					AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
					return false;
				}							
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
				AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
				
			}
		
	}	
	
	
	/**
	 * @Description 
	 * @param CheckedORNotChecked
	 * @return
	 * @throws Exception
	 */
	public boolean VerifyCheckBoxValue(String CheckedORNotChecked) throws Exception
	{
		try{
			WaitForPageToLoad(60);
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
				if(remoteDriver.findElements(By.xpath(xp_common_in_ed_and_vd)).size() >0)
				{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed_inline ++ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor-or-self::label[contains(@class,'checkbox')]/following-sibling::*[1]//*[@type='checkbox'][1]";
					System.out.println("xpath:"+xpath);
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
					{
						if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
						{
							System.out.println("Successfully verified checkbox field ("+fieldname+") as Not Checked.");
							AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Not Checked.", "Pass");
							return true;	
						}
						else
						{
							System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Not Checked)");
							AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Not Checked)", "Fail");
							return false;
						}
						
					}
					else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
					{
						if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
						{
							System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)");
							AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)", "Fail");
							return false;	
						}
						else
						{
							System.out.println("Successfully verified checkbox field ("+fieldname+") as Checked.");
							AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Checked.", "Pass");
							return true;
						}
						
					}
					else
					{
						System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
						AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
						return false;
					}
		
			
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::div[1]/descendant::img[1]";
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					
					String chk_app_field_val = remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt").toString().trim();
					if (chk_app_field_val.contains("Not") || chk_app_field_val.contains("Un") || chk_app_field_val.contains("not") || chk_app_field_val.contains("un")) {
					
						if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
						{
							System.out.println("Successfully verified checkbox field ("+fieldname+") as Not Checked.");
							AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Not Checked.", "Pass");
							return true;	
						}
						else
						{
							System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Not Checked)");
							AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Not Checked)", "Fail");
							return false;
						}
						
					}
					else
					{
						if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
						{
							System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)");
							AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)", "Fail");
							return false;	
						}
						else
						{
							System.out.println("Successfully verified checkbox field ("+fieldname+") as Checked.");
							AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Checked.", "Pass");
							return true;
						}
						
					}
					
					
				}	
				}
				else
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::div[1]/descendant::img[1]";
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					
					String chk_app_field_val = remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt").toString().trim();
					if (chk_app_field_val.contains("Not") || chk_app_field_val.contains("Un") || chk_app_field_val.contains("not") || chk_app_field_val.contains("un")) {
					
						if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
						{
							System.out.println("Successfully verified checkbox field ("+fieldname+") as Not Checked.");
							AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Not Checked.", "Pass");
							return true;	
						}
						else
						{
							System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Not Checked)");
							AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Not Checked)", "Fail");
							return false;
						}
						
					}
					else
					{
						if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
						{
							System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)");
							AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)", "Fail");
							return false;	
						}
						else
						{
							System.out.println("Successfully verified checkbox field ("+fieldname+") as Checked.");
							AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Checked.", "Pass");
							return true;
						}
						
					}
					
					
					
				}
				
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				//xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
				xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor-or-self::label[contains(@class,'checkbox')]/following-sibling::*[1]//*[@type='checkbox'][1]";
				System.out.println("xpath:"+xpath);
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
				{
					if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
					{
						System.out.println("Successfully verified checkbox field ("+fieldname+") as Not Checked.");
						AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Not Checked.", "Pass");
						return true;	
					}
					else
					{
						System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Not Checked)");
						AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Not Checked)", "Fail");
						return false;
					}
					
				}
				else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
				{
					if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
					{
						System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)");
						AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)", "Fail");
						return false;	
					}
					else
					{
						System.out.println("Successfully verified checkbox field ("+fieldname+") as Checked.");
						AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Checked.", "Pass");
						return true;
					}
					
				}
				else
				{
					System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
					AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
					return false;
				}
				
				
			}
			System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
			AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
			return false;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
			AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
			return false;
			
		}
				
	}
	
	
	/**
	 * @param ValueInPLField
	 * @return True if success else returns false
	 * @PageLayout Inline Edit / Edit Page Layout
	 * @Description Verifies the Default/Displayed value in single select pick list
	 * @throws Exception
	 */
	public boolean VerifyPLDefaultValue(String ValueInPLField) throws Exception
	{

		try
		{
			WaitForPageToLoad(60);
			
			
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[text()='"+fieldname+"']/ancestor-or-self::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')][1]/following-sibling::div[1]/descendant::*[local-name()='a' or local-name()='input'][contains(@class,'select') or contains(@class,'combobox')][1]";
			
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
													
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";
				//xpath = "(//div[contains(@class,'DESKTOP') and contains(@class,'active')]/descendant::div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')][text()='"+fieldname+"']/following-sibling::div[1]/descendant::input[contains(@class,'combobox')])[1]";
				xpath = "//div[contains(@class,'isModal') and contains(@class,'active')]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[text()='"+fieldname+"']/ancestor-or-self::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')][1]/following-sibling::div[contains(@class,'form-element')]//*[text()][1]";
			
			}
			if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
			{
				System.out.println("SERVICE CONSOLE CREATE PAGE");	
				String xp1 = xp_common_vd + "//descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][@role='combobox'][1]/descendant-or-self::*[text()][1]";
				String xp2 = xp_common_vd + "//descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/../following-sibling::*[1]/descendant::*[contains(@class,'select')][1]/descendant-or-self::*[text()][1]";
				String xp3 = xp_common_vd + "//descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/../descendant::button[contains(@class,'combobox')][1]//*[text()][1]";
				//Getting the correct element
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
	            List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xp3));
	            if (myDynamicElement.size() > 0)
	            {
	            	xpath = xp3;
	            }
	            else if(remoteDriver.findElements(By.xpath(xp2)).size()>0)
	            {	
	            	xpath = xp2;
	            }
	            else if(remoteDriver.findElements(By.xpath(xp1)).size()>0)
	            {	
	            	xpath = xp1;
	            }
	            else
	            {
	            	System.out.println("Error: No matching xpath found for single select picklist...");
	            	System.out.println("xp1:"+xp1);
	            	System.out.println("xp2:"+xp2);
	            	System.out.println("xp3:"+xp3);
	            }
	            System.out.println("xpath:"+xpath);
			}
			//Scrolling to element
			System.out.println("xpath:-->"+xpath);
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			String tag = remoteDriver.findElement(By.xpath(xpath)).getTagName();
			System.out.println("Tagname is:"+tag);
			String Value = "";
			if (tag.equals("a") || tag.equals("span"))
			{
				Value = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
			}
			else
			{
				Value = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value");
			}
			
			System.out.println("Value of field ("+fieldname + ") is:"+Value);
		if (Value.equals(ValueInPLField))
		{		
			AddLogToCustomReport("Successfully verified the selected value in picklist field ("+fieldname+"). is ("+Value+")", "Pass");
			System.out.println("Successfully verified the selected value in picklist field ("+fieldname+"). is ("+Value+")");
			return true;
		}
		else
		{
			System.out.println("Unable to read the value of picklist field ("+fieldname+") as xpath does not result any element.");
			AddLogToCustomReport("Unable to read the value of picklist field ("+fieldname+") as xpath does not result any element.", "Fail");
			return false;
		}
		}
		catch(Exception e)
		{
			AddLogToCustomReport("Unable to read the value of pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
			System.out.println("Unable to read the value of pick list field ("+fieldname+") when xpath is ("+xpath+")");
			return false;	
		}
		
	}

	  /**
	 	 * @author Sourav
	 	 * @PageDisplayMode Edit
	 	 * @Description Verify pick list field values from Edit page and sends the message to the Log
	 	 * @param Values
	 	 * @return boolean
	 	 * @throws Exception
	 	 */
	 	public boolean VerifyAllPLValue(String Values_SemicolonSeperated) throws Exception
	 	{
	 		
	 		//xpath="//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
			try
			{
				WaitForPageToLoad(60);
				
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed_inline + + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
						String xp1 = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][@role='combobox'][1]";
						String xp2 = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/../following-sibling::*[1]/descendant::*[contains(@class,'select')][1]";
						
						//Getting the correct element
						remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
			            List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xp1));
			            if (myDynamicElement.size() > 0)
			            {
			            	xpath = xp1;
			            }
			            else if(remoteDriver.findElements(By.xpath(xp2)).size()>0)
			            {	
			            	xpath = xp2;
			            }
			            System.out.println("xpath:"+xpath);
						
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					String xp1 = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][@role='combobox'][1]";
					String xp2 = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/../following-sibling::*[1]/descendant::*[contains(@class,'select')][1]";
					
					//Getting the correct element
					remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
		            List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xp1));
		            if (myDynamicElement.size() > 0)
		            {
		            	xpath = xp1;
		            }
		            else if(remoteDriver.findElements(By.xpath(xp2)).size()>0)
		            {	
		            	xpath = xp2;
		            }
		            System.out.println("xpath:"+xpath);
					
				}
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				ScrollToElement(getsingleWebelement);
				Thread.sleep(1000L);		
				getsingleWebelement.click();
				
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5)); 
				int no_of_val =  remoteDriver.findElements(By.xpath("(//div[contains(@class,'combobox') or contains(@class,'dropdown') or contains(@class,'select')][contains(@class,'is-open') or contains(@class,'visible')]//*[@role='option' or @role='menu']//*[text()=@title])")).size();
				
				List<String> ExpectedValues = Arrays.asList(Values_SemicolonSeperated.split(";"));
		 		String failedPLValue="";
		 		for(String exp:ExpectedValues)
		 		{
		 			
		 			int a = remoteDriver.findElements(By.xpath("(//div[contains(@class,'combobox') or contains(@class,'dropdown') or contains(@class,'select')][contains(@class,'is-open') or contains(@class,'visible')]//*[@role='option' or @role='menu']//*[text()=@title][normalize-space(text())='"+exp+"'])[1]")).size();
		 			if (a == 0)
		 			{
		 				if (failedPLValue.equals(""))
		 				{
		 					failedPLValue = exp;
		 					
						}
		 				else
		 				{
		 					failedPLValue = failedPLValue + "," + exp;
		 				}
						
					}
		 			
		 		}
				
		 		if(failedPLValue=="")
		 		{
		 			System.out.println("Successfully verified the Available List of Values("+Values_SemicolonSeperated+") in PickList field ("+fieldname+")");
		 			AddLogToCustomReport("Successfully verified the Available List of Values("+Values_SemicolonSeperated+") in picklist field ("+fieldname+")", "Pass");
		 			return true;
		 		}
		 		else
		 		{
		 			System.out.println("Could not find pick list values ("+failedPLValue+") in the available list of field("+fieldname+").");
		 			AddLogToCustomReport("Could not find pick list values ("+failedPLValue+") in the available list of field("+fieldname+").", "Fail");
		 			return false;
		 		}
		 		
		 	}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
				System.out.println("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")");
				return false;
			}
			
	}
	 	
	 	
	 	/**
	 	 * @return
	 	 * @Description Clicks on view only link text value on 1. Detail View 2. Edit Page 3. Inline Edit Page layout
	 	 * @throws Exception
	 	 */
	 	public boolean ClickONViewOnlyLinkValue() throws Exception
		{
			
					
	 		try{
				WaitForPageToLoad(60);
							
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
					if(remoteDriver.findElements(By.xpath(xp_common_in_ed_and_vd)).size() >0)
					{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]/descendant-or-self::a[1]";
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("xp_common_in_ed_and_vd -->  DETAIL VIEW PAGE");	
						xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1])/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]/descendant-or-self::a[1]";								
					}			
					}
					else
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::a[1]";						
					}
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]/descendant-or-self::a[1]";
					
					
				}
				System.out.println("xpath:"+xpath);
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				String Value = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
				//remoteDriver.findElement(By.xpath(xpath+"/descendant-or-self::*[text()][1]")).click();
				JavaScriptClick(remoteDriver.findElement(By.xpath(xpath+"/descendant-or-self::*[text()][1]")));
				System.out.println("Clicked on value("+Value+") of field ("+fieldname+").");
				AddLogToCustomReport("Clicked on value("+Value+") of field ("+fieldname+").", "Pass");
				return true;
						
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to find the text/link element to click against field ("+fieldname+").");
				AddLogToCustomReport("Unable to find the text/link element to click against field ("+fieldname+")", "Fail");
				return false;
				
			}
		}
	 	
	 	
	
		/**
		 * @return
		 * @PageType Only for Detail View page
		 * @Description This enables inline editing against the field 
		 * @throws Exception
		 */
		public boolean ClickToEnableInlineEditing() throws Exception
		{
						
				try{
					
					WaitForPageToLoad(60);
					
					
					if(
							(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
													&&
							(remoteDriver.getCurrentUrl().trim().contains("view"))
													&&
							(
								remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
									                ||
							    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
						    )
					  )
					{
						remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
						if(remoteDriver.findElements(By.xpath(xp_common_in_ed_and_vd)).size() >0)
						{
						if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
						{
							System.out.println("INLINE EDIT PAGE");
							//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
							//do nothing
					
						}				
						else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
						{
							System.out.println("xp_common_in_ed_and_vd - DETAIL VIEW PAGE");	
							xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/following-sibling::button[contains(@class,'inline-edit')][1]";
													
						}	
						}
						else
						{
							System.out.println("DETAIL VIEW PAGE");	
							xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/following-sibling::button[contains(@class,'inline-edit')][1]";							
						}
						
					}
					
					if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
					{
						System.out.println("---------EDIT VIEW-----------");
						//do nothing
					}
					
					
					remoteDriver.findElement(By.xpath(xpath)).click();
					System.out.println("Clicked on the inline editing button against field ("+fieldname+").");
					AddLogToCustomReport("Clicked on the inline editing button against field ("+fieldname+").", "Pass");
					return true;
							
					
				}catch(Exception e)
				{
					e.printStackTrace();
					System.out.println("Unable to click on inline editing button against the field ("+fieldname+").");
					AddLogToCustomReport("Unable to click on inline editing button against the field ("+fieldname+").","Fail");
					return false;
					
				}
			
		}
	 	
	 	
		/**
		 * @return True if click is successful else returns false
		 * @Description Clicks on any input field on Edit Layout and Inline Edit Layout  
		 * @throws Exception
		 */
		public boolean ClickONInputField() throws Exception
		{
						
				try{
					
					WaitForPageToLoad(60);
					
					if(
							(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
													&&
							(remoteDriver.getCurrentUrl().trim().contains("view"))
													&&
							(
								remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
									                ||
							    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
						    )
					  )
					{
						if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
						{
							System.out.println("INLINE EDIT PAGE");
							xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
						}				
						else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
						{
							System.out.println("DETAIL VIEW PAGE");	
															
						}			
						
					}
					
					if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
					{
						System.out.println("---------EDIT VIEW-----------");

						xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"'][1]/../descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}
					if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
					{
						System.out.println("SERVICE CONSOLE CREATE PAGE");	
						xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor-or-self::*[(local-name()='label' or local-name()='div') and contains(@class,'label')][1]/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}
					
					//Getting the value from field
					String Value = "";
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					Value = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value");
					remoteDriver.findElement(By.xpath(xpath)).clear();
					remoteDriver.findElement(By.xpath(xpath)).click();
					System.out.println("Clicked on the value("+Value+") of field ("+fieldname+").");
					AddLogToCustomReport("Clicked on the value("+Value+") of field ("+fieldname+").", "Pass");
					return true;
							
					
				}catch(Exception e)
				{
					e.printStackTrace();
					System.out.println("Unable to click the value against field ("+fieldname+").");
					AddLogToCustomReport("Unable to click the value against field ("+fieldname+")","Fail");
					return false;
					
				}
			
		}
		
		/**
		 * @return True if click is successful else returns false
		 * @Description Clicks on any text  or field  or label on any Layout as per input exact match which should be unique 
		 * @throws Exception
		 */
		public boolean ClickONAnyTextElementField() throws Exception
		{
						
				try{
					
					WaitForPageToLoad(60);
					xpath = "(//*[normalize-space(text())='"+fieldname+"'])[1]";
					List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
		            if (myDynamicElement.size() > 0)
		            {
		            	remoteDriver.findElement(By.xpath(xpath)).click();
		            }
										
					System.out.println("Clicked on the text element ("+fieldname+").");
					AddLogToCustomReport("Clicked on the text element ("+fieldname+").", "Pass");
					return true;
							
					
				}catch(Exception e)
				{
					e.printStackTrace();
					System.out.println("Unable to click on text element ("+fieldname+"), either the element is not available or could be multiple match");
					AddLogToCustomReport("Unable to click on text element ("+fieldname+"), either the element is not available or could be multiple match","Fail");
					return false;
					
				}
			
		}
		
		
		/**
		 * @return True if click is successful else returns false
		 * @Description Clicks on any text  or field  or label on any Layout as per input pattial match which should be unique 
		 * @throws Exception
		 */
		public boolean ClickONAnyPartialTextElementField() throws Exception
		{
						
				try{
					
					WaitForPageToLoad(60);
					xpath = "(//*[contains(normalize-space(text()),'"+fieldname+"')])[1]";
					List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
		            if (myDynamicElement.size() > 0)
		            {
		            	remoteDriver.findElement(By.xpath(xpath)).click();
		            }
										
					System.out.println("Clicked on the text element ("+fieldname+").");
					AddLogToCustomReport("Clicked on the text element ("+fieldname+").", "Pass");
					return true;
							
					
				}catch(Exception e)
				{
					e.printStackTrace();
					System.out.println("Unable to click on text element ("+fieldname+"), either the element is not available or could be multiple match");
					AddLogToCustomReport("Unable to click on text element ("+fieldname+"), either the element is not available or could be multiple match","Fail");
					return false;
					
				}
			
		}
		
		/**
		 * @param Value
		 * @Description Types supplied value of Text(input) Field/ Test Area/ Date Field. This cannot be used to type in Salesforce Lookup 
		 * @returns True on successful typing else returns false
		 * @PageLayout Edit Page and Inline Edit page layout
		 * @throws Exception
		 */
		public boolean Type(String Value) throws Exception
		{
						
				try{
					
					WaitForPageToLoad(60);
					
					
					if(
							(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
													&&
							(remoteDriver.getCurrentUrl().trim().contains("view"))
													&&
							(
								remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
									                ||
							    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
						    )
					  )
					{
						if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
						{
							System.out.println("INLINE EDIT PAGE");
							xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
							System.out.println("Xpath is:"+xpath);
							
						}				
						else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
						{
							System.out.println("DETAIL VIEW PAGE");	
															
						}			
						
					}
					
					if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
					{
						System.out.println("---------EDIT VIEW-----------");
						//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}
					if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
					{
						System.out.println("SALES / SERVICE CONSOLE CREATE PAGE");	
						xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor-or-self::*[(local-name()='label' or local-name()='div') and contains(@class,'label')][1]/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}
					
					
					
					
					
					System.out.println("Xpath:"+xpath);
					//Scrolling to element
					//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					//WaitForElement(xpath, 30);
					getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
					getsingleWebelement.clear();
					//Thread.sleep(1000L);
					getsingleWebelement.sendKeys(Value);
					//JavascriptExecutor jsExecutor = (JavascriptExecutor) remoteDriver;
					//jsExecutor.executeScript("arguments[0].fireEvent('onchange');", getsingleWebelement);
									
					AddLogToCustomReport("Entered the value ("+Value+") in the field ("+fieldname+").", "Pass");
					System.out.println("Entered the value ("+Value+") in the field ("+fieldname+").");
					return true;
			
				}catch(Exception e)
				{
					e.printStackTrace();
					AddLogToCustomReport("Unable to enter the value ("+Value+") in the field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
					System.out.println("Unable to enter the value ("+Value+") in the field ("+fieldname+") when xpath is ("+xpath+")");
					return false;
					
				}
			
		}
		
		
		/**
		 * 
		 * @author Sourav Mukherjee
		 * @Description Verifies the field level error message in the edit page
		 * @return boolean
		 * @throws Exception
		 */
		synchronized public boolean VerifyFieldErrorMsgOnEditPage(String ErrorMessage) throws Exception
		{
			
			String xp1="";
			String xp2="";
			String xp3="";
			String xp4="";
			try
			{
				System.out.println("-->"+remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString());
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					System.out.println("inside top levele if");
					System.out.println("xp_common_in_ed_and_vd:"+xp_common_in_ed_and_vd);
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed_inline ++ "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../../following-sibling::ul[contains(@class,'error')][1]";
						xp1 = xp_common_in_ed_inline+ "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]//*[normalize-space(text())='"+fieldname+"']/following-sibling::*[contains(@class,'help')][1]";
						System.out.println("xp1:"+xp1);
						
						xp2 = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]//*[normalize-space(text())='"+fieldname+"']/ancestor::*[contains(@class,'error')][1]/following-sibling::ul[contains(@class,'error')]//*[contains(@class,'help')][text()]";
						System.out.println("xp2:"+xp2);
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");

					xp1 = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]//*[normalize-space(text())='"+fieldname+"']/following-sibling::*[contains(@class,'help')][1]";
					System.out.println("xp1:"+xp1);
					
					xp2 = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]//*[normalize-space(text())='"+fieldname+"']/ancestor::*[contains(@class,'error')][1]/following-sibling::ul[contains(@class,'error')]//*[contains(@class,'help')][text()]";
					System.out.println("xp2:"+xp2);
					
					//*[contains(@class,'help')][text()]
					xp3 = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]//*[normalize-space(text())='"+fieldname+"']/ancestor::*[contains(@class,'error')][1]//*[contains(@class,'help')][text()]";
					System.out.println("xp3:"+xp3);				
					
					//*[contains(@class,'help')][text()]
					xp4 = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]//*[normalize-space(text())='"+fieldname+"']/ancestor::div[contains(@class, 'form-element')]//*[contains(@class, 'error')][contains(@class, 'uiInputDefaultError')]";
					System.out.println("xp4:"+xp4);	
				}
				if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
				{
					System.out.println("SERVICE CONSOLE CREATE PAGE");	
					xp1 = "//descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]//*[normalize-space(text())='"+fieldname+"']/ancestor::*[contains(@class,'error')][1]//*[contains(@class,'help')][text()]";
				}
								
				
				//Getting the correct xpath for Error message
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
				if (remoteDriver.findElements(By.xpath(xp1)).size() > 0)
	            {
					xpath = xp1;
	            	System.out.println("xpath matched for xp1:"+xpath);
	            }
				else if (remoteDriver.findElements(By.xpath(xp2)).size() > 0)
				{
					xpath = xp2;
					System.out.println("xpath matched for xp2:"+xpath);
				}
				else if (remoteDriver.findElements(By.xpath(xp3)).size() > 0) 
				{
					xpath = xp3;
					System.out.println("xpath matched for xp3:"+xpath);
				}
				else
				{
					System.out.println("unable to find any of the xpath as per defined criteria...");
				}
					
	            //Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));

				if (getsingleWebelement.getText().trim().contains(ErrorMessage.trim()))
				{
					System.out.println("Successfully verified the error message ("+ErrorMessage+") on field ("+fieldname+")");
					AddLogToCustomReport("Successfully verified the error message ("+ErrorMessage+") on field ("+fieldname+")", "Pass");
					return true;
				}
				else
				{
					System.out.println("Unable to verify the error message on field ("+fieldname+"). Actual Error Message was ("+getsingleWebelement.getText().trim()+") when Expected Error Message is ("+ErrorMessage+")");
					AddLogToCustomReport("Unable to verify the error message on field ("+fieldname+"). Actual Error Message was ("+getsingleWebelement.getText().trim()+") when Expected Error Message is ("+ErrorMessage+")", "Fail");
					return false;
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				AddLogToCustomReport("Unable to find the element when xpath is:"+xpath, "Fail");
				System.out.println("Unable to find the element when xpath is:"+xpath);
				return false;
			}
		}
		
		
		/**
		 * @param Value
		 * @return boolean
		 * @throws Exception
		 * @Description Selects pick list field value by visible text
		 */
		public synchronized void SelectPL(String Value) throws Exception
		{
			
			//xpath="//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
			try
			{
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed_inline + + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]/descendant::a[1]";
						String xp1 = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][@role='combobox'][1]";
						String xp2 = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/../following-sibling::*[1]/descendant::*[contains(@class,'select')][1]";
						
						//Getting the correct element
						remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
			            List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xp1));
			            if (myDynamicElement.size() > 0)
			            {
			            	xpath = xp1;
			            }
			            else if(remoteDriver.findElements(By.xpath(xp2)).size()>0)
			            {	
			            	xpath = xp2;
			            }
			            System.out.println("xpath:"+xpath);
						getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
						ScrollToElement(getsingleWebelement);
						Thread.sleep(1000L);		
						getsingleWebelement.click();
						Thread.sleep(1000L);
						remoteDriver.findElement(By.xpath("(//div[contains(@class,'combobox') or contains(@class,'dropdown') or contains(@class,'select')][contains(@class,'is-open') or contains(@class,'visible')]//*[@role='option' or @role='menu']//*[text()='"+Value.trim()+"'])[1]")).click();
						AddLogToCustomReport("Selected the value ("+Value+") from picklist field ("+fieldname+").", "Pass");
						System.out.println("Selected the value ("+Value+") from picklist field ("+fieldname+").");
				
						
						
						/*
						Robot robot = new Robot();
						Point coordinates = remoteDriver.findElement(By.xpath(xpath)).getLocation();
						robot.mouseMove(coordinates.getX(),coordinates.getY());
						robot.mouseWheel(3);
						 */
						/*
						JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
						js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
						         
						
						Thread.sleep(3000L);
						
						//remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")).click();
						xpath = "(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]";
						//js = (JavascriptExecutor) remoteDriver;
						//js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
						//remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")).click();
						JavaScriptClick(remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")));
						*/
						
						getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
						ScrollToElement(getsingleWebelement);
						Thread.sleep(1000L);		
						getsingleWebelement.click();
						remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")).click();
						
						
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";								
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					//xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'active')]/descendant::div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					String xp1 = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][@role='combobox'][1]";
					String xp2 = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/../following-sibling::*[1]/descendant::*[contains(@class,'select')][1]";
					String xp3 = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/../descendant::button[contains(@class,'combobox')][1]";
					
					//Getting the correct element
					remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
		            List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xp3));
		            if (myDynamicElement.size() > 0)
		            {
		            	xpath = xp3;
		            }
		            else if(remoteDriver.findElements(By.xpath(xp2)).size()>0)
		            {	
		            	xpath = xp2;
		            }
		            else if(remoteDriver.findElements(By.xpath(xp1)).size()>0)
		            {	
		            	xpath = xp1;
		            }
		            else
		            {
		            	System.out.println("Error: No matching xpath found for single select picklist...");
		            	System.out.println("xp1:"+xp1);
		            	System.out.println("xp2:"+xp2);
		            	System.out.println("xp3:"+xp3);
		            }
		            System.out.println("xpath:"+xpath);
					getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
					ScrollToElement(getsingleWebelement);
					Thread.sleep(2000L);	
					remoteDriver.switchTo().window(remoteDriver.getWindowHandle());
					getsingleWebelement.click();
					//JavaScriptClick(getsingleWebelement);
					//Thread.sleep(2000L);
					remoteDriver.findElement(By.xpath("(//div[contains(@class,'combobox') or contains(@class,'dropdown') or contains(@class,'select')][contains(@class,'is-open') or contains(@class,'visible')]//*[@role='option' or @role='menu']//*[normalize-space(text())='"+Value.trim()+"'])[1]")).click();
					AddLogToCustomReport("Selected the value ("+Value+") from picklist field ("+fieldname+").", "Pass");
					System.out.println("Selected the value ("+Value+") from picklist field ("+fieldname+").");
				
				}
				
				if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
				{
					System.out.println("SERVICE CONSOLE CREATE PAGE");	
					String xp1 = xp_common_vd + "//descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][@role='combobox'][1]";
					String xp2 = xp_common_vd + "//descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/../following-sibling::*[1]/descendant::*[contains(@class,'select')][1]";
					String xp3 = xp_common_vd + "//descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/../descendant::button[contains(@class,'combobox')][1]";
					//Getting the correct element
					remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
		            List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xp3));
		            if (myDynamicElement.size() > 0)
		            {
		            	xpath = xp3;
		            }
		            else if(remoteDriver.findElements(By.xpath(xp2)).size()>0)
		            {	
		            	xpath = xp2;
		            }
		            else if(remoteDriver.findElements(By.xpath(xp1)).size()>0)
		            {	
		            	xpath = xp1;
		            }
		            else
		            {
		            	System.out.println("Error: No matching xpath found for single select picklist...");
		            	System.out.println("xp1:"+xp1);
		            	System.out.println("xp2:"+xp2);
		            	System.out.println("xp3:"+xp3);
		            }
		            System.out.println("xpath:"+xpath);
		            getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
		            
		            ScrollToElement(getsingleWebelement);
					Thread.sleep(1000L);		
					getsingleWebelement.click();
					Thread.sleep(3000L);
					remoteDriver.findElement(By.xpath("(//div[contains(@class,'combobox') or contains(@class,'dropdown') or contains(@class,'select')][contains(@class,'is-open') or contains(@class,'visible')]//*[@role='option' or @role='menu']//*[text()='"+Value.trim()+"'])[1]")).click();
					AddLogToCustomReport("Selected the value ("+Value+") from picklist field ("+fieldname+").", "Pass");
					System.out.println("Selected the value ("+Value+") from picklist field ("+fieldname+").");
				
				}
							
					
			}
			catch(Exception e)
			{
				e.printStackTrace();
				AddLogToCustomReport("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
				System.out.println("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")");
				
			}
		}
		
		public synchronized void WaitFluentForElement() throws Exception
		{
			try
			{
			// Waiting 30 seconds for an element to be present on the page, checking
			// for its presence once every 5 seconds.
				
			//Yet to be implemented
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		public boolean SelectPLByJSClick(String Value) throws Exception
		{
			
			//xpath="//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
			try
			{
				/*
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed_inline + + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					
				}
				if((remoteDriver.getCurrentUrl().trim().contains("/view")||remoteDriver.getCurrentUrl().trim().contains("/home")) && !remoteDriver.getCurrentUrl().trim().contains("rlName") &&!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------VIEW DETAILS-----------");
					xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";								
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'active')]/descendant::div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					
					
				}
				//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				getsingleWebelement.click();
				//Thread.sleep(3000L);
				System.out.println("xpath:(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]");
				//remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")).click();
				JavaScriptClick(remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")));
				
				//Thread.sleep(2000L);
				if(remoteDriver.findElement(By.xpath(xpath+"/descendant::a[1]")).getText().trim().equals(Value))
				{
					AddLogToCustomReport("Selected the value ("+Value+") from picklist field ("+fieldname+").", "Pass");
					System.out.println("Selected the value ("+Value+") from picklist field ("+fieldname+").");
					return true;
				}
				else
				{
					AddLogToCustomReport("Unable to find the pick list field ("+fieldname+").", "Fail");
					System.out.println("Unable to find the pick list field ("+fieldname+").");
					return false;
				}
				
			}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
				System.out.println("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")");
				return false;
			}
		}
		
		
		/**
		 * @param Value
		 * @return
		 * @throws Exception
		 */
		public boolean SelectPL_Contains(String Value) throws Exception
		{
			
			//xpath="//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
			try
			{
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline +  "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					
				}
				if((remoteDriver.getCurrentUrl().trim().contains("/view")||remoteDriver.getCurrentUrl().trim().contains("/home")) && !remoteDriver.getCurrentUrl().trim().contains("rlName") &&!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------VIEW DETAILS-----------");
					xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				}
				else {
					xpath = "//button[contains(@class, 'slds-combobox')]/ancestor::*[local-name()='div' and contains(@part,'combobox')]/label[text()='"+fieldname+"']";
				}
				//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				getsingleWebelement.click();
				//Thread.sleep(1000L);
				WebElement combobox = remoteDriver.findElement(By.xpath(xpath+"/ancestor::*[local-name()='div' and contains(@part,'combobox')]/descendant::*[local-name()='div' and contains(@class, 'slds-listbox')]/lightning-base-combobox-item/span[2]/span[text()='"+Value+"']")); 
				combobox.click();
//				remoteDriver.findElement(By.xpath("//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'][1]/descendant-or-self::a[contains(normalize-space(text()),'"+Value.trim()+"')][1]")).click();
				//Thread.sleep(1000L);
//				if(remoteDriver.findElement(By.xpath(xpath+"/descendant::a[1]")).getText().trim().contains(Value))
//				{
//					AddLogToCustomReport("Selected the pick list value containing ("+Value+") from picklist field ("+fieldname+").", "Pass");
//					System.out.println("Selected the pick list value containing ("+Value+") from picklist field ("+fieldname+").");
//					return true;
//				}
//				else if(remoteDriver.findElement(By.xpath(xpath+"/ancestor::*[local-name()='div' and contains(@part,'combobox')]/descendant::*[local-name()='div' and contains(@class, 'slds-listbox')]/lightning-base-combobox-item/span[2]/span[text()='"+Value+"']")).getText().trim().contains(Value)) {
//					AddLogToCustomReport("Selected the pick list value containing ("+Value+") from picklist field ("+fieldname+").", "Pass");
//					System.out.println("Selected the pick list value containing ("+Value+") from picklist field ("+fieldname+").");
//					return true;
//				}
//				else
//				{
//					AddLogToCustomReport("Unable to find the pick list value containing ("+Value+") for field ("+fieldname+").", "Fail");
//					System.out.println("Unable to find the pick list value containing ("+Value+") for field ("+fieldname+").");
//					return false;
//				}
				AddLogToCustomReport("Selected the pick list value containing ("+Value+") from picklist field ("+fieldname+").", "Pass");
				System.out.println("Selected the pick list value containing ("+Value+") from picklist field ("+fieldname+").");
				return true;
				
			}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
				System.out.println("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")");
				return false;
			}
		}
		
		/**
	     * @author Sourav Mukherjee
	     * @Description Selects the picklist value by index where index starts from 1
	     * @param Index
	     * @return boolean
	     * @throws Exception
	     */
		public boolean SelectPLValueByIndex(int Index) throws Exception
		{
						
			try
			{
				/*
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed_inline + + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					
				}
				if((remoteDriver.getCurrentUrl().trim().contains("/view")||remoteDriver.getCurrentUrl().trim().contains("/home")) && !remoteDriver.getCurrentUrl().trim().contains("rlName") &&!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------VIEW DETAILS-----------");
					xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";								
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					
					
				}
				//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				getsingleWebelement.click();
				//Thread.sleep(3000L);
				
				remoteDriver.findElement(By.xpath("//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'][1]/ul[1]/li["+Index+"]/descendant-or-self::a[1]")).click();
				//Thread.sleep(1000L);
				AddLogToCustomReport("Selected the value by index ("+Index+") from picklist field ("+fieldname+").", "Pass");
	 			System.out.println("Selected the value by index ("+Index+") from picklist field ("+fieldname+").");
	 			return true;
				
			}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to choose the pick list field ("+fieldname+") value by index when xpath is ("+xpath+")", "Fail");
				System.out.println("Unable to find the pick list field ("+fieldname+") value by index when xpath is ("+xpath+")");
				return false;
			}
		}
		
		
		/**
		 * @param Value semicolon separated value for multiple
		 * @return boolean
		 * @throws Exception
		 * @Description Selects multiple values in the multi-select picklist field and adds to the Chosen list.
		 */
		public boolean MultiSelectAdd(String Value) throws Exception
		{
			String failed_value = "";
			try
			{
				String xp_available = "";
				String xp_chosen = "";
				String xp_available_alloptions = "";
				String xp_chosen_alloptions = "";
				String xp_right_arrow = "";
				String xp_left_arrow = "";
			
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed_inline + + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
						xp_available = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
						xp_chosen = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
						xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
						xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
						
						xpath = xp_available_alloptions;
						xp_right_arrow = xp_common_in_ed_inline+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
						xp_left_arrow = xp_common_in_ed_inline+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
							
						System.out.println("xp_available:"+xp_available);
						System.out.println("xp_chosen:"+xp_chosen);
						System.out.println("xp_available_alloptions:"+xp_available_alloptions);
						System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
						System.out.println("xp_right_arrow:"+xp_right_arrow);
						System.out.println("xp_left_arrow:"+xp_left_arrow);
						
						ScrollToElement(remoteDriver.findElement(By.xpath(xp_available)));
						
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");

					xp_available = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
					xp_chosen = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
					xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					
					xpath = xp_available_alloptions;
					xp_right_arrow = xp_common_in_ed+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
					xp_left_arrow = xp_common_in_ed+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
						
					System.out.println("xp_available:"+xp_available);
					System.out.println("xp_chosen:"+xp_chosen);
					System.out.println("xp_available_alloptions:"+xp_available_alloptions);
					System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
					System.out.println("xp_right_arrow:"+xp_right_arrow);
					System.out.println("xp_left_arrow:"+xp_left_arrow);
					
					ScrollToElement(remoteDriver.findElement(By.xpath(xp_available)));
					
					
				}
				
				if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
    			{
    				System.out.println("SERVICE/SALES CONSOLE CREATE PAGE");	
    				xp_available = xp_common_sales_or_service_console_create_page + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
					xp_chosen = xp_common_sales_or_service_console_create_page + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
					xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					
					xpath = xp_available_alloptions;
					xp_right_arrow = xp_common_sales_or_service_console_create_page+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
					xp_left_arrow = xp_common_sales_or_service_console_create_page+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
						
					System.out.println("xp_available:"+xp_available);
					System.out.println("xp_chosen:"+xp_chosen);
					System.out.println("xp_available_alloptions:"+xp_available_alloptions);
					System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
					System.out.println("xp_right_arrow:"+xp_right_arrow);
					System.out.println("xp_left_arrow:"+xp_left_arrow);
					
					ScrollToElement(remoteDriver.findElement(By.xpath(xp_available)));
				
    			}
				

				List<String> eachPLValue = Arrays.asList(Value.split(";"));
				for(String str: eachPLValue)
				{
					failed_value = str;
					remoteDriver.findElement(By.xpath("("+xpath+"[normalize-space(text())='"+str.trim()+"'])[1]")).click();
					remoteDriver.findElement(By.xpath(xp_right_arrow)).click();
										
				}
						
				System.out.println("Successfully added values ("+Value+") in the multi-select pick list field "+fieldname);
				AddLogToCustomReport("Successfully added values ("+Value+") in the multi-select pick list field "+fieldname, "Pass");
				return true;
			}
			catch(Exception e)
			{
				System.out.println("Unable to find the element for ("+failed_value+") while adding the value to multiselect picklist field ("+fieldname+") when xpath is:"+xpath);
				AddLogToCustomReport("Unable to find the element for ("+failed_value+") while adding the value to multiselect picklist field ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
			}

			
		}
		

		/**
		 * @param Value
		 * @return boolean
		 * @throws Exception
		 * @Description Removes multiple values from chosen list to Available list of multi-select pick list field. 
		 * 	
		 *  */
		public boolean MultiSelectRemove(String Value) throws Exception
		{
			String failed_value = "";
			try
			{
				String xp_available = "";
				String xp_chosen = "";
				String xp_available_alloptions = "";
				String xp_chosen_alloptions = "";
				String xp_right_arrow = "";
				String xp_left_arrow = "";
			
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed_inline ++ "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
						xp_available = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
						xp_chosen = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
						xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
						xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
						
						xpath = xp_chosen_alloptions;
						xp_right_arrow = xp_common_in_ed_inline+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
						xp_left_arrow = xp_common_in_ed_inline+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
							
						System.out.println("xp_available:"+xp_available);
						System.out.println("xp_chosen:"+xp_chosen);
						System.out.println("xp_available_alloptions:"+xp_available_alloptions);
						System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
						System.out.println("xp_right_arrow:"+xp_right_arrow);
						System.out.println("xp_left_arrow:"+xp_left_arrow);
						
						ScrollToElement(remoteDriver.findElement(By.xpath(xp_chosen)));
					
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");

					xp_available = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
					xp_chosen = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
					xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					
					xpath = xp_chosen_alloptions;
					xp_right_arrow = xp_common_in_ed+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
					xp_left_arrow = xp_common_in_ed+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
						
					System.out.println("xp_available:"+xp_available);
					System.out.println("xp_chosen:"+xp_chosen);
					System.out.println("xp_available_alloptions:"+xp_available_alloptions);
					System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
					System.out.println("xp_right_arrow:"+xp_right_arrow);
					System.out.println("xp_left_arrow:"+xp_left_arrow);
					
					ScrollToElement(remoteDriver.findElement(By.xpath(xp_chosen)));
					
					
				}
				if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
    			{
    				System.out.println("SERVICE/SALES CONSOLE CREATE PAGE");	
    				xp_available = xp_common_sales_or_service_console_create_page + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
					xp_chosen = xp_common_sales_or_service_console_create_page + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
					xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					
					xpath = xp_chosen_alloptions;
					xp_right_arrow = xp_common_sales_or_service_console_create_page+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
					xp_left_arrow = xp_common_sales_or_service_console_create_page+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
						
					System.out.println("xp_available:"+xp_available);
					System.out.println("xp_chosen:"+xp_chosen);
					System.out.println("xp_available_alloptions:"+xp_available_alloptions);
					System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
					System.out.println("xp_right_arrow:"+xp_right_arrow);
					System.out.println("xp_left_arrow:"+xp_left_arrow);
					
					ScrollToElement(remoteDriver.findElement(By.xpath(xp_chosen)));
				
    			}
				List<String> eachPLValue = Arrays.asList(Value.split(";"));
				for(String str: eachPLValue)
				{
					failed_value = str;
					remoteDriver.findElement(By.xpath("("+xpath+"[normalize-space(text())='"+str.trim()+"'])[1]")).click();
					remoteDriver.findElement(By.xpath(xp_left_arrow)).click();
										
				}
						
				System.out.println("Successfully removed value ("+Value+") from the multi-select pick list field "+fieldname);
				AddLogToCustomReport("Successfully removed values ("+Value+") from the multi-select pick list field "+fieldname, "Pass");
				return true;
			}
			catch(Exception e)
			{
				System.out.println("Unable to find the element for ("+failed_value+") while removing the value from multiselect picklist field ("+fieldname+") when xpath is:"+xpath);
				AddLogToCustomReport("Unable to find the element for ("+failed_value+") while removing the value from multiselect picklist field ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
			}

		}
		
		
		/**
		 * @return boolean
		 * @throws Exception
		 * @Description Selects and Adds all the available values of multi-select pick list field from Available List to Chosen List 
		 */
		public boolean MultiSelectAddAll() throws Exception
		{
			//xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
			try
			{
				String xp_available = "";
				String xp_chosen = "";
				String xp_available_alloptions = "";
				String xp_chosen_alloptions = "";
				String xp_right_arrow = "";
				String xp_left_arrow = "";
			
						
				/*
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline ++ "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
				}
				*/		
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed_inline ++ "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
						xp_available = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
						xp_chosen = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
						xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
						xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
						
						xpath = xp_available_alloptions;
						xp_right_arrow = xp_common_in_ed_inline+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
						xp_left_arrow = xp_common_in_ed_inline+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
							
						System.out.println("xp_available:"+xp_available);
						System.out.println("xp_chosen:"+xp_chosen);
						System.out.println("xp_available_alloptions:"+xp_available_alloptions);
						System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
						System.out.println("xp_right_arrow:"+xp_right_arrow);
						System.out.println("xp_left_arrow:"+xp_left_arrow);
						
						ScrollToElement(remoteDriver.findElement(By.xpath(xp_available)));
						
					
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");

					xp_available = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
					xp_chosen = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
					xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					
					xpath = xp_available_alloptions;
					xp_right_arrow = xp_common_in_ed+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
					xp_left_arrow = xp_common_in_ed+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
						
					System.out.println("xp_available:"+xp_available);
					System.out.println("xp_chosen:"+xp_chosen);
					System.out.println("xp_available_alloptions:"+xp_available_alloptions);
					System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
					System.out.println("xp_right_arrow:"+xp_right_arrow);
					System.out.println("xp_left_arrow:"+xp_left_arrow);
					
					ScrollToElement(remoteDriver.findElement(By.xpath(xp_available)));
					
					
				}
				
				if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
    			{
    				System.out.println("SERVICE/SALES CONSOLE CREATE PAGE");	
    				xp_available = xp_common_sales_or_service_console_create_page + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
					xp_chosen = xp_common_sales_or_service_console_create_page + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
					xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					
					xpath = xp_available_alloptions;
					xp_right_arrow = xp_common_sales_or_service_console_create_page+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
					xp_left_arrow = xp_common_sales_or_service_console_create_page+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
						
					System.out.println("xp_available:"+xp_available);
					System.out.println("xp_chosen:"+xp_chosen);
					System.out.println("xp_available_alloptions:"+xp_available_alloptions);
					System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
					System.out.println("xp_right_arrow:"+xp_right_arrow);
					System.out.println("xp_left_arrow:"+xp_left_arrow);
					
					ScrollToElement(remoteDriver.findElement(By.xpath(xp_available)));
				
    			}
				
				String all_selected_value = "";
				int all_avail_options = remoteDriver.findElements(By.xpath(xpath)).size();
				for(int g=1;g<=all_avail_options;g++)
				{
					WebElement each_elmnt = remoteDriver.findElement(By.xpath("("+xpath+")[1]"));
					String val = each_elmnt.getText().trim();
					System.out.println("pick list field value"+val);
					
					each_elmnt.click();
					
					remoteDriver.findElement(By.xpath(xp_right_arrow)).click();
					if (all_selected_value.equals(""))
					{
						all_selected_value = val;
					}
					else
					{
						all_selected_value = all_selected_value + "," + val;
					}							
					
				}
				
				
				
				System.out.println("Successfully added values ("+all_selected_value+") in the multi-select pick list field "+fieldname);
				AddLogToCustomReport("Successfully added values ("+all_selected_value+") in the multi-select pick list field "+fieldname, "Pass");
				return true;
			}
			catch(Exception e)
			{
				System.out.println("Unable to find the element while adding all values to multiselect picklist field ("+fieldname+") when xpath is:"+xpath);
				AddLogToCustomReport("Unable to find the element while adding all values to multiselect picklist field ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
			}
		}
		
		

		/**
		 * @return boolean
		 * @throws Exception
		 * @Description Selects and Removes all the available values of multi-select pick list field from Chosen List to Available List. 
		 */
		public boolean MultiSelectRemoveAll() throws Exception
		{
			
			//xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
			try
			{
				String xp_available = "";
				String xp_chosen = "";
				String xp_available_alloptions = "";
				String xp_chosen_alloptions = "";
				String xp_right_arrow = "";
				String xp_left_arrow = "";
						
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed_inline + + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
						xp_available = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
						xp_chosen = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
						xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
						xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
						
						xpath = xp_chosen_alloptions;
						xp_right_arrow = xp_common_in_ed_inline+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
						xp_left_arrow = xp_common_in_ed_inline+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
							
						System.out.println("xp_available:"+xp_available);
						System.out.println("xp_chosen:"+xp_chosen);
						System.out.println("xp_available_alloptions:"+xp_available_alloptions);
						System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
						System.out.println("xp_right_arrow:"+xp_right_arrow);
						System.out.println("xp_left_arrow:"+xp_left_arrow);
						
						ScrollToElement(remoteDriver.findElement(By.xpath(xp_chosen)));
						
					
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");

					xp_available = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
					xp_chosen = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
					xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					
					xpath = xp_chosen_alloptions;
					xp_right_arrow = xp_common_in_ed+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
					xp_left_arrow = xp_common_in_ed+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
						
					System.out.println("xp_available:"+xp_available);
					System.out.println("xp_chosen:"+xp_chosen);
					System.out.println("xp_available_alloptions:"+xp_available_alloptions);
					System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
					System.out.println("xp_right_arrow:"+xp_right_arrow);
					System.out.println("xp_left_arrow:"+xp_left_arrow);
					
					ScrollToElement(remoteDriver.findElement(By.xpath(xp_chosen)));
					
					
				}
				if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
    			{
    				System.out.println("SERVICE/SALES CONSOLE CREATE PAGE");	
    				xp_available = xp_common_sales_or_service_console_create_page + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
					xp_chosen = xp_common_sales_or_service_console_create_page + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
					xp_available_alloptions = xp_available + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					xp_chosen_alloptions = xp_chosen + "//following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
					
					xpath = xp_chosen_alloptions;
					xp_right_arrow = xp_common_sales_or_service_console_create_page+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='right'][1]";
					xp_left_arrow = xp_common_sales_or_service_console_create_page+ "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/ancestor::div[@role='group']//*[@data-key='left'][1]";
						
					System.out.println("xp_available:"+xp_available);
					System.out.println("xp_chosen:"+xp_chosen);
					System.out.println("xp_available_alloptions:"+xp_available_alloptions);
					System.out.println("xp_chosen_alloptions:"+xp_chosen_alloptions);
					System.out.println("xp_right_arrow:"+xp_right_arrow);
					System.out.println("xp_left_arrow:"+xp_left_arrow);
					
					ScrollToElement(remoteDriver.findElement(By.xpath(xp_chosen)));
				
    			}
								
				String all_selected_value = "";
				int all_chosen_options = remoteDriver.findElements(By.xpath(xpath)).size();
				for(int g=1;g<=all_chosen_options;g++)
				{
					WebElement each_elmnt = remoteDriver.findElement(By.xpath("("+xpath+")[1]"));
					String val = each_elmnt.getText().trim();
					System.out.println("pick list field value"+val);
					
					each_elmnt.click();
					
					remoteDriver.findElement(By.xpath(xp_left_arrow)).click();
					if (all_selected_value.equals(""))
					{
						all_selected_value = val;
					}
					else
					{
						all_selected_value = all_selected_value + "," + val;
					}
										
				}
				
				
				System.out.println("Successfully removed values ("+all_selected_value+") from the multi-select pick list field "+fieldname);
				AddLogToCustomReport("Successfully removed values ("+all_selected_value+") from the multi-select pick list field "+fieldname, "Pass");
				return true;
			}
			catch(Exception e)
			{
				System.out.println("Unable to find the element while removing all values to multiselect picklist field ("+fieldname+") when xpath is:"+xpath);
				AddLogToCustomReport("Unable to find the element while removing all values to multiselect picklist field ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
			}
		}
		
		
		/**
		 * @author Sourav
		 * @PageDisplayMode Edit
		 * @Description Verify the values displayed in Available list of a Multi-Select pick list field in Edit page
		 * @param Values are supplied as semicolon separated
		 * @return boolean
		 * @throws Exception
		 */
		public boolean VerifyMPLAvailable(String Values) throws Exception
		{

			try
			{
				/*
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
					
				}
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				Select s = new Select(getsingleWebelement);
				List<WebElement> options = s.getOptions();

				List<String> avail = new ArrayList<String>();
			
				for(WebElement eachOption: options)
				{
					avail.add(eachOption.getText().trim());
					//System.out.println("eachOption: "+eachOption.getText().trim());
				}
			
			
				List<String> AllavailValues = Arrays.asList(Values.split(";"));
				String failedPLValue="";
				for(String exp:AllavailValues)
				{
					if (!avail.contains(exp))
					{
						if (failedPLValue!="")
						{
							failedPLValue = failedPLValue + ";" + exp;
						}
						else
						{
							failedPLValue = exp;
						}
					}
				}
				if(failedPLValue=="")
				{
					System.out.println("Successfully verified the Available List of Values from Multiselect picklist field ("+fieldname+")");
					AddLogToCustomReport("Successfully verified the Available List of Values from Multiselect picklist field ("+fieldname+")", "Pass");
					return true;
				}
				else
				{
					System.out.println("Could not find multi select pick list values ("+failedPLValue+") in the available list of field("+fieldname+").");
					AddLogToCustomReport("Could not find multi select pick list values ("+failedPLValue+") in the available list of field("+fieldname+").", "Fail");
					return false;
				}
			
		}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to find the element when xpath is:"+xpath, "Fail");
				System.out.println("Unable to find the element when xpath is:"+xpath);
				return false;
				
			}
	}
		
		
		/**
		 * @author Sourav
		 * @PageDisplayMode Edit Page
		 * @Description Checks the checkbox field in Edit page 
		 * @return boolean
		 * @throws Exception
		 
		 */
		public boolean CheckBoxSelect() throws Exception
		{
		
		
		try
		{
			
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
			
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
													
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
				
				
			}
			if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
			{
				remoteDriver.findElement(By.xpath(xpath)).click();
				System.out.println("Successfully checked the checkbox for the field ("+fieldname+")");
				AddLogToCustomReport("Successfully checked the checkbox for the field ("+fieldname+")", "Pass");
				return true;
			}
			else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
			{
				System.out.println("The Checkbox for the field ("+fieldname+") is already checked.");
				AddLogToCustomReport("The Checkbox for the field ("+fieldname+") is already checked.", "Pass");
				return true;
			}
			else
			{
				System.out.println("Unable to check the check box for field ("+fieldname+")");
				AddLogToCustomReport("Unable to check the check box for field ("+fieldname+"). Please verify the property value", "Fail");
				return false;
			}	
		
		}
		catch(Exception e)
		{
			System.out.println("Unable to find the element when xpath is: "+xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"+xpath,"Fail");
			return false;
		}
		}
		

		/**
		 * @author Sourav
		 * @PageDisplayMode Edit Page
		 * @Description UnChecks the checkbox field in Edit page 
		 * @return boolean
		 * @throws Exception
		 */
		public boolean CheckBoxDeSelect() throws Exception
		{
			
			try
			{	
				/*
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed_inline + + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");

					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
					
				}
				
				if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
				{
					remoteDriver.findElement(By.xpath(xpath)).click();
					System.out.println("Successfully unchecked the checkbox for the field ("+fieldname+")");
					AddLogToCustomReport("Successfully unchecked the checkbox for the field ("+fieldname+")", "Pass");
					return true;
				}
				else if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
				{
					System.out.println("Successfully unchecked the checkbox for the field ("+fieldname+")");
					AddLogToCustomReport("Successfully unchecked the checkbox for the field ("+fieldname+")", "Pass");
					return true;
				}
				else
				{
					System.out.println("Unable to uncheck the check box for field ("+fieldname+")");
					AddLogToCustomReport("Unable to uncheck the check box for field ("+fieldname+")", "Fail");
					return false;
				}
				
			}
			catch(Exception e)
			{
				System.out.println("Unable to find the element when xpath is: "+xpath);
				AddLogToCustomReport("Unable to find the element when xpath is:"+xpath,"Fail");
				return false;
			}
		}
		
		
		//Choose value from lookup
		
		/**
		 * @author Sourav
		 * @PageDisplayMode Edit Page
		 * @param LookUpValue
		 * @Description Selects the value from SFDC OOB lookup field. If the text box field is editable then it types the value in that field then clicks on the lookup icon and clicks on the hyperlink displayed in search lookup. In case the text box field is read only then directly clicks on the lookup icon and searches the expected value in the search lookup window and clicks on hyperlink. It also sets the focus to the parent window 
		 * @return boolean
		 * @throws Exception
		 */
		public boolean SelectFromLookup(String LookUpValue) throws Exception
        {
               
               String common_xpath = ""; 
               try
               {
            	               	   
       			if(
    					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
    											&&
    					(remoteDriver.getCurrentUrl().trim().contains("view"))
    											&&
    					(
    						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
    							                ||
    					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
    				    )
    			  )
    			{
    				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
    				{
    					System.out.println("INLINE EDIT PAGE");
    					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[text()='"+fieldname+"'][1]/following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
                        common_xpath = xp_common_in_ed_inline + "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[text()='"+fieldname+"'][1]/";
                
    			
    			
    				}				
    				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
    				{
    					System.out.println("DETAIL VIEW PAGE");	
    													
    				}			
    				
    			}
    			
    			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
    			{
    				System.out.println("---------EDIT VIEW-----------");
    				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[text()='"+fieldname+"'][1]/following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
                    common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[text()='"+fieldname+"'][1]/"; 
                    
    				    				
    			}
    			if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
    			{
    				System.out.println("SERVICE CONSOLE CREATE PAGE");	
    				xpath = xp_common_vd + "//descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[text()='"+fieldname+"'][1]/..//div[contains(@class,'form-element')]//input[1]";
                    common_xpath = xp_common_vd + "//descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[text()='"+fieldname+"'][1]/";
                    System.out.println("xpath:-->"+xpath);
                    System.out.println("common_xpath:-->"+common_xpath);
    			}
    			
    			
                     ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
                     Thread.sleep(1000);
                     remoteDriver.findElement(By.xpath(xpath)).sendKeys(LookUpValue);
                     //Thread.sleep(2000L);
                     //xpath = common_xpath +"../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]/following-sibling::div[contains(@class,'lookup')][1]/descendant-or-self::div[@class='primaryLabel' and normalize-space(@title)='"+LookUpValue+"'][1]";
                     //xpath = common_xpath + "../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]/following-sibling::div[contains(@class,'lookup')][1]/descendant::div[normalize-space(@class)='listContent'][1]/descendant::ul[contains(@class,'lookup') and contains(@class,'list') and contains(@class,'visible')][1]/li[1]/a[1]/div[contains(@class,'body')][1]/div[contains(@class,'primaryLabel')][1]";
                     //xpath = common_xpath + "../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]/following-sibling::div[1]/div[contains(@class,'listContent')][1]/descendant::ul[contains(@class,'lookup') and contains(@class,'list') and contains(@class,'visible')][1]/li[1]/a[1]/descendant::div[contains(@class,'primaryLabel')][1]";
                    // xpath = common_xpath + "../following-sibling::div[1]/descendant::li/a/descendant::div[contains(@class,'primaryLabel') and @title='"+LookUpValue+"'][1]/descendant::mark[text()='"+LookUpValue+"'][1]";
                     //xpath = common_xpath + "ancestor::label[1]/following-sibling::div[1]/descendant::div[contains(@class,'searchButton') and contains(@class,'lookup')]/descendant::span[contains(@class,'itemLabel') and contains(@title,'"+LookUpValue+"')][1]";
                     //xpath = "/ancestor-or-self::label[1]/following-sibling::*[1]//*[contains(@data-value,'Search')][contains(@class,'listbox')][@role='option']//*[contains(text(),'Show All Result')][1]";
                     xpath = common_xpath + "ancestor-or-self::label[1]/following-sibling::*[1]//*[@role='listbox']//*[contains(@class,'search') and contains(@class,'icon')][1]//*[@data-key='search'][1]";
                     System.out.println("xpath of exact match:"+xpath);  
                     
                     //JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
                     //js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
                     Thread.sleep(1000);
                     remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
                     if (remoteDriver.findElements(By.xpath(xpath)).size()>0)
                     {
                    	 remoteDriver.findElement(By.xpath(xpath)).click();
                    	 
                    	 xpath = "//div[contains(@class,'searchWrapper')][1]/descendant::a[text()='"+LookUpValue+"'][1]";
                    	 remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
                    	 remoteDriver.findElement(By.xpath(xpath)).click();
                         System.out.println("Selected the value ("+LookUpValue+") from lookup field ("+fieldname+")");
                         AddLogToCustomReport("Selected the value ("+LookUpValue+") from lookup field ("+fieldname+")", "Pass");
                         return true;
                     }
                     else
                     {
                    	 AddLogToCustomReport("Unable to select the lookup value ("+LookUpValue+") against field ("+fieldname+")", "Fail");
                    	 return false;
                     }
                                    
               }
               catch(Exception e)
               {
                     e.printStackTrace();
                     System.out.println("Unable to find the value from lookup "+fieldname+" when xpath is: "+xpath);
                     AddLogToCustomReport("Unable to find the value from lookup "+fieldname+" when xpath is: "+xpath,"Fail");
                     return false;
                     
               }
               
        }

		/**
		 * @return
		 * @throws Exception
		 */
		public boolean RemoveFromLookup() throws Exception
        {
               
               String common_xpath = ""; 
               try
               {
            	  
       			if(
    					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
    											&&
    					(remoteDriver.getCurrentUrl().trim().contains("view"))
    											&&
    					(
    						remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
    							                ||
    					    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
    				    )
    			  )
    			{
    				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
    				{
    					System.out.println("INLINE EDIT PAGE");
    				
    					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='\"+fieldname+\"'][1]/../following-sibling::div[1]/descendant::span[contains(@class,'delete')][1]";
                        //common_xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/";
    					xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::span[contains(@class,'delete')][1]";
    					
    				}				
    				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
    				{
    					System.out.println("DETAIL VIEW PAGE");	
    													
    				}			
    				
    			}
    			
    			if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
    			{
    				System.out.println("---------EDIT VIEW-----------");
    				 xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::span[contains(@class,'delete')][1]";
                     //common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/"; 
    				 //ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
    				 //remoteDriver.findElement(By.xpath(xpath)).click();
    				
    			}
    			if(remoteDriver.findElement(By.xpath("//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::iframe")).isDisplayed()){
    				
    				xpath="";
    				
    			}
    			JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
                js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
         
                
                     
                     AddLogToCustomReport("Successfully deleted the existing lookup value.", "Pass");
                     System.out.println("Successfully deleted the existing lookup value.");
                     return true;
               }
               catch(Exception e)
               {
                     e.printStackTrace();
                     System.out.println("Unable to remore the existing value from lookup field "+fieldname+" when xpath is: "+xpath);
                     AddLogToCustomReport("Unable to remore the existing value from lookup field "+fieldname+" when xpath is: "+xpath,"Fail");
                     return false;
                     
               }
               
        }
		
		public boolean SelectFromLookup_CreateNew() throws Exception
		{
			
			
			String common_xpath = ""; 
			try
			{
				Thread.sleep(4000L);
				WaitForPageToLoad(30);
				/*
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
						common_xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/";
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
					common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/"; 
				}
				*/	
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
						common_xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/";
			
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
					common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/"; 
			
					
					
				}
				//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				//MouseScrol_Down();
				
				//remoteDriver.findElement(By.xpath(xpath)).click();
				JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
                js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
         
				
				Thread.sleep(3000L);
				//xpath = common_xpath +"../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]/following-sibling::div[contains(@class,'lookup')][1]/descendant-or-self::div[@class='primaryLabel' and normalize-space(@title)='"+LookUpValue+"'][1]";
				xpath = common_xpath + "../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]/following-sibling::div[contains(@class,'lookup')][1]/descendant::div[contains(@class,'createNew itemContainer')][1]/descendant-or-self::span[contains(@class,'itemLabel')][1]";
				//remoteDriver.findElement(By.xpath(xpath)).click();
				
				js = (JavascriptExecutor) remoteDriver;
                js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
         
                
				System.out.println("Clicked on lookup option to create new record against lookup field ("+fieldname+")");
				AddLogToCustomReport("Clicked on lookup option to create new record against lookup field ("+fieldname+")", "Pass");
				return true;			
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to find the Create New option from lookup "+fieldname+" when xpath is: "+xpath);
				AddLogToCustomReport("Unable to find the Create New option from lookup "+fieldname+" when xpath is: "+xpath,"Fail");
				return false;
				
			}
			
		}
		
		
		public boolean SelectFromDateLookup(String YYYY,String MONTH,String DAY) throws Exception
		{
			xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::a[contains(@class,'date')][1]";
			try
			{
				System.out.println(YYYY);
				System.out.println(MONTH);
				System.out.println(DAY);
				String common_xpath = "";
				/*
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::a[contains(@class,'date')][1]";
						common_xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/";
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::a[contains(@class,'date')][1]";
					common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/"; 
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("slds-card"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed_inline + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						//common_xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/";
						System.out.println("xpath:"+xpath);
						//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
						
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						//not applicable here
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::a[contains(@class,'date')][1]";
					//common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/"; 
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
										
				}
				if ((!remoteDriver.findElement(By.xpath(xp_desktop_contains_style)).getAttribute("style").toString().contains("hidden")) && remoteDriver.getCurrentUrl().trim().contains(url_service_console_createpage))
    			{
    				System.out.println("SERVICE/SALES CONSOLE CREATE PAGE");	
    				xpath = xp_common_sales_or_service_console_create_page + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='"+fieldname+"']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
    				
    				
    			}

				System.out.println("Xpath is:"+xpath);
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				Thread.sleep(1000L);
				
				remoteDriver.findElement(By.xpath(xpath)).click();
				
				//Selecting Month
				xpath = "(//div[contains(@class,'datepicker')][@role='dialog']//div[contains(@class,'month')]//h2[text()])[1]";
				if (WaitForElement(xpath, 5))
				{
					int i = 0;
					do{
						if(!remoteDriver.findElement(By.xpath(xpath)).getText().equalsIgnoreCase(MONTH.trim()))
						{
							remoteDriver.findElement(By.xpath(xpath+"/following-sibling::div[1]//button[contains(@title,'Next')][1]")).click();
					
						}
						else
						{
							i = 1;
							remoteDriver.findElement(By.xpath(xpath)).click();
						}
					}while(i==0);
						
					//Selecting Year
					xpath = "(//div[contains(@class,'datepicker')][@role='dialog']//select)[1]";
					Select s = new Select(remoteDriver.findElement(By.xpath(xpath)));
					s.selectByVisibleText(YYYY);
					
					
					//Select day
					xpath = "(//div[contains(@class,'datepicker')][@role='dialog']//span[@role='button'][contains(@class,'day')][text()='"+DAY+"'])[1]";
					remoteDriver.findElement(By.xpath(xpath)).click();
					System.out.println("Successfully selected the date value YEAR("+YYYY+") MONTH("+MONTH+") DAY("+DAY+") from date lookup field ("+fieldname+")");
					AddLogToCustomReport("Successfully selected the date value YEAR("+YYYY+") MONTH("+MONTH+") DAY("+DAY+") from date lookup field ("+fieldname+")", "Pass");
					return true;
				} 
				else
				{
					AddLogToCustomReport("The date picker did not appear...", "Fail");
					return false;
				}
					
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to select the date value from date lookup field ("+fieldname+") when xpath is: "+xpath);
				AddLogToCustomReport("Unable to select the date value from date lookup field ("+fieldname+") when xpath is: "+xpath,"Fail");
				return false;
				
			}
			
		}
		
		
	/**
	 * @author Sourav
	 * @Description Waits for specified time for the field to be displayed in the UI
	 * @param waitingTimeinSec
	 * @return boolean
	 * @throws Exception
	 */
	public boolean WaitForElement(long waitingTimeinSec) throws Exception
	{
		 xpath = "//*[normalize-space(text())='"+fieldname+"']";
		 try {
			 
			 if (remoteDriver.toString().contains("InternetExplorerDriver"))
     	 	 {
     	 			WebDriverWaitForElement(xpath,waitingTimeinSec);
     	 			return true;
     	 	 }
			 else
			 {
             remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinSec));
             List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
             if (myDynamicElement.size() > 0)
             {
            	 AddLogToCustomReport("The field ("+fieldname+") was available in the application.", "Pass");
            	 return true;
             }
             else
             {
            	 AddLogToCustomReport("Could not find the field ("+fieldname+") in the application.", "Fail");
            	 return false;
             }
			 }
             //System.out.println("The value of dynamic webelement is:"+myDynamicElement.isDisplayed());
             //return myDynamicElement.isDisplayed();
             }
         catch(NoSuchElementException e)
             {
             System.out.println("Could not find the element after waiting for specified time.");
             AddLogToCustomReport("Could not find the button ("+fieldname+") in the application.", "Fail");
             return false;
             //return false;
             }
	}
	
	
	/**
	 * @author Cognizant
	 * @param YesORNo
	 * @Description Verify if a field label is present in the View Details page
	 * @return
	 * @throws Exception
	 */
	public boolean IsDisplayed(String YesORNo) throws Exception
    {
           xpath = "(//*[normalize-space(text())='"+fieldname.trim()+"'])[1]";
           
           //System.out.println();
           
           if (YesORNo.equalsIgnoreCase("Yes"))
           {
                  try
                  {
                  WaitForElement(xpath, 20);
                  if((remoteDriver.findElement(By.xpath(xpath)).isEnabled()))
                  {
                        System.out.println("Successfully verified the existence of the field ("+fieldname+").");
                        AddLogToCustomReport("Successfully verified the existence of the field ("+fieldname+").", "Pass");
                        return true;  
                  }
                  else
                  {
                        System.out.println("Could not find the field ("+fieldname+") in the application.");
                        AddLogToCustomReport("Could not find the field ("+fieldname+") in the application.", "Fail");
                        return false;
                  }
                  }catch(Exception e)
                  {
                        System.out.println("Could not find the field ("+fieldname+") in the application when xpath is:"+xpath);
                        AddLogToCustomReport("Could not find the field ("+fieldname+") in the application when xpath is:"+xpath, "Fail");
                        e.printStackTrace();
                        return false;
                  }
           }
           else if (YesORNo.equalsIgnoreCase("No"))
           {
                  try
                  {
                  if((remoteDriver.findElement(By.xpath(xpath)).isDisplayed()))
                  {
                        System.out.println("The field ("+fieldname+") is present in the UI when it is not expected to be.");
                        AddLogToCustomReport("The field ("+fieldname+") is present in the UI when it is not expected to be.", "Fail");
                        return false;
                  }
                  else
                  {
                        System.out.println("Successfully verified that the field ("+fieldname+") is not present in the UI.");
                        AddLogToCustomReport("Successfully verified that the field ("+fieldname+") is not present in the UI.", "Pass");
                        return true;
                  }
                  }catch(Exception e2)
                  {
                        System.out.println("Successfully verified that the field ("+fieldname+") is not present in the UI.");
                        AddLogToCustomReport("Successfully verified that the field ("+fieldname+") is not present in the UI.", "Pass");
                        return true;
                  }
           }
           else
           {
                  System.out.println("The input parameter supplied in IsDisplayed() function is not correct. It should be either Yes or No");
                  AddLogToCustomReport("The input parameter supplied in IsDisplayed() function is not correct. It should be either Yes or No", "Fail");
                  return false;
           }
    }

	public boolean IsDisplayedByIndex(String YesORNo,int Index) throws Exception
    {
           xpath = "(//*[normalize-space(text())='"+fieldname.trim()+"'])["+Index+"]";
           
           //System.out.println();
           
           if (YesORNo.equalsIgnoreCase("Yes"))
           {
                  try
                  {
                  if((remoteDriver.findElement(By.xpath(xpath)).isDisplayed()))
                  {
                        System.out.println("Successfully verified the existence of the field ("+fieldname+").");
                        AddLogToCustomReport("Successfully verified the existence of the field ("+fieldname+").", "Pass");
                        return true;  
                  }
                  else
                  {
                        System.out.println("Could not find the field ("+fieldname+") in the application.");
                        AddLogToCustomReport("Could not find the field ("+fieldname+") in the application.", "Fail");
                        return false;
                  }
                  }catch(Exception e)
                  {
                        System.out.println("Could not find the field ("+fieldname+") in the application when xpath is:"+xpath);
                        AddLogToCustomReport("Could not find the field ("+fieldname+") in the application when xpath is:"+xpath, "Fail");
                        e.printStackTrace();
                        return false;
                  }
           }
           else if (YesORNo.equalsIgnoreCase("No"))
           {
                  try
                  {
                  if((remoteDriver.findElement(By.xpath(xpath)).isDisplayed()))
                  {
                        System.out.println("The field ("+fieldname+") is present in the UI when it is not expected to be.");
                        AddLogToCustomReport("The field ("+fieldname+") is present in the UI when it is not expected to be.", "Fail");
                        return false;
                  }
                  else
                  {
                        System.out.println("Successfully verified that the field ("+fieldname+") is not present in the UI.");
                        AddLogToCustomReport("Successfully verified that the field ("+fieldname+") is not present in the UI.", "Pass");
                        return true;
                  }
                  }catch(Exception e2)
                  {
                        System.out.println("Successfully verified that the field ("+fieldname+") is not present in the UI.");
                        AddLogToCustomReport("Successfully verified that the field ("+fieldname+") is not present in the UI.", "Pass");
                        return true;
                  }
           }
           else
           {
                  System.out.println("The input parameter supplied in IsDisplayed() function is not correct. It should be either Yes or No");
                  AddLogToCustomReport("The input parameter supplied in IsDisplayed() function is not correct. It should be either Yes or No", "Fail");
                  return false;
           }
    }
	
	/**
	 * @param element
	 * @Description Scroll vertically/ horizontally to make the element visible on the screen. 
	 * @throws Exception
	 */
	public synchronized void ScrollToElement(WebElement element) throws Exception
	{
		
		try
		{
			
			WaitForElement(element, 30);
			
			((JavascriptExecutor)remoteDriver).executeScript("arguments[0].scrollIntoView();", element);
			
			//Coordinates coordinate = ((Locatable) element).getCoordinates();
			//Point cord = element.getLocation();
			//cord.getY();
			//- 300;
			//Locatable
						
			//Point coordinates = element.getLocation();
			
			//Robot robot = new Robot();
			//robot.mouseWheel(1);
			
			
			
			//coordinate.onPage();
			//coordinate.onScreen();
			//coordinate.inViewPort();
					
			System.out.println("Successfully scrolled untill element.");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to scroll until elemnt");
		}
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param timeOutInSeconds
	 * @return void
	 * @throws Exception
	 * @Description Waits for the page to reach ready state 
	 * @Date Aug 7, 2014
	 */
	public void WaitForPageToLoad(int timeOutInSeconds) throws Exception
	{ 
		
		String command = "return document.readyState"; 

		try
		{
		for (int i=0; i<timeOutInSeconds; i++)
		{ 
			try
			{
				Thread.sleep(1000L);
			}
			catch (InterruptedException e)
			{
				System.out.println("Unable to load the webpage");				
				
			} 
			
			if (remoteDriver.executeScript(command).toString().equals("complete"))
			{ 
				//System.out.println("Inside WaitForPageToLoad(Success)");
				break; 
			} 
			
			
		} 
		}catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				//Assert.fail(Message);
				throw new Exception("Failed");
				//throw new MPException("Failure from custom exception");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param 1. xpath of the element. 2. Waiting Time in Second
	 * @return boolean
	 * @throws Exception
	 * @Description Waits for the specified time until the webelemnt is available to WebDriver
	 * @Date Aug 7, 2014
	 */
	public boolean WaitForElement(String xpath, long waitingTimeinsec) throws Exception
    {
         try {
        	 	        		
        	remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
     		List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
     		if (myDynamicElement.size() > 0)
     		{
     			System.out.println("Success: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return true;
     		}
     		else
     		{
     			System.out.println("Unsuccess: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return false;
     		} 
        }
         catch(NoSuchElementException e)
         {
        	 e.printStackTrace();
             System.out.println("Exception inside WaitForElement:"+xpath);
             return false;
         }
     }
	
	/**
	 * @param elmnt
	 * @param waitingTimeinsec
	 * @return
	 * @throws Exception
	 */
	public boolean WaitForElement(WebElement elmnt, long waitingTimeinsec) throws Exception
    {
         try {
        	 	        		
        	remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
     		
     		if (elmnt.isDisplayed())
     		{
     			System.out.println("WaitForElement:Success:"+elmnt.toString());
     			return true;
     		}
     		else
     		{
     			System.out.println("Unsuccess: WaitForElement: Failure:"+elmnt.toString());
     			return false;
     		} 
        }
         catch(NoSuchElementException e)
         {
        	 e.printStackTrace();
             System.out.println("Exception inside WaitForElement:"+xpath);
             return false;
         }
     }
	
	public void MouseScrol_Down() throws Exception
	{
		 Robot r = new Robot();
	     for(int i = 0; i < 20; i++){
	         //scroll and wait a bit to give the impression of smooth scrolling
	         r.mouseWheel(1);
	         try{ Thread.sleep(50); }catch(InterruptedException e){}
	     }
	}
	public void MouseScrol_Up() throws Exception
	{
		 Robot r = new Robot();
	     for(int i = 20; i > 0; i--){
	         //scroll and wait a bit to give the impression of smooth scrolling
	         r.mouseWheel(1);
	         try{ Thread.sleep(50); }catch(InterruptedException e){}
	     }
	}
     
	/**
	 * @author Sourav Mukherjee
	 * @Param NA
	 * @return void
	 * @throws Exception
	 * @Description Press TAB Key using Robot Class
	 * @Date Jan, 2015
	 */
	public void PressTABKeyOnWindowAlert() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			
			System.out.println("Pressed Tab Key on Window Alert.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
			System.out.println("Unable to press Tab key on Window Alert");
		}
		
	}
	public void PressF12Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_F12);
			robot.keyRelease(KeyEvent.VK_F12);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	public void PressPageUPKey() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_PAGE_UP);
			robot.keyRelease(KeyEvent.VK_PAGE_UP);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	
	public void PressPageDownKey() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	
	public void PressF5Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_F5);
			robot.keyRelease(KeyEvent.VK_F5);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	
	/**
	 * @param we
	 * @throws Exception
	 */
	public void JavaScriptClick(WebElement we) throws Exception
	{
		try{
			
			remoteDriver.executeScript("arguments[0].click();", we);
			System.out.println("Successfully clicked by JS on element.");
			AddLogToCustomReport("Successfully clicked by JS on element.", "Pass");
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click by JS on element.");
			AddLogToCustomReport("Unable to click by JS on element.", "Fail");
			
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param 1. xpath of the element, 2. Time specified in second
	 * @return WebElement
	 * @throws Exception
	 * @Description Waits for the specified time until the webelemnt is available to WebDriver. This uses WebDriverWait class 
	 * @Date Aug 7, 2014
	 */
	public WebElement WebDriverWaitForElement(String xpath, long waitingTimeinsec) throws Exception
    {
		WebElement element=null;
        try {
        	 	WebDriverWait wait = new WebDriverWait(remoteDriver, Duration.ofSeconds(waitingTimeinsec));
        	 	element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
        	 	return element;
           	 }
         	catch(NoSuchElementException e)
         	{
         		e.printStackTrace();
         		System.out.println("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec");
         		AddLogToCustomReport("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec", "Fail");
         		return element;
        	 
         	}
     }
}
