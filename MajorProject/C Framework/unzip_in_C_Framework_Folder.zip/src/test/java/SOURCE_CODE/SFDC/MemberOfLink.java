package SOURCE_CODE.SFDC;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.mop.qa.testbase.PageBase;

import io.appium.java_client.AppiumDriver;

public class MemberOfLink extends PageBase {

	public MemberOfLink(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
	}
	
	public MemberOfLink(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}

	int count = 0;
	public String Link;
	// WebDriver myWD;
	// SFDCAutomationFW autoFW;
	String xpath;
	List<WebElement> we;

	// MemberOfLink(String LN) {
	// Link = LN;
	// myWD = autoFW.myWD;
	//
	// }

	public boolean Click() throws Exception {
		try {

			WebElement link = getElementByLinkText(Link);
			if (link.isDisplayed()) {
				click(link, Link);
				System.out.println("Clicked on the hyperlink(" + Link + ")");
				// autoFW.AddToXLLogs("Clicked on the hyperlink(" + Link + ")",
				// "Pass");
				return true;
			} else {
				System.out.println("Unable to click on the hyperlink(" + Link + ")");
				// autoFW.AddToXLLogs("Unable to click on the hyperlink(" + Link
				// + ")", "Fail");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to click on the hyperlink(" + Link + ")");
			// autoFW.AddToXLLogs(
			// "Unable to click on the hyperlink(" + Link + ")", "Fail");
			return false;
		}

	}

	public boolean IsDisplayed() throws Exception {
		try {
			WebElement link = getElementByLinkText(Link);
			if (link.isDisplayed()) {

				System.out.println("Verified the existence of hyperlink (" + Link + ")");
				// autoFW.AddToXLLogs("Verified the existence of hyperlink ("
				// + Link + ")", "Pass");
				return true;
			} else {
				System.out.println("Unable to find the hyperlink(" + Link + ")");
				// autoFW.AddToXLLogs(
				// "Unable to find the hyperlink(" + Link + ")", "Fail");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to find the hyperlink(" + Link + ")");
			// autoFW.AddToXLLogs("Unable to find the hyperlink(" + Link + ")",
			// "Fail");
			return false;
		}

	}

	public boolean Click_Partial() throws Exception {
		try {
			WebElement link = getElementByLinkText(Link);
			if (link.isDisplayed()) {
				click(link, Link);
				System.out.println("Clicked on the hyperlink(" + Link + ")");
				// autoFW.AddToXLLogs("Clicked on the hyperlink(" + Link + ")",
				// "Pass");
				return true;
			} else {
				System.out.println("Unable to click on the hyperlink(" + Link + ")");
				// autoFW.AddToXLLogs("Unable to click on the hyperlink(" + Link
				// + ")", "Fail");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to click on the hyperlink(" + Link + ")");
			// autoFW.AddToXLLogs(
			// "Unable to click on the hyperlink(" + Link + ")", "Fail");
			return false;
		}
	}

	public boolean ClickByIndex_Partial(int index) throws Exception {
		try {
			we = findElementsPartialLinkText(Link);
			// we = myWD.findElements(By.partialLinkText(Link));
			System.out.println("size is:" + we.size());
			if (we.size() > 1) {
				count++;
				for (WebElement webe : we) {
					if (count == index) {
						click(webe, webe.getText());
						System.out.println("Successfully clicked on the Link(" + Link + ").");
						// autoFW.AddToXLLogs("Successfully clicked on the Link("
						// + Link + ").", "Pass");
						return true;
					}
					count++;

				}
				System.out.println("Unable to click on link (" + Link + " while ClickByIndex)");
				// autoFW.AddToXLLogs("Unable to click on link (" + Link
				// + " while ClickByIndex)", "Fail");
				return false;

			} else {
				System.out.println("Unable to find the link(" + Link + ") while trying to click by Index.");
				// autoFW.AddToXLLogs("Unable to find the link(" + Link
				// + ") while trying to click by Index.", "Fail");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception: Unable to find the link(" + Link + ") while trying to click by Index.");
			// autoFW.AddToXLLogs("Exception:Unable to find the link(" + Link
			// + ") while trying to click by Index.", "Fail");
			return false;
		}
	}

	public boolean ClickByIndex(int index) throws Exception {
		try {
			we = findElementsLinkText(Link);
			// we = myWD.findElements(By.linkText(Link));
			System.out.println("size is:" + we.size());
			if (we.size() > 1) {
				count++;
				for (WebElement webe : we) {
					if (count == index) {
						click(webe, webe.getText());
						System.out.println("Successfully clicked on the Link(" + Link + ").");
						// autoFW.AddToXLLogs("Successfully clicked on the Link("
						// + Link + ").", "Pass");
						return true;
					}
					count++;

				}
				System.out.println("Unable to click on link (" + Link + " while ClickByIndex)");
				// autoFW.AddToXLLogs("Unable to click on link (" + Link
				// + " while ClickByIndex)", "Fail");
				return false;

			} else {
				System.out.println("Unable to find the link(" + Link + ") while trying to click by Index.");
				// autoFW.AddToXLLogs("Unable to find the link(" + Link
				// + ") while trying to click by Index.", "Fail");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception:Unable to find the link(" + Link + ") while trying to click by Index.");
			// autoFW.AddToXLLogs("Exception:Unable to find the link(" + Link
			// + ") while trying to click by Index.", "Fail");
			return false;
		}

	}

}
