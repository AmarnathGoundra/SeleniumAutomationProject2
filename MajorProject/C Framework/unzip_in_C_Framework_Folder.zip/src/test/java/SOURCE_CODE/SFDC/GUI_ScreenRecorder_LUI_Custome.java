package SOURCE_CODE.SFDC;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EtchedBorder;

import org.apache.commons.lang3.StringUtils;
//import org.jboss.netty.util.internal.SystemPropertyUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import USER_SPACE.TestPrerequisite.DataSetup;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.stream.Collectors;
 
public class GUI_ScreenRecorder_LUI_Custome extends JFrame implements ActionListener 
  { 
    
    JTextField tf1, tf2, tf3, tf4;
    JButton btn1, btn2,btn3,btn4;
    ArrayList al_sfdcloginurl,al_sysadmin,al_sfdcobject,al_sfdcrecordurl;
    ArrayList al_all_window_id;
    SFDCAutomationFW sfdc;
 
    GUI_ScreenRecorder_LUI_Custome(SFDCAutomationFW sfdc_inst) throws Exception
    {	
    	sfdc = sfdc_inst;
    	al_all_window_id = new ArrayList<String>();
    	//setSize(50, 100);
    	
    	setBounds(1000, 30, 100, 50);
    	//setLocation(900, 10);
    	//setLayout(manager);(null);
    	    	        
        //setResizable(true);       
            
        //setLocationRelativeTo(null);
        
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	setUndecorated(true);
    	setTitle("REC");
    	EtchedBorder edge = new EtchedBorder(EtchedBorder.RAISED); 
        btn1 = new JButton(new ImageIcon(ImageIO.read(new File("Record_OR.png"))));
        btn2 = new JButton(new ImageIcon(ImageIO.read(new File("Record_Stop.png"))));
              
        btn1.setToolTipText("Start Recorder button must be clicked each time when you want to capture List View, Detail View/Related List screen.");
        
        btn2.setToolTipText("Stop Recorder button must be clicked only once per object. Once List View, Detail View / Related List screen recording is done then only this button needs to be clicked to generate the OR file for that particular object.");
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        
        
        //btn1.setBounds(10, 10, 30, 30);
        
        
        //btn1.setMargin(new Insets(0, 0, 30, 30));
        //btn1.setAlignmentX(LEFT_ALIGNMENT);
        //btn1.setAlignmentX(RIGHT_ALIGNMENT);
        
        btn1.setBackground(new Color(51,171,215));
        //btn1.setForeground(new Color(255,255,255));
        
        
        //btn2.setBounds(5, 0, 30, 40);
        //btn2.setMargin(new Insets(40, 5, 30, 40));
        btn2.setBackground(new Color(51,171,215));
        //btn2.setForeground(new Color(255,255,255));
        
        
       // btn1.setFont(new Font("Serif", Font.BOLD, 15));
        
        
        add(btn1,BorderLayout.WEST);
        add(btn2,BorderLayout.EAST);
        //add(btn2);
        
        //getContentPane().setBackground(new Color(102,178,255));
       
        //getContentPane().setPreferredSize(new Dimension(800, 240));
        
        //this.setPreferredSize(new Dimension(320, 240));
        //setBackground(new Color(102,178,255));
        setVisible(true);
        
    }
 
    public void actionPerformed(ActionEvent e) 
{
    	
    	try
    	{
    	
        if (e.getSource() == btn1)
        {
        	
        	//Getting total number of window opened.
        	Set<String> all_win_count = sfdc.GetWebDriver().getWindowHandles();
        	Iterator<String> ite_count = all_win_count.iterator(); 
        	int cnt = 0;
        	while(ite_count.hasNext()) 
	        { 
        		String win = ite_count.next().toString();
        		al_all_window_id.add(win); //index starts from 0
        		System.out.println(""+win);
        		cnt = cnt + 1;
        		
	        }
        	System.out.println("Total Window Opened is:"+cnt);
        	
        	sfdc.GetWebDriver().switchTo().window(al_all_window_id.get(al_all_window_id.size()-1).toString());
        	System.out.println("Title is:"+sfdc.GetWebDriver().getCurrentUrl());
        
        	sfdc._CreateAUTRepository_LU_Custome();
    
    	}
        if (e.getSource() == btn2)
        {/*
        	//Printing Array List content
			System.out.println("------------------------------------------------------------------------");
        	
			sfdc.al_rl_names = (ArrayList) sfdc.al_rl_names.stream().distinct().collect(Collectors.toList());
			
			for(String s:sfdc.al_rl_names)
			{
				System.out.println("al_rl_names---->"+s);
			}
			sfdc.al_rl_col_names = (ArrayList) sfdc.al_rl_col_names.stream().distinct().collect(Collectors.toList());
			for(String s:sfdc.al_rl_col_names)
			{
				System.out.println("al_rl_col_names---->"+s);
			}
			sfdc.al_rl_buttons = (ArrayList) sfdc.al_rl_buttons.stream().distinct().collect(Collectors.toList());
			for(String s:sfdc.al_rl_buttons)
			{
				System.out.println("al_rl_buttons---->"+s);
			}
			sfdc.al_lv_buttons = (ArrayList) sfdc.al_lv_buttons.stream().distinct().collect(Collectors.toList());
			for(String s:sfdc.al_lv_buttons)
			{
				System.out.println("al_lv_buttons---->"+s);
			}
			sfdc.al_lv_col_names = (ArrayList) sfdc.al_lv_col_names.stream().distinct().collect(Collectors.toList());
			for(String s:sfdc.al_lv_col_names)
			{
				System.out.println("al_lv_col_names---->"+s);
			}
			sfdc.al_dv_fields = (ArrayList) sfdc.al_dv_fields.stream().distinct().collect(Collectors.toList());			
			for(String s:sfdc.al_dv_fields)
			{
				System.out.println("al_dv_fields---->"+s);
			}
			sfdc.al_buttons = (ArrayList) sfdc.al_buttons.stream().distinct().collect(Collectors.toList());
			for(String s:sfdc.al_buttons)
			{
				System.out.println("al_buttons---->"+s);
			}
			//System.out.println("----------------------------------------");
			sfdc.al_rlname_plus_buttons = (ArrayList) sfdc.al_rlname_plus_buttons.stream().distinct().collect(Collectors.toList());
			for(String s:sfdc.al_rlname_plus_buttons)
			{
				System.out.println("---->"+s);
			}
			sfdc.al_rlname_plus_col = (ArrayList) sfdc.al_rlname_plus_col.stream().distinct().collect(Collectors.toList());
			for(String s:sfdc.al_rlname_plus_col)
			{
				System.out.println("---->"+s);
			}
			System.out.println("------------------------------------------------------------------------");
			//Removing duplicate item from all array list values
			
			
			SFDCAutomationFW.al_rl_names = (ArrayList) SFDCAutomationFW.al_rl_names.stream().distinct().collect(Collectors.toList());
			SFDCAutomationFW.al_rl_col_names = (ArrayList) SFDCAutomationFW.al_rl_col_names.stream().distinct().collect(Collectors.toList());
			SFDCAutomationFW.al_rl_buttons = (ArrayList) SFDCAutomationFW.al_rl_buttons.stream().distinct().collect(Collectors.toList());
			SFDCAutomationFW.al_lv_buttons = (ArrayList) SFDCAutomationFW.al_lv_buttons.stream().distinct().collect(Collectors.toList());
			SFDCAutomationFW.al_lv_col_names = (ArrayList) SFDCAutomationFW.al_lv_col_names.stream().distinct().collect(Collectors.toList());
			SFDCAutomationFW.al_dv_fields = (ArrayList) SFDCAutomationFW.al_dv_fields.stream().distinct().collect(Collectors.toList());
			SFDCAutomationFW.al_buttons = (ArrayList) SFDCAutomationFW.al_buttons.stream().distinct().collect(Collectors.toList());
			SFDCAutomationFW.al_rlname_plus_buttons = (ArrayList) SFDCAutomationFW.al_rlname_plus_buttons.stream().distinct().collect(Collectors.toList());
			SFDCAutomationFW.al_rlname_plus_col = (ArrayList) SFDCAutomationFW.al_rlname_plus_col.stream().distinct().collect(Collectors.toList());
			
			
			
			String sub= "";
			System.out.println("sfdc.obj_vd"+sfdc.obj_vd);
			
			if(sfdc.obj_lv.length() > 1)
			{
				//SFDCAutomationFW.screenname = SFDCAutomationFW.obj_lv + "Screen_LUI";
				sfdc.screenname = (StringUtils.capitalize(sfdc.obj_lv.replace(" ", "")) + "Screen_LUI"); 
			}
			else if(sfdc.obj_vd.length() > 1)
			{
				//SFDCAutomationFW.screenname = SFDCAutomationFW.obj_vd + "Screen_LUI";
				sfdc.screenname = (StringUtils.capitalize(sfdc.obj_vd) + "Screen_LUI"); 
				
			}
			else
			{
				sfdc.screenname = "Undefine" + "Screen_LUI";
			}
			
			
			*//*************** Generic Part of the Content of Screen File ******************//*
			String classname = sfdc.screenname.trim().replace("+", "").replace("&", "")
					.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
					.replace("-", "").replace(" ", "").replace("*", "")
					.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
					.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
					.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
			
			sfdc.screenname = classname;
			sfdc.contentofscreenfile = "package USER_SPACE.ObjectRepository; \n"
					+ "import SOURCE_CODE.SFDC.*; \n"
					+ "import org.openqa.selenium.remote.RemoteWebDriver; \n"
					+ "import io.appium.java_client.AppiumDriver;  \n"
					+ "import USER_SPACE.TestPrerequisite.*; \n"
					+ "\n \n \n"
					+ "public class "
					+ classname
					+" extends SFDCAutomationFW{ \n"
					+ "SFDCAutomationFW sfdc; \n"
					+ "String RList = \"\"; \n\n\n\n"
					+ "public "+classname+"(RemoteWebDriver remoteDriver) { \n"
					+ "super(remoteDriver); \n"
					+ "sfdc = new SFDCAutomationFW(remoteDriver); \n"
					+ "} \n\n\n"
					+ "public "+classname+"(AppiumDriver appiumDriver) { \n"
					+ "super(appiumDriver); \n"
					+ "sfdc = new SFDCAutomationFW(appiumDriver); \n"
					+ "}\n\n"
					+ "// ************************ Functions for Fields ************************************** \n \n ";
					
					for(String s:sfdc.al_dv_fields)
					{
						sub = s.trim();
						sfdc.contentofscreenfile = sfdc.contentofscreenfile 
								+ "public MemberOfField_LUI "+s.trim().replace("+", "").replace("&", "")
								.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
								.replace("-", "").replace(" ", "").replace("*", "")
								.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
								.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
								.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "")
								+"Field() throws Exception{  \n" 
								+ "return sfdc.Field_LUI(\""+sub+"\"); \n" 
								+  "} \n \n"; 						
					
					}
					
					// List Views related functions setup
					
					sfdc.contentofscreenfile = sfdc.contentofscreenfile 

							+ "// ************************ Functions and Classes for List Views ************************************** \n \n ";
					
					String sub_each_lvname = "";
					String each_lvname_changed = "";
					String each_lvname_plus_col = "";
					String each_col_lv_asperapp = "";
					String each_col_lv_changed = "";
					String each_lv_button_asperapp = "";
					String each_lv_button_changed = "";
					
					if(!sfdc.obj_lv.trim().equals(""))
					{
												
						each_lvname_changed = sfdc.obj_lv.trim().replace("+", "").replace("&", "")
								.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
								.replace("-", "").replace(" ", "").replace("*", "")
								.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
								.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
								.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
								
						sfdc.contentofscreenfile = sfdc.contentofscreenfile 
								
						+ "public Columns_"+each_lvname_changed+" LV_"+each_lvname_changed+"() throws Exception{ \n" 
						+ "return new Columns_"+each_lvname_changed+"(\""+sfdc.obj_lv.trim()+"\"); \n" 
						+ "} \n" 
								
						+ "public class Columns_"+each_lvname_changed+" \n"
						+ "{ \n"
						+ "Columns_"+each_lvname_changed+"(String RL) \n"
						+ "{ \n"
						+ "RList = RL;  \n"
						+ "}  \n";
						
						for(String s:sfdc.al_lv_col_names)
						{
								each_col_lv_asperapp = s.trim();
								each_lvname_changed = each_col_lv_asperapp.trim().replace("+", "").replace("&", "")
										.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
										.replace("-", "").replace(" ", "").replace("*", "")
										.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
										.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
										.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
								
								sfdc.contentofscreenfile = sfdc.contentofscreenfile 
										
										+ "public MemberOfLV_LUI "+each_lvname_changed+"() throws Exception \n"
										+ "{ \n"
										+ "return sfdc.LV_LUI(RList,\""+each_col_lv_asperapp+"\"); \n"
										+ "} \n"
										+ "public MemberOfLV_LUI "+each_lvname_changed+"(String TargetCOlumnValue) throws Exception \n"
										+ "{ \n"
										+ "return sfdc.LV_LUI(RList,\""+each_col_lv_asperapp+"\",TargetCOlumnValue); \n"
										+ "} \n";
							
						}
						
						for(String s:sfdc.al_buttons)
						{
								each_lv_button_asperapp = s.trim().replace(sub_each_lvname+":", "").replace("Button:", "").trim();
								each_lv_button_changed = each_lv_button_asperapp.replace("+", "").replace("&", "")
										.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
										.replace("-", "").replace(" ", "").replace("*", "")
										.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
										.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
										.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
								
								sfdc.contentofscreenfile = sfdc.contentofscreenfile 
										
										+ "public MemberOfLV_LUI "+each_lv_button_changed+"Button() throws Exception  \n"
										+ "{ \n"
										+ "return sfdc.LV_LUI(RList,\""+each_lv_button_asperapp+"Button\");  \n"
										+ "} \n";
						}
									
					}
					sfdc.contentofscreenfile = sfdc.contentofscreenfile 
										+ "} \n \n";
								
						
					
					
				// ------------------------------------------------------------------	
					
					
					sfdc.contentofscreenfile = sfdc.contentofscreenfile 

							+ "// ************************ Functions and Static Classes for Related Lists ************************************** \n \n ";
					
					String sub_each_rlname = "";
					String each_rlname_changed = "";
					String each_rlname_plus_col = "";
					String each_col_asperapp = "";
					String each_col_changed = "";
					String each_rl_button_asperapp = "";
					String each_rl_button_changed = "";
					
					for(String each_rlname:sfdc.al_rl_names)
					{
						
						sub_each_rlname = each_rlname.trim();
						each_rlname_changed = each_rlname.trim().replace("+", "").replace("&", "")
								.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
								.replace("-", "").replace(" ", "").replace("*", "")
								.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
								.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
								.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
								
						sfdc.contentofscreenfile = sfdc.contentofscreenfile 
								
						+ "public Columns_"+each_rlname_changed+" RL_"+each_rlname_changed+"() throws Exception{ \n" 
						+ "return new Columns_"+each_rlname_changed+"(\""+sub_each_rlname+"\"); \n" 
						+ "} \n" 
								
						+ "public class Columns_"+each_rlname_changed+" \n"
						+ "{ \n"
						+ "Columns_"+each_rlname_changed+"(String RL) \n"
						+ "{ \n"
						+ "RList = RL;  \n"
						+ "}  \n";
						
						for(String s:sfdc.al_rlname_plus_col)
						{
							if(s.trim().startsWith(sub_each_rlname+":"))
							{
								each_col_asperapp = s.trim().replace(sub_each_rlname+":", "").trim();
								each_rlname_changed = each_col_asperapp.trim().replace("+", "").replace("&", "")
										.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
										.replace("-", "").replace(" ", "").replace("*", "")
										.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
										.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
										.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
								
								sfdc.contentofscreenfile = sfdc.contentofscreenfile 
										
										+ "public MemberOfRL_LUI "+each_rlname_changed+"() throws Exception \n"
										+ "{ \n"
										+ "return sfdc.RL_LUI(RList,\""+each_col_asperapp+"\"); \n"
										+ "} \n"
										+ "public MemberOfRL_LUI "+each_rlname_changed+"(String TargetCOlumnValue) throws Exception \n"
										+ "{ \n"
										+ "return sfdc.RL_LUI(RList,\""+each_col_asperapp+"\",TargetCOlumnValue); \n"
										+ "} \n";
							}
						}
						
						for(String s:sfdc.al_rlname_plus_buttons)
						{
							if(s.trim().startsWith(sub_each_rlname+":"))
							{
								each_rl_button_asperapp = s.trim().replace(sub_each_rlname+":", "").replace("Button:", "").trim();
								each_rl_button_changed = each_rl_button_asperapp.replace("+", "").replace("&", "")
										.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
										.replace("-", "").replace(" ", "").replace("*", "")
										.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
										.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
										.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
								
								sfdc.contentofscreenfile = sfdc.contentofscreenfile 
										
										+ "public MemberOfRL_LUI "+each_rl_button_changed+"Button() throws Exception  \n"
										+ "{ \n"
										+ "return sfdc.RL_LUI(RList,\""+each_rl_button_asperapp+"Button\");  \n"
										+ "} \n";
							}
						}
						sfdc.contentofscreenfile = sfdc.contentofscreenfile 
										
										+ "public MemberOfRL_LUI RelatedListLink() throws Exception  \n"
										+ "{ \n"
										+ "return sfdc.RL_LUI(RList,\"RelatedListLink\"); \n"
										+ "} \n"
										+ "public MemberOfRL_LUI RelatedListItem() throws Exception  \n"
										+ "{ \n"
										+ "return sfdc.RL_LUI(RList,\"RelatedListItem\");  \n"
										+ "} \n } \n";
										
					}
					String each_button_asperapp = "";
					String each_button_changed = "";
					
					sfdc.contentofscreenfile = sfdc.contentofscreenfile
					+ "//************************* Functions for Buttons List ***************************** // \n \n";
					
					for(String s:sfdc.al_buttons)
					{
						each_button_asperapp = s.trim();
						each_button_changed = s.trim().replace("+", "").replace("&", "")
						.replace("?", "").replace(":", "").replace("]", "").replace("[", "")
						.replace("-", "").replace(" ", "").replace("*", "")
						.replace("/", "").replace("'", "").replace("(", "").replace(">", "").replace("<", "")
						.replace("%", "").replace(")", "").replace(",", "").replace("#", "").replace("!", "")
						.replace("$", "").replace(".", "").replace("\\", "").replace(" ", "");
						
						sfdc.contentofscreenfile = sfdc.contentofscreenfile 
								
						
						+ "public MemberOfButton_LUI "+each_button_changed+"Button() throws Exception{ \n" 
						+ "return sfdc.Button_LUI(\""+each_button_asperapp+"\"); \n"
						+ "} \n";
												
					}
											
					sfdc.contentofscreenfile = sfdc.contentofscreenfile 
							+ "} \n \n";
											
								
								
					sfdc._CreateScreenFile();
					*/
        	sfdc.contentofscreenfile = sfdc.contentofscreenfile ;
    		sfdc._CreateScreenFile();
        }
					
					
    		
    
    	}
    	catch(Exception e1)
    	{
    		e1.printStackTrace();
    		
    	}
    	
    } 


public static void main(String[] args) throws Exception{
   // new GUI_ScreenRecorder_LUI(new SFDCAutomationFW("TC"));      
  }
}