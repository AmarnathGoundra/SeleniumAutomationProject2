package SOURCE_CODE.SFDC;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

import org.openqa.selenium.JavascriptExecutor;

/**
 * @author Cognizant
 *
 */
public class MemberOfButton_LUI extends PageBase {
	
	String ButtonName;
	WebElement button;
	//WebDriver remoteDriver;
	//SFDCAutomationFW autoFW;
	String xpath,xp1,xp2,xp3,xp4,xp5,xp1_mb,xp2_mb,xp6_button_on_dialog;
	String xp_common_vd = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]";
	String xp_common_in_ed_and_vd = "//div[contains(@class,'test-id__record-layout-container riseTransitionEnabled')][1]/following-sibling::div[contains(@class,'riseTransitionEnabled test-id__inline-edit-record-layout-container')][1]";
	String xp_common_in_ed = "(//div[contains(@class,'windowViewMode') and contains(@class,'isModal active') and contains(@class,'active')])[1]";
	
	public MemberOfButton_LUI(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
		
	}

	public MemberOfButton_LUI(AppiumDriver appiumDriver) {
		super(appiumDriver);
		
	}
	
	public String generateXpath(String ButtonName) {
		
		
		xpath = "//button[@type='button']/descendant::*[contains(@class,'btn')][text()='"+ButtonName+"']";
		xp1 = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::li[contains(@class,'slds-button')]/descendant::a[1]/descendant::div[@title='"+ButtonName+"'])[1]";	
		
		xp2 = "//force-form-footer[contains(@class,'-footer') or contains(@class,'inlineFooter')]/descendant::button[contains(@class,'slds-button')]/descendant-or-self::*[normalize-space(text())='"+ButtonName+"'][1]";
		
		xp3 =  "//lightning-button//button[@type='button'][normalize-space(text())='"+ButtonName+"'][1]";
		
		xp1_mb = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::li[contains(@class,'slds-button') and (contains(@class,'DropDown') or contains(@class,'dropdown'))])[1]";	
		
		this.ButtonName = ButtonName.replace("Menu", "").replace("Button", "").replace(":","");
		xp2_mb = "(//div[contains(@class,'slds-dropdown')][@role='menu']//a[@role='menuitem']/descendant-or-self::*[text()='"+this.ButtonName+"'])[1]";
		
		xp4 = "(//button[contains(@class,'ModalFooter')]//*[text()='"+ButtonName+"'])[1]";
		
		xp5 = "("+xp_common_vd+"//button[contains(@class,'button')][@type='button']/descendant-or-self::*[normalize-space(text())='"+ButtonName+"'])[1]";
		
		xp6_button_on_dialog = "(//div[@role='dialog'][contains(@class,'in-open')]//div[contains(@class,'footer')]//*[contains(@class,'button')]/descendant-or-self::*[text()='"+ButtonName+"'])[1]";
		
		return xpath;
	}
	

	/**
	 * @param Index
	 * @return
	 * @Description Clicks on the button by xpath index
	 * @throws Exception
	 */
	public boolean ClickByIndex(int Index) throws Exception
	{
		try{
			WaitForPageToLoad(60);
			
				
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
			if(remoteDriver.findElements(By.xpath(xp1)).size() > 0)
			{
				xpath = xp1;
			}
			else if(remoteDriver.findElements(By.xpath(xp2)).size() > 0)
			{
				xpath = xp2;
			}
			
			
			remoteDriver.findElement(By.xpath(xpath)).click();
			System.out.println("Clicked on the button ("+ButtonName.trim()+").");
			AddLogToCustomReport("Clicked on the button ("+ButtonName.trim()+").", "Pass");
			return true;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on the button ("+ButtonName.trim()+")");
			AddLogToCustomReport("Unable to click on the button ("+ButtonName.trim()+")", "Fail");
			return false;
			
		}
	
	}
	public boolean ClickFooterDialog() throws Exception
	{
		try{
			WaitForPageToLoad(60);
			
			String xp = "//div[@role='dialog'][contains(@class,'in-open')]//div[contains(@class,'footer')]//button[normalize-space(text())='"+ButtonName+"'][1]";
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
			remoteDriver.findElement(By.xpath(xp)).click();
			System.out.println("Clicked on the button ("+ButtonName.trim()+").");
			AddLogToCustomReport("Clicked on the button ("+ButtonName.trim()+").", "Pass");
			return true;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on the button ("+ButtonName.trim()+")");
			AddLogToCustomReport("Unable to click on the button ("+ButtonName.trim()+")", "Fail");
			return false;
			
		}
	
	}
	/**
	 * @Description Switches context to active iframe in any Ligntning page, please note defaultcontent should be used seperately in test case level once iframe actions are completed 
	 * @throws Exception
	 */
	public void SwitchToActiveLightningiFrame() throws Exception
	{
		try 
		{
			remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::iframe")));

			System.out.println("Successfully switched to active iframe of ligntning page.");
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Unable to switch to active iframe of ligntning page.");
		}
	}
	
	
	/**
	 * @Author Sourav Mukherjee
	 * @Description Clicks on Salesforce OOB button
	 * @return boolean
	 * @throws Exception
	 */	
	synchronized public boolean Click() throws Exception
	{
		try{
			WaitForPageToLoad(60);		
			//Thread.sleep(3000L);			  
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
			if(remoteDriver.findElements(By.xpath(xp1)).size() > 0)
			{
				System.out.println("This is xp1");
				List<WebElement> buttons = remoteDriver.findElements(By.xpath(xp1));
				for(WebElement wb : buttons)
				{
					if (wb.isDisplayed()) {
						wb.click();
						break;
					} 
					//System.out.println("wb.isDisplayed():"+wb.isDisplayed());
					//System.out.println("wb.isEnabled():"+wb.isEnabled());
				}
				
				xpath = xp1;
				
			}
			else if(remoteDriver.findElements(By.xpath(xp2)).size() > 0)
			{
				System.out.println("This is xp2");
				List<WebElement> buttons = remoteDriver.findElements(By.xpath(xp2));
				for(WebElement wb : buttons)
				{
					if (wb.isDisplayed()) {
						wb.click();
						break;
					} 
					//System.out.println("xp2 -->wb.isDisplayed():"+wb.isDisplayed());
					//System.out.println("xp2 --> wb.isEnabled():"+wb.isEnabled());
				}
				
				xpath = xp2;
			}
			else if(remoteDriver.findElements(By.xpath(xp3)).size() > 0)
			{
				System.out.println("This is xp3");
				List<WebElement> buttons = remoteDriver.findElements(By.xpath(xp3));
				for(WebElement wb : buttons)
				{
					if (wb.isDisplayed()) {
						wb.click();
						break;
					} 
					//System.out.println("xp2 -->wb.isDisplayed():"+wb.isDisplayed());
					//System.out.println("xp2 --> wb.isEnabled():"+wb.isEnabled());
				}
				
				xpath = xp3;
			}	
			else if(remoteDriver.findElements(By.xpath(xp4)).size() > 0)
			{
				List<WebElement> buttons = remoteDriver.findElements(By.xpath(xp4));
				for(WebElement wb : buttons)
				{
					if (wb.isDisplayed()) {
						wb.click();
						break;
					} 
					//System.out.println("xp2 -->wb.isDisplayed():"+wb.isDisplayed());
					//System.out.println("xp2 --> wb.isEnabled():"+wb.isEnabled());
				}
				
				xpath = xp4;
			}	
			else if(remoteDriver.findElements(By.xpath(xp5)).size() > 0)
			{
				List<WebElement> buttons = remoteDriver.findElements(By.xpath(xp5));
				for(WebElement wb : buttons)
				{
					if (wb.isDisplayed()) {
						wb.click();
						break;
					} 
					//System.out.println("xp2 -->wb.isDisplayed():"+wb.isDisplayed());
					//System.out.println("xp2 --> wb.isEnabled():"+wb.isEnabled());
				}
				
				xpath = xp5;
			}	
			
			System.out.println("xpath:"+xpath);
			//remoteDriver.findElement(By.xpath(xpath)).click();
			System.out.println("Clicked on the button ("+ButtonName.trim()+").");
			AddLogToCustomReport("Clicked on the button ("+ButtonName.trim()+").", "Pass");
			return true;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on the button ("+ButtonName.trim()+")");
			AddLogToCustomReport("Unable to click on the button ("+ButtonName.trim()+")", "Fail");
			return false;
			
		}
	
	}
	
	
	public boolean MenuButtonClick() throws Exception
	{
		try{
			WaitForPageToLoad(60);
			
						  
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
			if(remoteDriver.findElements(By.xpath(xp1_mb)).size() > 0)
			{
				xpath = xp1_mb;
			}			
			
			remoteDriver.findElement(By.xpath(xpath)).click();
			Thread.sleep(3000L);
			System.out.println("xp2_mb:"+xp2_mb);
			remoteDriver.findElement(By.xpath(xp2_mb)).click();
			
			
			System.out.println("Clicked on the button ("+ButtonName.trim()+").");
			AddLogToCustomReport("Clicked on the button ("+ButtonName.trim()+").", "Pass");
			return true;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on the button ("+ButtonName.trim()+")");
			AddLogToCustomReport("Unable to click on the button ("+ButtonName.trim()+")", "Fail");
			return false;
			
		}
	
	}
	
	//Clicks on a button in Confirmation Dialog in Salesforce, 
	//example Delete, Cancel buttons on Deletion Confirmation dialog
	public boolean ClickButton_ConfirmationDialog() throws Exception
	{
		try{
			WaitForPageToLoad(60);
			
						  
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
			if(remoteDriver.findElements(By.xpath(xp6_button_on_dialog)).size() > 0)
			{
				xpath = xp6_button_on_dialog;
			}			
			
			remoteDriver.findElement(By.xpath(xpath)).click();
			Thread.sleep(3000L);
			System.out.println("xp6_button_on_dialog:"+xpath);
			
			
			System.out.println("Clicked on the button ("+ButtonName.trim()+").");
			AddLogToCustomReport("Clicked on the button ("+ButtonName.trim()+").", "Pass");
			return true;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on the button ("+ButtonName.trim()+")");
			AddLogToCustomReport("Unable to click on the button ("+ButtonName.trim()+")", "Fail");
			return false;
			
		}
	
	}
	
	
	/**
	 * @author Sourav
	 * @return boolean
	 * @throws Exception
	 * @Description Checks if the SFDC OOB button is displayed in the UI
	 */
	public boolean IsDisplayed() throws Exception
	{
		try{
			WaitForPageToLoad(60);
			
			
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
			if(remoteDriver.findElements(By.xpath(xp1)).size() > 0)
			{
				xpath = xp1;
			}
			else if(remoteDriver.findElements(By.xpath(xp2)).size() > 0)
			{
				xpath = xp2;
			}
			
			if(remoteDriver.findElement(By.xpath(xpath)).isDisplayed())
			{
				System.out.println("Successfully found the button ("+ButtonName.trim()+").");
				AddLogToCustomReport("Successfully found the button ("+ButtonName.trim()+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("Unable to find the button ("+ButtonName.trim()+").");
				AddLogToCustomReport("Unable to find the button ("+ButtonName.trim()+").", "Fail");
				return true;
			}
				
		}
		catch(Exception e)
		{
			System.out.println("Unable to find the button ("+ButtonName+").Xpath:"+xpath);
			AddLogToCustomReport("Unable to find the button ("+ButtonName+")", "Fail");
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * @author Sourav
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies the existence of button in the UI and sends the message in the log
	 */
	public boolean VerifyIfDisplayed(String YesORNo) throws Exception
	{
		try 
		{
			WaitForPageToLoad(60);
			
		
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
			if(remoteDriver.findElements(By.xpath(xp1)).size() > 0)
			{
				xpath = xp1;
			}
			else if(remoteDriver.findElements(By.xpath(xp2)).size() > 0)
			{
				xpath = xp2;
			}
			
			if(remoteDriver.findElements(By.xpath(xpath)).size() > 0 && YesORNo.equalsIgnoreCase("Yes"))
			{
				System.out.println("Successfully verified the presence of button ("+ButtonName.trim()+").");
				AddLogToCustomReport("Successfully verified the presence of button ("+ButtonName.trim()+").", "Pass");
				return true;
			}
			else if(remoteDriver.findElements(By.xpath(xpath)).size() > 0 && YesORNo.equalsIgnoreCase("No"))
			{
				System.out.println("The button ("+ButtonName.trim()+") is found in the application when it is not expected.");
				AddLogToCustomReport("The button ("+ButtonName.trim()+") is found in the application when it is not expected.", "Fail");
				return false;
			}
			else if(remoteDriver.findElements(By.xpath(xpath)).size() == 0 && YesORNo.equalsIgnoreCase("No"))
			{
				System.out.println("Successfully verified that the button ("+ButtonName.trim()+") is not available in the UI.");
				AddLogToCustomReport("Successfully verified that the button ("+ButtonName.trim()+") is not available in the UI.", "Pass");
				return true;
			}
			else if(remoteDriver.findElements(By.xpath(xpath)).size() == 0 && YesORNo.equalsIgnoreCase("Yes"))
			{
				System.out.println("The button ("+ButtonName.trim()+") was not available in the UI when it is expected.");
				AddLogToCustomReport("The button ("+ButtonName.trim()+") was not available in the UI when it is expected.", "Fail");
				return false;
			}
			else
			{
				AddLogToCustomReport("Incorrect input parameter provided as input. Please mention either Yes or No", "Fail");
				return false;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to verify the button due to exception", "Fail");
			return false;
		}
	}
	
	/**
	 * @param waitingTimeinSec
	 * @return boolean
	 * @throws Exception
	 * @Description Waits for specified time for the button to display in the UI
	 */
	public boolean WaitForElement(long waitingTimeinSec) throws Exception
	{
		try{
			WaitForPageToLoad(60);
			
			
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinSec));
			if(remoteDriver.findElements(By.xpath(xp1)).size() > 0)
			{
				xpath = xp1;
				System.out.println("WaitForElement:>>   -------- Success ---------");
				return true;
			}
			else if(remoteDriver.findElements(By.xpath(xp2)).size() > 0)
			{
				xpath = xp2;
				System.out.println("WaitForElement:>>   -------- Success ---------");
				return true;
			}
			else
			{
				System.out.println("WaitForElement:>>   -------- Failure ---------");
				return false;
			}
					
		}
		catch(Exception e)
		{
			System.out.println("WaitForElement:>>   -------- Failure ---------");
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param 1. xpath of the element. 2. Waiting Time in Second
	 * @return boolean
	 * @throws Exception
	 * @Description Waits for the specified time until the webelemnt is available to WebDriver
	 * @Date Aug 7, 2014
	 */
	public boolean WaitForElement(String xpath, long waitingTimeinsec) throws Exception
    {
         try {
        	 
        	remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
     		List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
     		if (myDynamicElement.size() > 0)
     		{
     			System.out.println("Success: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return true;
     		}
     		else
     		{
     			System.out.println("Unsuccess: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return false;
     		} 
        }
         catch(NoSuchElementException e)
         {
        	 e.printStackTrace();
             System.out.println("Exception inside WaitForElement:"+xpath);
             return false;
         }
     }
	
	/**
	 * @author Sourav Mukherjee
	 * @Param timeOutInSeconds
	 * @return void
	 * @throws Exception
	 * @Description Waits for the page to reach ready state 
	 * @Date Aug 7, 2014
	 */
	public void WaitForPageToLoad(int timeOutInSeconds) throws Exception
	{ 
		
		String command = "return document.readyState"; 

		try
		{
		for (int i=0; i<timeOutInSeconds; i++)
		{ 
			try
			{
				Thread.sleep(1000L);
			}
			catch (InterruptedException e)
			{
				System.out.println("Unable to load the webpage");				
				
			} 
			
			if (remoteDriver.executeScript(command).toString().equals("complete"))
			{ 
				//System.out.println("Inside WaitForPageToLoad(Success)");
				break; 
			} 
			
			
		} 
		}catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param 1. xpath of the element, 2. Time specified in second
	 * @return WebElement
	 * @throws Exception
	 * @Description Waits for the specified time until the webelemnt is available to WebDriver. This uses WebDriverWait class 
	 * @Date Aug 7, 2014
	 */
	public WebElement WebDriverWaitForElement(String xpath, long waitingTimeinsec) throws Exception
    {
		WebElement element=null;
        try {
        	
        	 	WebDriverWait wait = new WebDriverWait(remoteDriver, Duration.ofSeconds(waitingTimeinsec));
        	 	element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
        	 	return element;
           	 }
         	catch(NoSuchElementException e)
         	{
         		e.printStackTrace();
         		System.out.println("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec");
         		AddLogToCustomReport("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec", "Fail");
         		return element;
        	 
         	}
     }

	
}
