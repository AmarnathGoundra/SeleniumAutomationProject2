import pandas as pd # pip install pandas
import numpy as np
import openpyxl
import os
import sys

workingdir = os.getcwd()
print("working directory from python file code:"+workingdir)
print("No. of arguments:"+str(len(sys.argv)))
print("List of Arguments:"+str(sys.argv))


###### **************** Below Line of Code are all above Function Calls ******************* #######
def highlight_diff(data, other, color='pink'):
    # Define html attribute
    attr = 'background-color: {}'.format(color)
    # Where data != other set attribute
    return pd.DataFrame(np.where(data.ne(other), attr, ''), index=data.index, columns=data.columns)


def Compare_SourceTargetValues(cdp,EntityName):

    ### Reading source and target files for each of the object
    ##cdp = "C:\\1_SOURAV\\WS_CAAS_23v6\\CAAS\\TestDataStore\\FAV"
    
    sourcepath = cdp+"\\"+EntityName+"_E.xlsx"
    targetpath = cdp+"\\"+EntityName+".xlsx"
    resultpath = cdp+"\\"+EntityName+"_Result.xlsx"

    
    sourceDF1 = pd.read_excel(open(sourcepath, 'rb'),sheet_name=None)
    TargetDF1 = pd.read_excel(open(targetpath, 'rb'),sheet_name=None)
    
    sourceDF = pd.read_excel(open(sourcepath, 'rb'))
    TargetDF = pd.read_excel(open(targetpath, 'rb'))
    
    ##Print the names of the sheets
    print("***** Sheet Names of Source/Expected file *****")
    print(sourceDF1.keys())
    print("***** Sheet Names of Target/Actual file *****")
    print(TargetDF1.keys())

    RDF_Consolidated = {}
    ##Get each of the dataframe
    for sheet_name in sourceDF1.keys():
         each_df_s = sourceDF1[sheet_name]
         each_df_t = TargetDF1[sheet_name]
         #print(each_df_s)
         column_headers = each_df_s.columns.values.tolist()
         each_df_t = each_df_t[column_headers]
         # Set axis=None so it passes the entire frame
         RDF = each_df_t.style.apply(highlight_diff, axis=None, other=each_df_s)
         RDF_Consolidated[sheet_name] = RDF
    #     print("************ Each Result Sheet **************")
    #     RDF.to_excel(resultpath, index=False)
    
    with pd.ExcelWriter(resultpath) as writer:
        for each_sheet in RDF_Consolidated.keys():
            print("the name of data frame is:"+each_sheet)
            # Write the DataFrame back to the Excel file
            #RDF_Consolidated[each_sheet].to_excel(resultpath,sheet_name=each_sheet, index=False)
            RDF_Consolidated[each_sheet].to_excel(writer, sheet_name=each_sheet)



    #RDF_Consolidated.to_excel(resultpath, index=False)

    ######### Working code #########    
    # column_headers = sourceDF.columns.values.tolist()
    # TargetData = TargetDF[column_headers]        #aligns columns in target df with source df columns
    # # Set axis=None so it passes the entire frame
    # RDF = TargetData.style.apply(highlight_diff, axis=None, other=sourceDF)
    # RDF.to_excel(resultpath, index=False)

Compare_SourceTargetValues(sys.argv[1],sys.argv[2])
