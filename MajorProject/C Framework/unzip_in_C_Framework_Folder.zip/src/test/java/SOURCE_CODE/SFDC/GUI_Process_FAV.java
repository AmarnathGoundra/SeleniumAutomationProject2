package SOURCE_CODE.SFDC;
import javax.swing.*;
import javax.swing.event.*;

import org.apache.maven.shared.invoker.SystemOutHandler;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class GUI_Process_FAV implements  ActionListener{

    JList availableList, chosenList;
    JButton buttonin, buttonout;
    JButton btn_baseline, btn_validate;
    ArrayList<String> objects_sfdc;
    ArrayList<String> al_fields,al_profiles,al_perm_plus_paf,al_proposed_xl_by_row,al_perm_table_eachrow;
    ArrayList<ArrayList<String>>	al_al_perm;
    SFDCAutomationFW sfdc = null;
    //public String shoppingItems[];
    
    // The ListModels we will be using in the example.
    DefaultListModel shopping, items;
    JPanel totalGUI;
    JPanel tempPanel;
    JPanel buttonPanel;
    String xl_fav_sfdc_object,xp_field_access_table_common_header;
    
    FileOutputStream out;
    
    public JPanel createContentPane (SFDCAutomationFW sfdc, String shoppingItems[]){
    	this.sfdc = sfdc;
    	
        // Create the final Panel.
        totalGUI = new JPanel();
        xp_field_access_table_common_header = "(//div[contains(@style,'block') or not(@style)]//*[normalize-space(text())='Profiles'][contains(@style,'bold')])[1]";
        
        // Instantiate the List Models.
        shopping = new DefaultListModel();
        items = new DefaultListModel();

        // Things to be in the list.
        //String shoppingItems[] = {"Milk", "Cheese", "Bread", "Butter", "Beans",
        //"Soup", "Bacon", "Chicken", "Curry Sauce", "Chocolate1", "Chocolate2", "Chocolate3","Chocolate4" };

        // Using a for loop, we add every item in the String array
        // into the ListModel.

        for(int i = 0; i < shoppingItems.length; i++)
        {
            shopping.addElement(shoppingItems[i]);
        }

        // Creation of the list.
        // We set the cells in the list to be 20px x 140px.
        
        availableList = new JList(shopping);
        availableList.setVisibleRowCount(15);
        availableList.setFixedCellHeight(20);
        availableList.setFixedCellWidth(200);
        availableList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        
        // We then add them to a JScrollPane.
        // This means when we remove items from the JList
        // it will not shrink in size.
        JScrollPane list1 = new JScrollPane(availableList);
        
        chosenList = new JList(items);
        chosenList.setVisibleRowCount(15);
        chosenList.setFixedCellHeight(20);
        chosenList.setFixedCellWidth(200);
        chosenList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        
        // We add this list to a JScrollPane too.
        // This is so the list is displayed even though there are 
        // currently no items in the list.
        // Without the scrollpane, the list would not show.
        JScrollPane list2 = new JScrollPane(chosenList);

        // We create the buttons to be placed between the lists.
        buttonPanel = new JPanel();

        buttonin = new JButton(">>");
        buttonin.addActionListener(this);
        buttonPanel.add(buttonin);

        buttonout = new JButton("<<");
        buttonout.addActionListener(this);
        buttonPanel.add(buttonout);

        
        btn_baseline = new JButton("Baseline Field Accessibility");
        btn_baseline.addActionListener(this);
        //btn_baseline.setBounds(5, 10, 50, 30);
        

        btn_validate = new JButton("Validate Field Accessibility");
        btn_validate.addActionListener(this);
        //btn_validate.setBounds(5, 10, 50, 30);
        
        // This final bit of code uses a BoxLayout to space out the widgets
        // in the GUI.

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.LINE_AXIS));

        bottomPanel.add(Box.createRigidArea(new Dimension(10,0)));
        bottomPanel.add(list1);
        bottomPanel.add(Box.createRigidArea(new Dimension(5,0)));
        bottomPanel.add(buttonPanel);
        bottomPanel.add(Box.createRigidArea(new Dimension(5,0)));
        bottomPanel.add(list2);
        bottomPanel.add(Box.createRigidArea(new Dimension(10,0)));
               
        
        totalGUI.add(bottomPanel);
        totalGUI.add(btn_baseline);
        totalGUI.add(btn_validate);
        totalGUI.setBackground(new Color(0,0,128));
        totalGUI.setOpaque(true);
        return totalGUI;
    }

    // In this method, we create a square JPanel of a colour and set size
    // specified by the arguments.
    
   
    
    private JPanel createSquareJPanel(Color color, int size) {
        tempPanel = new JPanel();
        tempPanel.setBackground(color);
        tempPanel.setMinimumSize(new Dimension(size, size));
        tempPanel.setMaximumSize(new Dimension(size, size));
        tempPanel.setPreferredSize(new Dimension(size, size));
        return tempPanel;
    }

    // valueChanged is the method that deals with a ListSelectionEvent.
    // This simply changes the boxes that are selected to true.

    public void actionPerformed(ActionEvent e)
    {
    	try {
        int i = 0;
        
        // When the 'in' button is pressed,
        // we take the indices and values of the selected items
        // and output them to an array.

        if(e.getSource() == buttonin)
        {
            int[] fromindex = availableList.getSelectedIndices();
            Object[] from = availableList.getSelectedValuesList().toArray();

            // Then, for each item in the array, we add them to
            // the other list.
            for(i = 0; i < from.length; i++)
            {
                items.addElement(from[i]);
            }
            
            // Finally, we remove the items from the first list.
            // We must remove from the bottom, otherwise we try to 
            // remove the wrong objects.
            for(i = (fromindex.length-1); i >=0; i--)
            {
                shopping.remove(fromindex[i]);
            }
        }
        
        // If the out button is pressed, we take the indices and values of
        // the selected items and output them to an array.
        else if(e.getSource() == buttonout)
        {
            Object[] to = chosenList.getSelectedValuesList().toArray();
            int[] toindex = chosenList.getSelectedIndices();
            
            // Then, for each item in the array, we add them to
            // the other list.
            for(i = 0; i < to.length; i++)
            {
                shopping.addElement(to[i]);
            }
            
            // Finally, we remove the items from the first list.
            // We must remove from the bottom, otherwise we try to
            // remove the wrong objects.
            for(i = (toindex.length-1); i >=0; i--)
            {
                items.remove(toindex[i]);
            }
        }
        else if(e.getSource() == btn_baseline)
        {
        	createBaseline_And_Validate_Field_Access("Yes");
        }
        else if(e.getSource() == btn_validate)
        {
        	createBaseline_And_Validate_Field_Access("No");
            new Invoke_FAV_ComparisonPythonScript();
            System.exit(0);
//            int toindex = chosenList.getModel().getSize();
//            
//            // Then, for each item in the array, we add them to
//            // the other list.
//            for(i = 0; i < toindex; i++)
//            {
//            	System.out.println("Selected Objects are: "+chosenList.getModel().getElementAt(i));
//            	objects_sfdc.add(chosenList.getModel().getElementAt(i).toString());
//            }
        }
    	}catch(Exception ex)
    	{
    		ex.printStackTrace();
    	}
    }

    public void createBaseline_And_Validate_Field_Access(String IsBaseline) throws Exception
    {
    	String suffix_xl_filename = ""; 
    	if (IsBaseline.equalsIgnoreCase("Yes"))
    	{
    		suffix_xl_filename = "_E";
		}
    	
    	objects_sfdc = new ArrayList<String>();
        int toindex = chosenList.getModel().getSize();
        
        // Then, for each item in the array, we add them to
        // the other list.
        
        System.out.println("**************** CREATING BASELINE FOR SELECTED OBJECTS *************** ");
        for(int i = 0; i < toindex; i++)
        {
        	System.out.println("Selected Objects are: "+chosenList.getModel().getElementAt(i));
        	objects_sfdc.add(chosenList.getModel().getElementAt(i).toString());
        	
        }

        System.out.println("------------->"+objects_sfdc.size());   
        
        SwingUtilities.getWindowAncestor(totalGUI).setVisible(false);
        
        //Line of code to click on each Object and capture the permissions and store the data into baseline.
        for(int j=0;j<objects_sfdc.size();j++)
        {
        	System.out.println("Inside for loop");
        	String sfdc_object_name = objects_sfdc.get(j);
        	System.out.println("Scanning the data for Object: "+sfdc_object_name);
        	String xp_eachobj = "(//h2[text()='Select one:']/../ul//li//a[@href][normalize-space(text())='"+objects_sfdc.get(j)+"'])[1]";
        	sfdc.SwitchToDefaultContent();
        	sfdc.SwitchTovFFrameID_SalesforceLightning();
        	this.sfdc.ClickByJSFocus(this.sfdc.remoteDriver.findElement(By.xpath(xp_eachobj)));
        	Thread.sleep(4000L);

        	//Setting up to capture data in spread sheet
			xl_fav_sfdc_object = System.getProperty("user.dir")+"\\TestDataStore\\FAV\\";
			System.out.println("------>"+xl_fav_sfdc_object);
			//Thread.sleep(1000000000L);
			out = new FileOutputStream(new File(xl_fav_sfdc_object+sfdc_object_name+suffix_xl_filename+".xlsx"));
			// workbook object
			XSSFWorkbook workbook = new XSSFWorkbook();
			List<WebElement> AllValues_elements;
			List<String> al_record_types = new ArrayList<String>();
			String xp_select_pl_rec_type = "";
			Select s = null;
        	sfdc.SwitchToDefaultContent();
        	sfdc.SwitchTovFFrameID_SalesforceLightning();
        	if (this.sfdc.remoteDriver.findElements(By.linkText("View by Record Types")).size() > 0)
        	{
				this.sfdc.remoteDriver.findElement(By.linkText("View by Record Types")).click();
            	sfdc.SwitchToDefaultContent();
            	sfdc.SwitchTovFFrameID_SalesforceLightning();
            	xp_select_pl_rec_type = "(//*[normalize-space(text())='Record Type']/ancestor-or-self::tr[1]//select)[1]";
            	s = new Select(sfdc.remoteDriver.findElement(By.xpath(xp_select_pl_rec_type)));
				AllValues_elements = s.getOptions();
				for (WebElement eachElement : AllValues_elements) 
				{
					System.out.println("Record Type is:"+eachElement.getText().trim());
					if(!(eachElement.getText().trim().equalsIgnoreCase("-- None --") || eachElement.getText().trim().equalsIgnoreCase("-- Choose One --")))
					{
						System.out.println("Record Type inside if:"+eachElement.getText().trim());
						al_record_types.add(eachElement.getText().trim());
					}
				}
        	}
			
        	System.out.println("The size of record type is: "+al_record_types.size());
        	if (al_record_types.size() == 0)
        	{
        		System.out.println("no of record type is 0");
        		al_record_types.add("Field Access");
			}
			//Looping for each record types
        	ArrayList<String> al_record_types_for_xlsheetname = new ArrayList<>();
        
			for(int k=0;k<al_record_types.size();k++)
			//for(int k=0;k<2;k++)
			{
				
				
				al_fields = new ArrayList<String>();
				al_profiles = new ArrayList<String>();
				al_perm_plus_paf = new ArrayList<String>();
				al_proposed_xl_by_row = new ArrayList<String>();
				al_al_perm = new ArrayList<ArrayList<String>>();
				
				
				sfdc.SwitchToDefaultContent();
            	sfdc.SwitchTovFFrameID_SalesforceLightning();
            	
            	if (al_record_types.size() > 1)
            	{
            		xp_select_pl_rec_type = "(//*[normalize-space(text())='Record Type']/ancestor-or-self::tr[1]//select)[1]";
	            	s = new Select(sfdc.remoteDriver.findElement(By.xpath(xp_select_pl_rec_type)));
					s.selectByVisibleText(al_record_types.get(k).toString());
				}
            	
            	String xp_title_specific_record_type = "//*[contains(normalize-space(text()),'Field accessibility for Record Type: "+al_record_types.get(k).toString()+"')][1]";
            	
				//Xath for all the rows: Last row is extra that need to be removed later
				String xp_all_rows_starting_Fields_Ending_Profiles = xp_field_access_table_common_header+"/ancestor::tr[1]/following-sibling::tr";
				
				String xp_all_profiles_including_first_and_last_field_text = xp_field_access_table_common_header+"/ancestor::tr[1]/following-sibling::tr[1]//th/descendant-or-self::*[text()]";
				
				String xp_all_field_including_first_and_last_field_text = xp_field_access_table_common_header+"/ancestor::tr[1]/following-sibling::tr//th[1]/descendant-or-self::*[text()]";

            	System.out.println("xp_all_rows_starting_Fields_Ending_Profiles:"+sfdc.remoteDriver.findElements(By.xpath(xp_all_rows_starting_Fields_Ending_Profiles)).size());
            	System.out.println("xp_all_profiles_including_first_and_last_field_text:"+sfdc.remoteDriver.findElements(By.xpath(xp_all_profiles_including_first_and_last_field_text)).size());
            	System.out.println("xp_all_field_including_first_and_last_field_text:"+sfdc.remoteDriver.findElements(By.xpath(xp_all_field_including_first_and_last_field_text)).size());
									
				//int column_count_permission = sfdc.remoteDriver.findElements(By.xpath(xp_all_profiles_including_first_and_last_field_text)).size() - 2; // Excluding two columns for fields one at the begining and other one at the end
				//int row_count_permission = sfdc.remoteDriver.findElements(By.xpath(xp_all_field_including_first_and_last_field_text)).size() - 2; // Excluding two rows 1st one from the top while is for profile names and other ones is the last row for Profile names
				
            	int column_count_permission = sfdc.remoteDriver.findElements(By.xpath(xp_all_profiles_including_first_and_last_field_text)).size(); // includes two columns one at the beginning and other one at the end of column
				int row_count_permission = sfdc.remoteDriver.findElements(By.xpath(xp_all_field_including_first_and_last_field_text)).size(); // Including two rows 1st one from the top and 2nd one from the bottom
				
				sfdc.SwitchToDefaultContent();
            	sfdc.SwitchTovFFrameID_SalesforceLightning();
            	            	    	
            	
            	//Read all the profiles
            	System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<< NAME OF EACH PROFILE >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            	List<WebElement> all_profiles = sfdc.remoteDriver.findElements(By.xpath(xp_all_profiles_including_first_and_last_field_text));
            	for(WebElement each_profile:all_profiles) 
            	{
            		//if(!each_profile.getText().trim().equalsIgnoreCase("Fields")) 
            		//{
            			System.out.println("PROFILE NAME: "+each_profile.getText());
            			al_profiles.add(each_profile.getText());
            		//}
            		
            	}
            	
            	//Read all the fields 
            	System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< NAME OF EACH FIELD >>>>>>>>>>>>>>>>>>>>>>>>>>");
            	List<WebElement> all_fields = sfdc.remoteDriver.findElements(By.xpath(xp_all_field_including_first_and_last_field_text));
            	for(WebElement each_field:all_fields) 
            	{
            		//if(!each_field.getText().trim().equalsIgnoreCase("Fields")) 
            		//{
            			System.out.println("FIELD NAME: "+each_field.getText());
            			al_fields.add(each_field.getText());
            		//}	            		
            	}
            	
            	// spreadsheet object
            	String record_types_exclude_special_char = al_record_types.get(k).toString().trim()
            			.replace("+", "").replace("&", "").replace("?", "")
            			.replace(":", "").replace("]", "").replace("[", "")
						.replace("-", "").replace(" ", "").replace("*", "")
						.replace("/", "").replace("'", "").replace("(", "")
						.replace(">", "").replace("<", "").replace("%", "")
						.replace(")", "").replace(",", "").replace("#", "")
						.replace("!", "").replace("$", "").replace(".", "")
						.replace("!", "");
            	
            	//Code here to check duplicacy of sheet name
            	boolean isPresent = al_record_types_for_xlsheetname.contains(record_types_exclude_special_char);
            	XSSFSheet spreadsheet = null;
            	
            	if (isPresent) {
                    System.out.println("This record type has already been captured..");
                    row_count_permission = 0; //Because do not want to store the permission for this record type as it is duplicate
                }
            	else
            	{
            		al_record_types_for_xlsheetname.add(record_types_exclude_special_char);
            		spreadsheet = workbook.createSheet(record_types_exclude_special_char);
            	}
            	
            	
            	//****************
	

            	//Read all the permissions
            	for(int a=0;a<row_count_permission;a++)
            	{
            		System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<< BEGIN OF A ROW >>>>>>>>>>>>>>>>>>>>>>>>");
            		
            		al_perm_table_eachrow = new ArrayList<String>();
            		
            		// creating a row object
					XSSFRow row = spreadsheet.createRow(a);
					
            		for(int b=0;b<column_count_permission;b++) 
            		{
            			//String xp_permission = "((//*[normalize-space(text())='Profiles'][contains(@style,'bold')])[1]/ancestor::tr[1]/following-sibling::tr//td["+(a+1)+"]//a[text()])["+(b+1)+"]";
            			//String xp_permission = "(//*[normalize-space(text())='Profiles'][contains(@style,'bold')][1]/ancestor::tr[1]/following-sibling::tr//td["+(b+1)+"]//a[text()])["+(a+1)+"]";
            			String xp_permission_plus_Profiles_Fields = "("+xp_field_access_table_common_header+"/ancestor::tr[1]/following-sibling::tr["+(a+1)+"]//*[text()])["+(b+1)+"]";
            			WebElement each_perm_elmnt = sfdc.remoteDriver.findElement(By.xpath(xp_permission_plus_Profiles_Fields)); 
            			sfdc.HighLight(each_perm_elmnt);
            			System.out.println("Permission by each columns--> "+each_perm_elmnt.getText().trim().toString());
            			al_perm_plus_paf.add(each_perm_elmnt.getText().trim());
            			al_perm_table_eachrow.add(each_perm_elmnt.getText().trim());
            			
            			Cell cell = row.createCell(b);
        				cell.setCellValue((String)each_perm_elmnt.getText().trim());
            		}
            		
            		System.out.println("No of columns in the current table of field accessibility is:"+al_perm_table_eachrow.size());
            		al_al_perm.add(al_perm_table_eachrow);
            		System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<  END OF A ROW >>>>>>>>>>>>>>>>>>>>>>>>");
            	}
            	
            	//End of a record type
				
            	System.out.println("No of Profiles:"+al_profiles.size());
            	System.out.println("No of Fields:"+al_fields.size());
            	System.out.println("No of Perm:"+al_perm_plus_paf.size());
            		            	
        		            		
            	//al_proposed_xl_by_row
            	//Framing row wise data same as sfdc to be captured in excel
//            	int no_of_to_be_xl_row = al_fields.size() + 1;
//            	al_proposed_xl_by_row.add("Fields");	
//            	for(int f=0;f<al_profiles.size();f++)
//            	{
//            		al_proposed_xl_by_row.add(al_profiles.get(f));
//            	}
//            	for(int d=0;d<al_fields.size();d++)
//            	{
//            		
//            	}
            	
			} //End of looping all the record types
			workbook.write(out);
			out.close();
			this.sfdc.remoteDriver.findElement(By.partialLinkText("Choose a different tab")).click();
			
			
        } //End of looping all objects        
        
        

    }
    public void createAndShowGUI(SFDCAutomationFW sfdc,String shoppingItems[]) {

        JFrame.setDefaultLookAndFeelDecorated(true);
        JFrame frame = new JFrame("Selection of Salesforce Objects for Field Accessibility Validator");
       
        
        GUI_Process_FAV demo = new GUI_Process_FAV();
        frame.setContentPane(demo.createContentPane(sfdc,shoppingItems));
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int height = screenSize.height;
        int width = screenSize.width;
        frame.setSize(width/2, height/2);
        
        // here's the part where i center the jframe on screen
        frame.setLocationRelativeTo(null);
        
        frame.setVisible(true);
        frame.setVisible(true);
        
    }

//    public static void main(String[] args) {
//        //Schedule a job for the event-dispatching thread:
//        //creating and showing this application's GUI.
//        SwingUtilities.invokeLater(new Runnable() {
//            public void run() {
//                createAndShowGUI();
//            }
//        });
//    }
}