package SOURCE_CODE.SFDC;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.UIManager;

public class GUI_PageTypeCustome  extends JFrame implements ActionListener 
{ 

	SFDCAutomationFW sfdc;
	JLabel l1, l2, l3, l4, l5, l6, l7, l8;
	JTextField tf1, tf2, tf3, tf4;
	JButton btn1, btn2,btn3,btn4,btn5,btn6;
	JRadioButton rButton_Standard,rButton_Custome;

	public GUI_PageTypeCustome() throws Exception
	{	

		UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");

		setSize(500, 300);

		setLayout(null);

		setResizable(true);       

		setLocationRelativeTo(null);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setTitle("SALESFORCE SELENIUM AUTOMATION TESTING FRAMEWORK");

		l1 = new JLabel("PLEASE CONFIRM SALESFORCE PAGE TYPE");
		l1.setForeground(Color.blue);
		l1.setFont(new Font("TimesRoman", Font.ITALIC, 15));



		btn1 = new JButton("Clear");
		btn2 = new JButton("Create");
		btn3 = new JButton("<< Back");
		btn4 = new JButton("4. Run As Batch");
		btn5 = new JButton("5. Generate HTML Summary Report");
		btn6 = new JButton("6. Run Individually");
		rButton_Standard = new JRadioButton("Standard");
		rButton_Custome = new JRadioButton("Custome");

		btn1.addActionListener(this);

		btn2.addActionListener(this);

		btn3.addActionListener(this);

		btn4.addActionListener(this);

		btn5.addActionListener(this);

		btn6.addActionListener(this);
		rButton_Standard.addActionListener(this);
		rButton_Custome.addActionListener(this);

		


		l1.setBounds(100, 30, 400, 30); //Header label

			

		btn1.setBounds(160, 350, 100, 30);
		btn1.setBackground(new Color(64,64,64));
		btn1.setForeground(new Color(255,255,255));
		btn1.setFont(new Font("Serif", Font.BOLD, 15));

		btn2.setBounds(300, 200, 100, 30);
		btn2.setBackground(new Color(64,64,64));
		btn2.setForeground(new Color(255,255,255));
		btn2.setFont(new Font("Serif", Font.BOLD, 15));
		
		btn3.setBounds(70, 200, 100, 30);
		btn3.setBackground(new Color(64,64,64));
		btn3.setForeground(new Color(255,255,255));
		btn3.setFont(new Font("Serif", Font.BOLD, 15));
		
		rButton_Standard.setBounds(100, 100, 100, 30);
		rButton_Standard.setBackground(new Color(64,64,64));
		rButton_Standard.setForeground(new Color(0,51,0));
		rButton_Standard.setFont(new Font("Serif", Font.BOLD, 15));

		
		rButton_Custome.setBounds(200, 100, 150, 30);
		rButton_Custome.setBackground(new Color(64,64,64));
		rButton_Custome.setForeground(new Color(0,51,0));
		rButton_Custome.setFont(new Font("Serif", Font.BOLD, 15));


		btn4.setBounds(380, 410,230, 30);
		btn4.setBackground(new Color(64,64,64));
		btn4.setForeground(new Color(255,255,255));
		btn4.setFont(new Font("Serif", Font.BOLD, 15));

		btn5.setBounds(200, 470, 270, 30);
		btn5.setBackground(new Color(64,64,64));
		btn5.setForeground(new Color(255,255,255));
		btn5.setFont(new Font("Serif", Font.BOLD, 15));


		btn6.setBounds(360, 480, 230, 30);
		btn6.setBackground(new Color(64,64,64));
		btn6.setForeground(new Color(255,255,255));
		btn6.setFont(new Font("Serif", Font.BOLD, 15));

		add(l1);


//		add(btn1);
		add(btn2);
		add(btn3);
		add(rButton_Standard);
		add(rButton_Custome);

		
		getContentPane().setBackground(new Color(102,178,255));
		setBackground(new Color(102,178,255));
		setVisible(true);

	}

	public void actionPerformed(ActionEvent e) 
	{

		try
		{
			if(e.getSource() == btn1)
	        {
	        	tf1.setText("");
	        	tf2.setText("");
	        	tf3.setText("");
	        	tf4.setText("");
	        	
	        }
	        else if(e.getSource() == btn3)
	        {
	        	this.setVisible(false);
	        	new GUIFORFRAMEWORK();
	        	//GUI_For_Framework  swingControlDemo = new GUI_For_Framework();      
	            //swingControlDemo.showInitialScreen();
	        }

			
			else if(e.getSource() == btn2)
			{
				this.setVisible(false);

				if(rButton_Standard.isSelected())
				{
					new GUI_For_ObjectRepository_LUI();
//					sfdc._CreateAUTRepository_LU();
				}
				else if(rButton_Custome.isSelected())
				{
//					sfdc._CreateAUTRepository_LU_Custome();
					//      		new GUI_PageType();
					      		new GUI_For_ObjectRepository_LUI_Custome();
				}
			}
			else if(e.getSource() == rButton_Standard)
			{

				rButton_Custome.setSelected(false);

			}
			else if(e.getSource() == rButton_Custome)
			{
				rButton_Standard.setSelected(false);
			}
			/*
      else if(e.getSource() == btn4)
      {
      	this.setVisible(false);
      	//new GUI_FOR_BATCHRUN();
      }
      else if(e.getSource() == btn5)
      {
      	//this.setVisible(false);
      	//new GenerateHTMLSummaryReport();
      }
      else if(e.getSource() == btn6)
      {
      	this.setVisible(false);
      	//new GUI_FOR_INDIVIDUAL_RUN();
      }
			 */
		}
		catch(Exception e1)
		{
			e1.printStackTrace();

		}

	} 
	public static void main(String[] args) throws Exception{
		new GUI_PageTypeCustome();      
	}
}