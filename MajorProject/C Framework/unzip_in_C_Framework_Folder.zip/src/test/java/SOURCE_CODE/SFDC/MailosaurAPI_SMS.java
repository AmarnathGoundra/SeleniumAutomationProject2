package SOURCE_CODE.SFDC;


import org.junit.Test;
import static org.junit.Assert.*;
import com.mailosaur.MailosaurClient;
import com.mailosaur.MailosaurException;
import com.mailosaur.models.*;
import java.io.IOException;
import java.util.Date;

public class MailosaurAPI_SMS {
	
  @Test public void testExample() throws IOException, MailosaurException {
    // Available in the API tab of a server
    String apiKey = "PAkUpWIiFASWaAl3yRO7xnrADBv9yCDu";
    String serverId = "5pu52uey";
    String serverDomain = "5pu52uey.mailosaur.net";

    MailosaurClient mailosaur = new MailosaurClient(apiKey);
    Date testStart = new Date(); // Only look for messages after our test began

    // Send an SMS message to your test number...

    MessageSearchParams params = new MessageSearchParams();
    params.withServer(serverId).withReceivedAfter(testStart);

    SearchCriteria criteria = new SearchCriteria();
    criteria.withSentTo("7206403830"); // YOUR_TEST_NUMBER

    Message message = mailosaur.messages().get(params, criteria);

    System.out.println(message.text().body()); // "Your order number is 51223"
    System.out.println(message.text().codes().get(0).value()); // "51223"
  
  }
}
