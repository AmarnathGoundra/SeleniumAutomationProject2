package SOURCE_CODE.SFDC;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class MemberOfAllApps_LUI extends PageBase {

	//WebDriver myWD;
	//SFDCAutomationFW autoFW;
	WebElement tab;
	String TabName;
	String AppName;
	String xpath;
	
	public MemberOfAllApps_LUI(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
		
	}

	public MemberOfAllApps_LUI(AppiumDriver appiumDriver) {
		super(appiumDriver);
		
	}
	
	public String generateXpath(String TabName) {
		xpath = "//div[contains(@class,'app-launcher')]//p[normalize-space(text())='"+AppName+"'][1]";
		return xpath;
	}
	
	
	
	/*
	MemberOfTab_LUI(String TN)
	{
		TabName = TN;
		xpath = ".//*[@title='"+ TabName+"' or @title='"+TabName+" Tab - Selected' or @title='"+TabName+" Tab'][1]";
		myWD = SFDCAutomationFW.myWD;
	}
	*/
	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return boolean
	 * @throws Exception
	 * @Description Clicks on the Tab Name displayed on SFDC menu 
	 * @Date Aug 7, 2014
	 */
	public boolean Click() throws Exception
	{
		try
		{
						
			Thread.sleep(4000L);
			String xp="//button[contains(@class,'icon-waffle')][1]//div[contains(@class,'icon-waffle')][1]";
			remoteDriver.findElement(By.xpath(xp)).click();
			xp = "(//button[@type='button'][text()='View All'])[1]";
			click(xp, "View All");				
			String xp1 = "//div[contains(@class,'app-launcher')]//p[normalize-space(text())='"+AppName+"'][1]";
			remoteDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			WebElement elm = remoteDriver.findElement(By.xpath(xp1));
			ScrollToElement(elm);
			elm.click();
			AddLogToCustomReport("Selected the app ("+AppName+") successfully.", "Pass");
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on tab ("+AppName+").");
			AddLogToCustomReport("Unable to click on tab ("+AppName+").", "Fail");
			return false;
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return true if tab name displayed return false if Tab Name is not displayed 
	 * @throws Exception
	 * @Description Verified if a TabName is displayed
	 * @Date Aug 7, 2014
	 */
	public boolean IsDisplayed() throws Exception
	{
		try
		{
			if(isElementDisplayed(xpath))
			{
				System.out.println("The tab ("+AppName+") is displayed.");
				remoteDriver.findElement(By.xpath(xpath)).click();
				AddLogToCustomReport("The tab ("+AppName+") is displayed.", "Pass");
				return true;
			}
			else
			{
				System.out.println("Unable to find tab ("+AppName+") when xpath is :"+xpath);
				AddLogToCustomReport("Unable to find tab ("+AppName+") when xpath is :"+xpath, "Fail");
				return false;
			}
							
		}
		catch(Exception e)
		{
			System.out.println("Unable to find tab ("+AppName+") when xpath is :"+xpath);
			AddLogToCustomReport("Unable to find tab ("+AppName+") when xpath is :"+xpath, "Fail");
			return false;
		}
	}
	
	
	/**
	 * @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}
	}
	
	
	public void ScrollToElement(WebElement element) throws Exception
	{
		
		try
		{
			((JavascriptExecutor)remoteDriver).executeScript("arguments[0].scrollIntoView();", element);
			
			System.out.println("Successfully scrolled untill element.");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to scroll until elemnt");
		}
	}
	
}
