
package SOURCE_CODE.SFDC;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class MemberOfRL_LUI extends PageBase{

	String RelatedList, Value, TargetColumnName;
	//Integer RowIndex;
	String TargetColumnValue;
	//WebDriver remoteDriver;
	//SFDCAutomationFW autoFW;
	String xpath;
	List<WebElement> allposblefieldelements;
	WebElement getsingleWebelement;
	String xpath_common;
	
	/*
	MemberOfRL_LUI(String RL,String CN)
	{
		RelatedList = RL;
		TargetColumnName = CN;		
		remoteDriver = autoFW.remoteDriver;
		xpath_common = "(//div[contains(@class,'oneContent') and contains(@class,'active')])[1]/descendant::div[contains(@class,'forceListViewManagerHeader')][1]/descendant::*[local-name()='h1' or local-name()='span'][text()='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::div[@class='listViewContainer'][1]/descendant::div[@class='displayArea'][1]/descendant::div[contains(@class,'fixed_container')][1]";
	}
	MemberOfRL_LUI(String RL,String TCN,String TCV)
	{
		RelatedList = RL;
		TargetColumnName = TCN;
		TargetColumnValue = TCV;
		remoteDriver = autoFW.remoteDriver;
		xpath_common = "(//div[contains(@class,'oneContent') and contains(@class,'active')])[1]/descendant::div[contains(@class,'forceListViewManagerHeader')][1]/descendant::*[local-name()='h1' or local-name()='span'][text()='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::div[@class='listViewContainer'][1]/descendant::div[@class='displayArea'][1]/descendant::div[contains(@class,'fixed_container')][1]";
	}
	*/
	
	public MemberOfRL_LUI(RemoteWebDriver remoteDriver) {
		super(remoteDriver);	
		//xpath_common = "(//div[contains(@class,'oneContent') and contains(@class,'active')])[1]/descendant::div[contains(@class,'forceListViewManagerHeader')][1]/descendant::*[local-name()='h1' or local-name()='span'][text()='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::div[@class='listViewContainer'][1]/descendant::div[@class='displayArea'][1]/descendant::div[contains(@class,'fixed_container')][1]";
		//xpath_common = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::*[local-name()='h1' or local-name()='span'][text()='"+RelatedList+"'][1]/ancestor::div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'listViewContent') and contains(@class,'table--header') and contains(@class,'fixed_container')][1]";
	}
	
	public MemberOfRL_LUI(AppiumDriver appiumDriver) {
		super(appiumDriver);
		//xpath_common = "(//div[contains(@class,'oneContent') and contains(@class,'active')])[1]/descendant::div[contains(@class,'forceListViewManagerHeader')][1]/descendant::*[local-name()='h1' or local-name()='span'][text()='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::div[@class='listViewContainer'][1]/descendant::div[@class='displayArea'][1]/descendant::div[contains(@class,'fixed_container')][1]";
		//xpath_common = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::*[local-name()='h1' or local-name()='span'][text()='"+RelatedList+"'][1]/ancestor::div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'listViewContent') and contains(@class,'table--header') and contains(@class,'fixed_container')][1]";
	}
	
	
	public String generateXpath(String RList) {
		//xpath_common = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::*[local-name()='h1' or local-name()='span'][text()='"+RList+"'][1]/ancestor::div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'listViewContent') and contains(@class,'table--header') and contains(@class,'fixed_container')][1]";
		xpath_common = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::*[local-name()='h1' or local-name()='span'][text()='Opportunities'][1]/ancestor::div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'listViewContainer')][1]";		   
		return xpath_common;
	}
	
	/**
	 * @param KeyColumnName
	 * @param KeyColumnValue
	 * @Description: Verifies if the value of Related List Column is 
	 * @return
	 * @throws Exception
	 */
	public boolean VerifyValueEquals(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //System.out.println("RelatedList:"+RelatedList);
		  //System.out.println("TargetColumnName:"+TargetColumnName);
		  //System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  //System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    		if(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(TargetColumnValue.trim()))
 		    		{
 		    			System.out.println("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+RelatedList+") related list.");
 		    			AddLogToCustomReport("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+RelatedList+") related list.", "Pass");
 		    			return true;
 		    		}
 		    		else
 		    		{
 		    			System.out.println("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")");
 		    			AddLogToCustomReport("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")", "Fail");
 		    			return false;
 		    		}
 		    	}
 		  }
		  
		  System.out.println("Could not find any matching value out of ("+i+") related list item for Related List "+RelatedList);
		  AddLogToCustomReport("Could not find any matching value out of ("+i+") related list item for Related List "+RelatedList, "Fail");
		  return false;
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+TargetColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+TargetColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
	
	}

	
	
	public boolean VerifyValueContains(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //System.out.println("RelatedList:"+RelatedList);
		  //System.out.println("TargetColumnName:"+TargetColumnName);
		  //System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  //System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    		if(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().contains(TargetColumnValue.trim()))
 		    		{
 		    			System.out.println("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+RelatedList+") related list.");
 		    			AddLogToCustomReport("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+RelatedList+") related list.", "Pass");
 		    			return true;
 		    		}
 		    		else
 		    		{
 		    			System.out.println("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")");
 		    			AddLogToCustomReport("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")", "Fail");
 		    			return false;
 		    		}
 		    	}
 		  }
		  
		  System.out.println("Could not find any matching value out of ("+i+") related list item for Related List "+RelatedList);
		  AddLogToCustomReport("Could not find any matching value out of ("+i+") related list item for Related List "+RelatedList, "Fail");
		  return false;
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+TargetColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+TargetColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
	
	}

	public boolean VerifyValueDoesNotContain(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //System.out.println("RelatedList:"+RelatedList);
		  //System.out.println("TargetColumnName:"+TargetColumnName);
		  //System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  //System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    		if(!remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().contains(TargetColumnValue.trim()))
 		    		{
 		    			System.out.println("Successfully verified that ("+TargetColumnName+") does not contain ("+TargetColumnValue+") in ("+RelatedList+") related list.");
 		    			AddLogToCustomReport("Successfully verified that ("+TargetColumnName+") does not contain ("+TargetColumnValue+") in ("+RelatedList+") related list.", "Pass");
 		    			return true;
 		    		}
 		    		else
 		    		{
 		    			System.out.println("Related List field verification failed on ("+TargetColumnName+") when does not contain ("+TargetColumnValue+") in ("+RelatedList+") related list.");
 		    			AddLogToCustomReport("Related List field verification failed on ("+TargetColumnName+") when does not contain ("+TargetColumnValue+") in ("+RelatedList+") related list.", "Fail");
 		    			return false;
 		    		}
 		    	}
 		  }
		  
		  System.out.println("Related List field verification failed on ("+TargetColumnName+") when does not contain ("+TargetColumnValue+") in ("+RelatedList+") related list.");
		  AddLogToCustomReport("Related List field verification failed on ("+TargetColumnName+") when does not contain ("+TargetColumnValue+") in ("+RelatedList+") related list.", "Fail");
		  return false;
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+TargetColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+TargetColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
	
	}
	public boolean VerifyCheckBoxValueEquals(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  //WaitForPageToLoad(30);
	
		  
		  System.out.println(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th");
		  System.out.println(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th");
		  System.out.println(xpath_common+"/descendant::tbody[1]/descendant::tr");
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  System.out.println("RelatedList:"+RelatedList);
		  System.out.println("TargetColumnName:"+TargetColumnName);
		  System.out.println("TargetColumnValue:"+TargetColumnValue);
		  System.out.println("KeyColumnName:"+KeyColumnName);
		  System.out.println("KeyColumnValue:"+KeyColumnValue);
		  
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  System.out.println("column_index_target_column:"+column_index_target_column);
		  System.out.println("total_no_of_row:"+total_no_of_row);
		 
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant::img[normalize-space(@alt)][1]")).getAttribute("alt").toString().trim().equalsIgnoreCase("True"));
 		    		if(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant::img[normalize-space(@alt)][1]")).getAttribute("alt").toString().trim().equalsIgnoreCase(TargetColumnValue))
 		    		{
 		    			System.out.println("Successfully verified the checkbox value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+RelatedList+") related list.");
 		    			AddLogToCustomReport("Successfully verified the checkbox value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+RelatedList+") related list.", "Pass");
 		    			return true;
 		    		}
 		    		else
 		    		{
 		    			System.out.println("Related List checkbox Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")");
 		    			AddLogToCustomReport("Related List checkbox Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")", "Fail");
 		    			return false;
 		    		}
 		    	}
 		  }
		  
		  System.out.println("Could not find any matching value out of ("+i+") related list item for Related List "+RelatedList);
		  AddLogToCustomReport("Could not find any matching value out of ("+i+") related list item for Related List "+RelatedList, "Fail");
		  return false;
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+TargetColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+TargetColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
	
	}
	
	public String GetValue(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  
		  System.out.println("RelatedList:"+RelatedList);
		  System.out.println("TargetColumnName:"+TargetColumnName);
		  System.out.println("TargetColumnValue:"+TargetColumnValue);
		  System.out.println("KeyColumnName:"+KeyColumnName);
		  System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  System.out.println("total_no_of_columns:"+column_index_key_columnNvalue);
		  System.out.println("column_index_key_columnNvalue:"+column_index_target_column);
		  System.out.println("column_index_target_column:"+total_no_of_row);
		  
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    		Value = remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim();
 		    		System.out.println("Successfully read the value under ("+TargetColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")");
 		    		AddLogToCustomReport("Successfully read the value under ("+TargetColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")", "Pass");
 		    		return Value;
 		    	}
 		  }
		  
		  System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
		  AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
		  return "";
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
			AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
			return "";			
		}
	
	}

	public boolean Click(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //System.out.println("RelatedList:"+RelatedList);
		  //System.out.println("TargetColumnName:"+TargetColumnName);
		  //System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  //System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    		Value = remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim();
 		    		remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).click();
 		    		
 		    		System.out.println("Successfully clicked the value under ("+TargetColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")");
 		    		AddLogToCustomReport("Successfully clicked the value under ("+TargetColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")", "Pass");
 		    		return true;
 		    	}
 		  }
		  
		  System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
		  AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
		  return false;
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
			AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
			return false;			
		}
	
	}
	

	public boolean Click(int RowIndex) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+RelatedList+"' and normalize-space(text())='"+RelatedList+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //System.out.println("RelatedList:"+RelatedList);
		  //System.out.println("TargetColumnName:"+TargetColumnName);
		  //System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  //System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  //remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+RowIndex+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).click();
		  remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+RowIndex+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).click();
		  System.out.println(xpath_common+"/descendant::tbody[1]/tr["+RowIndex+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]");
 		  System.out.println("Successfully clicked the value under ("+TargetColumnName+") on Related List Item ("+RowIndex+")");
 		  AddLogToCustomReport("Successfully clicked the value under ("+TargetColumnName+") on Related List Item ("+RowIndex+")", "Pass");
 		  return true;  
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find any element when click by index under column ("+TargetColumnName); 
			AddLogToCustomReport("Unable to find any element when click by index under column ("+TargetColumnName, "Fail");
			return false;			
		}
	
	}
	
	public boolean WaitForElement(String xpath, long waitingTimeinsec) throws Exception
    {
         try {
        	 	        		
        	remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
     		List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
     		if (myDynamicElement.size() > 0)
     		{
     			System.out.println("Success: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return true;
     		}
     		else
     		{
     			System.out.println("Unsuccess: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return false;
     		} 
        }
         catch(NoSuchElementException e)
         {
        	 e.printStackTrace();
             System.out.println("Exception inside WaitForElement:"+xpath);
             return false;
         }
     }
	
	public boolean Click() throws Exception
	{
		
		if(TargetColumnName.trim().equalsIgnoreCase("RelatedListLink"))
		{
	  try{
		  String xp = "(//h2[contains(@class,'header-title')]/descendant-or-self::*[text()='"+RelatedList+"'][@title])[1]";
		  WaitForElement(xp, 20);
		  System.out.println("xpath is:"+xp);
		  
		  ScrollToElement(remoteDriver.findElement(By.xpath(xp)));
		  Thread.sleep(2000L);
		  ClickWebElementByJS(remoteDriver.findElement(By.xpath(xp)));
		  //remoteDriver.findElement(By.xpath(xp)).click();
 		  
		  System.out.println("Successfully clicked on ("+RelatedList+") Related List hyperlink");
 		  AddLogToCustomReport("Successfully clicked on ("+RelatedList+") Related List hyperlink", "Pass");
 		  return true;  
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on related list ("+RelatedList+")"); 
			AddLogToCustomReport("Unable to click on related list ("+RelatedList+")", "Fail");
			return false;			
		}
		}
		else if(TargetColumnName.trim().contains("Button"))
		{
			 String ButtonName = "";
			 try{
				 ButtonName = TargetColumnName.trim().substring(0,TargetColumnName.trim().indexOf("Button"));
				 
				  System.out.println("ButtonName:"+ButtonName);
				  WaitForElement("//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::li[contains(@class,'slds-button')]/descendant::a[1]/descendant::div[@title=normalize-space(text())][text()='"+ButtonName+"'][1]", 20);
				  remoteDriver.findElement(By.xpath("//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::li[contains(@class,'slds-button')]/descendant::a[1]/descendant::div[@title=normalize-space(text())][text()='"+ButtonName+"'][1]")).click();
		 		  System.out.println("Successfully clicked on ("+ButtonName+") button under Related List("+RelatedList+").");
		 		  AddLogToCustomReport("Successfully clicked on ("+ButtonName+") button under Related List("+RelatedList+").", "Pass");
		 		  return true;  
				  
				}
				catch(Exception e)
				{
					e.printStackTrace();
					System.out.println("Unable to click on ("+ButtonName+") button under related list ("+RelatedList+")"); 
					AddLogToCustomReport("Unable to click on ("+ButtonName+") button under related list ("+RelatedList+")", "Fail");
					return false;			
				}
		}
		else
		{
			System.out.println("Click() method call is not for this element."); 
			AddLogToCustomReport("Click() method call is not for this element.", "Fail");
			return false;
		}
	}
	
	
	public int GetNumberOfRelatedListItem() throws Exception
	{
		int no_of_rl_item = 0;
	
		if(TargetColumnName.trim().equals("RelatedListItem"))
		{
			try{
		  
				no_of_rl_item = Integer.parseInt(remoteDriver.findElement(By.xpath("//header[contains(@class,'flexi-truncate')]/descendant::h2[@id]/descendant::a[contains(@class,'header-link')][1]/descendant-or-self::*[normalize-space(text())='"+RelatedList+"'][1]/following-sibling::*[1][text()]")).getText().trim().replace("(", "").replace(")", "").trim());
				System.out.println("Read the total number of related list item ("+no_of_rl_item+") from ("+RelatedList+") Related List ");
				AddLogToCustomReport("Read the total number of related list item ("+no_of_rl_item+") from ("+RelatedList+") Related List ", "Pass");
				return no_of_rl_item;  
		  
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to read the count of realted list item against ("+RelatedList+")"); 
				AddLogToCustomReport("Unable to read the count of realted list item against ("+RelatedList+")", "Fail");
				return 0;			
			}
		}
		System.out.println("GetNumberOfRelatedListItem() method call is not for this element."); 
		AddLogToCustomReport("GetNumberOfRelatedListItem() method call is not for this element.", "Fail");
		return 0;
		
	}
	
	
	public boolean MenuButtonClick(String ButtonName) throws Exception
	{
	  try{
		 
		  //Please note target column is becoming KeyColumn Here and targetcolumn value is becoming keycolumn value
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  System.out.println("RelatedList:"+RelatedList);
		  System.out.println("TargetColumnName:"+TargetColumnName);
		  System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
		   
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  System.out.println("total_no_of_row:"+total_no_of_row);
		 
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(TargetColumnValue.trim()))
 		    	{
 		    		remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th'][last()]/descendant::a[contains(@class,'button') and contains(@class,'Action')][1]")).click();
 		    		Thread.sleep(2000L);
 		    		remoteDriver.findElement(By.xpath("//div[contains(@class,'actionMenu') and contains(@class,'uiMenuList--default visible')]/descendant::a[normalize-space(@title)='"+ButtonName+"' and normalize-space(@role)='menuitem'][1]")).click();
 		    		System.out.println("Clicked on ("+ButtonName+") menu button when ("+TargetColumnName+") is ("+TargetColumnValue+").");
 		    		AddLogToCustomReport("Clicked on ("+ButtonName+") menu button when ("+TargetColumnName+") is ("+TargetColumnValue+").", "Pass");
 		    		return true;
 		    	}
 		    	
 		  }
		  System.out.println("Unable to find any matching record when ("+TargetColumnName+") is ("+TargetColumnValue+") while clicking on menu button.");
		  AddLogToCustomReport("Unable to find any matching record when ("+TargetColumnName+") is ("+TargetColumnValue+") while clicking on menu button.", "Pass");
		  return false;
	  }
	  catch(Exception e)
	  {
		e.printStackTrace();
		System.out.println("Unable to find any matching record when ("+TargetColumnName+") is ("+TargetColumnValue+") while clicking on menu button.");
		AddLogToCustomReport("Unable to find any matching record when ("+TargetColumnName+") is ("+TargetColumnValue+") while clicking on menu button.", "Pass");
		return false;
	  }
	
	}
	
	/**
	 * @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param timeOutInSeconds
	 * @return void
	 * @throws Exception
	 * @Description Waits for the page to reach ready state 
	 * @Date Aug 7, 2014
	 */
	public void WaitForPageToLoad(int timeOutInSeconds) throws Exception
	{ 
		
		String command = "return document.readyState"; 

		try
		{
		for (int i=0; i<timeOutInSeconds; i++)
		{ 
			try
			{
				Thread.sleep(1000L);
			}
			catch (InterruptedException e)
			{
				System.out.println("Unable to load the webpage");				
				
			} 
			
			if (remoteDriver.executeScript(command).toString().equals("complete"))
			{ 
				//System.out.println("Inside WaitForPageToLoad(Success)");
				break; 
			} 
			
			
		} 
		}catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	/**
	 * @param elmnt
	 * @param waitingTimeinsec
	 * @return
	 * @throws Exception
	 */
	public boolean WaitForElement(WebElement elmnt, long waitingTimeinsec) throws Exception
    {
         try {
        	 	        		
        	remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
     		
     		if (elmnt.isDisplayed())
     		{
     			System.out.println("WaitForElement:Success:"+elmnt.toString());
     			return true;
     		}
     		else
     		{
     			System.out.println("Unsuccess: WaitForElement: Failure:"+elmnt.toString());
     			return false;
     		} 
        }
         catch(NoSuchElementException e)
         {
        	 e.printStackTrace();
             System.out.println("Exception inside WaitForElement:"+xpath);
             return false;
         }
     }
	
	/**
	 * @param element
	 * @Description Scroll vertically/ horizontally to make the element visible on the screen. 
	 * @throws Exception
	 */
	public void ScrollToElement(WebElement element) throws Exception
	{
		
		try
		{
			
			WaitForElement(element, 30);
			
			((JavascriptExecutor)remoteDriver).executeScript("arguments[0].scrollIntoView();", element);
			
			//Coordinates coordinate = ((Locatable) element).getCoordinates();
			//Point cord = element.getLocation();
			//cord.getY();
			//- 300;
			//Locatable
						
			//Point coordinates = element.getLocation();
			
			//Robot robot = new Robot();
			//robot.mouseWheel(1);
			
			
			
			//coordinate.onPage();
			//coordinate.onScreen();
			//coordinate.inViewPort();
					
			System.out.println("Successfully scrolled untill element.");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to scroll until elemnt");
		}
	}
	
	
	/**
	 * @author Sourav Mukherjee
	 * @Param WebElement
	 * @return void
	 * @throws Exception
	 * @Description Clicks on the WebElement by using JavaScript
	 * @Date Aug 7, 2014
	 */
	public void ClickWebElementByJS(WebElement weElement) 
	{
		try {
			
		JavascriptExecutor executor = (JavascriptExecutor)remoteDriver;
		executor.executeScript("arguments[0].click();", weElement);
		}
		catch(Exception e)
		{e.printStackTrace();}
		
	}


	

}
