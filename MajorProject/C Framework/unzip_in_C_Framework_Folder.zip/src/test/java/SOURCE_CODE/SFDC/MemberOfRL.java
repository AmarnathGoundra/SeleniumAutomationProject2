
package SOURCE_CODE.SFDC;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class MemberOfRL extends PageBase{

	String RelatedList,Value,ColumnName;
	Integer RowIndex;
	
	
	String xpath;
	List<WebElement> allposblefieldelements;
	WebElement getsingleWebelement;
	
	public MemberOfRL(RemoteWebDriver remoteDriver) {
		super(remoteDriver);	
	}
	
	public MemberOfRL(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}
	
	
	/**
	 * @author Sourav
	 * @return boolean
	 * @throws Exception
	 * @Description Clicks on the hyperlink present against the selected column name from repository and row index of the related list item  
	 */
	public boolean Click() throws Exception
	{
		System.out.println("RelatesList:-->"+RelatedList);
		xpath = "//*[text()='"+RelatedList+"'][local-name()='h3'][1]/ancestor-or-self::div[contains(@class,'Header')]/following-sibling::div[1]/descendant::tr[1]";
		try
		{
		getsingleWebelement = getElement(xpath);
		String xpath_TargetColumnPosition = xpath + "/descendant::*[(local-name()='th' or local-name()='td') and (text()='"+ColumnName+"')]/preceding-sibling::*[local-name()='th' or local-name()='td']";
	    Integer TargetColumnPosition = remoteDriver.findElements(By.xpath(xpath_TargetColumnPosition)).size() + 1;

	    Value = remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).getText().trim();
	    remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).click();
   		 
   		System.out.println("Successfully clicked on the value ("+Value+") under the column ("+ColumnName+") in related list ("+RelatedList+")");
   		AddLogToCustomReport("Successfully clicked on the value ("+Value+") under the column ("+ColumnName+") in related list ("+RelatedList+")", "Pass");
   		System.out.println("ColumnName:"+ColumnName+";Value:"+Value+";RelatedList:"+RelatedList);
   		return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on the element under the column ("+ColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to click on the element under the column ("+ColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
	}
	
	/**
	 * @author Sourav
	 * @param ExpectedValue
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies the related list value against the selected column from repository and selected rowindex of the related list item
	 */
	public boolean VerifyValue(String ExpectedValue) throws Exception
	{
		xpath = "//*[normalize-space(text())='"+RelatedList+"'][local-name()='h3'][1]/ancestor-or-self::div[contains(normalize-space(@class),'Header')]/following-sibling::div[1]/descendant::tr[1]";
		try
		{
			getsingleWebelement = getElement(xpath);
		String xpath_TargetColumnPosition = xpath + "/descendant::*[(local-name()='th' or local-name()='td') and (normalize-space(text())='"+ColumnName+"')]/preceding-sibling::*[local-name()='th' or local-name()='td']";
	    Integer TargetColumnPosition = remoteDriver.findElements(By.xpath(xpath_TargetColumnPosition)).size() + 1;
   		//remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).click();
   		if (RowIndex == -1)
   		{
   			Integer CountOfRLItems =  remoteDriver.findElements(By.xpath(xpath+"/following-sibling::tr")).size();
   			
   		    for(int i=1;i<=CountOfRLItems;i++)
   		    {
   		    	if (remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+i+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).getText().trim().contains(ExpectedValue.trim()))
   		    	{
   		    		System.out.println("Successfully verified the value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.");
   		    		AddLogToCustomReport("Successfully verified the value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.", "Pass");
   		    		return true;
   		    	}
   		    }
   		    System.out.println("Could not find the value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.");
    		AddLogToCustomReport("Could not find the value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.", "Fail");
    		return false;

   		}
   		else
   		{
   			Value = remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).getText().trim(); 
   			if (Value.equals(ExpectedValue.trim()))
   	   		{
   	   			System.out.println("Successfully Verified the value ("+Value+") under the column ("+ColumnName+") in related list ("+RelatedList+")");
   	   			AddLogToCustomReport("Successfully verified the value ("+Value+") under the column ("+ColumnName+") in related list ("+RelatedList+")", "Pass");
   	   			return true;
   	   		}
   	   		else
   	   		{
   	   			System.out.println("Actual Value("+Value+") and Expected Value("+ExpectedValue+") does not match under the column ("+ColumnName+") in related list.");
   	   			AddLogToCustomReport("Actual Value("+Value+") and Expected Value("+ExpectedValue+") does not match under the column ("+ColumnName+") in related list.", "Fail");
   	   			return false;
   	   		}
   		}
   		
	    
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+ColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+ColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
	
	}
	/**
	 * @author Sourav
	 * @param CheckedORNotChecked
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies if the checkbox value is Checked or Not Checked as per supplied parameter under the selected Related List and Columns from repository 
	 */
	public boolean VerifyCheckBoxValue(String CheckedORNotChecked) throws Exception
	{
		xpath = "//*[normalize-space(text())='"+RelatedList+"'][local-name()='h3'][1]/ancestor-or-self::div[contains(normalize-space(@class),'Header')]/following-sibling::div[1]/descendant::tr[1]";
		try
		{
			getsingleWebelement = getElement(xpath);
		String xpath_TargetColumnPosition = xpath + "/descendant::*[(local-name()='th' or local-name()='td') and (normalize-space(text())='"+ColumnName+"')]/preceding-sibling::*[local-name()='th' or local-name()='td']";
	    Integer TargetColumnPosition = remoteDriver.findElements(By.xpath(xpath_TargetColumnPosition)).size() + 1;
   		//remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).click();
   		Value = remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::img[normalize-space(@alt) != '']")).getAttribute("alt").trim(); 
   		if (CheckedORNotChecked.contains("Not") || CheckedORNotChecked.contains("not")) 
   		{
   			CheckedORNotChecked = "Not Checked";
   		}
   		if (Value.contains("Not") || Value.contains("not")) 
   		{
   			Value = "Not Checked";
   		}
   		if (Value.equalsIgnoreCase(CheckedORNotChecked.trim()))
   		{
   			System.out.println("Successfully Verified the value ("+Value+") under the column ("+ColumnName+") in related list ("+RelatedList+")");
   			AddLogToCustomReport("Successfully verified the value ("+Value+") under the column ("+ColumnName+") in related list ("+RelatedList+")", "Pass");
   			return true;
   		}
   		else
   		{
   			System.out.println("Actual Value("+Value+") and Expected Value("+CheckedORNotChecked+") does not match under the column ("+ColumnName+") in related list.");
   			AddLogToCustomReport("Actual Value("+Value+") and Expected Value("+CheckedORNotChecked+") does not match under the column ("+ColumnName+") in related list.", "Fail");
   			return false;
   		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+ColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+ColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
	
	}

	/**
	 * @author Sourav
	 * @param ExpectedValue
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies the displayed value under the selected column of a selected related list from repository is as per supplied parameter "ExpectedValue".
	 */
	public boolean VerifyValueContains(String ExpectedValue) throws Exception
	{
		xpath = "//*[normalize-space(text())='"+RelatedList+"'][local-name()='h3'][1]/ancestor-or-self::div[contains(normalize-space(@class),'Header')]/following-sibling::div[1]/descendant::tr[1]";
		try
		{
			getsingleWebelement = getElement(xpath);
		String xpath_TargetColumnPosition = xpath + "/descendant::*[(local-name()='th' or local-name()='td') and (normalize-space(text())='"+ColumnName+"')]/preceding-sibling::*[local-name()='th' or local-name()='td']";
	    Integer TargetColumnPosition = remoteDriver.findElements(By.xpath(xpath_TargetColumnPosition)).size() + 1;
   		//remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).click();
	    if (RowIndex == -1)
   		{
   			Integer CountOfRLItems =  remoteDriver.findElements(By.xpath(xpath+"/following-sibling::tr")).size();
   			
   		    for(int i=1;i<=CountOfRLItems;i++)
   		    {
   		    	if (remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+i+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).getText().trim().contains(ExpectedValue.trim()))
   		    	{
   		    		System.out.println("Successfully verified the value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.");
   		    		AddLogToCustomReport("Successfully verified the value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.", "Pass");
   		    		return true;
   		    	}
   		    }
   		    System.out.println("Could not find the value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.");
    		AddLogToCustomReport("Could not find the value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.", "Fail");
    		return false;

   		}
	    else 
	    {
	    	Value = remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).getText().trim(); 
	    	if (Value.contains(ExpectedValue.trim()))
	    	{
	    		System.out.println("Successfully Verified the value ("+Value+") under the column ("+ColumnName+") in related list ("+RelatedList+")");
	    		AddLogToCustomReport("Successfully verified the value ("+Value+") under the column ("+ColumnName+") in related list ("+RelatedList+")", "Pass");
	    		return true;
	    	}
	    	else
	    	{
	    		System.out.println("Actual Value("+Value+") and Expected Value("+ExpectedValue+") does not match under the column ("+ColumnName+") in related list.");
	    		AddLogToCustomReport("Actual Value("+Value+") and Expected Value("+ExpectedValue+") does not match under the column ("+ColumnName+") in related list.", "Fail");
	    		return false;
	    	}
	    }
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+ColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+ColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
	
	}

	
	/**
	 * @author Sourav
	 * @param ExpectedValue
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies the absence of displayed value under the selected column of a selected related list from repository is as per supplied parameter "ExpectedValue".
	 */
	public boolean VerifyValueDoesNotContain(String ExpectedValue) throws Exception
	{
		xpath = "//*[normalize-space(text())='"+RelatedList+"'][local-name()='h3'][1]/ancestor-or-self::div[contains(normalize-space(@class),'Header')]/following-sibling::div[1]/descendant::tr[1]";
		try
		{
			getsingleWebelement = getElement(xpath);
		String xpath_TargetColumnPosition = xpath + "/descendant::*[(local-name()='th' or local-name()='td') and (normalize-space(text())='"+ColumnName+"')]/preceding-sibling::*[local-name()='th' or local-name()='td']";
	    Integer TargetColumnPosition = remoteDriver.findElements(By.xpath(xpath_TargetColumnPosition)).size() + 1;
   		//remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).click();
	    if (RowIndex == -1)
   		{
   			Integer CountOfRLItems =  remoteDriver.findElements(By.xpath(xpath+"/following-sibling::tr")).size();
   			
   		    for(int i=1;i<=CountOfRLItems;i++)
   		    {
   		    	if (remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+i+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).getText().trim().contains(ExpectedValue.trim()))
   		    	{
   		    		
   		    		System.out.println("The column ("+ColumnName+") under ("+RelatedList+") related list contains the value ("+ExpectedValue+") when not expected.");
   		    		AddLogToCustomReport("The column ("+ColumnName+") under ("+RelatedList+") related list contains the value ("+ExpectedValue+") when not expected.", "Fail");
   		    		return false;
   		    	}
   		    }
   		    System.out.println("Successfully verified the absence of value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.");
    		AddLogToCustomReport("Successfully verified the absence of value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.", "Pass");
    		return true;

   		}
	    else 
	    {
	    	Value = remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).getText().trim(); 
	    	if (Value.contains(ExpectedValue.trim()))
	    	{
	    		System.out.println("The column ("+ColumnName+") under ("+RelatedList+") related list contains the value ("+ExpectedValue+") when not expected.");
		    	AddLogToCustomReport("The column ("+ColumnName+") under ("+RelatedList+") related list contains the value ("+ExpectedValue+") when not expected.", "Fail");
		    	return false;
	    	}
	    	else
	    	{
	    		System.out.println("Successfully verified the absence of value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.");
	    		AddLogToCustomReport("Successfully verified the absence of value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.", "Pass");
	    		return true;
	    	}
	    }
		}
		catch(Exception e)
		{
			e.printStackTrace();
    		System.out.println("Successfully verified the absence of value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.");
    		AddLogToCustomReport("Successfully verified the absence of value ("+ExpectedValue+") under the column ("+ColumnName+") in ("+RelatedList+") related list.", "Pass");
    		return true;
			
		}
	
	}

	/**
	 * @author Sourav
	 * @return On Success, Returns the value displayed under the selected column of a selected related list from repository. On Failure it returns blank value.  
	 * @throws Exception
	 * @Description Reads the value displayed under the selected column of a selected related list from repository and returns the same on success. And returns blank value on failure
	 */
	public String GetValue() throws Exception
	{
		xpath = "//*[normalize-space(text())='"+RelatedList+"'][local-name()='h3'][1]/ancestor-or-self::div[contains(@class,'Header')]/following-sibling::div[1]/descendant::tr[1]";
		try
		{
			getsingleWebelement = getElement(xpath);
		Value = "";
		String xpath_TargetColumnPosition = xpath + "/descendant::*[(local-name()='th' or local-name()='td') and (text()='"+ColumnName+"')]/preceding-sibling::*[local-name()='th' or local-name()='td']";
	    Integer TargetColumnPosition = remoteDriver.findElements(By.xpath(xpath_TargetColumnPosition)).size() + 1;
   		//remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).click();
   		Value = remoteDriver.findElement(By.xpath(xpath+"/following-sibling::tr["+RowIndex+"]/descendant::*[local-name()='td' or local-name()='th']["+TargetColumnPosition+"]/descendant-or-self::*[text()]")).getText().trim(); 
 
   		System.out.println("Successfully read the value ("+Value+") under the column ("+ColumnName+") in related list ("+RelatedList+")");
   		AddLogToCustomReport("Successfully read the value ("+Value+") under the column ("+ColumnName+") in related list ("+RelatedList+")", "Pass");
   		return Value;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to read value under the column ("+ColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to read value under the column ("+ColumnName+") in related list ("+RelatedList+") when xpath is:"+xpath, "Fail");
			return "";
			
		}
	
	}
	public void AddLogToCustomReport(String Message,String Result) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new MPException("Failure from custom exception");
		}
	}
	
	
	
}
