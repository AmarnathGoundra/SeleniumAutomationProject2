package SOURCE_CODE.SFDC;

import io.appium.java_client.AppiumDriver;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;


/**
 * @author Cognizant
 *
 */
/**
 * @author Cognizant
 *
 */
public class CustomMemberOfField_LUI extends PageBase{

	String fieldname;
	//WebDriver remoteDriver;
	//SFDCAutomationFW autoFW;
	String xpath;
	List<WebElement> allposblefieldelements;
	WebElement getsingleWebelement;


	public CustomMemberOfField_LUI(RemoteWebDriver remoteDriver) {
		super(remoteDriver);	

	}

	public CustomMemberOfField_LUI(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}

	/**
	 * @param Value
	 * @Description Types supplied value of Text(input) Field/ Test Area/ Date Field. This cannot be used to type in Salesforce Lookup 
	 * @returns True on successful typing else returns false
	 * @PageLayout Edit Page and Inline Edit page layout
	 * @throws Exception
	 */
	public boolean Type(String Value) throws Exception
	{
		try{
			WaitForPageToLoad(60);
			String updatedfieldname= " "+fieldname;

			//			xpath="//div[contains(@class,'section-expandable ng-isolate-scope expanded')]/ancestor-or-self::div[1]/descendant::div/descendant::div/descendant::div/descendant::div/descendant::*[(local-name()='div' or local-name()='div')]/descendant::label[normalize-space(text()='"+fieldname+"')]/../following-sibling::*[1]/descendant-or-self::input[1]";

			if(!fieldname.equals("Project Manager User ID")){
				xpath="//div[contains(@class,'section-expandable ng-isolate-scope expanded')]/ancestor-or-self::div[1]/descendant::div/descendant::div/descendant::div/descendant::div/descendant::*[(local-name()='div' or local-name()='div')]/descendant::label[text()='"+fieldname+"']/../following-sibling::*[1]/descendant-or-self::input[1]";
			}else{
				xpath="//div[contains(@class,'section-expandable ng-isolate-scope expanded')]/ancestor-or-self::div[1]/descendant::div/descendant::div/descendant::div/descendant::div/descendant::*[(local-name()='div' or local-name()='div')]/descendant::label[text()='"+fieldname+"' or text()='"+updatedfieldname+"']/../following-sibling::*[1]/descendant-or-self::input[1]";
			}

			getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
			getsingleWebelement.clear();
			getsingleWebelement.sendKeys(Value);

			AddLogToCustomReport("Entered the value ("+Value+") in the field ("+fieldname+").", "Pass");
			System.out.println("Entered the value ("+Value+") in the field ("+fieldname+").");
			return true;

		}catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Unable to enter the value ("+Value+") in the field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
			System.out.println("Unable to enter the value ("+Value+") in the field ("+fieldname+") when xpath is ("+xpath+")");
			return false;
		}

	}
	public boolean SelectFromLookup(String LookUpValue) throws Exception
	{

		String common_xpath = ""; 
		try
		{
			xpath = "//label[normalize-space(text())='"+fieldname+"'][1]/ancestor::div[1]/following-sibling::div[1]/descendant::a[1]";
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			remoteDriver.findElement(By.xpath(xpath)).click();
			Thread.sleep(2000L);


			//use below xpath

			//label[normalize-space(text())='Basket Stage'][1]/ancestor::div[1]/following-sibling::div[1]/descendant::a[1]
			//div[contains(@class,'select') and contains(@style,'display') and contains(@style,'block')][1]/descendant::div[contains(@class,'select') and contains(@role,'option')][normalize-space(text())='Draft'][1]

			xpath = "//div[contains(@class,'select') and contains(@style,'display') and contains(@style,'block')][1]/descendant::input[contains(@class,'select') and contains(@role,'combobox')][1]";		
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			remoteDriver.findElement(By.xpath(xpath)).sendKeys(LookUpValue);
			Thread.sleep(6000);

			//			xpath = common_xpath + "ancestor::label[1]/following-sibling::div[1]/descendant::div[contains(@class,'searchButton') and contains(@class,'lookup')]/descendant::span[contains(@class,'itemLabel') and contains(@title,'"+LookUpValue+"')][1]";
			//			xpath = "//div[contains(@class,'select') and contains(@style,'display') and contains(@style,'block')][1]/descendant::div[contains(@class,'select') and contains(@role,'option')][normalize-space(text())='"+LookUpValue+"'][1]";
			//div[contains(@class,'select') and contains(@style,'display') and contains(@style,'block')][1]/descendant::ul[contains(@class,'select') and contains(@role,'listbox')]/li/div/descendant::span[normalize-space(text()='"+LookUpValue+"')][1]";
			xpath = "//div[contains(@class,'select') and contains(@style,'display') and contains(@style,'block')][1]/descendant::ul[contains(@class,'select') and contains(@role,'listbox')]/li/div/descendant::span[normalize-space(text()='"+LookUpValue+"')][1]";
			System.out.println("xpath of exact match:"+xpath);  

			JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
			js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));

			//remoteDriver.findElement(By.xpath(xpath)).click();
			Thread.sleep(6000);
			//			xpath = "//div[contains(@class,'select') and contains(@style,'display') and contains(@style,'block')][1]/descendant::div[contains(@class,'select') and contains(@role,'option')][normalize-space(text())='"+LookUpValue+"'][1]";
			xpath = "//div[contains(@class,'select') and contains(@style,'display') and contains(@style,'block')][1]/descendant::ul[contains(@class,'select') and contains(@role,'listbox')]/li/div/descendant::span[normalize-space(text()='"+LookUpValue+"')][1]";
			//			xpath ="//div[contains(@class,'select') and contains(@style,'display') and contains(@style,'block')][1]/descendant::ul[contains(@class,'select') and contains(@role,'listbox')]/descendant::span[normalize-space(text()='"+LookUpValue+"')][1]";
			remoteDriver.findElement(By.xpath(xpath)).click();

			System.out.println("Selected the value ("+LookUpValue+") from lookup field ("+fieldname+")");
			AddLogToCustomReport("Selected the value ("+LookUpValue+") from lookup field ("+fieldname+")", "Pass");
			return true;               
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find the value from lookup "+fieldname+" when xpath is: "+xpath);
			AddLogToCustomReport("Unable to find the value from lookup "+fieldname+" when xpath is: "+xpath,"Fail");
			return false;

		}

	}
	public boolean RemoveFromLookup() throws Exception
	{
		try{

			//			xpath ="//div[contains(@class,'section-expandable ng-isolate-scope expanded')]/ancestor-or-self::div[1]/descendant::div/descendant::div/descendant::div/descendant::div/descendant::*[(local-name()='div' or local-name()='div')]/descendant::label[text()='"+fieldname+"']/../following-sibling::*[1]/descendant-or-self::div/a/descendant::abbr[contains(@class,'close')][1]";
			//			xpath ="//label[normalize-space(text())='"+fieldname+"'][1]/ancestor::div[1]/following-sibling::div[1]/descendant::a[1]/descendant::abbr";
			xpath ="//label[normalize-space(text())='Basket Stage'][1]/ancestor::div[1]/following-sibling::div[1]/descendant::a[1]/descendant::abbr[contains(@class,'close')]";

			JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
			js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));

			AddLogToCustomReport("Successfully deleted the existing lookup value.", "Pass");
			System.out.println("Successfully deleted the existing lookup value.");
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to remore the existing value from lookup field "+fieldname+" when xpath is: "+xpath);
			AddLogToCustomReport("Unable to remore the existing value from lookup field "+fieldname+" when xpath is: "+xpath,"Fail");
			return false;
		}
	}

	/**
	 * @author Cognizant
	 * @param YesORNo
	 * @Description Verify if a field label is present in the View Details page
	 * @return
	 * @throws Exception
	 */
	public boolean IsDisplayed(String YesORNo) throws Exception
	{
		xpath = "//*[normalize-space(text())='"+fieldname+"']";

		//System.out.println();

		if (YesORNo.equalsIgnoreCase("Yes"))
		{
			try
			{
				if((remoteDriver.findElement(By.xpath(xpath)).isDisplayed()))
				{
					System.out.println("Successfully verified the existence of the field ("+fieldname+").");
					AddLogToCustomReport("Successfully verified the existence of the field ("+fieldname+").", "Pass");
					return true;  
				}
				else
				{
					System.out.println("Could not find the field ("+fieldname+") in the application.");
					AddLogToCustomReport("Could not find the field ("+fieldname+") in the application.", "Fail");
					return false;
				}
			}catch(Exception e)
			{
				System.out.println("Could not find the field ("+fieldname+") in the application when xpath is:"+xpath);
				AddLogToCustomReport("Could not find the field ("+fieldname+") in the application when xpath is:"+xpath, "Fail");
				e.printStackTrace();
				return false;
			}
		}
		else if (YesORNo.equalsIgnoreCase("No"))
		{
			try
			{
				if((remoteDriver.findElement(By.xpath(xpath)).isDisplayed()))
				{
					System.out.println("The field ("+fieldname+") is present in the UI when it is not expected to be.");
					AddLogToCustomReport("The field ("+fieldname+") is present in the UI when it is not expected to be.", "Fail");
					return false;
				}
				else
				{
					System.out.println("Successfully verified that the field ("+fieldname+") is not present in the UI.");
					AddLogToCustomReport("Successfully verified that the field ("+fieldname+") is not present in the UI.", "Pass");
					return true;
				}
			}catch(Exception e2)
			{
				System.out.println("Successfully verified that the field ("+fieldname+") is not present in the UI.");
				AddLogToCustomReport("Successfully verified that the field ("+fieldname+") is not present in the UI.", "Pass");
				return true;
			}
		}
		else
		{
			System.out.println("The input parameter supplied in IsDisplayed() function is not correct. It should be either Yes or No");
			AddLogToCustomReport("The input parameter supplied in IsDisplayed() function is not correct. It should be either Yes or No", "Fail");
			return false;
		}
	}

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit Page
	 * @Description Checks the checkbox field in Edit page 
	 * @return boolean
	 * @throws Exception

	 */
	public boolean CheckBoxSelect() throws Exception
	{
		try
		{
			xpath ="//div[contains(@class,'section-expandable ng-isolate-scope expanded')]/ancestor-or-self::div[1]/descendant::div/descendant::div/descendant::div/descendant::div/descendant::*[(local-name()='div' or local-name()='div')]/descendant::label[text()='"+fieldname+"']/../following-sibling::*[1]/button";

			if((!remoteDriver.findElement(By.xpath(xpath)).getAttribute("class").equals("btn btn-checkbox checked")))
			{
				remoteDriver.findElement(By.xpath(xpath)).click();
				System.out.println("Successfully checked the checkbox for the field ("+fieldname+")");
				AddLogToCustomReport("Successfully checked the checkbox for the field ("+fieldname+")", "Pass");
				return true;
			}
			else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("class").equals("btn btn-checkbox checked"))))
			{
				System.out.println("The Checkbox for the field ("+fieldname+") is already checked.");
				AddLogToCustomReport("The Checkbox for the field ("+fieldname+") is already checked.", "Pass");
				return true;
			}
			else
			{
				System.out.println("Unable to check the check box for field ("+fieldname+")");
				AddLogToCustomReport("Unable to check the check box for field ("+fieldname+"). Please verify the property value", "Fail");
				return false;
			}	

		}
		catch(Exception e)
		{
			System.out.println("Unable to find the element when xpath is: "+xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"+xpath,"Fail");
			return false;
		}
	}

	public WebElement WebDriverWaitForElement(String xpath, long waitingTimeinsec) throws Exception
	{
		WebElement element=null;
		try {
			WebDriverWait wait = new WebDriverWait(remoteDriver, Duration.ofSeconds(waitingTimeinsec));
			element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
			return element;
		}
		catch(NoSuchElementException e)
		{
			e.printStackTrace();
			System.out.println("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec");
			AddLogToCustomReport("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec", "Fail");
			return element;
		}
	}
	/* @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {

			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new MPException("Failure from custom exception");
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new MPException("Failure from custom exception");
		}
	}

	public void WaitForPageToLoad(int timeOutInSeconds) throws Exception
	{ 
		String command = "return document.readyState"; 
		try
		{
			for (int i=0; i<timeOutInSeconds; i++)
			{ 
				try
				{
					Thread.sleep(1000L);
				}
				catch (InterruptedException e)
				{
					System.out.println("Unable to load the webpage");				

				} 

				if (remoteDriver.executeScript(command).toString().equals("complete"))
				{ 
					//System.out.println("Inside WaitForPageToLoad(Success)");
					break; 
				} 
			} 
		}catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	/**
	 * @param element
	 * @Description Scroll vertically/ horizontally to make the element visible on the screen. 
	 * @throws Exception
	 */
	public void ScrollToElement(WebElement element) throws Exception
	{

		try
		{
			((JavascriptExecutor)remoteDriver).executeScript("arguments[0].scrollIntoView();", element);

			//Coordinates coordinate = ((Locatable) element).getCoordinates();
			//Point cord = element.getLocation();
			//cord.getY();
			//- 300;
			//Locatable

			//Point coordinates = element.getLocation();

			//Robot robot = new Robot();
			//robot.mouseWheel(1);



			//coordinate.onPage();
			//coordinate.onScreen();
			//coordinate.inViewPort();

			System.out.println("Successfully scrolled untill element.");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to scroll until elemnt");
		}
	}

}
