package SOURCE_CODE.SFDC;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class MemberOfTab extends PageBase {

	public String TabName;
	public WebElement tab;
	public String xpath;

	public MemberOfTab(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
	}

	public MemberOfTab(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}

	public String generateXpath(String TabName) {
        xpath = "//a[contains(@title,'Tab - Selected') or contains(@title,'Tab')][normalize-space(text())='"+TabName+"'][1]";
        return xpath;
 }


	/**
	 * @author Sangeetha
	 * @Param 
	 * @return boolean
	 * @throws Exception
	 * @Description Clicks on the Tab Name displayed on SFDC menu 
	 * @Date Sep 27, 2018
	 */
	public void Click() throws Exception {
        try {
               if(remoteDriver.findElements(By.xpath(xpath)).size() == 1)
               {
                     remoteDriver.findElement(By.xpath(xpath)).click();  
               }
               else
               {
                     //Click on All Tabs
                     remoteDriver.findElement(By.xpath("(//img[@title='All Tabs']/parent::a)[1]")).click();
                     xpath = "//img[@alt=@title][@title='"+TabName+"'][1]";
                     WaitForElement(xpath, 30);
                     remoteDriver.findElement(By.xpath(xpath)).click();
               }
               AddLogToCustomReport("Selected the Tab ("+TabName+") successfully.", "Pass");
               System.out.println("Selected the Tab ("+TabName+") successfully.");
        } catch (Exception e) {
               AddLogToCustomReport("Unable to click on tab ("+TabName+").", "Fail");
               System.out.println("Unable to click on tab ("+TabName+").");
               
               e.printStackTrace();
        }
 }


	/**
	 * @author Sourav Mukherjee
	 * @Param 
	 * @return true if tab name displayed return false if Tab Name is not displayed 
	 * @throws Exception
	 * @Description Verified if a TabName is displayed
	 * @Date Aug 7, 2014
	 */
	public boolean IsDisplayed() throws Exception
	{
		try
		{
			if(isElementDisplayed(xpath))
			{
				System.out.println("The tab ("+TabName+") is displayed.");
				AddLogToCustomReport("The tab ("+TabName+") is displayed.", "Pass");
				return true;

			}
			else
			{
				System.out.println("Unable to find tab ("+TabName+") when xpath is :"+xpath);
				AddLogToCustomReport("Unable to find tab ("+TabName+") when xpath is :"+xpath, "Fail");
				return false;
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find tab ("+TabName+") when xpath is :"+xpath);
			AddLogToCustomReport("Unable to find tab ("+TabName+") when xpath is :"+xpath, "Fail");
			return false;

		}
	}
	/**
	 * @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}
	}
	
	public boolean WaitForElement(String xpath, long waitingTimeinsec) throws Exception
	{
		try {
			//Uncomment WaitForPageLoad() function call when executing the scripts in IE
			//Otherwise comment out

			//WaitForPageToLoad(30);
			/*if (remoteDriver.toString().contains("InternetExplorerDriver"))
        	 	{
        	 		if (WebDriverWaitForElement(xpath,waitingTimeinsec)!=null)	
        	 		{
        	 			return true;
        	 		}
        	 		else
        	 		{
        	 			return false;
        	 		}
        	 	}
        	 	else
        	 	{

        	 	remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
        		List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
        		if (myDynamicElement.size() > 0)
        		{
        			//System.out.println("Inside WaitForElement(Success):"+myDynamicElement.size());
        			return true;
        		}
        		else
        		{
        			return false;
        		} 
        	 	}*/

			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
			List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
			if (myDynamicElement.size() > 0)
			{
				System.out.println("Success: WaitForElement->Number of Element present is: "+myDynamicElement.size());
				return true;
			}
			else
			{
				System.out.println("Unsuccess: WaitForElement->Number of Element present is: "+myDynamicElement.size());
				return false;
			} 
		}
		catch(NoSuchElementException e)
		{
			e.printStackTrace();
			System.out.println("Exception inside WaitForElement:"+xpath);
			return false;
		}
	}
}
