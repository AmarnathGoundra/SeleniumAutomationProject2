package SOURCE_CODE.SFDC;

public class HOME {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		String xl_path = System.getProperty("user.dir")+"\\TestDataStore\\FAV\\";
		System.out.println("------>"+xl_path); 
		new GUIFORFRAMEWORK();
	}
}
