package SOURCE_CODE.SFDC;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Invoke_FAV_ComparisonPythonScript {

	Invoke_FAV_ComparisonPythonScript()
	{
		try {
			
			String path_testdatastore = System.getProperty("user.dir")+"\\TestDataStore\\FAV";
			String path_python_script = System.getProperty("user.dir")+"\\src\\test\\java\\SOURCE_CODE\\SFDC\\FAV_Comparison.py";
			System.out.println("path_testdatastore:"+path_testdatastore);
			ProcessBuilder builder= new ProcessBuilder("python",path_python_script,path_testdatastore,"Affiliation");
			Process process = builder.start();
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			BufferedReader readers = new BufferedReader(new InputStreamReader(process.getErrorStream()));
					
			
			String lines=null;
			
			while((lines=reader.readLine())!=null)
			{
				System.out.println("lines: "+lines);
			}
			
			while((lines=readers.readLine())!=null)
			{
				System.out.println("lines: "+lines);
			}
			}
			catch(Exception e) {
				e.printStackTrace();
			}

	}
	
	
	
	
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		new Invoke_FAV_ComparisonPythonScript();
//	}
	
	

}
