package SOURCE_CODE.SFDC;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class MemberOfSEC extends PageBase {

	public String SectionName, FieldName;
	Integer RowIndex;
	
	public String xpath;
	public WebElement getsingleWebelement;
	public List<WebElement> allposblefieldelements;
	

	public MemberOfSEC(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
				
	}
	
	public MemberOfSEC(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param Yes or No
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies if the selected section from repository is present
	 *              in the UI as per supplied parameter
	 * @Date Aug 7, 2014
	 */
	public boolean IsDisplayed(String YesORNo) throws Exception {
		// xpath =
		// "((//*[text()='"+fieldname+"'])[1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1])/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::*[(local-name()='input' or local-name()='textarea') and @type !='hidden']";
		xpath = "//*[text()='" + SectionName + "'][local-name()='h3'][1]";
		
		// System.out.println("getText():"+myWD.findElement(By.xpath(xpath)).isDisplayed());
		try {
				getsingleWebelement = getElement(xpath);
			
			
				if (YesORNo.equalsIgnoreCase("Yes")) {
					if (getAttributeValue(getsingleWebelement, "tagName").toString().trim()
							.equalsIgnoreCase("h3")) {
						System.out
								.println("The section ("
										+ SectionName
										+ ") is displayed as expected in the application.");
						AddLogToCustomReport(
								"The section ("
										+ SectionName
										+ ") is displayed as expected in the application.",
								"Pass");
						return true;
					} else {
						System.out.println("The section (" + SectionName
								+ ") is not displayed in the application.");
						AddLogToCustomReport("The section (" + SectionName
								+ ") is not displayed in the application.",
								"Fail");
						return false;
					}
				}

				if (YesORNo.equalsIgnoreCase("No")) {
					// System.out.println("tagnameis:"+myWD.findElement(By.xpath(xpath)).getTagName());
					System.out.println();
					if (!getAttributeValue(getsingleWebelement, "tagName").toString().trim()
							.equalsIgnoreCase("h3")){
						System.out
								.println("The section ("
										+ SectionName
										+ ") is not displayed as expected in the application.");
						AddLogToCustomReport(
								"The section ("
										+ SectionName
										+ ") is not displayed as expected in the application.",
								"Pass");
						return true;
					} else {
						System.out
								.println("The section ("
										+ SectionName
										+ ") is displayed in the application which is not expected.");
						AddLogToCustomReport(
								"The section ("
										+ SectionName
										+ ") is displayed in the application which is not expected.",
								"Fail");
						return false;
					}
				
			
			
		}
				return false;
		}catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * @author Sourav Mukherjee
	 * @Param Yes or No
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies if the selected field inside the selected section
	 *              from repository is displayed in the UI as per supplied
	 *              parameter
	 * @Date Aug 7, 2014
	 */
	public boolean IsFieldDisplayed(String YesORNo) throws Exception {

		xpath = "//*[text()='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
				+ FieldName + "')][1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				if (YesORNo.equalsIgnoreCase("Yes")) {
					System.out.println("The field (" + FieldName
							+ ") is visible under the section (" + SectionName
							+ ") as expected");
					AddLogToCustomReport("The field (" + FieldName
							+ ") is visible under the section (" + SectionName
							+ ") as expected", "Pass");
					return true;
				} else if (YesORNo.equalsIgnoreCase("No")) {
					System.out.println("The field (" + FieldName
							+ ") is visible under the section (" + SectionName
							+ ") when it is not expected to be visible.");
					AddLogToCustomReport("The field (" + FieldName
							+ ") is visible under the section (" + SectionName
							+ ") when it is not expected to be visible.",
							"Fail");
					return false;
				} else {
					System.out
							.println("Please verify the input parameter for function IsFieldDisplayed()");
					AddLogToCustomReport(
							"Please verify the input parameter for function IsFieldDisplayed()",
							"Fail");
					return false;
				}

			} else {
				if (YesORNo.equalsIgnoreCase("No")) {
					System.out.println("The field (" + FieldName
							+ ") is not visible under the section ("
							+ SectionName + ") as expected.");
					AddLogToCustomReport("The field (" + FieldName
							+ ") is not visible under the section ("
							+ SectionName + ") as expected.", "Pass");
					return true;
				} else if (YesORNo.equalsIgnoreCase("Yes")) {
					System.out.println("The field (" + FieldName
							+ ") is not visible under the section ("
							+ SectionName
							+ ") when it is expected to be visible.");
					AddLogToCustomReport("The field (" + FieldName
							+ ") is not visible under the section ("
							+ SectionName
							+ ") when it is expected to be visible.", "Fail");
					return false;
				} else {
					System.out
							.println("Please verify the input parameter for function IsFieldDisplayed()");
					AddLogToCustomReport(
							"Please verify the input parameter for function IsFieldDisplayed()",
							"Fail");
					return false;
				}

			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * @author Sourav Mukherjee
	 * @Param Expected value in the field in View Page
	 * @return boolean
	 * @DisplayMode Viewonly
	 * @throws Exception
	 * @Description Verifies if the supplied value of selected field inside
	 *              selected section is displayed as per supplied parameter
	 *              "Value"
	 * @Date Aug 7, 2014
	 */
	public boolean VerifyViewOnlyValueEquals(String Value) throws Exception {
		
		xpath = "(//*[starts-with(local-name(),'h')  and normalize-space(text())='"+SectionName+"'])[1]/ancestor::div[contains(@class,'pbHeader')][1]/following-sibling::div[contains(@class,'pbBody')][1]/descendant-or-self::*[contains(text(),'"+FieldName+"')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant::*[text()][1]";
		getsingleWebelement = getElement(xpath);
		try {
			if (getsingleWebelement.isDisplayed()) {
				if (getText(getsingleWebelement).trim()
						.equals(Value)) {
					System.out.println("The value(" + Value
							+ ") has been verified successfully for the field("
							+ FieldName + ") inside the section ("
							+ SectionName + ")");
					AddLogToCustomReport("The value(" + Value
							+ ") has been verified successfully for the field("
							+ FieldName + ") inside the section ("
							+ SectionName + ")", "Pass");
					return true;
				} else {
					System.out.println("Could not find the value("
							+ Value
							+ ") for the field("
							+ FieldName
							+ ") inside section("
							+ SectionName
							+ "). Actual Value:"
							+ getText(getsingleWebelement).trim()
									.trim());
					AddLogToCustomReport(
							"Could not find the value("
									+ Value
									+ ") for the field("
									+ FieldName
									+ ") inside section("
									+ SectionName
									+ "). Actual Value:"
									+ getText(getsingleWebelement).trim().trim(), "Fail");
					return false;
				}
			} else {
				System.out
						.println("Could not find the element to verify viewonly value when xpath is: "
								+ xpath);
				AddLogToCustomReport(
						"Could not find the element to verify viewonly value when xpath is: "
								+ xpath, "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param
	 * @return Returns the value displayed against a field inside selected
	 *         section from repository
	 * @throws Exception
	 * @Description Reads the value displayed in a field inside a section and
	 *              returns the same on success, On failure it returns blank
	 *              value.
	 * @Date Aug 7, 2014
	 */
	public String GetViewOnlyValue() throws Exception {
		String Value = "";

		xpath = "(//*[starts-with(local-name(),'h')  and normalize-space(text())='"+SectionName+"'])[1]/ancestor::div[contains(@class,'pbHeader')][1]/following-sibling::div[contains(@class,'pbBody')][1]/descendant-or-self::*[contains(text(),'"+FieldName+"')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant::*[text()][1]";
		try {
			System.out.println("Xpath is:"+xpath);
			System.out.println("remoredriver in MemberOfSEC:"+remoteDriver);
			//getsingleWebelement = getElement(xpath);
			getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
			if (getsingleWebelement.isDisplayed()) {
				Value = getText(getsingleWebelement).trim();
				System.out.println("The value of field (" + FieldName
						+ ") is (" + Value + ")");
				AddLogToCustomReport("The value of field (" + FieldName
						+ ") is (" + Value + ")", "Pass");
				return Value;
			} else {
				System.out.println("Unable to read the value of field ("
						+ FieldName + ") when xpath is: " + xpath);
				AddLogToCustomReport("Unable to read the value of field ("
						+ FieldName + ") when xpath is: " + xpath, "Fail");
				return Value;
			}
		} catch (Exception e) {
			System.out.println("Unable to read the value of field ("
					+ FieldName + ") when xpath is: " + xpath);
			AddLogToCustomReport("Unable to read the value of field ("
					+ FieldName + ") when xpath is: " + xpath, "Fail");
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param Expected Value
	 * @return boolean
	 * @DisplayMode View Only
	 * @throws Exception
	 * @Description Verifies the field value inside a section contains supplied
	 *              value "Value"
	 * @Date Aug 7, 2014
	 */
	public boolean VerifyViewOnlyValueContains(String Value) throws Exception {
		xpath = "(//*[starts-with(local-name(),'h')  and normalize-space(text())='"+SectionName+"'])[1]/ancestor::div[contains(@class,'pbHeader')][1]/following-sibling::div[contains(@class,'pbBody')][1]/descendant-or-self::*[contains(text(),'"+FieldName+"')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant::*[text()][1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				if (getText(getsingleWebelement).trim()
						.contains(Value)) {
					System.out.println("The value(" + Value
							+ ") has been verified successfully for the field("
							+ FieldName + ")");
					AddLogToCustomReport("The value(" + Value
							+ ") has been verified successfully for the field("
							+ FieldName + ") inside the section ("
							+ SectionName + ")", "Pass");
					return true;
				} else {
					System.out.println("Could not find the value("
							+ Value
							+ ") for the field("
							+ FieldName
							+ "). Actual Value:"
							+ getText(getsingleWebelement)
									.trim());
					AddLogToCustomReport(
							"Could not find the value("
									+ Value
									+ ") for the field("
									+ FieldName
									+ "). Actual Value:"
									+ getText(getsingleWebelement).trim(), "Fail");
					return false;
				}
			} else {
				System.out
						.println("Could not find the element to verify viewonly value when xpath is: "
								+ xpath);
				AddLogToCustomReport(
						"Could not find the element to verify viewonly value when xpath is: "
								+ xpath, "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param Expected Value
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies the field value inside a section starts with
	 *              supplied value "Value"
	 * @Date Aug 7, 2014
	 */
	public boolean VerifyViewOnlyValueStartsWith(String Value) throws Exception {
		xpath = "(//*[starts-with(local-name(),'h')  and normalize-space(text())='"+SectionName+"'])[1]/ancestor::div[contains(@class,'pbHeader')][1]/following-sibling::div[contains(@class,'pbBody')][1]/descendant-or-self::*[contains(text(),'"+FieldName+"')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant::*[text()][1]";
		
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				if (getText(getsingleWebelement).trim()
						.startsWith(Value)) {
					System.out.println("The value(" + Value
							+ ") has been verified successfully for the field("
							+ FieldName + ")");
					AddLogToCustomReport("The value(" + Value
							+ ") has been verified successfully for the field("
							+ FieldName + ") inside the section ("
							+ SectionName + ")", "Pass");
					return true;
				} else {
					System.out.println("Could not find the value("
							+ Value
							+ ") for the field("
							+ FieldName
							+ "). Actual Value:"
							+ getText(getsingleWebelement)
									.trim());
					AddLogToCustomReport(
							"Could not find the value("
									+ Value
									+ ") for the field("
									+ FieldName
									+ "). Actual Value:"
									+ getText(getsingleWebelement).trim(), "Fail");
					return false;
				}
			} else {
				System.out
						.println("Could not find the element to verify viewonly value when xpath is: "
								+ xpath);
				AddLogToCustomReport(
						"Could not find the element to verify viewonly value when xpath is: "
								+ xpath, "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param Expected Value
	 * @DisplayMode View Only
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies the field value inside a section ends with supplied
	 *              value "Value"
	 * @Date Aug 7, 2014
	 */
	public boolean VerifyViewOnlyValueEndsWith(String Value) throws Exception {
		xpath = "(//*[starts-with(local-name(),'h')  and normalize-space(text())='"+SectionName+"'])[1]/ancestor::div[contains(@class,'pbHeader')][1]/following-sibling::div[contains(@class,'pbBody')][1]/descendant-or-self::*[contains(text(),'"+FieldName+"')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant::*[text()][1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				if (getText(getsingleWebelement).trim()
						.endsWith(Value)) {
					System.out.println("The value(" + Value
							+ ") has been verified successfully for the field("
							+ FieldName + ")");
					AddLogToCustomReport("The value(" + Value
							+ ") has been verified successfully for the field("
							+ FieldName + ") inside the section ("
							+ SectionName + ")", "Pass");
					return true;
				} else {
					System.out.println("Could not find the value("
							+ Value
							+ ") for the field("
							+ FieldName
							+ "). Actual Value:"
							+ getText(getsingleWebelement)
									.trim());
					AddLogToCustomReport(
							"Could not find the value("
									+ Value
									+ ") for the field("
									+ FieldName
									+ "). Actual Value:"
									+ getText(getsingleWebelement).trim(), "Fail");
					return false;
				}
			} else {
				System.out
						.println("Could not find the element to verify viewonly value when xpath is: "
								+ xpath);
				AddLogToCustomReport(
						"Could not find the element to verify viewonly value when xpath is: "
								+ xpath, "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param Expeceted Value
	 * @DisplayMode Edit Page
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies the field value inside a section is equal to the
	 *              supplied value "Value"
	 * @Date Aug 7, 2014
	 */
	public boolean VerifyEditFieldValue(String Value) throws Exception {
	xpath = "//*[starts-with(local-name(),'h') and text()='"+ SectionName	+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"+ FieldName	+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::*[(local-name()='input' or local-name()='textarea') and @type !='hidden']";
		// xpath="//*[text()='"+fieldname+"'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				
				if (getsingleWebelement.getAttribute("value").trim()
						.equals(Value.trim())) {
					System.out
							.println("Successfully verified the value for the field ("
									+ FieldName + ")");
					AddLogToCustomReport("The value(" + Value
							+ ") has been verified successfully for the field("
							+ FieldName + ") inside the section ("
							+ SectionName + ")", "Pass");
					return true;
				} else {
					System.out.println("Could not find the value (" + Value
							+ ") for the field (" + FieldName
							+ "). Actual value is ("
							+ getsingleWebelement.getAttribute("value").trim()
							+ ")");
					AddLogToCustomReport("Could not find the value (" + Value
							+ ") for the field (" + FieldName
							+ "). Actual value is ("
							+ getsingleWebelement.getAttribute("value").trim()
							+ ")", "Fail");
					return false;
				}
			} else {
				System.out
						.println("Could not find the element to verify viewonly value when xpath is: "
								+ xpath);
				AddLogToCustomReport(
						"Could not find the element to verify viewonly value when xpath is: "
								+ xpath, "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param
	 * @DisplayMode Edit Page
	 * @return Returns the field value displayed inside a section
	 * @throws Exception
	 * @Description Reads the field value inside a section and returns the same
	 *              on success, on failure it returns blank value
	 * @Date Aug 7, 2014
	 */
	public String GetEditFieldValue() throws Exception {
		String Value = "";
		xpath = "//*[starts-with(local-name(),'h') and text()='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
				+ FieldName
				+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::*[(local-name()='input' or local-name()='textarea') and @type !='hidden']";

		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				Value = getAttributeValue(getsingleWebelement, "value");
				System.out.println("The value for field (" + FieldName
						+ ") is (" + Value + ")");
				AddLogToCustomReport("The value for field (" + FieldName
						+ ") is (" + Value + ")", "Pass");
				return Value;
			} else {
				System.out.println("Unable to read the value for field ("
						+ FieldName + ") when xpath is: " + xpath);
				AddLogToCustomReport("Unable to read the value for field ("
						+ FieldName + ") when xpath is: " + xpath, "Fail");
				return Value;
			}
		} catch (Exception e) {
			System.out.println("Unable to read the value for field ("
					+ FieldName + ") when xpath is: " + xpath);
			AddLogToCustomReport("Unable to read the value for field ("
					+ FieldName + ") when xpath is: " + xpath, "Fail");
			return "";
		}
	}

	/*******************************************************************************************/
	// Following function verifies if the value of a check box in
	// checked/unchecked //
	// in view details page as well as Edit page //
	// //
	/*******************************************************************************************/
	/**
	 * @author Sourav Mukherjee
	 * @Param Checked/Not Checked
	 * @DisplayMode View Only/Edit Page
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies if the check box value inside a section is
	 *              displayed as per supplied parameter
	 * @Date Aug 7, 2014
	 */
	public boolean VerifyChkBoxValue(String CheckedORNotChecked)
			throws Exception {
		xpath = "//*[starts-with(local-name(),'h') and text()='"+ SectionName+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"+ FieldName+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::*[(local-name()='img' or local-name()='input')][1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				if (CheckedORNotChecked.equalsIgnoreCase("Checked")) {
					if ((getAttributeValue(getsingleWebelement, "title").equals(""))
							&& (getAttributeValue(getsingleWebelement, "checked") != null)
							&& (getAttributeValue(getsingleWebelement, "checked").equals("true"))) {
						System.out
								.println("Successfully verified the value as checked for the checkbox field ("
										+ FieldName + ")");
						AddLogToCustomReport(
								"Successfully verified the value as checked for the checkbox field ("
										+ FieldName + ")", "Pass");
						return true;
					} else if ((getAttributeValue(getsingleWebelement, "title").equals("Checked"))
							&& (getAttributeValue(getsingleWebelement, "checked") == null)) {
						System.out
								.println("Successfully verified the value as checked for the checkbox field ("
										+ FieldName + ")");
						AddLogToCustomReport(
								"Successfully verified the value as checked for the checkbox field ("
										+ FieldName + ")", "Pass");
						return true;
					} else {
						System.out
								.println("Could not find the value as checked for the checkbox field ("
										+ FieldName + ")");
						AddLogToCustomReport(
								"Could not find the value as checked for the checkbox field ("
										+ FieldName + ")", "Fail");
						return false;
					}
				}
				if (CheckedORNotChecked.equalsIgnoreCase("Not Checked")) {
					if ((getAttributeValue(getsingleWebelement, "title").equals("Not Checked"))
							&& (getAttributeValue(getsingleWebelement, "checked") == null)) {
						System.out
								.println("Successfully verified the value as unchecked for the checkbox field ("
										+ FieldName + ")");
						AddLogToCustomReport(
								"Successfully verified the value as unchecked for the checkbox field ("
										+ FieldName + ")", "Pass");
						return true;
					} else if ((getAttributeValue(getsingleWebelement, "title").equals(""))
							&& (getAttributeValue(getsingleWebelement, "checked") == null)) {
						System.out
								.println("Successfully verified the value as checked for the checkbox field ("
										+ FieldName + ")");
						AddLogToCustomReport(
								"Successfully verified the value as checked for the checkbox field ("
										+ FieldName + ")", "Pass");
						return true;
					} else {
						System.out
								.println("Could not find the value as unchecked for the checkbox field ("
										+ FieldName + ")");
						AddLogToCustomReport(
								"Could not find the value as unchecked for the checkbox field ("
										+ FieldName + ")", "Fail");
						return false;
					}

				} else {
					System.out
							.println("The input parameter value for the function VerifyChkBoxValue is not expected: "
									+ CheckedORNotChecked);
					AddLogToCustomReport(
							"The input parameter value for the function VerifyChkBoxValue is not expected: "
									+ CheckedORNotChecked, "Fail");
					return false;
				}
			} else {
				System.out
						.println("Unable to Verify checkbox value for the field("
								+ FieldName + ") when xpath is: " + xpath);
				AddLogToCustomReport(
						"Unable to Verify checkbox value for the field("
								+ FieldName + ") when xpath is: " + xpath,
						"Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * @author Sourav Mukherjee
	 * @Param
	 * @DisplayMode Edit Page
	 * @return boolean
	 * @throws Exception
	 * @Description Checks the checkbox of a field inside a section
	 * @Date Aug 7, 2014
	 */
	public boolean CheckBoxSelect() throws Exception {
		xpath = "//*[starts-with(local-name(),'h') and text()='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
				+ FieldName
				+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::*[(local-name()='img' or local-name()='input')][1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				if ((getAttributeValue(getsingleWebelement, "title")
						.equals("") || getAttributeValue(getsingleWebelement, "title").equals("Not Checked"))
						&& (getAttributeValue(getsingleWebelement, "checked") == null)) {
					click(getsingleWebelement, FieldName);
					System.out
							.println("Successfully checked the checkbox for the field ("
									+ FieldName + ")");
					AddLogToCustomReport(
							"Successfully checked the checkbox for the field ("
									+ FieldName + ")", "Pass");
					return true;
				} else if (((getAttributeValue(getsingleWebelement, "title").equals("Checked")) && (getAttributeValue(getsingleWebelement, "checked") == null))
						|| ((getAttributeValue(getsingleWebelement, "title").equals("")) && (getAttributeValue(getsingleWebelement, "checked") != null))) {
					System.out
							.println("Successfully checked the checkbox for the field ("
									+ FieldName + ")");
					AddLogToCustomReport(
							"Successfully checked the checkbox for the field ("
									+ FieldName + ")", "Pass");
					return true;
				} else {
					System.out
							.println("Unable to check the check box for field ("
									+ FieldName + ")");
					AddLogToCustomReport(
							"Unable to check the check box for field ("
									+ FieldName + ")", "Fail");
					return false;
				}
			} else {
				System.out.println("Unable to Select checkbox for the field("
						+ FieldName + ") when xpath is: " + xpath);
				AddLogToCustomReport("Unable to Select checkbox for the field("
						+ FieldName + ") when xpath is: " + xpath, "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param
	 * @DisplayMode Edit Page
	 * @return boolean
	 * @throws Exception
	 * @Description Unchecks the checkbox field inside a section
	 * @Date Aug 7, 2014
	 */
	public boolean CheckBoxDeSelect() throws Exception {
		xpath = "//*[ starts-with(local-name(),'h') and text()='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
				+ FieldName
				+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::*[(local-name()='img' or local-name()='input')][1]";

		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				if (((getAttributeValue(getsingleWebelement, "title")
						.equals("Checked")) && (getAttributeValue(getsingleWebelement, "checked") == null))
						|| ((getAttributeValue(getsingleWebelement, "title").equals("")) && (getAttributeValue(getsingleWebelement, "checked") != null))) {
					click(getsingleWebelement, FieldName);
					System.out
							.println("Successfully unchecked the checkbox for the field ("
									+ FieldName + ")");
					AddLogToCustomReport(
							"Successfully unchecked the checkbox for the field ("
									+ FieldName + ")", "Pass");
					return true;
				} else if ((getAttributeValue(getsingleWebelement, "title").equals("") || getAttributeValue(getsingleWebelement, "title")
						.equals("Not Checked"))
						&& (getAttributeValue(getsingleWebelement, "checked") == null)) {
					System.out
							.println("Successfully unchecked the checkbox for the field ("
									+ FieldName + ")");
					AddLogToCustomReport(
							"Successfully unchecked the checkbox for the field ("
									+ FieldName + ")", "Pass");
					return true;
				} else {
					System.out
							.println("Unable to uncheck the check box for field ("
									+ FieldName + ")");
					AddLogToCustomReport(
							"Unable to uncheck the check box for field ("
									+ FieldName + ")", "Fail");
					return false;
				}
			} else {
				System.out.println("Unable to DeSelect checkbox for the field("
						+ FieldName + ") when xpath is: " + xpath);
				AddLogToCustomReport("Unable to DeSelect checkbox for the field("
						+ FieldName + ") when xpath is: " + xpath, "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	

	/**
	 * @author Sourav Mukherjee
	 * @Param Value to be entered
	 * @return boolean
	 * @throws Exception
	 * @Description Enters the field(text box,text area) value inside a section.
	 * @Date Aug 7, 2014
	 */
	public boolean Type(String Value) throws Exception {

		xpath = "//*[ starts-with(local-name(),'h') and text()='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
				+ FieldName
				+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::*[(local-name()='input' or local-name()='textarea') and @type !='hidden']";

		// xpath="//*[text()='"+fieldname+"'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				getsingleWebelement.clear();
				getsingleWebelement.sendKeys(Value);
				System.out.println("Successfully entered the value (" + Value
						+ ") for the field (" + FieldName + ")");
				AddLogToCustomReport("Successfully entered the value (" + Value
						+ ") for the field (" + FieldName + ")", "Pass");
				return true;
			} else {
				System.out.println("Unable to enter the value(" + Value
						+ ") in the field(" + FieldName + ") when xpath is: "
						+ xpath);
				AddLogToCustomReport("Unable to enter the value(" + Value
						+ ") in the field(" + FieldName + ") when xpath is: "
						+ xpath, "Fail");
				return false;
			}

		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param Value to be selected from SFDC OOB lookup
	 * @DisplayMode Edit page
	 * @return boolean
	 * @throws Exception
	 * @Description Selects the value from SFDC OOB lookup field inside a
	 *              section. If the text box field is editable then it types the
	 *              value in that field then clicks on the lookup icon and
	 *              clicks on the hyperlink displayed in search lookup. In case
	 *              the text box field is read only then directly clicks on the
	 *              lookup icon and searches the expected value in the search
	 *              lookup window and clicks on hyperlink. It also set the focus
	 *              to parent window
	 * @Date Aug 7, 2014
	 */
	public boolean SelectFromLookup(String LookUpValue) throws Exception {

		String parentwindowtitle = "";
		xpath = "//*[ starts-with(local-name(),'h') and normalize-space(text())='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(normalize-space(text()),'"
				+ FieldName
				+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::span[contains(normalize-space(@class),'lookup')]/input[1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {

				
				parentwindowtitle = getPageTitle().trim();

				if (getsingleWebelement.getAttribute("readonly") == null) {

					getsingleWebelement.clear();
					getsingleWebelement.sendKeys(LookUpValue);
					xpath = "//*[text()='"
							+ SectionName
							+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
							+ FieldName
							+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::span[contains(normalize-space(@class),'lookup')]/descendant-or-self::img[contains(normalize-space(@alt),'New Window')]";
					getsingleWebelement = getElement(xpath);
					getsingleWebelement.click();
					Thread.sleep(2000L);

					SelectWindow("Search");
				} else if (getsingleWebelement.getAttribute("readonly")
						.equalsIgnoreCase("true")) {
					xpath = "//*[text()='"
							+ SectionName
							+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
							+ FieldName
							+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::span[contains(normalize-space(@class),'lookup')]/descendant-or-self::img[contains(normalize-space(@alt),'New Window')]";
					getsingleWebelement = getElement(xpath);
					getsingleWebelement.click();
					Thread.sleep(2000L);
					SelectWindow("Search");
					remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("//frame[contains((@title),'Search')]")));
					remoteDriver.findElement(By.xpath("//input[contains(normalize-space(@placeholder),'Search') and normalize-space(@type)='text']")).sendKeys(LookUpValue);
					Thread.sleep(1000L);
					remoteDriver.findElement(By.xpath("//input[contains(normalize-space(@placeholder),'Search') and normalize-space(@type)='text']")).sendKeys(Keys.ENTER);

				}

				Thread.sleep(3000L);
				SelectWindow("Search");
				remoteDriver.switchTo()
						.frame(remoteDriver.findElement(By
								.xpath("//frame[contains(normalize-space(@title),'Result')]")));
				if (remoteDriver.findElement(By.linkText(LookUpValue)).isDisplayed()) {
					remoteDriver.findElement(By.linkText(LookUpValue)).click();
					AddLogToCustomReport("Successfully picked the value ("
							+ LookUpValue + ") from lookup field (" + FieldName
							+ ")", "Pass");
					System.out.println("Successfully picked the value ("
							+ LookUpValue + ") from lookup field (" + FieldName
							+ ")");
					SelectWindow(parentwindowtitle);
					return true;
				} else {

					AddLogToCustomReport("Unable to find any such record ("
							+ LookUpValue + ") from the lookup field ("
							+ FieldName + ")", "Fail");
					System.out.println("Unable to find any such record ("
							+ LookUpValue + ") from the lookup field ("
							+ FieldName + ")");
					CloseWindow("Search");
					SelectWindow(parentwindowtitle);
					return false;
				}

			} else {

				AddLogToCustomReport("Unable to pick the supplied value("
						+ LookUpValue + ") from lookup field (" + FieldName
						+ ") when xpath is (" + xpath + ")", "Fail");
				System.out.println("Unable to pick the supplied value("
						+ LookUpValue + ") from lookup field (" + FieldName
						+ ") when xpath is (" + xpath + ")");
				CloseWindow("Search");
				SelectWindow(parentwindowtitle);
				return false;

			}
		} catch (Exception e) {

			AddLogToCustomReport("Unable to pick the supplied value("
					+ LookUpValue + ") from lookup field (" + FieldName
					+ ") when xpath is (" + xpath + ")", "Fail");
			System.out.println("Exception: Unable to pick the supplied value("
					+ LookUpValue + ") from lookup field (" + FieldName
					+ ") when xpath is (" + xpath + ")");
			e.printStackTrace();
			CloseWindow("Search");
			SelectWindow(parentwindowtitle);
			return false;
		}

		/*
		 * xpath = "//*[text()='"+SectionName+
		 * "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
		 * +FieldName+
		 * "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::span[contains(normalize-space(@class),'lookup')]/input[1]"
		 * ; try { if (autoFW.WaitForElement(xpath,10)) {
		 * 
		 * getsingleWebelement = myWD.findElement(By.xpath(xpath));
		 * getsingleWebelement.clear();
		 * getsingleWebelement.sendKeys(LookUpValue);
		 * //getsingleWebelement.sendKeys("QA_LEADS_APJ01"); xpath =
		 * "//*[text()='"+SectionName+
		 * "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
		 * +FieldName+
		 * "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::span[contains(normalize-space(@class),'lookup')]/descendant-or-self::img[contains(normalize-space(@alt),'New Window')]"
		 * ; getsingleWebelement = myWD.findElement(By.xpath(xpath));
		 * getsingleWebelement.click(); Thread.sleep(2000L);
		 * 
		 * autoFW.SelectWindow("Search"); Thread.sleep(1000L);
		 * 
		 * myWD.switchTo().frame(myWD.findElement(By.xpath(
		 * "//frame[contains((@title),'Result')]"))); if
		 * (myWD.findElement(By.linkText(LookUpValue)).isDisplayed()) {
		 * myWD.findElement(By.linkText(LookUpValue)).click();
		 * AddLogToCustomReport
		 * ("Successfully picked the value ("+LookUpValue+") from lookup field ("
		 * +FieldName+") under the section ("+SectionName+")", "Pass");
		 * System.out.println("Successfully picked the value ("+LookUpValue+
		 * ") from lookup field ("
		 * +FieldName+") under the section ("+SectionName+")"); return true; }
		 * else {
		 * 
		 * AddLogToCustomReport("Unable to find any such record ("+LookUpValue+
		 * ") from the lookup field ("
		 * +FieldName+") under the section ("+SectionName+")", "Fail");
		 * System.out.println("Unable to find any such record ("+LookUpValue+
		 * ") from the lookup field ("
		 * +FieldName+") under the section ("+SectionName+")");
		 * autoFW.CloseWindow("Search"); return false; }
		 * 
		 * 
		 * } else {
		 * 
		 * AddLogToCustomReport("Unable to pick the supplied value("+LookUpValue+
		 * ") from lookup field ("
		 * +FieldName+") under Section ("+SectionName+") when xpath is ("
		 * +xpath+")", "Fail");
		 * System.out.println("Unable to pick the supplied value("
		 * +LookUpValue+") from lookup field ("
		 * +FieldName+") under section ("+SectionName
		 * +") when xpath is ("+xpath+")"); autoFW.CloseWindow("Search"); return
		 * false;
		 * 
		 * } } catch(Exception e) {
		 * 
		 * AddLogToCustomReport("Exception: Unable to pick the supplied value("+
		 * LookUpValue
		 * +") from lookup field ("+FieldName+") under the section ("+
		 * SectionName+") when xpath is ("+xpath+")", "Fail");
		 * System.out.println
		 * ("Exception: Unable to pick the supplied value("+LookUpValue
		 * +") from lookup field ("
		 * +FieldName+") under the section ("+SectionName
		 * +") when xpath is ("+xpath+")"); e.printStackTrace();
		 * autoFW.CloseWindow("Search"); return false; }
		 */
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param Value to be selected from picklist/dropdown(Single Select List)
	 * @return boolean
	 * @throws Exception
	 * @Description Selects the picklist field value inside a section by its
	 *              display text as per supplied parameter
	 * @Date Aug 7, 2014
	 */
	public boolean SelectPL(String Value) throws Exception {
		// Working xpath =
		// "((//*[text()='"+fieldname+"'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='select']";
		xpath = "//*[ starts-with(local-name(),'h') and text()='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
				+ FieldName
				+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th'][1]/following-sibling::*[local-name()='td' or local-name()='th'][1]/descendant-or-self::*[local-name()='select']";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				// System.out.println("Inside SelectPL:");

				if (getsingleWebelement.getAttribute("type").trim()
						.equals("select-one")
						|| (getsingleWebelement.getTagName().trim()
								.equals("select"))) {
					Select s = new Select(getsingleWebelement);
					s.selectByVisibleText(Value);
					System.out
							.println("Successfully selected the picklist value ("
									+ Value + ") for field (" + FieldName + ")");
					AddLogToCustomReport(
							"Successfully selected the picklist value ("
									+ Value + ") for field (" + FieldName + ")",
							"Pass");
					return true;
				} else {
					System.out
							.println("Unable to select the picklist value when xpath is :"
									+ xpath);
					AddLogToCustomReport(
							"Unable to select the picklist value when xpath is :"
									+ xpath, "Fail");
					return false;
				}
				// System.out.println("TagName:"+getsingleWebelement.getTagName()+"|"+"class:"+getsingleWebelement.getAttribute("class")+"|"+"id:"+getsingleWebelement.getAttribute("id")+"|"+"type:"+getsingleWebelement.getAttribute("type")+"|"+"text:"+getsingleWebelement.getText()+"|");

			} else {
				System.out.println("Unable to select the pick list value("
						+ Value + ") for the field(" + FieldName
						+ ") when xpath is: " + xpath);
				AddLogToCustomReport("Unable to select the pick list value("
						+ Value + ") for the field(" + FieldName
						+ ") when xpath is: " + xpath, "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param Type the expected selected/defeult value in the picklist field
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies if the already selected pick list value/default
	 *              value for a field inside a section is equal to the supplied
	 *              parameter
	 * @Date Aug 7, 2014
	 */
	public boolean VerifyPLValue(String Value) throws Exception {

		xpath = "//*[ starts-with(local-name(),'h') and text()='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
				+ FieldName
				+ "')][1]/ancestor::td[1]/following-sibling::td[1]/descendant-or-self::*[local-name()='select']";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				// System.out.println("Inside SelectPL:");
				if (getsingleWebelement.getAttribute("type").trim()
						.equals("select-one")
						|| (getsingleWebelement.getTagName().trim()
								.equals("select"))) {
					Select s = new Select(getsingleWebelement);
					if (s.getFirstSelectedOption().getText().trim()
							.equals(Value)) {
						System.out
								.println("Successfully verified the selected value ("
										+ Value
										+ ") in the picklist field ("
										+ FieldName + ")");
						AddLogToCustomReport(
								"Successfully verified the selected value ("
										+ Value + ") in the picklist field ("
										+ FieldName + ")", "Pass");
						return true;
					} else {
						System.out.println("The value ("
								+ s.getFirstSelectedOption()
								+ ") displayed in the pick list field ("
								+ FieldName
								+ ") is not expected. Expected value is: ("
								+ Value + ")");
						AddLogToCustomReport(
								"The value ("
										+ s.getFirstSelectedOption()
										+ ") displayed in the pick list field ("
										+ FieldName
										+ ") is not expected. Expected value is: ("
										+ Value + ")", "Fail");
						return false;
					}
				} else {
					System.out
							.println("Unable to find the select element while verifying the pick list value for field ("
									+ FieldName + ")");
					AddLogToCustomReport(
							"Unable to find the select element while verifying the pick list value for field ("
									+ FieldName + ")", "Fail");
					return false;
				}
			} else {
				System.out.println("Unable to verify the pick list value("
						+ Value + ") for the field(" + FieldName
						+ ") when xpath is: " + xpath);
				AddLogToCustomReport("Unable to verify the pick list value("
						+ Value + ") for the field(" + FieldName
						+ ") when xpath is: " + xpath, "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @DisplayMode Edit Page
	 * @Param Semi colon(;) seperated value to be added in the multi select pick
	 *        list field
	 * @return boolean
	 * @throws Exception
	 * @Description Selects and Adds the multi select pick list field values
	 *              inside a section
	 * @Date Aug 7, 2014
	 */
	public boolean MultiSelectAdd(String Value) throws Exception {
		xpath = "//*[ starts-with(local-name(),'h') and text()='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
				+ FieldName
				+ "')][1]/ancestor::td[1]/following-sibling::td[1]/descendant-or-self::*[local-name()='optgroup'][1]/ancestor::select[1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				Select s = new Select(getsingleWebelement);

				System.out.println("Inside multiSelect Add:");

				List<String> eachPLValue = Arrays.asList(Value.split(";"));
				for (String str : eachPLValue) {
					s.selectByVisibleText(str);
					System.out.println("Multiselect pick list values are:"
							+ str.trim());
				}

				getsingleWebelement = remoteDriver
						.findElement(By
								.xpath("//*[starts-with(local-name(),'h') and text()='"
										+ SectionName
										+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
										+ FieldName
										+ "')][1]/ancestor::td[1]/following-sibling::td[1]/descendant-or-self::*[local-name()='img'][1]"));
				getsingleWebelement.click();
				System.out
						.println("Successfully added multiselect pick list values ("
								+ Value + ") for field (" + FieldName + ")");
				// System.out.println("TagName:"+getsingleWebelement.getTagName()+"|"+"class:"+getsingleWebelement.getAttribute("class")+"|"+"id:"+getsingleWebelement.getAttribute("id")+"|"+"type:"+getsingleWebelement.getAttribute("type")+"|"+"text:"+getsingleWebelement.getText()+"|");
				AddLogToCustomReport(
						"Successfully added multiselect pick list values ("
								+ Value + ") for field (" + FieldName + ")",
						"Pass");
				return true;
			} else {
				System.out.println("Unable to add pick list value(" + Value
						+ ") for the field(" + FieldName + ") when xpath is: "
						+ xpath);
				AddLogToCustomReport("Unable to add pick list value(" + Value
						+ ") for the field(" + FieldName + ") when xpath is: "
						+ xpath, "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @DisplayMode Edit Page
	 * @Param Semi colon(;) seperated value to be removed from the multi select
	 *        pick list field
	 * @return boolean
	 * @throws Exception
	 * @Description Selects and Removes the multi select pick list field values
	 *              inside a section
	 * @Date Aug 7, 2014
	 */
	public boolean MultiSelectRemove(String Value) throws Exception {
		xpath = "//*[starts-with(local-name(),'h') and text()='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
				+ FieldName
				+ "')][1]/ancestor::td[1]/following-sibling::td[1]/descendant-or-self::*[local-name()='optgroup'][2]/ancestor::select[1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {

				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				Select s = new Select(getsingleWebelement);

				// System.out.println("Inside multiSelect Remove:");

				List<String> eachPLValue = Arrays.asList(Value.split(";"));
				for (String str : eachPLValue) {
					s.selectByVisibleText(str);
					// System.out.println("Multiselect pick list values are:"+str.trim());
				}
				getsingleWebelement = remoteDriver
						.findElement(By
								.xpath("//*[starts-with(local-name(),'h') and text()='"
										+ SectionName
										+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
										+ FieldName
										+ "')][1]/ancestor::td[1]/following-sibling::td[1]/descendant-or-self::*[local-name()='img'][2]"));
				getsingleWebelement.click();
				System.out
						.println("Successfully removed multiselect pick list values ("
								+ Value + ") for field (" + FieldName + ")");
				// System.out.println("TagName:"+getsingleWebelement.getTagName()+"|"+"class:"+getsingleWebelement.getAttribute("class")+"|"+"id:"+getsingleWebelement.getAttribute("id")+"|"+"type:"+getsingleWebelement.getAttribute("type")+"|"+"text:"+getsingleWebelement.getText()+"|");
				AddLogToCustomReport(
						"Successfully removed multiselect pick list values ("
								+ Value + ") for field (" + FieldName + ")",
						"Pass");
				return true;
			} else {
				System.out.println("Unable to remove pick list value(" + Value
						+ ") for the field(" + FieldName + ") when xpath is: "
						+ xpath);
				AddLogToCustomReport("Unable to remove pick list value(" + Value
						+ ") for the field(" + FieldName + ") when xpath is: "
						+ xpath, "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @DisplayMode Edit Page
	 * @Param Semi Colon(;) seperated values expected to be displayed in the
	 *        available list of multi select pick list field inside a section
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies the list of values displayed in the Avaliable List
	 *              of a multi select pick list field inside a section are as
	 *              per supplied parameter
	 * @Date Aug 7, 2014
	 */
	public boolean VerifyMPLAvailable(String Value) throws Exception {
		xpath = "//*[starts-with(local-name(),'h') and text()='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
				+ FieldName
				+ "')][1]/ancestor::td[1]/following-sibling::td[1]/descendant-or-self::*[local-name()='optgroup'][1]/ancestor::select[1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				Select s = new Select(getsingleWebelement);
				List<WebElement> options = s.getOptions();
				List<String> avail = new ArrayList<String>();
				for (WebElement eachOption : options) {
					avail.add(eachOption.getText().trim());
					// System.out.println("eachOption: "+eachOption.getText().trim());

				}

				List<String> AllavailValues = Arrays.asList(Value.split(";"));
				String failedPLValue = "";
				for (String exp : AllavailValues) {
					if (!avail.contains(exp)) {
						if (failedPLValue != "") {
							failedPLValue = failedPLValue + ";" + exp;
						} else {
							failedPLValue = exp;
						}
					}

				}
				if (failedPLValue == "") {
					System.out
							.println("Successfully verified the Available List of Values from Multiselect picklist field ("
									+ FieldName + ")");
					AddLogToCustomReport(
							"Successfully verified the Available List of Values from Multiselect picklist field ("
									+ FieldName + ")", "Pass");
					return true;
				} else {
					System.out
							.println("Could not find multi select pick list values ("
									+ failedPLValue
									+ ") in the available list of field("
									+ FieldName + ").");
					AddLogToCustomReport(
							"Could not find multi select pick list values ("
									+ failedPLValue
									+ ") in the available list of field("
									+ FieldName + ").", "Fail");
					return false;
				}

			} else {
				System.out
						.println("Could not find the element for multiselect available when Verifying the available value in the field ("
								+ FieldName + ") ");
				AddLogToCustomReport(
						"Could not find the element for multiselect available when Verifying the available value in the field ("
								+ FieldName + ") ", "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * @author Sourav Mukherjee
	 * @DisplayMode Edit Page
	 * @Param Semi Colon(;) seperated values expected to be displayed in the
	 *        chosen list of multi select pick list field inside a section
	 * @return boolean
	 * @throws Exception
	 * @Description Verifies the list of values displayed in the Chosen List of
	 *              a multi select pick list field inside a section are as per
	 *              supplied parameter
	 * @Date Aug 7, 2014
	 */
	public boolean VerifyMPLChosen(String Value) throws Exception {
		xpath = "//*[starts-with(local-name(),'h') and text()='"
				+ SectionName
				+ "'][local-name()='h3'][1]/ancestor-or-self::div[1]/following-sibling::div[1]/descendant-or-self::*[contains(text(),'"
				+ FieldName
				+ "')][1]/ancestor::td[1]/following-sibling::td[1]/descendant-or-self::*[local-name()='optgroup'][2]/ancestor::select[1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (getsingleWebelement.isDisplayed()) {
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				Select s = new Select(getsingleWebelement);
				List<WebElement> options = s.getOptions();
				List<String> avail = new ArrayList<String>();

				for (WebElement eachOption : options) {
					avail.add(eachOption.getText().trim());
					// System.out.println("eachOption: "+eachOption.getText().trim());
				}

				List<String> AllavailValues = Arrays.asList(Value.split(";"));
				String failedPLValue = "";
				for (String exp : AllavailValues) {
					if (!avail.contains(exp)) {
						if (failedPLValue != "") {
							failedPLValue = failedPLValue + ";" + exp;
						} else {
							failedPLValue = exp;
						}
					}
				}

				if (failedPLValue == "") {
					System.out
							.println("Successfully verified the Chosen List of Values from Multiselect picklist field ("
									+ FieldName + ")");
					AddLogToCustomReport(
							"Successfully verified the Chosen List of Values from Multiselect picklist field ("
									+ FieldName + ")", "Pass");
					return true;
				} else {
					System.out
							.println("Could not find multi select pick list values ("
									+ failedPLValue
									+ ") in the Chosen list of field("
									+ FieldName + ").");
					AddLogToCustomReport(
							"Could not find multi select pick list values ("
									+ failedPLValue
									+ ") in the Chosen list of field("
									+ FieldName + ").", "Fail");
					return false;
				}
			} else {
				System.out
						.println("Could not find the element for multiselect Chosen when Verifying the Chosen values in the field ("
								+ FieldName + ") ");
				AddLogToCustomReport(
						"Could not find the element for multiselect Chosen when Verifying the Chosen values in the field ("
								+ FieldName + ") ", "Fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:"
					+ xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"
					+ xpath, "Fail");
			e.printStackTrace();
			return false;
		}
	}
	
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}
	}
	
	
	/**
	 * @author Sourav Mukherjee
	 * @Param UniqueStringinWindowTitle
	 * @return boolean
	 * @throws Exception
	 * @Description Selects the window opened by Selenium Webdriver.
	 * @Date Aug 7, 2014
	 */
	public boolean SelectWindow(String UniqueStringinWindowTitle) throws Exception
	{
		
		try
		{
			int c=0;
			String mainwindow = remoteDriver.getWindowHandle();   
			System.out.println("mainwindow:"+mainwindow);
			
			Set<String> s = remoteDriver.getWindowHandles(); 
	        Iterator<String> ite = s.iterator(); 
	        while(ite.hasNext()) 
	        { 
	            String popup = ite.next(); 
	            System.out.println("inside SelectWindow:"+popup);
	            if(!popup.equalsIgnoreCase(mainwindow))
	            { 
	            	remoteDriver.switchTo().window(popup); 
	                System.out.println("Window Title is: "+remoteDriver.getTitle());
	                if(remoteDriver.getWindowHandle().contains(popup))
	                {
	                	//mainwindow = null;
	                	//s=null;
	                	return true;
	                	
	                }
	                else
	                {
	                	c = c + 1;
	                }
	             }
	        }
	        if (c>0)
	        {
	        	
	        	return false;
	        }
	        else
	        {
	        	
	        	return true;
	        	
	        }
		/*	
		Set <String> handles = myWD.getWindowHandles();
		Iterator<String> it = handles.iterator();
		//iterate through your windows
		while (it.hasNext())
		{
			//String parent = it.next();
			String win = it.next();
			System.out.println("win:"+win);
			myWD.switchTo().window(win);
			if (myWD.getTitle().contains(UniqueStringinWindowTitle))
			{
				System.out.println("The title of the Selected window is:"+myWD.getTitle());
				return true;
			}
						
		}
		System.out.println("Could not find the window with title containing "+UniqueStringinWindowTitle);
		return false;
		*/
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Exception in SelectWindow Function while trying to select the window having title containing  "+UniqueStringinWindowTitle);
			return false;
		}
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param UniqueStringinWindowTitle
	 * @return boolean
	 * @throws Exception
	 * @Description Whenever you call this function CloseWindow(), You must call SelectWindow() function after this function call to continue working on the next window, otherwise the focus to the next workable window will be lost.  
	 * @Date Aug 7, 2014
	 */
	public boolean CloseWindow(String UniqueStringinWindowTitle) throws Exception
	{
		try
		{
			
			String AlreadySelectedWindow = remoteDriver.getWindowHandle();   
			System.out.println("AlreadySelectedWindow:"+AlreadySelectedWindow);
			
			Set<String> s = remoteDriver.getWindowHandles(); 
	        Iterator<String> ite = s.iterator(); 
	        while(ite.hasNext()) 
	        { 
	            String popup = ite.next(); 
	            System.out.println("inside closewindow:"+popup);
	            if(popup.equalsIgnoreCase(AlreadySelectedWindow))
	            { 
	            	remoteDriver.switchTo().window(popup).close(); 
	                return true;
	            }
	            
	        }
		System.out.println("Could not find the window with title containing "+UniqueStringinWindowTitle+" while trying to close.");
		return false;
		}catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Exception in CloseWindow Function while trying to close the window having title containing  "+UniqueStringinWindowTitle);
			return false;
		}
	}
	
}
