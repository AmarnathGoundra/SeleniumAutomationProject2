package SOURCE_CODE.SFDC;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

import org.openqa.selenium.JavascriptExecutor;

/**
 * @author Cognizant
 *
 */
public class CustomMemberOfButton_LUI extends PageBase {
	
	String ButtonName;
	WebElement button;
	//WebDriver remoteDriver;
	//SFDCAutomationFW autoFW;
	String xpath;
	String xp_common_vd = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]";
	String xp_common_in_ed_and_vd = "//div[contains(@class,'test-id__record-layout-container riseTransitionEnabled')][1]/following-sibling::div[contains(@class,'riseTransitionEnabled test-id__inline-edit-record-layout-container')][1]";
	String xp_common_in_ed = "//div[contains(@class,'test-id__record-layout-container riseTransitionEnabled')][1]/following-sibling::div[contains(@class,'riseTransitionEnabled test-id__inline-edit-record-layout-container')][1]";
	
	public CustomMemberOfButton_LUI(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
		
	}

	public CustomMemberOfButton_LUI(AppiumDriver appiumDriver) {
		super(appiumDriver);
		
	}
	
	public String generateXpath(String ButtonName) {
		xpath = "(//input[(@value=' " + ButtonName+
				" ' or normalize-space(@value)='" + ButtonName + 
				"' or @value='  " + ButtonName +
				"  ') and contains(normalize-space(@class),'btn')])[1]";
		return xpath;
	}
	

	/**
	 * @Author Sourav Mukherjee
	 * @Description Clicks on Salesforce OOB button
	 * @return boolean
	 * @throws Exception
	 */
	
	public boolean ClickByIndex(int Index) throws Exception
	{
		try{
			
			if(remoteDriver.getCurrentUrl().trim().contains("list") && !remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------LIST VIEW-----------");
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = "(//button[contains(@class,'slds-button')]/span[text()='"+ButtonName+"'])["+Index+"]";
				
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "(//button[contains(@class,'slds-button')]/span[text()='"+ButtonName+"'])["+Index+"]";								
				}			
				
			}
			
			if(remoteDriver.getCurrentUrl().trim().contains("rlName") && !remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------RELATED LIST VIEW-----------");
				xpath = "//div[contains(@class,'oneContent') and contains(@class,'active')]/descendant::li[contains(@class,'button')]/descendant::*[normalize-space(text())='"+ButtonName+"'][1]";
				//SFDCAutomationFW.WaitForElement(xpath, 30);
				
			}
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'footer')]/descendant::button/descendant-or-self::span[normalize-space(text())='"+ButtonName+"'][1]";
				//SFDCAutomationFW.WaitForElement(xpath, 30);
			}
			//SFDCAutomationFW.WaitForElement(xpath, 30);
			System.out.println("xpath:"+xpath);
			remoteDriver.findElement(By.xpath(xpath)).click();
			AddLogToCustomReport("Successfully clicked on button ("+ButtonName+").", "Pass");
			System.out.println("Successfully clicked on button ("+ButtonName+").");
			return true;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			return false;
			
		}
	}
	public boolean Click() throws Exception
	{
		try{
			System.out.println(remoteDriver.getCurrentUrl().trim());
			
			waitForPageLoad();
			Thread.sleep(3000L);
			
			xpath="//button[contains(@ng-class,'button.cssClass')][normalize-space(text())='"+ButtonName+"']";
					
			//SFDCAutomationFW.WaitForElement(xpath, 30);
			System.out.println("XPath-->"+xpath);
			waitForVisibilityOfElement(xpath);
			remoteDriver.findElement(By.xpath(xpath)).click();
			AddLogToCustomReport("Successfully clicked on button ("+ButtonName+").", "Pass");
			System.out.println("Successfully clicked on button ("+ButtonName+").");
			return true;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on the button ("+ButtonName+").Xpath:"+xpath);
			AddLogToCustomReport("Unable to click on the button ("+ButtonName+")", "Fail");
			return false;
		}
	
	}
	
	/**
	 * @param waitingTimeinSec
	 * @return boolean
	 * @throws Exception
	 * @Description Waits for specified time for the button to display in the UI
	 */
	public boolean WaitForElement(long waitingTimeinSec) throws Exception
	{
		 try {
			
			 if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath("(//div[normalize-space(@class)='forceInlineEdit'])[1]/div[1]")).getAttribute("class").toString().equalsIgnoreCase("active"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = "(//div[contains(@class,'footer') and contains(@class,'active')])[1]/descendant-or-self::button[normalize-space(@title)='"+ButtonName+"'][1]";
						        
					}
					
					else if(remoteDriver.findElement(By.xpath("(//div[normalize-space(@class)='forceInlineEdit'])[1]/div[1]")).getAttribute("class").toString().equalsIgnoreCase(""))
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = "//div[contains(@class,'oneContent') and contains(@class,'active')]/descendant::li[contains(@class,'button')]/descendant::*[normalize-space(text())='"+ButtonName+"'][1]";
																
					}
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'footer')]/descendant-or-self::button[normalize-space(@title)='"+ButtonName+"'][1]";
				}
			 
			 
			 
			 //Thread.sleep(2000L);
			 remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinSec));
			 System.out.println("Xpath inside WaitForElement:"+xpath);
             List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
             if (myDynamicElement.size() > 0)
             {
            	 AddLogToCustomReport("The button ("+ButtonName+") was available in the application.", "Pass");
            	 System.out.println("The button ("+ButtonName+") was available in the application.");
            	 return true;
             }
             else
             {
            	 AddLogToCustomReport("Could not find the button ("+ButtonName+") in the application.", "Fail");
            	 System.out.println("Could not find the button ("+ButtonName+") in the application.");
            	 return false;
             }
			 
             //System.out.println("The value of dynamic webelement is:"+myDynamicElement.isDisplayed());
             //return myDynamicElement.isDisplayed();
             }
         catch(NoSuchElementException e)
             {
             System.out.println("Could not find the element after waiting for specified time.");
             AddLogToCustomReport("Could not find the button ("+ButtonName+") in the application.", "Fail");
         	 e.printStackTrace();
             return false;
             //return false;
             }
	}
	/**
	 * @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new MPException("Failure from custom exception");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new MPException("Failure from custom exception");
		}
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param 1. xpath of the element. 2. Waiting Time in Second
	 * @return boolean
	 * @throws Exception
	 * @Description Waits for the specified time until the webelemnt is available to WebDriver
	 * @Date Aug 7, 2014
	 */
	public boolean WaitForElement(String xpath, long waitingTimeinsec) throws Exception
    {
         try {
        	 	//Uncomment WaitForPageLoad() function call when executing the scripts in IE
        	 	//Otherwise comment out
        	 	
        	 	//WaitForPageToLoad(30);
        	 	/*if (remoteDriver.toString().contains("InternetExplorerDriver"))
        	 	{
        	 		if (WebDriverWaitForElement(xpath,waitingTimeinsec)!=null)	
        	 		{
        	 			return true;
        	 		}
        	 		else
        	 		{
        	 			return false;
        	 		}
        	 	}
        	 	else
        	 	{
        		        		
        	 	remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
        		List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
        		if (myDynamicElement.size() > 0)
        		{
        			//System.out.println("Inside WaitForElement(Success):"+myDynamicElement.size());
        			return true;
        		}
        		else
        		{
        			return false;
        		} 
        	 	}*/
        		
        	remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
     		List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
     		if (myDynamicElement.size() > 0)
     		{
     			System.out.println("Success: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return true;
     		}
     		else
     		{
     			System.out.println("Unsuccess: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return false;
     		} 
        }
         catch(NoSuchElementException e)
         {
        	 e.printStackTrace();
             System.out.println("Exception inside WaitForElement:"+xpath);
             return false;
         }
     }
	
	/**
	 * @author Sourav Mukherjee
	 * @Param timeOutInSeconds
	 * @return void
	 * @throws Exception
	 * @Description Waits for the page to reach ready state 
	 * @Date Aug 7, 2014
	 */

}
