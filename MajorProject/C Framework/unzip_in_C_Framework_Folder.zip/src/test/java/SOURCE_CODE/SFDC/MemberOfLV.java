package SOURCE_CODE.SFDC;

import java.util.List;

import io.appium.java_client.AppiumDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

public class MemberOfLV extends PageBase {

	String Value,ColumnName;
	Integer RowIndex;

	//	String ObjectName,Value,TargetColumnName;
	//Integer RowIndex;
	//	String TargetColumnValue;
	//WebDriver remoteDriver;
	//SFDCAutomationFW autoFW;
	String xpath;
	List<WebElement> allposblefieldelements;
	WebElement getsingleWebelement;
	String xpath_common;

	public MemberOfLV(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
	}

	public MemberOfLV(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}
	/**
	 * @author Sangeetha
	 * @param KeyColumnName
	 * @param KeyColumnValue
	 * @Description: Verifies the value of Related List Column is equals 
	 * @return
	 * @throws Exception
	 */
	public boolean VerifyValueEquals(String KeyColumnName,String KeyColumnValue) throws Exception
	{
		try{

			int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::div[text()='"+KeyColumnName+"'][1]/ancestor::td[1]/preceding-sibling::td")).size() + 1;
			int total_no_of_row = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr")).size();

			int i;
			for(i=1;i<=total_no_of_row;i++){
				if(remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim().equals(KeyColumnValue.trim())){
					if(remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim().equals(KeyColumnValue.trim())){
						Value=remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim();
						System.out.println("Successfully verified the value under ("+KeyColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")");
						AddLogToCustomReport("Successfully verified the value under ("+KeyColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")", "Pass");
						return true;
					}else{
						System.out.println("Related List View Column Value verification failed.No such value ("+KeyColumnValue+") found under column ("+KeyColumnName+")");
						AddLogToCustomReport("Related List View Column Value verification failed.No such value ("+KeyColumnValue+") found under column ("+KeyColumnName+")", "Fail");
						return false;
					}
				}
			}
			System.out.println("Could not find any matching value out of ("+i+") related list item for Related List view "+KeyColumnName);
			AddLogToCustomReport("Could not find any matching value out of ("+i+") related list item for Related List view "+KeyColumnName, "Fail");
			return false;
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+KeyColumnName+") in related list view");
			AddLogToCustomReport("Unable to verify value under the column ("+KeyColumnName+") in related list view", "Fail");
			return false;
		}
	}
	/**
	 * @author Sangeetha
	 * @param KeyColumnName
	 * @param KeyColumnValue
	 * @Description: Verifies the value of Related List Column if contains 
	 * @return
	 * @throws Exception
	 */
	public boolean VerifyValueContains(String KeyColumnName,String KeyColumnValue) throws Exception
	{
		try{

			int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::div[text()='"+KeyColumnName+"'][1]/ancestor::td[1]/preceding-sibling::td")).size() + 1;
			int total_no_of_row = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr")).size();

			int i;
			for(i=1;i<=total_no_of_row;i++){
				if(remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim().contains(KeyColumnValue.trim())){
					if(remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim().contains(KeyColumnValue.trim())){
						Value=remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim();
						System.out.println("Successfully verified the value under ("+KeyColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")");
						AddLogToCustomReport("Successfully verified the value under ("+KeyColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")", "Pass");
						return true;
					}else{
						System.out.println("Related List View Column Value verification failed.No such value ("+KeyColumnValue+") found under column ("+KeyColumnName+")");
						AddLogToCustomReport("Related List View Column Value verification failed.No such value ("+KeyColumnValue+") found under column ("+KeyColumnName+")", "Fail");
						return false;
					}
				}
			}
			System.out.println("Could not find any matching value out of ("+i+") related list item for Related List view "+KeyColumnName);
			AddLogToCustomReport("Could not find any matching value out of ("+i+") related list item for Related List view "+KeyColumnName, "Fail");
			return false;
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+KeyColumnName+") in related list view");
			AddLogToCustomReport("Unable to verify value under the column ("+KeyColumnName+") in related list view", "Fail");
			return false;
		}
	}
	/**
	 * @author Sangeetha
	 * @param KeyColumnName
	 * @param KeyColumnValue
	 * @Description: Click the value of Related List View Column  
	 * @return
	 * @throws Exception
	 */
	public boolean Click(String KeyColumnName,String KeyColumnValue) throws Exception
	{
		try{
			int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::div[text()='"+KeyColumnName+"'][1]/ancestor::td[1]/preceding-sibling::td")).size() + 1;
			//int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
			int total_no_of_row = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr")).size();

			for(int i=1;i<=total_no_of_row;i++){
				if(remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim().equals(KeyColumnValue.trim())){

					Value=remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim();
					remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).click();

					System.out.println("Successfully clicked the value under ("+KeyColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")");
					AddLogToCustomReport("Successfully clicked the value under ("+KeyColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")", "Pass");
					return true;
				}
			}
			System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
			AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
			return false;
		}

		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
			AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
			return false;			
		}

	}
	/**
	 * @author Sangeetha
	 * @param RowIndex
	 * @Description: Click the value of Related List View Column  
	 * @return
	 * @throws Exception
	 */
	public boolean Click(int RowIndex) throws Exception
	{
		try{

			int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::div[text()='"+ColumnName+"'][1]/ancestor::td[1]/preceding-sibling::td")).size() + 1;
			//			int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
			int total_no_of_row = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr")).size();


			//System.out.println("ObjectName:"+ObjectName);
			//System.out.println("TargetColumnName:"+TargetColumnName);
			//System.out.println("TargetColumnValue:"+TargetColumnValue);
			//System.out.println("KeyColumnName:"+KeyColumnName);
			//System.out.println("KeyColumnValue:"+KeyColumnValue);

			int record = RowIndex+1;

			//System.out.println("total_no_of_columns:"+total_no_of_columns);
			//System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
			//System.out.println("column_index_target_column:"+column_index_target_column);
			//System.out.println("total_no_of_row:"+total_no_of_row);
			//		  remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+RowIndex+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).click();
			remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+record+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).click();
			System.out.println("Successfully clicked the value under ("+ColumnName+") on Related List Item ("+RowIndex+")");
			AddLogToCustomReport("Successfully clicked the value under ("+ColumnName+") on Related List Item ("+RowIndex+")", "Pass");
			return true;  

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find any element when click by index under column ("+ColumnName); 
			AddLogToCustomReport("Unable to find any element when click by index under column ("+ColumnName, "Fail");
			return false;			
		}

	}
	/**
	 * @author Sangeetha
	 * @PageDisplayMode View Page
	 * @Description Reads the field (text) value displayed in the View page
	 *              and returns the value
	 * @return Returns field value on success and returns blank value in case
	 *         failure
	 * @throws Exception
	 */
	public String GetValue(String KeyColumnName,String KeyColumnValue) throws Exception
	{
		try{
			Thread.sleep(2000L);
			int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::div[text()='"+KeyColumnName+"'][1]/ancestor::td[1]/preceding-sibling::td")).size() + 1;
			System.out.println("Actual size is"+remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::div[text()='"+KeyColumnName+"'][1]/ancestor::td[1]/preceding-sibling::td")).size());
			System.out.println(remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::div[text()='"+KeyColumnName+"'][1]")).getText());
			System.out.println("column_index_key_columnNvalue"+column_index_key_columnNvalue);

			int total_no_of_row = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr")).size();
			System.out.println("total no of row"+total_no_of_row);
			for(int i=1;i<=total_no_of_row;i++){
				if(remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim().equals(KeyColumnValue.trim())){

					Value=remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim();
					System.out.println("getValue="+remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim());
					//										System.out.println("Successfully clicked the check-box for KeyColumn ("+KeyColumnName+") and KeyColumnvalue ("+KeyColumnValue+").");
					System.out.println("Successfully read the value under ("+ColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")");
					AddLogToCustomReport("Successfully read the value under ("+ColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")", "Pass");
					return Value;
				}
			}
			System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
			AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
			return "";
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
			AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
			return "";	
		}

	}

	/**
	 * @author Sangeetha
	 * @Description -- Below functionality would click a check-box to select a record in list view based on key column & value. 
	 * @param KeyColumnName, KeyColumnValue
	 * @return void
	 * @throws Exception 
	 */
	public void selectRecordInListView_CheckBox(String KeyColumnName, String KeyColumnValue) throws Exception{

		try{
			Thread.sleep(2000L);
			int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::div[text()='"+KeyColumnName+"'][1]/ancestor::td[1]/preceding-sibling::td")).size() + 1;
			System.out.println("Actual size is"+remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::div[text()='"+KeyColumnName+"'][1]/ancestor::td[1]/preceding-sibling::td")).size());
			System.out.println(remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::div[text()='"+KeyColumnName+"'][1]")).getText());
			System.out.println("column_index_key_columnNvalue"+column_index_key_columnNvalue);

			int total_no_of_row = remoteDriver.findElements(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr")).size();
			System.out.println("total no of row"+total_no_of_row);
			for(int i=1;i<=total_no_of_row;i++){
				if(remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td["+column_index_key_columnNvalue+"]/descendant-or-self::*[text()]")).getText().trim().equals(KeyColumnValue.trim())){
					remoteDriver.findElement(By.xpath("//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr["+i+"]/descendant::td[contains(@class,'cell')][1]")).click();
					System.out.println("Successfully clicked the check-box for KeyColumn ("+KeyColumnName+") and KeyColumnvalue ("+KeyColumnValue+").");
					AddLogToCustomReport("Successfully clicked the check-box based on KeyColumn ("+KeyColumnName+") and KeyColumnvalue ("+KeyColumnValue+").", "Pass");
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Unable to click on check-box to select the record.");
			AddLogToCustomReport("Unable to click on check-box to select the record.", "Fail");
		}
	}
	/**
	 * @author Sangeetha
	 * @Description -- Below functionality would click a check-box to select all records in list view. 
	 * @param
	 * @return void
	 * @throws Exception 
	 */
	public void selectAllRecordsInListView() throws Exception{
		//String xpath_common = "(//div[contains(@class,'active oneContent')])[1]/descendant::div[contains(@class,'forceListViewManagerHeader')][1]/descendant::*[local-name()='h1' or local-name()='span'][text()='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::div[@class='listViewContainer'][1]/descendant::div[@class='displayArea'][1]/descendant::div[contains(@class,'fixed_container')][1]";
		xpath_common = "//select[contains(@title,'View')]/ancestor::div[1]/ancestor::div[1]/following-sibling::div[2]/descendant::tr[contains(@class,'hd-row')][1]/descendant::td[contains(@class,'cell')]";
		try{
			Thread.sleep(2000L);
			remoteDriver.findElement(By.xpath(xpath_common)).click();
			System.out.println("Successfully clicked on check-box to select all records.");
			AddLogToCustomReport("Successfully clicked on check-box to select all records.", "Pass");
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Unable to click on check-box to select all records.");
			AddLogToCustomReport("Unable to click on check-box to select all records.", "Pass");
		}
	}
	/**
	 * @author Sangeetha
	 * @Description -- Below functionality would select a mentioned view name from List View page
	 * @param viewName
	 * @return void
	 * @throws Exception 
	 */
	public void SelectView(String viewName) throws Exception{
		try{
			Thread.sleep(4000L);
			System.out.println(SFDCAutomationFW.xp_lui_common_part + "/descendant::a[@title='View'][1]");
			remoteDriver.findElement(By.xpath("//select[contains(@title,'View')][1]")).click();
			Thread.sleep(2000L);
			remoteDriver.findElement(By.xpath("//select[contains(@title,'View')][1]/descendant::option[text()='"+viewName+"']")).click();
			Thread.sleep(1000L);
			System.out.println("Selected the view ("+viewName+") from dropdown.");
			AddLogToCustomReport("Selected the view ("+viewName+") from dropdown.", "Pass");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Unable to select the view ("+viewName+") from dropdown.");
			AddLogToCustomReport("Unable to select the view ("+viewName+") from dropdown.", "Fail");
		}
	}


	/**
	 * @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try{
			if(Result.toString().trim().equalsIgnoreCase("Pass")){
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}else if(Result.toString().trim().equalsIgnoreCase("Fail")){
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}
		}
		catch(Exception e){
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param timeOutInSeconds
	 * @return void
	 * @throws Exception
	 * @Description Waits for the page to reach ready state 
	 * @Date Aug 7, 2014
	 */
	public void WaitForPageToLoad(int timeOutInSeconds) throws Exception{ 
		String command = "return document.readyState"; 
		try{
			for (int i=0; i<timeOutInSeconds; i++){ 
				try{
					Thread.sleep(1000L);
				}catch (InterruptedException e){
					System.out.println("Unable to load the webpage");				
				} 
				if (remoteDriver.executeScript(command).toString().equals("complete")){ 
					//System.out.println("Inside WaitForPageToLoad(Success)");
					break; 
				} 
			} 
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}