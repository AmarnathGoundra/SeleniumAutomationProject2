package SOURCE_CODE.SFDC;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;


/**
 * @author Cognizant
 *
 */
/**
 * @author Cognizant
 *
 */
/**
 * @author 712104
 *
 */
public class MemberOfHealthCloud_LUI extends PageBase{

	String fieldname;
	String xpath;
	String ButtonName;
	String TargetColumnValue;
	String xpath_common;
	
	
	List<WebElement> allposblefieldelements;
	WebElement getsingleWebelement;
		
	
	public MemberOfHealthCloud_LUI(RemoteWebDriver remoteDriver) {
		super(remoteDriver);	
		
	}
	
	public MemberOfHealthCloud_LUI(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}
	
	/**
	 * @author Monoj
	 * @Description Select from lookup 
	 * @param  Value
	 * @return boolean
	 * @throws Exception
	 */
	
	public boolean SelectFromLookup_HC(String LookUpValue) throws Exception
    {
                   
           try
           {
        	   LookUpValue = LookUpValue + " ";
        	   	xpath = "(//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"']/ancestor::div[contains(@class,'slds-large-size')][1]/descendant::input)[1]";
        	   	getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				getsingleWebelement.clear();
				getsingleWebelement.sendKeys(LookUpValue);
				Thread.sleep(2000L);
        	   	xpath = "(//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"']/ancestor::div[contains(@class,'slds-large-size')][1]/descendant::li)[1]";
                
                 Thread.sleep(3000L);
              
                 remoteDriver.findElement(By.xpath(xpath)).click();
                 System.out.println("Selected the value ("+LookUpValue+") from lookup field ("+fieldname+")");
                 AddLogToCustomReport("Selected the value ("+LookUpValue+") from lookup field ("+fieldname+")", "Pass");
                 return true;               
           }
           catch(Exception e)
           {
                 e.printStackTrace();
                 System.out.println("Unable to find the value from lookup "+fieldname+" when xpath is: "+xpath);
                 AddLogToCustomReport("Unable to find the value from lookup "+fieldname+" when xpath is: "+xpath,"Fail");
                 return false;
                 
           }
           
    }

	
	
	
	
	
	
	/**
	 * @author Monoj
	 * @Description Type in field 
	 * @param  Value
	 * @return boolean
	 * @throws Exception
	 */
		
		public boolean Type_HC(String Value) throws Exception
		{
						
				try{
									
					//xpath = "//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"']/following-sibling::div/descendant::input";
					//xpath = "(//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"']/following-sibling::div/descendant::input)[1]";
					
					xpath = "(//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"']/ancestor::div[contains(@class,'slds-large-size')][1]/descendant::input)[1]";
					getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
					getsingleWebelement.clear();
					getsingleWebelement.sendKeys(Value);
									
					AddLogToCustomReport("Entered the value ("+Value+") in the field ("+fieldname+").", "Pass");
					System.out.println("Entered the value ("+Value+") in the field ("+fieldname+").");
					return true;
			
				}catch(Exception e)
				{
					e.printStackTrace();
					AddLogToCustomReport("Unable to enter the value ("+Value+") in the field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
					System.out.println("Unable to enter the value ("+Value+") in the field ("+fieldname+") when xpath is ("+xpath+")");
					return false;
					
				}
			
		}
		
		/**
		 * @param LookUpValue
		 * @return
		 * @Description Removes the value from lookup field
		 * @throws Exception
		 */
		public boolean RemoveFromLookup_HC(String LookUpValue) throws Exception
	    {
	                   
	           try
	           {
	        	   LookUpValue = LookUpValue + " ";
	        	   	xpath = "		(//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"'])[1]/ancestor::div[1]/following-sibling::*[1]/descendant::button[contains(@class,'remove')][1]";
	        	   	getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
					//getsingleWebelement.clear();
					//getsingleWebelement.sendKeys(LookUpValue);
					
	                 remoteDriver.findElement(By.xpath(xpath)).click();
	                 System.out.println("Removed existing value from lookup field ("+fieldname+")");
	                 AddLogToCustomReport("Removed existing value from lookup field ("+fieldname+")", "Pass");
	                 return true;               
	           }
	           catch(Exception e)
	           {
	                 e.printStackTrace();
	                 System.out.println("Unable to click remove button icon from lookup field "+fieldname + " when xpath is:"+xpath);
	                 AddLogToCustomReport("Unable to click remove button icon from lookup field "+fieldname + " when xpath is:"+xpath,"Fail");
	                 return false;
	                 
	           }
	           
	    }


				
		
		/**
		 * @author Monoj
		 * @Description Type in field by index
		 * @param Index , Value
		 * @return boolean
		 * @throws Exception
		 */
		
		public boolean TypeByIndex_HC(int Index, String Value) throws Exception
		{
						
				try{
									
					//xpath = "(//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"'])["+Index+"]/following-sibling::div/descendant::input";
					xpath = "((//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"'])["+Index+"]/ancestor::div[contains(@class,'slds-large-size')][1]/descendant::input)[1]";
					
					getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
					getsingleWebelement.clear();
					getsingleWebelement.sendKeys(Value);
									
					AddLogToCustomReport("Entered the value ("+Value+") in the field ("+fieldname+").", "Pass");
					System.out.println("Entered the value ("+Value+") in the field ("+fieldname+").");
					return true;
			
				}catch(Exception e)
				{
					e.printStackTrace();
					AddLogToCustomReport("Unable to enter the value ("+Value+") in the field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
					System.out.println("Unable to enter the value ("+Value+") in the field ("+fieldname+") when xpath is ("+xpath+")");
					return false;
					
				}
			
		}
		
		
		
		
		
		/**
		 * @author Monoj
		 * @Description Select picklist value 
		 * @param  Value
		 * @return boolean
		 * @throws Exception
		 */
		public boolean SelectPL_HC(String Value) throws Exception {
			// Working xpath =
			// "((//*[text()='"+fieldname+"'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='select']";
			//xpath = "(//*[normalize-space(text())='" + fieldname+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[local-name()='select'])[1]";
		
			 
			//xpath = "((//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"'])[1]/ancestor::label[1]/following-sibling::div[1]/descendant::select)[1]";
			
			xpath = "(//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"']/ancestor::div[contains(@class,'large')][1]/descendant::select)[1]";
			try {
				getsingleWebelement = getElement(xpath);
				if(getAttributeValue(getsingleWebelement, "type").toString().trim().equalsIgnoreCase("select-one") || getAttributeValue(getsingleWebelement, "tagName").toString().trim().equalsIgnoreCase("select"))
				{
					Select s = new Select(getsingleWebelement);
					s.selectByVisibleText(Value);
					AddLogToCustomReport("Pass","Selected picklist value ("+Value+") in field ("+fieldname+")");
					return true;
				}
				return false;
			}
			catch(Exception e)
			{
				AddLogToCustomReport("Fail", "Unable to select the picklist value("+Value+") in field ("+fieldname+")");
				e.printStackTrace();
				return false;
			}
		}
			
		/**
		 * @author Monoj
		 * @Description Select picklist value by Index
		 * @param Index , Value
		 * @return boolean
		 * @throws Exception
		 */
		
		public boolean SelectPLByIndex_HC(int Index,String Value) throws Exception {
			// Working xpath =
			// "((//*[text()='"+fieldname+"'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='select']";
			//xpath = "(//*[normalize-space(text())='" + fieldname+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[local-name()='select'])[1]";
		
			 //xpath = "((//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"'])["+Index+"]/ancestor::label[1]/following-sibling::div[1]/descendant::select)[1]";
			 
			 xpath = "(//label[contains(@class,'label') and contains(@class,'slds-form')]/descendant-or-self::*[text()='"+fieldname+"']/ancestor::div[contains(@class,'large')][1]/descendant::select)["+Index+"]";
			 
			try {
				getsingleWebelement = getElement(xpath);
				if(getAttributeValue(getsingleWebelement, "type").toString().trim().equalsIgnoreCase("select-one") || getAttributeValue(getsingleWebelement, "tagName").toString().trim().equalsIgnoreCase("select"))
				{
					Select s = new Select(getsingleWebelement);
					s.selectByVisibleText(Value);
					AddLogToCustomReport("Pass","Selected picklist value ("+Value+") in field ("+fieldname+")");
					return true;
				}
				return false;
			}
			catch(Exception e)
			{
				AddLogToCustomReport("Fail", "Unable to select the picklist value("+Value+") in field ("+fieldname+")");
				e.printStackTrace();
				return false;
			}
		}
		
		/**
		 * @author Monoj
		 * @Description Click on Button
		 * @param 
		 * @return boolean
		 * @throws Exception
		 */
		
		public boolean ClickButton_HC() throws Exception
		{
			try{
				
				waitForPageLoad();
				xpath = "//button[contains(@class,'slds-button_brand') or contains(@class,'buttonClassCustom') or contains(text(),'"+ButtonName+"')]";
				//xpath = "//button[text()='"+Value+"']";
				System.out.println("XPath-->"+xpath);
				//waitForVisibilityOfElement(xpath);
				//SwitchToActiveLightningiFrame();
				System.out.println("count of elements--------->"+remoteDriver.findElements(By.xpath(xpath)).size());
				remoteDriver.findElement(By.xpath(xpath)).click();
				AddLogToCustomReport("Successfully clicked on button ("+ButtonName+").", "Pass");
				System.out.println("Successfully clicked on button ("+ButtonName+").");
				return true;
				
								
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to click on the button ("+ButtonName+").Xpath:"+xpath);
				AddLogToCustomReport("Unable to click on the button ("+ButtonName+")", "Fail");
				return false;
			}
		
		}
		
		/**
		 * @author Monoj
		 * @Description Click on Element
		 * @param 
		 * @return boolean
		 * @throws Exception
		 */
		
		
		public boolean Click_HC() throws Exception
		{
			try{
				
				waitForPageLoad();
				
				xpath = "//label[(contains(@class,'label') and contains(@class,'slds-form')) or contains(@class,'label') or  contains(@class,'slds-checkbox') ]/descendant-or-self::*[contains(text(),'"+fieldname+"')]";
				System.out.println("XPath-->"+xpath);
				//waitForVisibilityOfElement(xpath);
				//SwitchToActiveLightningiFrame();
				System.out.println("count of elements--------->"+remoteDriver.findElements(By.xpath(xpath)).size());
				remoteDriver.findElement(By.xpath(xpath)).click();
				AddLogToCustomReport("Successfully clicked on button ("+fieldname+").", "Pass");
				System.out.println("Successfully clicked on button ("+fieldname+").");
				return true;
				
								
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to click on the button ("+fieldname+").Xpath:"+xpath);
				AddLogToCustomReport("Unable to click on the button ("+fieldname+")", "Fail");
				return false;
			}
		
		}
		
		/**
		 * @author Monoj
		 * @Description Click on Element by index
		 * @param Index
		 * @return boolean
		 * @throws Exception
		 */
		public boolean ClickByIndex_HC(int Index) throws Exception
		{
			try{
				
				waitForPageLoad();
				
				xpath = "(//label[(contains(@class,'label') and contains(@class,'slds-form')) or contains(@class,'label') or  contains(@class,'slds-checkbox') ]/descendant-or-self::*[contains(text(),'"+fieldname+"')])["+Index+"]";
				System.out.println("XPath-->"+xpath);
				//waitForVisibilityOfElement(xpath);
				//SwitchToActiveLightningiFrame();
				System.out.println("count of elements--------->"+remoteDriver.findElements(By.xpath(xpath)).size());
				remoteDriver.findElement(By.xpath(xpath)).click();
				AddLogToCustomReport("Successfully clicked on field ("+fieldname+").", "Pass");
				System.out.println("Successfully clicked on field ("+fieldname+").");
				return true;
											
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to click on the field ("+fieldname+").Xpath:"+xpath);
				AddLogToCustomReport("Unable to click on the field ("+fieldname+")", "Fail");
				return false;
			}
		
		}
		
	
		
		/**
		 * @author Monoj
		 * @Description Validate field level Error message 
		 * @param ErrorMessage
		 * @return boolean
		 * @throws Exception
		 */
		public boolean VerifyFieldErrorMsgOnEditPage(String ErrorMessage) throws Exception {
			///xpath = "//*[contains(normalize-space(text()),'" + fieldname
				//	+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[contains(@class,'errorMsg')]";
			
			xpath = "//label[(contains(@class,'label') and contains(@class,'slds-form')) or contains(@class,'label') or  contains(@class,'slds-checkbox') ]/descendant-or-self::*[text()='"+fieldname+"']/ancestor::div[contains(@class,'slds-large-size')][1]/descendant::*[text()='"+ErrorMessage+"']";
			
			try {
				getsingleWebelement = getElement(xpath);
					// System.out.println("Inside Type:"+allposblefieldelements.size());
					if (getText(getsingleWebelement).trim().contains(ErrorMessage.trim())) {
						System.out.println("Successfully verified the error message (" + ErrorMessage + ") on field ("
								+ fieldname + ")");
						AddLogToCustomReport("Pass","Successfully verified the error message (" + ErrorMessage + ") on field ("
								+ fieldname + ")");
						return true;
					} else {
						System.out.println("Unable to verify the error message on field (" + fieldname
								+ "). Actual Error Message was (" + getText(getsingleWebelement).trim()
								+ ") when Expected Error Message is (" + ErrorMessage + ")");
						AddLogToCustomReport("Fail", "Unable to verify the error message on field (" + fieldname + "). Actual Error Message was (" + getText(getsingleWebelement).trim() + ") when Expected Error Message is (" + ErrorMessage + ")");
						return false;
					}
			} catch (Exception e) {
				System.out.println("Unable to find the element when xpath is:" + xpath);
				AddLogToCustomReport("Fail", "Unable to verify the error message on field (" + fieldname + "). Actual Error Message was (" + getText(getsingleWebelement).trim() + ") when Expected Error Message is (" + ErrorMessage + ")");
				e.printStackTrace();
				return false;
			}
			// xpath =
					// "(//*[normalize-space(text())='"+fieldname+"'][1]/ancestor-or-self::*[local-name()='td'
					// or local-name()='th'][1])/following-sibling::*[local-name()='td' or
					// local-name()='th'][1]/descendant-or-self::*[@type !='hidden' and
					// contains(@class,'errorMsg')]";
		}
		
		
	/**
	 * @author Sourav
	 * @Description Waits for specified time for the field to be displayed in the UI
	 * @param waitingTimeinSec
	 * @return boolean
	 * @throws Exception
	 */
	public boolean WaitForElement(long waitingTimeinSec) throws Exception
	{
		 xpath = "//*[normalize-space(text())='"+fieldname+"']";
		 try {
			 
			 if (remoteDriver.toString().contains("InternetExplorerDriver"))
     	 	 {
     	 			WebDriverWaitForElement(xpath,waitingTimeinSec);
     	 			return true;
     	 	 }
			 else
			 {
             remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinSec));
             List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
             if (myDynamicElement.size() > 0)
             {
            	 AddLogToCustomReport("The field ("+fieldname+") was available in the application.", "Pass");
            	 return true;
             }
             else
             {
            	 AddLogToCustomReport("Could not find the field ("+fieldname+") in the application.", "Fail");
            	 return false;
             }
			 }
             //System.out.println("The value of dynamic webelement is:"+myDynamicElement.isDisplayed());
             //return myDynamicElement.isDisplayed();
             }
         catch(NoSuchElementException e)
             {
             System.out.println("Could not find the element after waiting for specified time.");
             AddLogToCustomReport("Could not find the button ("+fieldname+") in the application.", "Fail");
             return false;
             //return false;
             }
	}
	
	
	/**
	 * @author Cognizant
	 * @param YesORNo
	 * @Description Verify if a field label is present in the View Details page
	 * @return
	 * @throws Exception
	 */
	public boolean IsDisplayed(String YesORNo) throws Exception
    {
           xpath = "//*[normalize-space(text())='"+fieldname+"']";
           
           //System.out.println();
           
           if (YesORNo.equalsIgnoreCase("Yes"))
           {
                  try
                  {
                  if((remoteDriver.findElement(By.xpath(xpath)).isDisplayed()))
                  {
                        System.out.println("Successfully verified the existence of the field ("+fieldname+").");
                        AddLogToCustomReport("Successfully verified the existence of the field ("+fieldname+").", "Pass");
                        return true;  
                  }
                  else
                  {
                        System.out.println("Could not find the field ("+fieldname+") in the application.");
                        AddLogToCustomReport("Could not find the field ("+fieldname+") in the application.", "Fail");
                        return false;
                  }
                  }catch(Exception e)
                  {
                        System.out.println("Could not find the field ("+fieldname+") in the application when xpath is:"+xpath);
                        AddLogToCustomReport("Could not find the field ("+fieldname+") in the application when xpath is:"+xpath, "Fail");
                        e.printStackTrace();
                        return false;
                  }
           }
           else if (YesORNo.equalsIgnoreCase("No"))
           {
                  try
                  {
                  if((remoteDriver.findElement(By.xpath(xpath)).isDisplayed()))
                  {
                        System.out.println("The field ("+fieldname+") is present in the UI when it is not expected to be.");
                        AddLogToCustomReport("The field ("+fieldname+") is present in the UI when it is not expected to be.", "Fail");
                        return false;
                  }
                  else
                  {
                        System.out.println("Successfully verified that the field ("+fieldname+") is not present in the UI.");
                        AddLogToCustomReport("Successfully verified that the field ("+fieldname+") is not present in the UI.", "Pass");
                        return true;
                  }
                  }catch(Exception e2)
                  {
                        System.out.println("Successfully verified that the field ("+fieldname+") is not present in the UI.");
                        AddLogToCustomReport("Successfully verified that the field ("+fieldname+") is not present in the UI.", "Pass");
                        return true;
                  }
           }
           else
           {
                  System.out.println("The input parameter supplied in IsDisplayed() function is not correct. It should be either Yes or No");
                  AddLogToCustomReport("The input parameter supplied in IsDisplayed() function is not correct. It should be either Yes or No", "Fail");
                  return false;
           }
    }

	
	/**
	 * @param element
	 * @Description Scroll vertically/ horizontally to make the element visible on the screen. 
	 * @throws Exception
	 */
	public void ScrollToElement(WebElement element) throws Exception
	{
		
		try
		{
			((JavascriptExecutor)remoteDriver).executeScript("arguments[0].scrollIntoView();", element);
			
			//Coordinates coordinate = ((Locatable) element).getCoordinates();
			//Point cord = element.getLocation();
			//cord.getY();
			//- 300;
			//Locatable
						
			//Point coordinates = element.getLocation();
			
			//Robot robot = new Robot();
			//robot.mouseWheel(1);
			
			
			
			//coordinate.onPage();
			//coordinate.onScreen();
			//coordinate.inViewPort();
					
			System.out.println("Successfully scrolled untill element.");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to scroll until elemnt");
		}
	}
	
	
	/**
	 * @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param 1. xpath of the element. 2. Waiting Time in Second
	 * @return boolean
	 * @throws Exception
	 * @Description Waits for the specified time until the webelemnt is available to WebDriver
	 * @Date Aug 7, 2014
	 */
	public boolean WaitForElement(String xpath, long waitingTimeinsec) throws Exception
    {
         try {
        	 	        		
        	remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
     		List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
     		if (myDynamicElement.size() > 0)
     		{
     			System.out.println("Success: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return true;
     		}
     		else
     		{
     			System.out.println("Unsuccess: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return false;
     		} 
        }
         catch(NoSuchElementException e)
         {
        	 e.printStackTrace();
             System.out.println("Exception inside WaitForElement:"+xpath);
             return false;
         }
     }
	
	public void MouseScrol_Down() throws Exception
	{
		 Robot r = new Robot();
	     for(int i = 0; i < 20; i++){
	         //scroll and wait a bit to give the impression of smooth scrolling
	         r.mouseWheel(1);
	         try{ Thread.sleep(50); }catch(InterruptedException e){}
	     }
	}
	public void MouseScrol_Up() throws Exception
	{
		 Robot r = new Robot();
	     for(int i = 20; i > 0; i--){
	         //scroll and wait a bit to give the impression of smooth scrolling
	         r.mouseWheel(1);
	         try{ Thread.sleep(50); }catch(InterruptedException e){}
	     }
	}
     
	/**
	 * @author Sourav Mukherjee
	 * @Param NA
	 * @return void
	 * @throws Exception
	 * @Description Press TAB Key using Robot Class
	 * @Date Jan, 2015
	 */
	public void PressTABKeyOnWindowAlert() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			
			System.out.println("Pressed Tab Key on Window Alert.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
			System.out.println("Unable to press Tab key on Window Alert");
		}
		
	}
	public void PressF12Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_F12);
			robot.keyRelease(KeyEvent.VK_F12);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	public void PressPageUPKey() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_PAGE_UP);
			robot.keyRelease(KeyEvent.VK_PAGE_UP);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	
	public void PressPageDownKey() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	
	public void PressF5Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_F5);
			robot.keyRelease(KeyEvent.VK_F5);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	
	/**
	 * @param we
	 * @throws Exception
	 */
	public void JavaScriptClick(WebElement we) throws Exception
	{
		try{
			
			remoteDriver.executeScript("arguments[0].click();", we);
			System.out.println("Successfully clicked by JS on element.");
			AddLogToCustomReport("Successfully clicked by JS on element.", "Pass");
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click by JS on element.");
			AddLogToCustomReport("Unable to click by JS on element.", "Fail");
			
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param 1. xpath of the element, 2. Time specified in second
	 * @return WebElement
	 * @throws Exception
	 * @Description Waits for the specified time until the webelemnt is available to WebDriver. This uses WebDriverWait class 
	 * @Date Aug 7, 2014
	 */
	public WebElement WebDriverWaitForElement(String xpath, long waitingTimeinsec) throws Exception
    {
		WebElement element=null;
        try {
        	 	WebDriverWait wait = new WebDriverWait(remoteDriver, Duration.ofSeconds(waitingTimeinsec));
        	 	element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
        	 	return element;
           	 }
         	catch(NoSuchElementException e)
         	{
         		e.printStackTrace();
         		System.out.println("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec");
         		AddLogToCustomReport("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec", "Fail");
         		return element;
        	 
         	}
     }
}
