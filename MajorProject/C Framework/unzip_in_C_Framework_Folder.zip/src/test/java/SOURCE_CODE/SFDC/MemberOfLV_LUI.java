
package SOURCE_CODE.SFDC;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class MemberOfLV_LUI extends PageBase{

	String ObjectName,Value,TargetColumnName;
	//Integer RowIndex;
	String TargetColumnValue;
	//WebDriver remoteDriver;
	//SFDCAutomationFW autoFW;
	String xpath;
	List<WebElement> allposblefieldelements;
	WebElement getsingleWebelement;
	String xpath_common;
	
	public MemberOfLV_LUI(RemoteWebDriver remoteDriver) {
		super(remoteDriver);	
		xpath_common = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'listViewContent') and contains(@class,'table--header') and contains(@class,'fixed_container')][1]";
	}
	
	public MemberOfLV_LUI(AppiumDriver appiumDriver) {
		super(appiumDriver);
		xpath_common = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'listViewContent') and contains(@class,'table--header') and contains(@class,'fixed_container')][1]";
	}
	/*
	MemberOfLV_LUI()
	{
		remoteDriver = autoFW.remoteDriver;
	}
	
	MemberOfLV_LUI(String ON,String CN)
	{
		ObjectName = ON;
		TargetColumnName = CN;		
		remoteDriver = autoFW.remoteDriver;
		xpath_common = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'listViewContent') and contains(@class,'table--header') and contains(@class,'fixed_container')][1]";
		
	}
	MemberOfLV_LUI(String ON,String TCN,String TCV)
	{
		ObjectName = ON;
		TargetColumnName = TCN;
		TargetColumnValue = TCV;
		remoteDriver = autoFW.remoteDriver;
		xpath_common = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'listViewContent') and contains(@class,'table--header') and contains(@class,'fixed_container')][1]";
	}
	*/
	
	/**
	 * @param KeyColumnName
	 * @param KeyColumnValue
	 * @Description: Verifies if the value of Related List Column is 
	 * @return
	 * @throws Exception
	 */
	public boolean VerifyValueEquals(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //System.out.println("ObjectName:"+ObjectName);
		  //System.out.println("TargetColumnName:"+TargetColumnName);
		  //System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  //System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    		if(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(TargetColumnValue.trim()))
 		    		{
 		    			System.out.println("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+ObjectName+") related list.");
 		    			AddLogToCustomReport("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+ObjectName+") related list.", "Pass");
 		    			return true;
 		    		}
 		    		else
 		    		{
 		    			System.out.println("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")");
 		    			AddLogToCustomReport("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")", "Fail");
 		    			return false;
 		    		}
 		    	}
 		  }
		  
		  System.out.println("Could not find any matching value out of ("+i+") related list item for Related List "+ObjectName);
		  AddLogToCustomReport("Could not find any matching value out of ("+i+") related list item for Related List "+ObjectName, "Fail");
		  return false;
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+TargetColumnName+") in related list ("+ObjectName+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+TargetColumnName+") in related list ("+ObjectName+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
	
	}
	
	public boolean VerifyValueContains(String KeyColumnName,String KeyColumnValue) throws Exception
	{
		try{

			//int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
			//int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
			//int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
			Thread.sleep(3000L);


			int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
			int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
			int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();



			//System.out.println("ObjectName:"+ObjectName);
			//System.out.println("TargetColumnName:"+TargetColumnName);
			//System.out.println("TargetColumnValue:"+TargetColumnValue);
			//System.out.println("KeyColumnName:"+KeyColumnName);
			//System.out.println("KeyColumnValue:"+KeyColumnValue);



			//System.out.println("total_no_of_columns:"+total_no_of_columns);
			//System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
			//System.out.println("column_index_target_column:"+column_index_target_column);
			//System.out.println("total_no_of_row:"+total_no_of_row);
			List<String> result = new ArrayList<String>();
			int i=1;
			for(i=1;i<=total_no_of_row;i++)
			{

				//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
				System.out.println("Outer if Before:"+remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
				if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
				{
					System.out.println("Keycolumn Value match and checking for target:"+remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
					//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
					if(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().contains(TargetColumnValue.trim()))
					{
						System.out.println("final match");
						/*System.out.println("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+ObjectName+") related list.");
 		    			AddLogToCustomReport("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+ObjectName+") related list.", "Pass");
 		    			return true;*/

						//Verifies for first occurrence of target value and stores true   - sachin
						result.add("true");
						break;
					}
					else
					{
						/*System.out.println("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")");
 		    			AddLogToCustomReport("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")", "Fail");
 		    			return false;*/
						System.out.println("final mismatch");
						//Verifies for all occurrences of failure until first occurrence of target value and stores false   - sachin
						result.add("false");
					}
				}
			}

			//Returns true or false based on occurrence of target value  - sachin
			if(result.contains("true")){
				System.out.println("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+ObjectName+") related list.");
				AddLogToCustomReport("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+ObjectName+") related list.", "Pass");
				return true;
			}else if(result.contains("false")){
				System.out.println("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")");
				AddLogToCustomReport("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")", "Fail");
				return false;
			}
			System.out.println("Could not find any matching value out of ("+i+") related list item for Related List "+ObjectName);
			AddLogToCustomReport("Could not find any matching value out of ("+i+") related list item for Related List "+ObjectName, "Fail");
			return false;

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+TargetColumnName+") in related list ("+ObjectName+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+TargetColumnName+") in related list ("+ObjectName+") when xpath is:"+xpath, "Fail");
			return false;

		}

	}

	
	
	/*
	public boolean VerifyValueContains(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //System.out.println("ObjectName:"+ObjectName);
		  //System.out.println("TargetColumnName:"+TargetColumnName);
		  //System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  //System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    		if(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().contains(TargetColumnValue.trim()))
 		    		{
 		    			System.out.println("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+ObjectName+") related list.");
 		    			AddLogToCustomReport("Successfully verified the value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+ObjectName+") related list.", "Pass");
 		    			return true;
 		    		}
 		    		else
 		    		{
 		    			System.out.println("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")");
 		    			AddLogToCustomReport("Related List Column Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")", "Fail");
 		    			return false;
 		    		}
 		    	}
 		  }
		  
		  System.out.println("Could not find any matching value out of ("+i+") related list item for Related List "+ObjectName);
		  AddLogToCustomReport("Could not find any matching value out of ("+i+") related list item for Related List "+ObjectName, "Fail");
		  return false;
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+TargetColumnName+") in related list ("+ObjectName+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+TargetColumnName+") in related list ("+ObjectName+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
	
	}
*/
	public boolean VerifyValueDoesNotContain(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //System.out.println("ObjectName:"+ObjectName);
		  //System.out.println("TargetColumnName:"+TargetColumnName);
		  //System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  //System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    		if(!remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().contains(TargetColumnValue.trim()))
 		    		{
 		    			System.out.println("Successfully verified that ("+TargetColumnName+") does not contain ("+TargetColumnValue+") in ("+ObjectName+") related list.");
 		    			AddLogToCustomReport("Successfully verified that ("+TargetColumnName+") does not contain ("+TargetColumnValue+") in ("+ObjectName+") related list.", "Pass");
 		    			return true;
 		    		}
 		    		else
 		    		{
 		    			System.out.println("Related List field verification failed on ("+TargetColumnName+") when does not contain ("+TargetColumnValue+") in ("+ObjectName+") related list.");
 		    			AddLogToCustomReport("Related List field verification failed on ("+TargetColumnName+") when does not contain ("+TargetColumnValue+") in ("+ObjectName+") related list.", "Fail");
 		    			return false;
 		    		}
 		    	}
 		  }
		  System.out.println("Related List field verification failed on ("+TargetColumnName+") when does not contain ("+TargetColumnValue+") in ("+ObjectName+") related list.");
		  AddLogToCustomReport("Related List field verification failed on ("+TargetColumnName+") when does not contain ("+TargetColumnValue+") in ("+ObjectName+") related list.", "Fail");
		  return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+TargetColumnName+") in related list ("+ObjectName+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+TargetColumnName+") in related list ("+ObjectName+") when xpath is:"+xpath, "Fail");
			return false;
		}
	}
	public boolean VerifyCheckBoxValueEquals(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  WaitForPageToLoad(30);
		  
		  //System.out.println(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th");
		  //System.out.println(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th");
		  //System.out.println(xpath_common+"/descendant::tbody[1]/descendant::tr");
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  /*
		  System.out.println("ObjectName:"+ObjectName);
		  System.out.println("TargetColumnName:"+TargetColumnName);
		  System.out.println("TargetColumnValue:"+TargetColumnValue);
		  System.out.println("KeyColumnName:"+KeyColumnName);
		  System.out.println("KeyColumnValue:"+KeyColumnValue);
		   */
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  System.out.println("column_index_target_column:"+column_index_target_column);
		  System.out.println("total_no_of_row:"+total_no_of_row);
		 
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant::img[normalize-space(@alt)][1]")).getAttribute("alt").toString().trim().equalsIgnoreCase("True"));
 		    		if(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant::img[normalize-space(@alt)][1]")).getAttribute("alt").toString().trim().equalsIgnoreCase(TargetColumnValue))
 		    		{
 		    			System.out.println("Successfully verified the checkbox value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+ObjectName+") related list.");
 		    			AddLogToCustomReport("Successfully verified the checkbox value ("+TargetColumnValue+") under the column ("+TargetColumnName+") in ("+ObjectName+") related list.", "Pass");
 		    			return true;
 		    		}
 		    		else
 		    		{
 		    			System.out.println("Related List checkbox Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")");
 		    			AddLogToCustomReport("Related List checkbox Value verification failed.No such value ("+TargetColumnValue+") found under column ("+TargetColumnName+")", "Fail");
 		    			return false;
 		    		}
 		    	}
 		  }
		  
		  System.out.println("Could not find any matching value out of ("+i+") related list item for Related List "+ObjectName);
		  AddLogToCustomReport("Could not find any matching value out of ("+i+") related list item for Related List "+ObjectName, "Fail");
		  return false;
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to verify value under the column ("+TargetColumnName+") in related list ("+ObjectName+") when xpath is:"+xpath);
			AddLogToCustomReport("Unable to verify value under the column ("+TargetColumnName+") in related list ("+ObjectName+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
	
	}
	
	public String GetValue(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //System.out.println("ObjectName:"+ObjectName);
		  //System.out.println("TargetColumnName:"+TargetColumnName);
		  //System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  //System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    		Value = remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim();
 		    		System.out.println("Successfully read the value under ("+TargetColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")");
 		    		AddLogToCustomReport("Successfully read the value under ("+TargetColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")", "Pass");
 		    		return Value;
 		    	}
 		  }
		  
		  System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
		  AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
		  return "";
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
			AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
			return "";			
		}
	
	}

	public boolean Click(String KeyColumnName,String KeyColumnValue) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //System.out.println("ObjectName:"+ObjectName);
		  System.out.println("TargetColumnName:"+TargetColumnName);
		  System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  //System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim()))
 		    	{
 		    		//System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    		
 		    		Value = remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim();
 		    		remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).click();
 		    		System.out.println("Successfully clicked the value under ("+TargetColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")");
 		    		AddLogToCustomReport("Successfully clicked the value under ("+TargetColumnName+") as ("+Value+") when ("+KeyColumnName+"="+KeyColumnValue+")", "Pass");
 		    		return true;
 		    	}
 		  }
		  
		  System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
		  AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
		  return false;
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")"); 
			AddLogToCustomReport("Unable to find any matching value when ("+KeyColumnName+"="+KeyColumnValue+")", "Fail");
			return false;			
		}
	
	}
	

	public boolean Click(int RowIndex) throws Exception
	{
	  try{
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int column_index_target_column = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  //int total_no_of_row = remoteDriver.findElements(By.xpath("//h1[normalize-space(@title)='"+ObjectName+"' and normalize-space(text())='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::table[contains(@class,'uiVirtualDataTable')][1]/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int column_index_target_column = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  
		  
		  //System.out.println("ObjectName:"+ObjectName);
		  //System.out.println("TargetColumnName:"+TargetColumnName);
		  //System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
	    
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  //System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  //System.out.println("total_no_of_row:"+total_no_of_row);
		  remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+RowIndex+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_target_column+"]/descendant-or-self::*[normalize-space(text())]")).click();
 		  System.out.println("Successfully clicked the value under ("+TargetColumnName+") on Related List Item ("+RowIndex+")");
 		  AddLogToCustomReport("Successfully clicked the value under ("+TargetColumnName+") on Related List Item ("+RowIndex+")", "Pass");
 		  return true;  
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find any element when click by index under column ("+TargetColumnName); 
			AddLogToCustomReport("Unable to find any element when click by index under column ("+TargetColumnName, "Fail");
			return false;			
		}
	
	}
	
	public boolean MenuButtonClick() throws Exception
	{
		String buttonName = TargetColumnName.replace("MenuButton", "").replace("Button", "");
	  try{
		  System.out.println("ObjectName:"+ObjectName);
		  System.out.println("TargetColumnName:"+TargetColumnName);
		  waitForVisibilityOfElement("//span[text()='Show more actions'][1]");
		  Thread.sleep(3000L);
		  remoteDriver.findElement(By.xpath("//a[contains(@title,'Show') and contains(@title,'more') and contains(@title,'action')][1]")).click();
		  Thread.sleep(1000L);
		  remoteDriver.findElement(By.xpath("//div[contains(@class,'actionMenu') and contains(@class,'visible')]/descendant::a[@title='"+buttonName+"'][1]")).click();
		  AddLogToCustomReport("Successfully clicked on menu button ("+buttonName+")", "Pass");
		  System.out.println("Successfully clicked on menu button ("+buttonName+")");
		  return true;
	  }catch(Exception e)
	  {
		  e.printStackTrace();
		  AddLogToCustomReport("Unable to click on menu button ("+buttonName+")","Fail");
		  System.out.println("Unable to click on menu button ("+buttonName+")");
		  return false;
	  }
	  
	}
	
	
	public boolean MenuButtonClick(String ButtonName) throws Exception
	{
	  try{
		 
		  //Please note target column is becoming KeyColumn Here and targetcolumn value is becoming keycolumn value
		  int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
		  int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
		  
		  System.out.println("xpath column_index_key_columnNvalue:"+xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+TargetColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th");
		  System.out.println("xpath total_no_of_row:"+xpath_common+"/descendant::tbody[1]/descendant::tr");
		  
		  System.out.println("ObjectName:"+ObjectName);
		  System.out.println("TargetColumnName:"+TargetColumnName);
		  System.out.println("TargetColumnValue:"+TargetColumnValue);
		  //System.out.println("KeyColumnName:"+KeyColumnName);
		  //System.out.println("KeyColumnValue:"+KeyColumnValue);
		   
		  
		  
		  //System.out.println("total_no_of_columns:"+total_no_of_columns);
		  System.out.println("column_index_key_columnNvalue:"+column_index_key_columnNvalue);
		  //System.out.println("column_index_target_column:"+column_index_target_column);
		  System.out.println("total_no_of_row:"+total_no_of_row);
		 
		  int i=1;
		  for(i=1;i<=total_no_of_row;i++)
 		  {
			
			  	System.out.println(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim());
 		    	if (remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(TargetColumnValue.trim()))
 		    	{
 		    		remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th'][last()]/descendant::a[contains(@class,'button') and contains(@class,'Action')][1]")).click();
 		    		Thread.sleep(2000L);
 		    		remoteDriver.findElement(By.xpath("//div[contains(@class,'actionMenu') and contains(@class,'uiMenuList--default visible')]/descendant::a[normalize-space(@title)='"+ButtonName+"' and normalize-space(@role)='menuitem'][1]")).click();
 		    		System.out.println("Clicked on ("+ButtonName+") menu button when ("+TargetColumnName+") is ("+TargetColumnValue+").");
 		    		AddLogToCustomReport("Clicked on ("+ButtonName+") menu button when ("+TargetColumnName+") is ("+TargetColumnValue+").", "Pass");
 		    		return true;
 		    	}
 		    	
 		  }
		  System.out.println("Unable to find any matching record when ("+TargetColumnName+") is ("+TargetColumnValue+") while clicking on menu button.");
		  AddLogToCustomReport("Unable to find any matching record when ("+TargetColumnName+") is ("+TargetColumnValue+") while clicking on menu button.", "Pass");
		  return false;
	  }
	  catch(Exception e)
	  {
		e.printStackTrace();
		System.out.println("Unable to find any matching record when ("+TargetColumnName+") is ("+TargetColumnValue+") while clicking on menu button.");
		AddLogToCustomReport("Unable to find any matching record when ("+TargetColumnName+") is ("+TargetColumnValue+") while clicking on menu button.", "Pass");
		return false;
	  }
	
	}


	/**
	 * @author Sachin Bagelikar
	 * @Description -- Below functionality would click a check-box to select a record in list view based on key column & value. 
	 * @param KeyColumnName, KeyColumnValue
	 * @return void
	 * @throws Exception 
	 */
	public void selectRecordInListView_CheckBox(String KeyColumnName, String KeyColumnValue) throws Exception{
		//String xpath_common = "(//div[contains(@class,'active oneContent')])[1]/descendant::div[contains(@class,'forceListViewManagerHeader')][1]/descendant::*[local-name()='h1' or local-name()='span'][text()='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::div[@class='listViewContainer'][1]/descendant::div[@class='displayArea'][1]/descendant::div[contains(@class,'fixed_container')][1]";
		xpath_common = xpath_common + "/descendant::thead[1]/tr[1]/descendant::*[local-name()='span'][contains(@class,'checkbox--faux')]";
		
		try{
			Thread.sleep(2000L);
			//int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/descendant-or-self::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
			int column_index_key_columnNvalue = remoteDriver.findElements(By.xpath(xpath_common+"/ancestor::thead[1]/tr[1]/descendant::span[normalize-space(text())='"+KeyColumnName+"'][1]/ancestor::th[1]/preceding-sibling::th")).size() + 1;
			//int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/descendant::tbody[1]/descendant::tr")).size();
			int total_no_of_row = remoteDriver.findElements(By.xpath(xpath_common+"/ancestor::thead[1]/following-sibling::tbody[1]/descendant::tr")).size();

			for(int i=1;i<=total_no_of_row;i++){
				//if(remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())]")).getText().trim().equals(KeyColumnValue.trim())){
				if(remoteDriver.findElement(By.xpath(xpath_common+"/ancestor::thead[1]/following-sibling::tbody[1]/tr["+i+"]/descendant-or-self::*[local-name()='td' or local-name()='th']["+column_index_key_columnNvalue+"]/descendant-or-self::*[normalize-space(text())][1]")).getText().trim().equals(KeyColumnValue.trim())){
					
					//remoteDriver.findElement(By.xpath(xpath_common+"/descendant::tbody[1]/tr["+i+"]/descendant::*[local-name()='span'][contains(@class,'checkbox--faux')]")).click();
					remoteDriver.findElement(By.xpath(xpath_common+"/ancestor::thead[1]/following-sibling::tbody[1]/tr["+i+"]/descendant::*[local-name()='span'][contains(@class,'checkbox--faux')]")).click();
					System.out.println("Successfully clicked the check-box for KeyColumn ("+KeyColumnName+") and KeyColumnvalue ("+KeyColumnValue+").");
					AddLogToCustomReport("Successfully clicked the check-box based on KeyColumn ("+KeyColumnName+") and KeyColumnvalue ("+KeyColumnValue+").", "Pass");
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Unable to click on check-box to select the record.");
			AddLogToCustomReport("Unable to click on check-box to select the record.", "Fail");
		}
	}


	/**
	 * @author Sachin Bagelikar
	 * @Description -- Below functionality would click a check-box to select all records in list view. 
	 * @param
	 * @return void
	 * @throws Exception 
	 */
	public void selectAllRecordsInListView() throws Exception{
		//String xpath_common = "(//div[contains(@class,'active oneContent')])[1]/descendant::div[contains(@class,'forceListViewManagerHeader')][1]/descendant::*[local-name()='h1' or local-name()='span'][text()='"+ObjectName+"'][1]/ancestor::div[contains(@class,'forceListViewManagerHeader')][1]/following-sibling::div[1]/descendant::div[@class='listViewContainer'][1]/descendant::div[@class='displayArea'][1]/descendant::div[contains(@class,'fixed_container')][1]";
		xpath_common = xpath_common + "/descendant::thead[1]/tr[1]/descendant::*[local-name()='span'][contains(@class,'checkbox--faux')]";
		try{
			Thread.sleep(2000L);
			remoteDriver.findElement(By.xpath(xpath_common)).click();
			System.out.println("Successfully clicked on check-box to select all records.");
			AddLogToCustomReport("Successfully clicked on check-box to select all records.", "Pass");
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Unable to click on check-box to select all records.");
			AddLogToCustomReport("Unable to click on check-box to select all records.", "Pass");
		}
	}
	
	/**
	 * @author Sourav
	 * @Description -- Below functionality would select a mentioned view name from List View page
	 * @param viewName
	 * @return void
	 * @throws Exception 
	 */
	public void SelectView(String viewName) throws Exception{
		try{
			Thread.sleep(4000L);
			System.out.println(SFDCAutomationFW.xp_lui_common_part + "/descendant::a[@title='Select List View'][1]");
			remoteDriver.findElement(By.xpath(SFDCAutomationFW.xp_lui_common_part + "/descendant::a[@title='Select List View'][1]")).click();
			Thread.sleep(2000L);
			remoteDriver.findElement(By.xpath("//div[@class='list uiAbstractList forceVirtualAutocompleteMenuList']/descendant::ul[contains(@class,'dropdown')][1]/descendant::span[normalize-space(text())='"+viewName+"'][1]")).click();
			Thread.sleep(1000L);
			System.out.println("Selected the view ("+viewName+") from dropdown.");
			AddLogToCustomReport("Selected the view ("+viewName+") from dropdown.", "Pass");
					
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Unable to select the view ("+viewName+") from dropdown.");
			AddLogToCustomReport("Unable to select the view ("+viewName+") from dropdown.", "Fail");
			
		}
	}



	/**
	 * @author Sachin Bagelikar
	 * @Description -- Below functionality would select mentioned view name from look-up in an object. 
	 * @param viewName
	 * @return void
	 * @throws Exception 
	 */
	public void selectViewFromLookUp(String viewName) throws Exception{
		try{
			Thread.sleep(2000L);
			if(remoteDriver.findElement(By.xpath("//div[contains(@class,'active') and contains(@class,'oneContent')]")).isDisplayed()){
				remoteDriver.findElement(By.xpath("//div[contains(@class,'active oneContent')]/descendant::*[(local-name()='span' or local-name()='p') and normalize-space(text())='"+ObjectName+"']/ancestor::div[1]/descendant::a[1]")).click();
				Thread.sleep(2000L);
				try{
					remoteDriver.findElement(By.xpath("//div[contains(@class,'open active')]/descendant::div[contains(@class,'picklist')]/descendant::input")).click();
					remoteDriver.findElement(By.xpath("//div[contains(@class,'open active')]/descendant::div[contains(@class,'picklist')]/descendant::input")).clear();
					remoteDriver.findElement(By.xpath("//div[contains(@class,'open active')]/descendant::div[contains(@class,'picklist')]/descendant::input")).sendKeys(viewName);

					System.out.println("Successfully entered the view ("+viewName+") in object ("+ObjectName+") look-up.");
					AddLogToCustomReport("Successfully entered the view ("+viewName+") in object ("+ObjectName+") look-up.", "Pass");
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Unable to enter the view ("+viewName+") in object ("+ObjectName+") look-up.");
					AddLogToCustomReport("Unable to enter the view ("+viewName+") in object ("+ObjectName+") look-up.", "Fail");
				}

				try{
					Thread.sleep(2000L);
					remoteDriver.findElement(By.xpath("//div[contains(@class,'open active')]/descendant::div[contains(@class,'picklist')]/descendant::*[local-name()='span'][contains(@class,'virtualAutocompleteOptionText')]/descendant-or-self::*[normalize-space(text())='"+viewName+"']")).click();
					System.out.println("Successfully clicked on view ("+viewName+") in object ("+ObjectName+").");
					AddLogToCustomReport("Successfully clicked on view ("+viewName+") in object ("+ObjectName+").", "Pass");
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Unable to select the view ("+viewName+") in object ("+ObjectName+") look-up.");
					AddLogToCustomReport("Unable to select the view ("+viewName+") in object ("+ObjectName+") look-up.", "Fail");
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Issue in selecting view ("+viewName+") in object ("+ObjectName+") look-up.");
			AddLogToCustomReport("Issue in selecting view ("+viewName+") in object ("+ObjectName+") look-up.", "Fail");
		}
	}
	/**
	 * @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param timeOutInSeconds
	 * @return void
	 * @throws Exception
	 * @Description Waits for the page to reach ready state 
	 * @Date Aug 7, 2014
	 */
	public void WaitForPageToLoad(int timeOutInSeconds) throws Exception
	{ 
		
		String command = "return document.readyState"; 

		try
		{
		for (int i=0; i<timeOutInSeconds; i++)
		{ 
			try
			{
				Thread.sleep(1000L);
			}
			catch (InterruptedException e)
			{
				System.out.println("Unable to load the webpage");				
				
			} 
			
			if (remoteDriver.executeScript(command).toString().equals("complete"))
			{ 
				//System.out.println("Inside WaitForPageToLoad(Success)");
				break; 
			} 
			
			
		} 
		}catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
}
