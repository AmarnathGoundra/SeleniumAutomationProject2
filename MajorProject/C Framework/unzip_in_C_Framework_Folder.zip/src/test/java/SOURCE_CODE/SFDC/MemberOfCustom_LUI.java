package SOURCE_CODE.SFDC;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;


/**
 * @author Cognizant
 *
 */
/**
 * @author Cognizant
 *
 */
public class MemberOfCustom_LUI extends PageBase{

	String fieldname;
	String TableCellName;
	String RelatedList_ColumnName;
	//WebDriver remoteDriver;
	//SFDCAutomationFW autoFW;
	String xpath;
	String ButtonName;
	String RelatedList, Value, TargetColumnName;
	//Integer RowIndex;
	String TargetColumnValue;
	//WebDriver remoteDriver;
	//SFDCAutomationFW autoFW;
	//String xpath;
	//List<WebElement> allposblefieldelements;
//	WebElement getsingleWebelement;
	String xpath_common;
	
	
	List<WebElement> allposblefieldelements;
	WebElement getsingleWebelement;
	String xp_common_vd = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]";
	String xp_common_in_ed_and_vd = "//div[contains(@class,'test-id__record-layout-container riseTransitionEnabled')][1]/following-sibling::div[contains(@class,'riseTransitionEnabled test-id__inline-edit-record-layout-container')][1]";
	String xp_common_in_ed = "//div[contains(@class,'test-id__record-layout-container riseTransitionEnabled')][1]/following-sibling::div[contains(@class,'riseTransitionEnabled test-id__inline-edit-record-layout-container')][1]";
	
	
	
	public MemberOfCustom_LUI(RemoteWebDriver remoteDriver) {
		super(remoteDriver);	
		
	}
	
	public MemberOfCustom_LUI(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}
	
	
	public String generateXpath(String RList) {
		xpath_common = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::*[local-name()='h1' or local-name()='span'][text()='"+RList+"'][1]/ancestor::div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'listViewContent') and contains(@class,'table--header') and contains(@class,'fixed_container')][1]";
		return xpath_common;
	}
	
	
	/**
	 * @return
	 * @throws Exception
	 * @Description: Reads the value(text,link) of view only field from 1. Detail View Layout 2. Edit Layout 3. Inline Edit Layout and returns the same 
	 */
	public String GetViewOnlyValue() throws Exception
	{
				
		try{
									
			//Identifying the page type
			/*
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
			{
				
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[@class='itemBody']/descendant-or-self::div[contains(@class,'data')][1]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1])/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";									
				}			
				
			}
			
			else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("EDIT PAGE");
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
			}
			*/
			
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					//xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1])/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";	
			}
			
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
			//Getting the value from field
			String Value = "";
			Value = remoteDriver.findElement(By.xpath(xpath)).getText();
			System.out.println("Read the value("+Value+") of field ("+fieldname+") ");
			AddLogToCustomReport("Read the value("+Value+") of field ("+fieldname+") ", "Pass");
			
			return Value;
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to read the value from field ("+fieldname+") .");
			AddLogToCustomReport("Unable to read the value from field ("+fieldname+") from view detail.", "Fail");
			return "";
			
		}
		
	}
	
	/**
	 * @Description Clicks on the JTreeCheckbox link
	 * @throws Exception
	 */
	public void JSTreeCheckBoxClick() throws Exception
	{
		try {
			WaitForElement("//a[contains(@class,'jstree')][normalize-space(text())='"+fieldname+"']", 60);
			remoteDriver.findElement(By.xpath("//a[contains(@class,'jstree')][normalize-space(text())='"+fieldname+"']")).click();
			AddLogToCustomReport("Successfully Clicked on checkbox against field ("+fieldname+")", "Pass");
			System.out.println("Successfully Clicked on checkbox against field ("+fieldname+")");
						
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to check the JTree Check Box against field ("+fieldname+")");
			AddLogToCustomReport("Unable to read the value from field ("+fieldname+") from view detail.", "Fail");
			
		}
		
	}
	
	/**
	 * Description Expands the JTree 
	 * @throws Exception
	 */
	public void JSTreeClickToExpand() throws Exception
	{
		try {
			xpath = "//a[contains(@class,'jstree')][normalize-space(text())='"+fieldname+"']/preceding-sibling::i[contains(@class,'jstree-icon')][1]";
			WaitForElement(xpath, 60);
			remoteDriver.findElement(By.xpath(xpath)).click();
			AddLogToCustomReport("Clicked on icon of ("+fieldname+") to expand", "Pass");
			System.out.println("Clicked on icon of ("+fieldname+") to expand");
						
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable expand the field ("+fieldname+")");
			AddLogToCustomReport("Unable expand the field ("+fieldname+")", "Fail");
			
		}
		
	}
	


	/**
	 * @param value
	 * @Description  Selects a vlue from custom cloud sense drop down
	 * @throws Exception
	 */
	public void CustomField_SelectCloudSenseDropDown(String value) throws Exception
	{
		try {
			xpath = "//label[contains(@class,'label') and text()='"+fieldname+"'][1]/following-sibling::div[contains(@data-role,'field')][1]/descendant::a[contains(@class,'select')][1]/descendant::span[1]";
			//WaitForElement(xpath, 60);
			System.out.println("checking ------------------> "+remoteDriver.findElements(By.xpath(xpath)).size());
			remoteDriver.findElement(By.xpath(xpath)).click();
			Thread.sleep(5000L);

			remoteDriver.findElement(By.xpath("//div[contains(@class,'select') and contains(@class,'drop-active') and contains(@style,'display: block')][1]/descendant::input[@role='combobox'][1]")).sendKeys(value);

			Thread.sleep(10000L);
			remoteDriver.findElement(By.xpath("//div[contains(@class,'select') and contains(@class,'drop-active') and contains(@style,'display: block')][1]/descendant::input[@role='combobox'][1]/ancestor::div[contains(@class,'select') and contains(@class,'search')][1]/following-sibling::ul[contains(@class,'select') and contains(@class,'results') and @role='listbox'][1]/descendant::*[normalize-space(text())='"+value+"'][1]")).click();
			
			AddLogToCustomReport("A value ("+value+") has been selected from drop down field "+fieldname, "Pass");
			System.out.println("A value ("+value+") has been selected from drop down field "+fieldname);
						
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to selected the value ("+value+") from drop down field "+fieldname);
			AddLogToCustomReport("Unable to selected the value ("+value+") from drop down field "+fieldname, "Fail");
			
		}
		
	}
	
	
	/**
	 * @Description Choose date from datepicker calendar in cloud sense page
	 * @param YYYY
	 * @param MMM
	 * @param DD
	 * @throws Exception
	 */
	public void CustomField_SelectFromDateLookup(String YYYY,String MMM,String DD) throws Exception
	{
		try {
			xpath = "(//label[contains(@class,'label') and text()='"+fieldname+"'][1]/following-sibling::div[contains(@data-role,'field')])[1]/descendant::span[contains(@class,'icon-calendar')][1]";
			
			
			remoteDriver.findElement(By.xpath(xpath)).click();
			Thread.sleep(3000L);
			
			String xpath_year = "(//div[@class='datePicker' and contains(@style,'display: block;')]/descendant::select[@title='Year'])[1]";
			
			String xpath_month = "(//div[@class='datePicker' and contains(@style,'display: block;')]/descendant::select[@title='Month'])[1]";
			
			String xpath_dd = "(//div[@class='datePicker' and contains(@style,'display: block;')]/descendant::table[@class='calDays']/descendant::td[text()='"+DD+"'])[1]";
			
			Select sy = new Select(remoteDriver.findElement(By.xpath(xpath_year)));
			sy.selectByVisibleText(YYYY);
			
			Select sm = new Select(remoteDriver.findElement(By.xpath(xpath_month)));
			sm.selectByVisibleText(MMM);
			
			remoteDriver.findElement(By.xpath(xpath_dd)).click();
			
			
			AddLogToCustomReport("Successfully selected date from the calendar against field "+fieldname, "Pass");
			System.out.println("Successfully selected date from the calendar against field "+fieldname);
						
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to choose the date from calendar against field "+fieldname);
			AddLogToCustomReport("Unable to choose the date from calendar against field "+fieldname, "Fail");
			
		}
		
	}
	
	/**
	 * @param value
	 * @Description Enter the value in cloudsense text field
	 * @throws Exception
	 */
	public void CustomField_CloudSenseType(String value) throws Exception
	{
		try {
			//xpath = "//label[contains(@class,'label') and text()='"+fieldname+"'][1]/following-sibling::div[contains(@data-role,'field')]/descendant::input[1]";
			xpath="//label[(contains(@class,'label') or @for) and normalize-space(text())='"+fieldname+"'][1]/following-sibling::div[contains(@data-role,'field') or contains(@class,'form')]/descendant::input[1]";
			WaitForElement(xpath, 60);
			remoteDriver.findElement(By.xpath(xpath)).click();
			remoteDriver.findElement(By.xpath(xpath)).clear();
			remoteDriver.findElement(By.xpath(xpath)).sendKeys(value);
			Thread.sleep(3000L);

			AddLogToCustomReport("Entered the  value "+value+" in the field "+fieldname, "Pass");
			System.out.println("Entered the  value "+value+" in the field "+fieldname);
						
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to enter the value ("+value+") in field "+fieldname);
			AddLogToCustomReport("Unable to enter the value ("+value+") in field "+fieldname, "Fail");
			
		}
		
	}
	
	/**
	 * @Description Clicked on the custom tab
	 * @throws Exception
	 */
	public void CustomTab_Click() throws Exception
	{
		try {
			
			xpath="//a[contains(@class,'slds-tabs') and @role='tab'][text()]/ancestor::li[@title='"+fieldname+"'][1]";
			WaitForElement(xpath, 60);
			remoteDriver.findElement(By.xpath(xpath)).click();
			
			AddLogToCustomReport("Clicked on the custom tab ("+fieldname+")", "Pass");
			System.out.println("Clicked on the custom tab ("+fieldname+")");
						
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on the custom tab ("+fieldname+")");
			AddLogToCustomReport("Unable to click on the custom tab ("+fieldname+")", "Fail");
			
		}
		
	}
	
	/**
	 * @description Reads the value from edit field	 *
	 * @return
	 * @throws Exception
	 */
	public String GetCustomEditFieldValue() throws Exception
	{
		try {
			
			xpath = "//label[contains(@ng-bind,'label') and contains(@ng-bind,'field') and text()='"+fieldname+"'][1]/ancestor::div[1]/following-sibling::div[1]/descendant::input[1]";
			WaitForElement(xpath, 60);
			String val = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value");
			
			AddLogToCustomReport("Successfully read the value ("+val+") from drop down against field ("+fieldname+")", "Pass");
			System.out.println("Successfully read the value ("+val+") from drop down against field ("+fieldname+")");
			return val;
		}
		catch(Exception e) {
			
			AddLogToCustomReport("Unable to read the value from field ("+fieldname+")", "Fail");
			System.out.println("Unable to read the value from field ("+fieldname+")");
			e.printStackTrace();	
			return "";
		}
	}
	
	/**
	 * Description Clicks on custom buttons
	 * @throws Exception
	 */
	public void CustomButtonClick() throws Exception
	{
		try {
			
			//System.out.println("--end--");
			//System.out.println("value is:"+remoteDriver.findElements(By.xpath("//button[contains(@class,'slds-button')][text()='"+ButtonName+"'][1]")).size());
			//System.out.println("Value is:"+remoteDriver.findElements(By.xpath("//button[contains(@class,'btn') or contains(@class,'slds-button')]/descendant-or-self::*[text()='"+ButtonName+"'][1]")).size());
			//System.out.println("-end-");
			/*
			if (remoteDriver.findElements(By.xpath("//button[contains(@class,'slds-button')][text()='"+ButtonName+"'][1]")).size() > 0)
			{
				System.out.println("--------------------->xpath1");
				xpath = "//button[contains(@class,'slds-button')][text()='"+ButtonName+"'][1]";
				
			}
			else if (remoteDriver.findElements(By.xpath("//button[contains(@class,'btn')]/descendant::span[text()='"+ButtonName+"'][1]")).size() > 0)
			{
				System.out.println("--------------------->xpath2");
				xpath = "//button[contains(@class,'btn')]/descendant::span[text()='"+ButtonName+"'][1]";
				//System.out.println("--------------------->xpath2");
			}
			*/
			
			xpath = "(//button[contains(@class,'btn') or contains(@class,'slds-button')]/descendant-or-self::*[text()='"+ButtonName+"'])[1]";
			
			//WaitForElement(xpath, 60);
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			List<WebElement> all_but = remoteDriver.findElements(By.xpath(xpath));
			System.out.println("size of button element just before first if:"+all_but.size());
			WebElement element=null;
			for(WebElement elmnt:all_but)
			{
				System.out.println("elmnt.isDisplayed()"+elmnt.isDisplayed());
				System.out.println("isEnabled():"+elmnt.isEnabled());
				System.out.println("isSelected:"+elmnt.isSelected());
				element = elmnt;
			}
			
			if(all_but.size() == 0 || (element.isDisplayed() == false))
			{
				all_but = null;
				System.out.println("Inside First if statement");
				xpath = "//input[contains(@class,'slds-button') and @value='"+ButtonName+"'][1]";
				remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
				all_but = remoteDriver.findElements(By.xpath(xpath));
				System.out.println("size of button element just before 2nd if:"+all_but.size());
				if(all_but.size() == 0)
				{
					xpath = "//div[@class='footer-right'][1]/descendant::button[contains(@class,'slds-button')][text()='"+ButtonName+"'][1]";
					remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
					all_but = remoteDriver.findElements(By.xpath(xpath));
					System.out.println("Inside 2nd If statement "+xpath);
				}
				
			}
			System.out.println("count of button elemens:"+all_but.size());
			for(WebElement elm:all_but)
			{
				ScrollToElement(elm);
				elm.click();
				break;
			}
			all_but = null;
			//remoteDriver.findElement(By.xpath(xpath)).click();
			AddLogToCustomReport("Clicked on Button ("+ButtonName+")", "Pass");
			System.out.println("Clicked on Button ("+ButtonName+")");
						
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on button ("+ButtonName+")");
			AddLogToCustomReport("Unable to click on button ("+ButtonName+")", "Fail");
			
		}
		
	}
	
	
	/**
	 * @param YesNo
	 * @Description To verify the presence of button on a page with Yes and No parameter
	 * @throws Exception
	 */
	public boolean CustomButtonVerifyIfExist(String YesNo) throws Exception
	{
		try {
			
			xpath = "(//button[contains(@class,'btn') or contains(@class,'slds-button')]/descendant-or-self::*[text()='"+ButtonName+"'])[1]";
			
			if (YesNo.equalsIgnoreCase("Yes"))
			{
				//Expecting the button on the page
				if(remoteDriver.findElements(By.xpath(xpath)).size() > 0)
				{
					AddLogToCustomReport("The button ("+ButtonName+") is available on the page","Pass");
					System.out.println("The button ("+ButtonName+") is available on the page");
					return true;
				}
				else
				{
					AddLogToCustomReport("The button ("+ButtonName+") is not available on the page","Fail");
					System.out.println("The button ("+ButtonName+") is not available on the page");
					return false;
					
				}
				
			}
			else if(YesNo.equalsIgnoreCase("No"))
			{
				//Not Expecting the button
				if(remoteDriver.findElements(By.xpath(xpath)).size() == 0)
				{
					AddLogToCustomReport("The button ("+ButtonName+") is available on the page","Pass");
					System.out.println("The button ("+ButtonName+") is available on the page");
					return true;
				}
				else
				{
					AddLogToCustomReport("The button ("+ButtonName+") is not available on the page","Fail");
					System.out.println("The button ("+ButtonName+") is not available on the page");
					return false;
					
				}
			}
			else
			{
				
				System.out.println("Please verify the input parameter of the method (CustomButtonVerifyIfExist), should be Yes or No");
				return false;
				
			}
						
						
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find the availability of the button ("+ButtonName+")");
			AddLogToCustomReport("Unable to find the availability of the button ("+ButtonName+")", "Fail");
			return false;
		}
		
	}
	
	
	/**
	 * Description Clicks on Expand icon with the name of table cell column name
	 * @throws Exception
	 */
	public void CustomTableCell_Expand() throws Exception
	{
		try {
			xpath = "//div[contains(@class,'table-cell') and normalize-space(text())='"+TableCellName+"'][1]/preceding-sibling::div[contains(@class,'action')][1]";
			WaitForElement(xpath, 60);
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			remoteDriver.findElement(By.xpath(xpath)).click();
			AddLogToCustomReport("Clicked on Button ("+TableCellName+") to expand", "Pass");
			System.out.println("Clicked on Button ("+TableCellName+") to expand");
						
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on button ("+TableCellName+")");
			AddLogToCustomReport("Unable to click on button ("+TableCellName+")", "Fail");
			
		}
		
	}
	
	
	public void CustomTableCell_SelectAddress(int rownum) throws Exception
	{
		try {
			xpath = "//div[contains(@class,'table') and contains(@class,'header')]/descendant::*[contains(@class,'cell')][text()][@title='"+TableCellName+"'][1]/ancestor::div[contains(@class,'header')][1]/following-sibling::div[1]/descendant::div[contains(@ng-class,'row-selected')]["+rownum+"]";
			WaitForElement(xpath, 60);
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			remoteDriver.findElement(By.xpath(xpath)).click();
						
			AddLogToCustomReport("Clicked on Button ("+TableCellName+") to expand", "Pass");
			System.out.println("Clicked on Button ("+TableCellName+") to expand");
						
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on button ("+TableCellName+")");
			AddLogToCustomReport("Unable to click on button ("+TableCellName+")", "Fail");
			
		}
		
	}
	
	/**
	 * @Description Getting the name of RL only
	 * @return
	 */
	public String CustomRelatedList_GetRLName()
	{
		try {
			String rlname = "";
			
			rlname = RelatedList_ColumnName.substring(0,RelatedList_ColumnName.indexOf('_'));
			System.out.println("rlname:---------------------->"+rlname);
						
			return rlname;
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	
	/**
	 * @Description Getting the name of RL Column Name only
	 * @return
	 */
	public String CustomRelatedList_GetRLColumnName()
	{
		try {
			String rlname_col = "";
			
			rlname_col = RelatedList_ColumnName.substring(RelatedList_ColumnName.indexOf('_')+1);
			System.out.println("rlname:---------------------->"+rlname_col);
						
			return rlname_col;
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	
	/**
	 * @param RowNumber
	 * @return
	 * @Description Verifies the presence of related list item in a CloudSense related list
	 * @throws Exception
	 */
	public boolean CustomRelatedList_IsRListItemExist(int RowNumber) throws Exception
	{
		try {
			xpath = "//h2/descendant::span[contains(@class,'definition')][normalize-space(text())='"+CustomRelatedList_GetRLName().toString().trim()+"']/ancestor::div[contains(@class,'header')][1]/following-sibling::*[1]/descendant::thead/descendant-or-self::*[local-name()='div' or local-name()='th'][not(descendant::*)][normalize-space(text())='"+CustomRelatedList_GetRLColumnName().toString().trim()+"'][1]/ancestor::thead[1]/following-sibling::tbody[1]/descendant::tr["+RowNumber+"]";
			if(WaitForElement(xpath, 60))
			{
				
				AddLogToCustomReport("Verified the presence of related list item ("+RowNumber+") against related list ("+CustomRelatedList_GetRLName().toString().trim()+")", "Pass");
				System.out.println("Verified the presence of related list item ("+RowNumber+") against related list ("+CustomRelatedList_GetRLName().toString().trim()+")");
				return true;	
			}
			else
			{
				AddLogToCustomReport("Could not find presence of related list item ("+RowNumber+") against related list ("+CustomRelatedList_GetRLName().toString().trim()+")", "Pass");
				System.out.println("Could not find presence of related list item ("+RowNumber+") against related list ("+CustomRelatedList_GetRLName().toString().trim()+")");
				return false;	
			}
			
						
		}catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Could not find presence of related list item ("+RowNumber+") against related list ("+CustomRelatedList_GetRLName().toString().trim()+")", "Pass");
			System.out.println("Could not find presence of related list item ("+RowNumber+") against related list ("+CustomRelatedList_GetRLName().toString().trim()+")");
			return false;	
		}
		
	}
	
	
	
	/**
	 * @Description Clicks on Edit image icon by column name by row number in a table cell
	 * @param RowNumber
	 * @throws Exception
	 */
	public void CustomTableCell_ClickEditImageByRowNumber(int RowNumber) throws Exception
	{
		try {
			xpath = "//div[contains(@class,'table-cell') and normalize-space(text())='"+TableCellName+"'][1]/ancestor::div[contains(@class,'table-header-container')][1]/following-sibling::div[contains(@class,'table-body')]/descendant::button[contains(@class,'btn-edit icon')]["+RowNumber+"]";
			WaitForElement(xpath, 60);
			//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			remoteDriver.findElement(By.xpath(xpath)).click();
			AddLogToCustomReport("Clicked on Edit Image against ("+TableCellName+") and row "+RowNumber, "Pass");
			System.out.println("Clicked on Edit Image against ("+TableCellName+") and row "+RowNumber);
						
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click on Edit Image against ("+TableCellName+") and row "+RowNumber);
			AddLogToCustomReport("Unable to click on Edit Image against ("+TableCellName+") and row "+RowNumber, "Fail");
			
		}
		
	}
	
	/**
	 * @param RowNumber
	 * @return
	 * @Description Reads the value from TableCell Column against row number
	 * @throws Exception
	 */
	public String CustomTableCell_GetViewOnlyValueByRowNumber(int RowNumber) throws Exception
	{
		try {
			//xpath = "//div[@class='slds-box']/descendant::table/descendant-or-self::*[local-name()='th' or local-name()='div'][text()='"+TableCellName+"'][1]";
			
			String xpath_col_pos = "//div[@class='slds-box']/descendant::table/descendant-or-self::*[local-name()='th' or local-name()='div'][text()='"+TableCellName+"'][1]/ancestor::th[1]/preceding-sibling::th";
			
			 
			//WaitForElement(xpath, 60);
			int col_pos = remoteDriver.findElements(By.xpath(xpath_col_pos)).size() + 1;
			String xpath_target_value = "//div[@class='slds-box']/descendant::table/descendant-or-self::*[local-name()='th' or local-name()='div'][text()='Total'][1]/ancestor::thead[1]/following-sibling::tbody[1]/descendant::tr["+RowNumber+"]/descendant::td["+col_pos+"]";
			
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath_target_value)));
			String value = remoteDriver.findElement(By.xpath(xpath_target_value)).getText();
			AddLogToCustomReport("Successfully read the value ("+value+") from tablecell column ("+TableCellName+") against row ("+RowNumber+")", "Pass");
			System.out.println("Successfully read the value ("+value+") from tablecell column ("+TableCellName+") against row ("+RowNumber+")");
            return value;			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to read value from Table Cell Column ("+TableCellName+") from row number "+RowNumber);
			AddLogToCustomReport("Unable to read value from Table Cell Column ("+TableCellName+") from row number "+RowNumber, "Fail");
			return "";
		}
		
	}
	
	/**
	 * @return
	 * @throws Exception
	 * @Page Layout: Support of Lightening UI in below two layout 1. Edit Page Layout 2. Inline Edit Page  
	 * @Description Can read the value from TextField, TextArea, DateLookup from record edit page and inline edit page. It cannot read from lookup field, Single Select Picklist, Multiselect picklist and checkbox values. There are separate methods
	 */
	public String GetEditFieldValue() throws Exception
	{
					
			try{
				
				
				
				//Identifying the page type
				/*
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";								
				}
				*/
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
								
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";								
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::input[1]";
							
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String Value = "";
				Value = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value");
				System.out.println("Read the value("+Value+") of field ("+fieldname+") ");
				AddLogToCustomReport("Read the value("+Value+") of field ("+fieldname+") ", "Pass");
				return Value;
						
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to read the value from field ("+fieldname+").");
				AddLogToCustomReport("Unable to read the value from field ("+fieldname+").", "Fail");
				return "";
				
			}
		
	}		
	
	/**
	 * 
	 * @Description Reads the picklist value from 1. Edit page Layout 2. Inline Edit page layout and returns the value as a String
	 * @throws Exception
	 * @return String, the value present in the pick list field in edit page.
	 * 
	 */
	public String GetPLDefaultValue() throws Exception
	{

		try
		{
			WaitForPageToLoad(60);
			
			//Identifying the page type
			/*
			if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
			{
				System.out.println("INLINE EDIT PAGE");
				xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";
			}				
			else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
			{
				System.out.println("DETAIL VIEW PAGE");	
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";							
			}
			*/
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";
			
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";								
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");

				
				
			}
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
		if (WaitForElement(xpath,30))
		{
			
			String Value = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
			AddLogToCustomReport("The default value in picklist field ("+fieldname+"). is ("+Value+")", "Pass");
			System.out.println("The default value in picklist field ("+fieldname+"). is ("+Value+")");
			return Value;
		}
		else
		{
			System.out.println("Unable to read the value of picklist field ("+fieldname+") as xpath does not result any element.");
			AddLogToCustomReport("Unable to read the value of picklist field ("+fieldname+") as xpath does not result any element.", "Fail");
			return "";
		}
		}
		catch(Exception e)
		{
			AddLogToCustomReport("Unable to read the value of pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
			System.out.println("Unable to read the value of pick list field ("+fieldname+") when xpath is ("+xpath+")");
			return "";	
		}
		
	}

	//below functions need to be tested 11/2/17 12:35PM
	/**
	 * @return
	 * @throws Exception
	 * @Description Reads the value of lookup field from Inline Edit page as well as Edit page
	 * 
	 */
	public String GetLookupEditValue() throws Exception
	{

		try
		{
			WaitForPageToLoad(30);
			/*
			//Identifying the page type
			if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
			{
				System.out.println("INLINE EDIT PAGE");
				xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::span[@class='pillText'][1]";
								
			}				
			else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
			{
				System.out.println("DETAIL VIEW PAGE");	
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::span[@class='pillText'][1]";						
			}
				*/
		
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
				
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::span[@class='pillText'][1]";
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::span[@class='pillText'][1]";								
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant::span[contains(@class,'pillText')][text()]";
				
				
			}
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
		if (WaitForElement(xpath,30))
		{
			
			String Value = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
			AddLogToCustomReport("The value in lookup field ("+fieldname+"). is ("+Value+")", "Pass");
			System.out.println("The value in lookup field ("+fieldname+"). is ("+Value+")");
			return Value;
		}
		else
		{
			System.out.println("Unable to read the value of lookup field ("+fieldname+") as xpath does not result any element.");
			AddLogToCustomReport("Unable to read the value of lookup field ("+fieldname+") as xpath does not result any element.", "Fail");
			return "";
		}
		}
		catch(Exception e)
		{
			AddLogToCustomReport("Unable to read the value of lookup field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
			System.out.println("Unable to read the value of lookup field ("+fieldname+") when xpath is ("+xpath+")");
			return "";	
		}
		
	}
	
	/**
	 * @Description Reads the value of check box from 1. Detail View page, 2. Edit Page Layout 3. Inline Edit Page Layout  
	 * @return Returns the value True/False as a String.
	 * @throws Exception
	 */
	public String GetCheckBoxValue() throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
						
			//Identifying the page type
			
			/*
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
					{
						
						System.out.println("The checkbox field ("+fieldname+") is not checked.");
						AddLogToCustomReport("The checkbox field ("+fieldname+") is not checked.", "Pass");
						return "True";
					}
					else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
					{
						System.out.println("The Checkbox field ("+fieldname+") is checked.");
						AddLogToCustomReport("The Checkbox field ("+fieldname+") is checked.", "Pass");
						return "True";
					}
					else
					{
						System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
						AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
						return "";
					}
				}
				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::div[1]/descendant::img[1]";
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					System.out.println("The Checkbox field ("+fieldname+") is "+remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt").toString().trim());
					AddLogToCustomReport("The Checkbox field ("+fieldname+") is "+remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt").toString().trim(), "Pass");
				
					return (remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt")).toString().trim();
				}
				else
				{
					System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
					AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
					return "";	
				}
				
			}
			else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("EDIT PAGE");
				xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
				{
					
					System.out.println("The checkbox field ("+fieldname+") is not checked.");
					AddLogToCustomReport("The checkbox field ("+fieldname+") is not checked.", "Pass");
					return "True";
				}
				else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
				{
					System.out.println("The Checkbox field ("+fieldname+") is checked.");
					AddLogToCustomReport("The Checkbox field ("+fieldname+") is checked.", "Pass");
					return "True";
				}
				else
				{
					System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
					AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
					return "";
				}
			}
			System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
			AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
			return "";
			*/
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
					{
						
						System.out.println("The checkbox field ("+fieldname+") is not checked.");
						AddLogToCustomReport("The checkbox field ("+fieldname+") is not checked.", "Pass");
						return "True";
					}
					else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
					{
						System.out.println("The Checkbox field ("+fieldname+") is checked.");
						AddLogToCustomReport("The Checkbox field ("+fieldname+") is checked.", "Pass");
						return "True";
					}
					else
					{
						System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
						AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
						return "";
					}
			
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::div[1]/descendant::img[1]";
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					System.out.println("The Checkbox field ("+fieldname+") is "+remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt").toString().trim());
					AddLogToCustomReport("The Checkbox field ("+fieldname+") is "+remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt").toString().trim(), "Pass");
				
					return (remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt")).toString().trim();								
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
				{
					
					System.out.println("The checkbox field ("+fieldname+") is not checked.");
					AddLogToCustomReport("The checkbox field ("+fieldname+") is not checked.", "Pass");
					return "True";
				}
				else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
				{
					System.out.println("The Checkbox field ("+fieldname+") is checked.");
					AddLogToCustomReport("The Checkbox field ("+fieldname+") is checked.", "Pass");
					return "True";
				}
				else
				{
					System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
					AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
					return "";
				}
				
				
			}
			System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
			AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
			return "";
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
			AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
			return "";
			
		}
		
	}
	
	/**
	 * @param Value
	 * @return Returns true on success else false
	 * @Description Verifies the value of view only (Any Text/Link) value from 1. Detail View 2. Inline Edit 3. Edit Layout page 
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueEquals(String Value) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
			Thread.sleep(3000L);
						
			//Identifying the page type
			/*
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
			{
				//System.out.println("xp_common_in_ed_and_vd:"+xp_common_in_ed_and_vd);
				System.out.println("---------->"+remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString());
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					//xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1])/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";									
				}
				
			}
			else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("EDIT PAGE");
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
			}
			*/
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
					
			
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";					
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");

				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
				
			}
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
			//Getting the value from field
			String aValue = "";
			aValue = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
			if(aValue.equals(Value.trim()))
			{
				System.out.println("Successfully verified the view only value("+Value+") of field ("+fieldname+").");
				AddLogToCustomReport("Successfully verified the view only value("+Value+") of field ("+fieldname+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
				AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
				return false;
			}
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
			AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
		
	}
	
	
	/**
	 * @param Value
	 * @return Returns true on success else false
	 * @Description Verifies the value of view only (Any Text/Link) value from 1. Detail View 2. Inline Edit 3. Edit Layout page 
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueContains(String Value) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
						
			//Identifying the page type
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
					//xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";								
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");

				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			}
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
			//Getting the value from field
			String aValue = "";
			aValue = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
			if(aValue.contains(Value.trim()))
			{
				System.out.println("Successfully verified the view only value("+Value+") of field ("+fieldname+").");
				AddLogToCustomReport("Successfully verified the view only value("+Value+") of field ("+fieldname+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
				AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
				return false;
			}
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
			AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
		
	}
	
	/**
	 * @param ValueDoesNotContain
	 * @return
	 * @Description Verifies that view only value does not contain supplied value for (Text value/Link value) of fields.  
	 * @Page Layout Acts on 1. Detail View 2. Edit Page 3. Inline Edit page
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueDoesNotContain(String ValueDoesNotContain) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
						
			//Identifying the page type
			/*
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1])/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";
															
				}
				
			}
			else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("EDIT PAGE");
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
			}
			*/
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
				
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					//xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1])/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
				
			}
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
			//Getting the value from field
			String aValue = "";
			aValue = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
			if(!aValue.contains(ValueDoesNotContain.trim()))
			{
				System.out.println("Verified successfully that view only value of field ("+fieldname+") does not contain ("+ValueDoesNotContain+").");
				AddLogToCustomReport("Verified successfully that view only value of field ("+fieldname+") does not contain ("+ValueDoesNotContain+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("Field Verification failed on fieldname ("+fieldname+") while checking does not contain ("+ValueDoesNotContain+")");
				AddLogToCustomReport("Field Verification failed on fieldname ("+fieldname+") while checking does not contain ("+ValueDoesNotContain+")", "Fail");
				return false;
			}
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Field Verification failed on fieldname ("+fieldname+") while checking does not contain ("+ValueDoesNotContain+")");
			AddLogToCustomReport("Field Verification failed on fieldname ("+fieldname+") while checking does not contain ("+ValueDoesNotContain+")", "Fail");
			return false;
		}
		
	}
	
	/**
	 * @param Value
	 * @return Returns true on success else false
	 * @Description Verifies the value of view only (Any Text/Link) value from 1. Detail View 2. Inline Edit 3. Edit Layout page 
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueStartsWith(String Value) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
						
			//Identifying the page type
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
					//xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";								
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");

				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			}
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
			//Getting the value from field
			String aValue = "";
			aValue = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
			if(aValue.startsWith(Value.trim()))
			{
				System.out.println("Successfully verified the view only value("+Value+") of field ("+fieldname+").");
				AddLogToCustomReport("Successfully verified the view only value("+Value+") of field ("+fieldname+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
				AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
				return false;
			}
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
			AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
		
	}
	
	/**
	 * @param Value
	 * @return Returns true on success else false
	 * @Description Verifies the value of view only (Any Text/Link) value from 1. Detail View 2. Inline Edit 3. Edit Layout page 
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueEndsWith(String Value) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
						
			//Identifying the page type
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[contains(@class,'itemBody')][1]/descendant-or-self::text()[1]";
					//xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]";
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";								
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");

				//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]";
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[local-name()='span' or local-name()='a'][text()][1]";
			}
			
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			
			//Getting the value from field
			String aValue = "";
			aValue = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
			if(aValue.endsWith(Value.trim()))
			{
				System.out.println("Successfully verified the view only value("+Value+") of field ("+fieldname+").");
				AddLogToCustomReport("Successfully verified the view only value("+Value+") of field ("+fieldname+").", "Pass");
				return true;
			}
			else
			{
				System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
				AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
				return false;
			}
					
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("VerifyViewOnlyValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
			AddLogToCustomReport("VerifyViewOnlyValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
			return false;
			
		}
		
	}
	
	
	
	
	/**
	 * @return
	 * @Page Layout: Support of Lightening UI in below two layout 1. Edit Page Layout 2. Inline Edit Page  
	 * @Description Can read the value from TextField, TextArea, DateLookup from record edit page and inline edit page. It cannot verify from lookup field, Single Select Picklist, Multiselect picklist and checkbox values. There are separate methods to accomplish these tyles of elements
	 * @throws Exception
	 */
	public boolean VerifyEditFieldValueEquals(String Value) throws Exception
	{
			try{
				
				WaitForPageToLoad(60);
				
				//Identifying the page type
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[1]";
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						//Not applicable in this logic			
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");

					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String aValue = "";
				aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value").trim();
				if(aValue.equals(Value.trim()))
				{
					System.out.println("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").");
					AddLogToCustomReport("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").", "Pass");
					return true;
				}
				else
				{
					System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
					AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
					return false;
				}							
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
				AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
				
			}
		
	}		
	
	/**
	 * @param ValueDoesNotContain
	 * @return
	 * @Description Verifies Edit field value does not contain supplied value
	 * @PageLayout 1. Inline Edit Layout 2. Edit Layout   
	 * @FieldType Text Box, Text Area, Date type  
	 * @throws Exception
	 */
	public boolean VerifyEditFieldValueDoesNotContain(String ValueDoesNotContain) throws Exception
	{
			try{
				
				WaitForPageToLoad(60);
				
				//Identifying the page type
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[1]";
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
				}
				*/
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String aValue = "";
				aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value").trim();
				if(!aValue.contains(ValueDoesNotContain.trim()))
				{
					System.out.println("Successfully verified that Edit field ("+fieldname+") does not contain ("+ValueDoesNotContain+").");
					AddLogToCustomReport("Successfully verified that Edit field ("+fieldname+") does not contain ("+ValueDoesNotContain+").", "Pass");
					return true;
				}
				else
				{
					System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+") while checking doesnot contain ("+ValueDoesNotContain+")");
					AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") while checking doesnot contain ("+ValueDoesNotContain+")", "Fail");
					return false;
				}							
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+") while checking doesnot contain ("+ValueDoesNotContain+")");
				AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") while checking doesnot contain ("+ValueDoesNotContain+")", "Fail");
				return false;
				
			}
		
	}		
	
	
	/**
	 * @return
	 * @Page Layout: Support of Lightening UI in below two layout 1. Edit Page Layout 2. Inline Edit Page  
	 * @Description Can read the value from TextField, TextArea, DateLookup from record edit page and inline edit page. It cannot verify from lookup field, Single Select Picklist, Multiselect picklist and checkbox values. There are separate methods to accomplish these tyles of elements
	 * @throws Exception
	 */
	public boolean VerifyEditFieldValueContains(String Value) throws Exception
	{
			try{
				
				WaitForPageToLoad(60);
				
				//Identifying the page type
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[1]";
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String aValue = "";
				aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value").trim();
				if(aValue.contains(Value.trim()))
				{
					System.out.println("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").");
					AddLogToCustomReport("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").", "Pass");
					return true;
				}
				else
				{
					System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
					AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
					return false;
				}							
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
				AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
				
			}
		
	}	
	/**
	 * @return
	 * @Page Layout: Support of Lightening UI in below two layout 1. Edit Page Layout 2. Inline Edit Page  
	 * @Description Can read the value from TextField, TextArea, DateLookup from record edit page and inline edit page. It cannot verify from lookup field, Single Select Picklist, Multiselect picklist and checkbox values. There are separate methods to accomplish these tyles of elements
	 * @throws Exception
	 */
	public boolean VerifyEditFieldValueStartsWith(String Value) throws Exception
	{
			try{
				
				WaitForPageToLoad(60);
				
				//Identifying the page type
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[1]";
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String aValue = "";
				aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value").trim();
				if(aValue.startsWith(Value.trim()))
				{
					System.out.println("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").");
					AddLogToCustomReport("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").", "Pass");
					return true;
				}
				else
				{
					System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
					AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
					return false;
				}							
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
				AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
				
			}
		
	}	
	/**
	 * @return
	 * @Page Layout: Support of Lightening UI in below two layout 1. Edit Page Layout 2. Inline Edit Page  
	 * @Description Can read the value from TextField, TextArea, DateLookup from record edit page and inline edit page. It cannot verify from lookup field, Single Select Picklist, Multiselect picklist and checkbox values. There are separate methods to accomplish these tyles of elements
	 * @throws Exception
	 */
	public boolean VerifyEditFieldValueEndsWith(String Value) throws Exception
	{
			try{
				
				WaitForPageToLoad(60);
				
				//Identifying the page type
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[1]";
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				//Getting the value from field
				String aValue = "";
				aValue = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value").trim();
				if(aValue.endsWith(Value.trim()))
				{
					System.out.println("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").");
					AddLogToCustomReport("Successfully verified the Edit field value("+Value+") of field ("+fieldname+").", "Pass");
					return true;
				}
				else
				{
					System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")");
					AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), Actual Value:("+aValue+") and Expected Value ("+Value+")", "Fail");
					return false;
				}							
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("VerifyEditFieldValue Failed on fieldname ("+fieldname+"), when xpath is:"+xpath);
				AddLogToCustomReport("VerifyEditFieldValue Failed on fieldname ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
				
			}
		
	}	
	
	
	/**
	 * @Description 
	 * @param CheckedORNotChecked
	 * @return
	 * @throws Exception
	 */
	public boolean VerifyCheckBoxValue(String CheckedORNotChecked) throws Exception
	{
				
		try{
			WaitForPageToLoad(60);
						
			//Identifying the page type
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
					{
						if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
						{
							System.out.println("Successfully verified checkbox field ("+fieldname+") as Not Checked.");
							AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Not Checked.", "Pass");
							return true;	
						}
						else
						{
							System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)");
							AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)", "Fail");
							return false;
						}
						
					}
					else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
					{
						if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
						{
							System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)");
							AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)", "Fail");
							return false;						
						}
						else
						{
							System.out.println("Successfully verified checkbox field ("+fieldname+") as Checked.");
							AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Checked.", "Pass");
							return true;	
						
						}
					}
					else
					{
						System.out.println("Unable to verify the value from checkbox field ("+fieldname+").");
						AddLogToCustomReport("Unable to verify the value from checkbox field ("+fieldname+").", "Fail");
						return false;
					}
			
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
					//xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::div[1]/descendant::img[1]";
					xpath =  "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant::img[@alt][1]";
					ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					if(remoteDriver.findElement(By.xpath(xpath)).getAttribute("alt").toString().trim().equalsIgnoreCase("True"))
					{
					if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
					{
						System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)");
						AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)", "Fail");
						return false;						
					}
					else
					{
						System.out.println("Successfully verified checkbox field ("+fieldname+") as Checked.");
						AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Checked.", "Pass");
						return true;	
					
					}
					}
					else
					{
						if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
						{
							System.out.println("Successfully verified checkbox field ("+fieldname+") as Not Checked.");
							AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Not Checked.", "Pass");
							return true;	
						}
						else
						{
							System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)");
							AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)", "Fail");
							return false;
						}
					}
									
					
				}
				else
				{
					System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
					AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
					return false;	
				}								
			}				
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				
				if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
				{
					if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
					{
						System.out.println("Successfully verified checkbox field ("+fieldname+") as Not Checked.");
						AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Not Checked.", "Pass");
						return true;	
					}
					else
					{
						System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)");
						AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)", "Fail");
						return false;
					}
					
				}
				else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
				{
					if(CheckedORNotChecked.trim().contains("Not") || CheckedORNotChecked.trim().contains("Un"))
					{
						System.out.println("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)");
						AddLogToCustomReport("The actual value did not match with expected value in checkbox field ("+fieldname+").Actual Value is (Checked)", "Fail");
						return false;						
					}
					else
					{
						System.out.println("Successfully verified checkbox field ("+fieldname+") as Checked.");
						AddLogToCustomReport("Successfully verified checkbox field ("+fieldname+") as Checked.", "Pass");
						return true;	
					
					}
				}
				else
				{
					System.out.println("Unable to verify the value from checkbox field ("+fieldname+").");
					AddLogToCustomReport("Unable to verify the value from checkbox field ("+fieldname+").", "Fail");
					return false;
				}
			}
			
		System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
		AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
		return false;
		
	}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to read the value from checkbox field ("+fieldname+").");
			AddLogToCustomReport("Unable to read the value from checkbox field ("+fieldname+").", "Fail");
			return false;
			
		}
		
	}
	
	
	/**
	 * @param ValueInPLField
	 * @return True if success else returns false
	 * @PageLayout Inline Edit / Edit Page Layout
	 * @Description Verifies the Default/Displayed value in single select pick list
	 * @throws Exception
	 */
	public boolean VerifyPLDefaultValue(String ValueInPLField) throws Exception
	{

		try
		{
			WaitForPageToLoad(60);
			
			//Identifying the page type
			/*
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";
					
				}		
				//System.out.println("No inline edit page found");
				
			}
			else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("EDIT PAGE");
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";
				
			}
			*/
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";
			
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
													
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'select')  or contains(@class,'uiMenu')][1]/descendant-or-self::a[normalize-space(text())][1]";
				
				
			}
			//Scrolling to element
			ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
			String Value = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
			
		if (Value.equals(ValueInPLField))
		{		
			AddLogToCustomReport("The selected value in picklist field ("+fieldname+"). is ("+Value+")", "Pass");
			System.out.println("The selected value in picklist field ("+fieldname+"). is ("+Value+")");
			return true;
		}
		else
		{
			System.out.println("Unable to read the value of picklist field ("+fieldname+") as xpath does not result any element.");
			AddLogToCustomReport("Unable to read the value of picklist field ("+fieldname+") as xpath does not result any element.", "Fail");
			return false;
		}
		}
		catch(Exception e)
		{
			AddLogToCustomReport("Unable to read the value of pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
			System.out.println("Unable to read the value of pick list field ("+fieldname+") when xpath is ("+xpath+")");
			return false;	
		}
		
	}

	  /**
	 	 * @author Sourav
	 	 * @PageDisplayMode Edit
	 	 * @Description Verify pick list field values from Edit page and sends the message to the Log
	 	 * @param Values
	 	 * @return boolean
	 	 * @throws Exception
	 	 */
	 	public boolean VerifyAllPLValue(String Values_SemicolonSeperated) throws Exception
	 	{
	 		
	 		//xpath="//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
			try
			{
				WaitForPageToLoad(60);
				
				//Identifying the page type
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
				}
				//Scrolling to element
				//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				//System.out.println("Before:"+xpath);
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				//System.out.println("After:"+xpath);
				getsingleWebelement.click();
				
				Thread.sleep(1000L);

				ArrayList<String> al_actual_values = new  ArrayList<String>();
				
				List<WebElement> All_elements = remoteDriver.findElements(By.xpath("//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'][1]/descendant-or-self::a[normalize-space(text())]"));
				for(WebElement web_el : All_elements)
				{
					ScrollToElement(web_el);
					al_actual_values.add(web_el.getText().trim());
				}
				
				PressTABKeyOnWindowAlert();
				
				List<String> ExpectedValues = Arrays.asList(Values_SemicolonSeperated.split(";"));
		 		String failedPLValue="";
		 		for(String exp:ExpectedValues)
		 		{
		 			if(!al_actual_values.toString().contains(exp))
		 			{	
		 				if (failedPLValue!="")
		 				{
		 					failedPLValue = failedPLValue + ";" + exp;
		 				}
		 				else
		 				{
		 					failedPLValue = exp;
		 				}
		 				
		 			}
		 			
		 		}
				
		 		if(failedPLValue=="")
		 		{
		 			System.out.println("Successfully verified the Available List of Values("+Values_SemicolonSeperated+") from PickList field ("+fieldname+")");
		 			AddLogToCustomReport("Successfully verified the Available List of Values("+Values_SemicolonSeperated+") from picklist field ("+fieldname+")", "Pass");
		 			return true;
		 		}
		 		else
		 		{
		 			System.out.println("Could not find pick list values ("+failedPLValue+") in the available list of field("+fieldname+").");
		 			AddLogToCustomReport("Could not find pick list values ("+failedPLValue+") in the available list of field("+fieldname+").", "Fail");
		 			return false;
		 		}
		 		
		 	}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
				System.out.println("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")");
				return false;
			}
			
	}
	 	
	 	
	 	/**
	 	 * @return
	 	 * @Description Clicks on view only link text value on 1. Detail View 2. Edit Page 3. Inline Edit Page layout
	 	 * @throws Exception
	 	 */
	 	public boolean ClickONViewOnlyLinkValue() throws Exception
		{
			
					
	 		try{
				WaitForPageToLoad(60);
							
				//Identifying the page type
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[@class='itemBody']/descendant-or-self::div[contains(@class,'data')][1]/descendant-or-self::a[1]";
						//xpath = "//div[normalize-space(@class)='forceInlineEdit'][1]/div[normalize-space(@class)='active'])[1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/following-sibling::div[@class='itemBody']/descendant-or-self::div[contains(@class,'data')][1]/descendant-or-self::a[text()='"+fieldname+"'][1]";
					}
					
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1])/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]/descendant-or-self::a[1]";
						//xpath = "//div[contains(@class,'oneContent') and contains(@class,'active')]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/following-sibling::div[@class='itemBody']/descendant-or-self::div[contains(@class,'data')][1]/descendant-or-self::a[text()='"+fieldname+"'][1]";
																
					}
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]/descendant-or-self::a[1]";
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/following-sibling::div[1]/descendant::div[contains(@class,'data')][1]/descendant-or-self::a[text()='"+fieldname+"'][1]"; 
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[@class='itemBody']/descendant-or-self::div[contains(@class,'data')][1]/descendant-or-self::a[1]";
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = xp_common_vd + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1])/../following-sibling::div[contains(@class,'itemBody')]/*[local-name()='span' or local-name()='div'][contains(@class,'data') or contains(@class,'field-value')]/descendant-or-self::a[1]";								
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::div[contains(@class,'data')][1]/descendant-or-self::a[1]";
					
					
				}
				//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				String Value = remoteDriver.findElement(By.xpath(xpath)).getText().trim();
				remoteDriver.findElement(By.xpath(xpath+"/descendant-or-self::*[text()][1]")).click();
				System.out.println("Clicked on value("+Value+") of field ("+fieldname+").");
				AddLogToCustomReport("Clicked on value("+Value+") of field ("+fieldname+").", "Pass");
				return true;
						
				
			}catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to find the text/link element to click against field ("+fieldname+").");
				AddLogToCustomReport("Unable to find the text/link element to click against field ("+fieldname+")", "Fail");
				return false;
				
			}
		}
	 	
	 	
	
		/**
		 * @return
		 * @PageType Only for Detail View page
		 * @Description This enables inline editing against the field 
		 * @throws Exception
		 */
		public boolean ClickToEnableInlineEditing() throws Exception
		{
						
				try{
					
					WaitForPageToLoad(60);
					
					
					if(
							(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
													&&
							(remoteDriver.getCurrentUrl().trim().contains("view"))
													&&
							(
								remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
									                ||
							    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
						    )
					  )
					{
						if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
						{
							System.out.println("INLINE EDIT PAGE");
							//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
							//do nothing
					
						}				
						else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
						{
							System.out.println("DETAIL VIEW PAGE");	
							xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/following-sibling::button[contains(@class,'inline-edit')][1]";
													
						}			
						
					}
					
					if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
					{
						System.out.println("---------EDIT VIEW-----------");
						//do nothing
					}
					
					
					remoteDriver.findElement(By.xpath(xpath)).click();
					System.out.println("Clicked on the inline editing button against field ("+fieldname+").");
					AddLogToCustomReport("Clicked on the inline editing button against field ("+fieldname+").", "Pass");
					return true;
							
					
				}catch(Exception e)
				{
					e.printStackTrace();
					System.out.println("Unable to click on inline editing button against the field ("+fieldname+").");
					AddLogToCustomReport("Unable to click on inline editing button against the field ("+fieldname+").","Fail");
					return false;
					
				}
			
		}
	 	
	 	
		/**
		 * @return True if click is successful else returns false
		 * @Description Clicks on any input field on Edit Layout and Inline Edit Layout  
		 * @throws Exception
		 */
		public boolean ClickONInputField() throws Exception
		{
						
				try{
					
					WaitForPageToLoad(60);
					
					//Identifying the page type
					/*
					if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
					{
						if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
						{
							System.out.println("INLINE EDIT PAGE");
							//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[1]";
							xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
							
						}		
						//System.out.println("No inline edit page found");
						
					}
					else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
					{
						System.out.println("EDIT PAGE");
						xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}
					
					*/	
					if(
							(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
													&&
							(remoteDriver.getCurrentUrl().trim().contains("view"))
													&&
							(
								remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
									                ||
							    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
						    )
					  )
					{
						if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
						{
							System.out.println("INLINE EDIT PAGE");
							xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
						}				
						else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
						{
							System.out.println("DETAIL VIEW PAGE");	
															
						}			
						
					}
					
					if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
					{
						System.out.println("---------EDIT VIEW-----------");

						xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}
					//Getting the value from field
					String Value = "";
					Value = remoteDriver.findElement(By.xpath(xpath)).getAttribute("value");
					remoteDriver.findElement(By.xpath(xpath)).click();
					System.out.println("Clicked on the value("+Value+") of field ("+fieldname+").");
					AddLogToCustomReport("Clicked on the value("+Value+") of field ("+fieldname+").", "Pass");
					return true;
							
					
				}catch(Exception e)
				{
					e.printStackTrace();
					System.out.println("Unable to click the value against field ("+fieldname+").");
					AddLogToCustomReport("Unable to click the value against field ("+fieldname+")","Fail");
					return false;
					
				}
			
		}
		
		
		
		/**
		 * @param Value
		 * @Description Types supplied value of Text(input) Field/ Test Area/ Date Field. This cannot be used to type in Salesforce Lookup 
		 * @returns True on successful typing else returns false
		 * @PageLayout Edit Page and Inline Edit page layout
		 * @throws Exception
		 */
		public boolean Type(String Value) throws Exception
		{
						
				try{
					
					WaitForPageToLoad(60);
					
					//Identifying the page type
					/*
					if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
					{
						if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
						{
							System.out.println("INLINE EDIT PAGE");
							//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[1]";
							xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
							
						}		
						//System.out.println("No inline edit page found");
						
					}
					else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
					{
						System.out.println("EDIT PAGE");
						xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}
					*/
					if(
							(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
													&&
							(remoteDriver.getCurrentUrl().trim().contains("view"))
													&&
							(
								remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
									                ||
							    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
						    )
					  )
					{
						if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
						{
							System.out.println("INLINE EDIT PAGE");
							xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
					
					
						}				
						else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
						{
							System.out.println("DETAIL VIEW PAGE");	
															
						}			
						
					}
					
					if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
					{
						System.out.println("---------EDIT VIEW-----------");
						xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}
					/*if(remoteDriver.findElements(By.tagName("iframe")).size()>0){
						xpath ="//div[contains(@class,'section-expandable ng-isolate-scope expanded')]/ancestor-or-self::div[1]/descendant::div/descendant::div/descendant::div/descendant::div/descendant::div[2]/descendant::input";
					}*/
					/*if(remoteDriver.findElements(By.xpath("//div[contains(@id,'oppSingleServicePgID:mainOpp:pgblkid')]/descendant::div[1]/descendant::div/descendant::fieldset/descendant::div/descendant::label[text()]")).size()>1){
						
						System.out.println("---------iframe VIEW-----------");
						xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
						
					}*/
					//Scrolling to element
					//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
					//WaitForElement(xpath, 30);
					getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
					getsingleWebelement.clear();
					//Thread.sleep(1000L);
					getsingleWebelement.sendKeys(Value);
					//JavascriptExecutor jsExecutor = (JavascriptExecutor) remoteDriver;
					//jsExecutor.executeScript("arguments[0].fireEvent('onchange');", getsingleWebelement);
									
					AddLogToCustomReport("Entered the value ("+Value+") in the field ("+fieldname+").", "Pass");
					System.out.println("Entered the value ("+Value+") in the field ("+fieldname+").");
					return true;
			
				}catch(Exception e)
				{
					e.printStackTrace();
					AddLogToCustomReport("Unable to enter the value ("+Value+") in the field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
					System.out.println("Unable to enter the value ("+Value+") in the field ("+fieldname+") when xpath is ("+xpath+")");
					return false;
					
				}
			
		}
		
		
		/**
		 * 
		 * @author Sourav Mukherjee
		 * @Description Verifies the field level error message in the edit page
		 * @return boolean
		 * @throws Exception
		 */
		public boolean VerifyFieldErrorMsgOnEditPage(String ErrorMessage) throws Exception
		{
			
			
			try
			{
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[1]";
						//Updated xpath - Sachin
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../../following-sibling::ul[contains(@class,'error')][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../../following-sibling::ul[contains(@class,'error')][1]";
					//Updated xpath - Sachin
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/*[normalize-space(text())='"+fieldname+"']/../../following-sibling::*[contains(@class,'error')][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../../following-sibling::ul[contains(@class,'error')][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");

					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/*[normalize-space(text())='"+fieldname+"']/../../following-sibling::*[contains(@class,'error')][1]";
					
				}
				//Scrolling to element
				ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));

				if (getsingleWebelement.getText().trim().contains(ErrorMessage.trim()))
				{
					System.out.println("Successfully verified the error message ("+ErrorMessage+") on field ("+fieldname+")");
					AddLogToCustomReport("Successfully verified the error message ("+ErrorMessage+") on field ("+fieldname+")", "Pass");
					return true;
				}
				else
				{
					System.out.println("Unable to verify the error message on field ("+fieldname+"). Actual Error Message was ("+getsingleWebelement.getText().trim()+") when Expected Error Message is ("+ErrorMessage+")");
					AddLogToCustomReport("Unable to verify the error message on field ("+fieldname+"). Actual Error Message was ("+getsingleWebelement.getText().trim()+") when Expected Error Message is ("+ErrorMessage+")", "Fail");
					return false;
				}
			}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to find the element when xpath is:"+xpath, "Fail");
				System.out.println("Unable to find the element when xpath is:"+xpath);
				e.printStackTrace();
				return false;
			}
		}
		
		
		/**
		 * @param Value
		 * @return boolean
		 * @throws Exception
		 * @Description Selects pick list field value by visible text
		 */
		public boolean SelectPL(String Value) throws Exception
		{
			
			//xpath="//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
			try
			{
				
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]/descendant::a[1]";
						System.out.println("xpath:"+xpath);
						
						/*
						Robot robot = new Robot();
						Point coordinates = remoteDriver.findElement(By.xpath(xpath)).getLocation();
						robot.mouseMove(coordinates.getX(),coordinates.getY());
						robot.mouseWheel(3);
						 */
						/*
						JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
						js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
						         
						
						Thread.sleep(3000L);
						
						//remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")).click();
						xpath = "(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]";
						//js = (JavascriptExecutor) remoteDriver;
						//js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
						//remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")).click();
						JavaScriptClick(remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")));
						*/
						
						getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
						//ScrollToElement(getsingleWebelement);
						Thread.sleep(3000L);		
						getsingleWebelement.click();
						Thread.sleep(5000L);
						remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")).click();
						
						
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";								
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'])[1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'active')]/descendant::div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				
					getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
					ScrollToElement(getsingleWebelement);
					Thread.sleep(1000L);		
					getsingleWebelement.click();
					Thread.sleep(1000L);
					remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")).click();
					
				}
				
				
				
				//Thread.sleep(1000L);
				if(remoteDriver.findElement(By.xpath(xpath+"/descendant::a[1]")).getText().trim().equals(Value))
				{
					AddLogToCustomReport("Selected the value ("+Value+") from picklist field ("+fieldname+").", "Pass");
					System.out.println("Selected the value ("+Value+") from picklist field ("+fieldname+").");
					return true;
				}
				else
				{
					AddLogToCustomReport("Unable to find the pick list field ("+fieldname+").", "Fail");
					System.out.println("--Unable to find the pick list field ("+fieldname+").");
					return false;
				}
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				AddLogToCustomReport("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
				System.out.println("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")");
				return false;
			}
		}
		
		
		public boolean SelectPLByJSClick(String Value) throws Exception
		{
			
			//xpath="//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
			try
			{
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					
				}
				if((remoteDriver.getCurrentUrl().trim().contains("/view")||remoteDriver.getCurrentUrl().trim().contains("/home")) && !remoteDriver.getCurrentUrl().trim().contains("rlName") &&!remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------VIEW DETAILS-----------");
					xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";								
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					//xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'active')]/descendant::div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					
					
				}
				//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				getsingleWebelement.click();
				//Thread.sleep(3000L);
				System.out.println("xpath:(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]");
				//remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")).click();
				JavaScriptClick(remoteDriver.findElement(By.xpath("(//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'])[1]/ul[1]/li/descendant-or-self::a[normalize-space(text())='"+Value.trim()+"'][1]")));
				
				//Thread.sleep(2000L);
				if(remoteDriver.findElement(By.xpath(xpath+"/descendant::a[1]")).getText().trim().equals(Value))
				{
					AddLogToCustomReport("Selected the value ("+Value+") from picklist field ("+fieldname+").", "Pass");
					System.out.println("Selected the value ("+Value+") from picklist field ("+fieldname+").");
					return true;
				}
				else
				{
					AddLogToCustomReport("Unable to find the pick list field ("+fieldname+").", "Fail");
					System.out.println("Unable to find the pick list field ("+fieldname+").");
					return false;
				}
				
			}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
				System.out.println("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")");
				return false;
			}
		}
		
		
		/**
		 * @param Value
		 * @return
		 * @throws Exception
		 */
		public boolean SelectPL_Contains(String Value) throws Exception
		{
			
			//xpath="//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
			try
			{
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					
				}
				if((remoteDriver.getCurrentUrl().trim().contains("/view")||remoteDriver.getCurrentUrl().trim().contains("/home")) && !remoteDriver.getCurrentUrl().trim().contains("rlName") &&!remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------VIEW DETAILS-----------");
					xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				}
				//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				getsingleWebelement.click();
				//Thread.sleep(1000L);
				
				remoteDriver.findElement(By.xpath("//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'][1]/descendant-or-self::a[contains(normalize-space(text()),'"+Value.trim()+"')][1]")).click();
				//Thread.sleep(1000L);
				if(remoteDriver.findElement(By.xpath(xpath+"/descendant::a[1]")).getText().trim().contains(Value))
				{
					AddLogToCustomReport("Selected the pick list value containing ("+Value+") from picklist field ("+fieldname+").", "Pass");
					System.out.println("Selected the pick list value containing ("+Value+") from picklist field ("+fieldname+").");
					return true;
				}
				else
				{
					AddLogToCustomReport("Unable to find the pick list value containing ("+Value+") for field ("+fieldname+").", "Fail");
					System.out.println("Unable to find the pick list value containing ("+Value+") for field ("+fieldname+").");
					return false;
				}
				
			}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");
				System.out.println("Unable to find the pick list field ("+fieldname+") when xpath is ("+xpath+")");
				return false;
			}
		}
		
		/**
	     * @author Sourav Mukherjee
	     * @Description Selects the picklist value by index where index starts from 1
	     * @param Index
	     * @return boolean
	     * @throws Exception
	     */
		public boolean SelectPLValueByIndex(int Index) throws Exception
		{
						
			try
			{
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					
				}
				if((remoteDriver.getCurrentUrl().trim().contains("/view")||remoteDriver.getCurrentUrl().trim().contains("/home")) && !remoteDriver.getCurrentUrl().trim().contains("rlName") &&!remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------VIEW DETAILS-----------");
					xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						xpath = xp_common_vd + "/descendant::section[contains(@class,'active')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";								
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[contains(@class,'uiMenu')][1]";
					
					
				}
				//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				getsingleWebelement.click();
				//Thread.sleep(3000L);
				
				remoteDriver.findElement(By.xpath("//div[contains(@class,'select-options') and contains(@class,'uiMenuList--short visible')][1]/descendant::div[@class='select-options' and @role='menu'][1]/ul[1]/li["+Index+"]/descendant-or-self::a[1]")).click();
				//Thread.sleep(1000L);
				AddLogToCustomReport("Selected the value by index ("+Index+") from picklist field ("+fieldname+").", "Pass");
	 			System.out.println("Selected the value by index ("+Index+") from picklist field ("+fieldname+").");
	 			return true;
				
			}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to choose the pick list field ("+fieldname+") value by index when xpath is ("+xpath+")", "Fail");
				System.out.println("Unable to find the pick list field ("+fieldname+") value by index when xpath is ("+xpath+")");
				return false;
			}
		}
		
		
		/**
		 * @param Value semicolon separated value for multiple
		 * @return boolean
		 * @throws Exception
		 * @Description Selects multiple values in the multi-select picklist field and adds to the Chosen list.
		 */
		public boolean MultiSelectAdd(String Value) throws Exception
		{
			//xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
			try
			{
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
					
				}
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				Select s = new Select(getsingleWebelement);
				
				
				List<String> eachPLValue = Arrays.asList(Value.split(";"));
				for(String str: eachPLValue)
				{
					s.selectByVisibleText(str);
					Thread.sleep(1000L);
					System.out.println("Multiselect pick list values are:"+str.trim());
					
				}
				AddLogToCustomReport("Successfully added values ("+Value+") for multi-select pick list field ("+fieldname+").", "Pass");	
				System.out.println("Successfully added values ("+Value+") for multi-select pick list field ("+fieldname+").");
				
				return true;
			}

			catch(Exception e)
			{
				AddLogToCustomReport("Unable to add values ("+Value+") for multi-select pick list field ("+fieldname+") when xpath is("+xpath+")", "Fail");	
				System.out.println("Unable to add values ("+Value+") for multi-select pick list field ("+fieldname+") when xpath is("+xpath+")");
				return false;
			}
		}
		

		/**
		 * @param Value
		 * @return boolean
		 * @throws Exception
		 * @Description Removes multiple values from chosen list to Available list of multi-select pick list field. 
		 * 	
		 *  */
		public boolean MultiSelectRemove(String Value) throws Exception
		{
			//xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
			try
			{
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
					
				}
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				Select s = new Select(getsingleWebelement);
				List<String> eachPLValue = Arrays.asList(Value.split(";"));
				for(String str: eachPLValue)
				{
					s.deselectByVisibleText(str);
				}
						
				AddLogToCustomReport("Successfully deselected values ("+Value+") from multi-select pick list field ("+fieldname+")", "Pass");	
				System.out.println("Successfully deselected values ("+Value+") from multi-select pick list field ("+fieldname+")");
				return true;
			}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to deselect values ("+Value+") from multi-select pick list field ("+fieldname+") when xpath is ("+xpath+")", "Fail");	
				System.out.println("Unable to deselect values ("+Value+") from multi-select pick list field ("+fieldname+") when xpath is ("+xpath+")");
				return false;
			}
		}
		
		
		/**
		 * @return boolean
		 * @throws Exception
		 * @Description Selects and Adds all the available values of multi-select pick list field from Available List to Chosen List 
		 */
		public boolean MultiSelectAddAll() throws Exception
		{
			//xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
			try
			{
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
				}
				*/		
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");

					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
				}
				WebElement getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				Select s = new Select(getsingleWebelement);
				String allvalues="";		
				List<WebElement> options = s.getOptions();
				for(WebElement eachOption: options)
				{
				
					s.selectByVisibleText(eachOption.getText().trim());
					if(allvalues.equals(""))
					{
						allvalues = eachOption.getText().trim() + ";";
					}
					else
					{
						allvalues = allvalues + eachOption.getText().trim() + ";";
					}
					
				}
				System.out.println("Successfully added values ("+allvalues+") in the multi-select pick list field "+fieldname);
				AddLogToCustomReport("Successfully added values ("+allvalues+") in the multi-select pick list field "+fieldname, "Pass");
				return true;
			}
			catch(Exception e)
			{
				System.out.println("Unable to find the element while adding all values to multiselect picklist field ("+fieldname+") when xpath is:"+xpath);
				AddLogToCustomReport("Unable to find the element while adding all values to multiselect picklist field ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
			}
		}
		
		

		/**
		 * @return boolean
		 * @throws Exception
		 * @Description Selects and Removes all the available values of multi-select pick list field from Chosen List to Available List. 
		 */
		public boolean MultiSelectRemoveAll() throws Exception
		{
			
			String allvalues="";
			try
			{
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
					
				}
			WebElement getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
			Select s = new Select(getsingleWebelement);
			s.deselectAll();
			
			List<WebElement> options = s.getOptions();
				
			
			for(WebElement eachOption: options)
			{		
				
				if (allvalues.equals(""))
				{
					allvalues = eachOption.getText().trim();
				}
				else
				{
					allvalues = allvalues +";"+ eachOption.getText().trim();
				}
				
				
			}

			System.out.println("Successfully deselected values ("+allvalues+") in the multi-select pick list field "+fieldname);
			AddLogToCustomReport("Successfully deselected values ("+allvalues+") in the multi-select pick list field "+fieldname, "Pass");
			return true;
			}
			catch(Exception e)
			{
				System.out.println("Unable to find the element while removing all values to multiselect picklist field ("+fieldname+") when xpath is:"+xpath);
				AddLogToCustomReport("Unable to find the element while removing all values to multiselect picklist field ("+fieldname+") when xpath is:"+xpath, "Fail");
				return false;
			}
		}
		
		
		/**
		 * @author Sourav
		 * @PageDisplayMode Edit
		 * @Description Verify the values displayed in Available list of a Multi-Select pick list field in Edit page
		 * @param Values
		 * @return boolean
		 * @throws Exception
		 */
		public boolean VerifyMPLAvailable(String Values) throws Exception
		{

			try
			{
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::select[normalize-space(@class)='select'][1]";
					
					
				}
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				Select s = new Select(getsingleWebelement);
				List<WebElement> options = s.getOptions();

				List<String> avail = new ArrayList<String>();
			
				for(WebElement eachOption: options)
				{
					avail.add(eachOption.getText().trim());
					//System.out.println("eachOption: "+eachOption.getText().trim());
				}
			
			
				List<String> AllavailValues = Arrays.asList(Values.split(";"));
				String failedPLValue="";
				for(String exp:AllavailValues)
				{
					if (!avail.contains(exp))
					{
						if (failedPLValue!="")
						{
							failedPLValue = failedPLValue + ";" + exp;
						}
						else
						{
							failedPLValue = exp;
						}
					}
				}
				if(failedPLValue=="")
				{
					System.out.println("Successfully verified the Available List of Values from Multiselect picklist field ("+fieldname+")");
					AddLogToCustomReport("Successfully verified the Available List of Values from Multiselect picklist field ("+fieldname+")", "Pass");
					return true;
				}
				else
				{
					System.out.println("Could not find multi select pick list values ("+failedPLValue+") in the available list of field("+fieldname+").");
					AddLogToCustomReport("Could not find multi select pick list values ("+failedPLValue+") in the available list of field("+fieldname+").", "Fail");
					return false;
				}
			
		}
			catch(Exception e)
			{
				AddLogToCustomReport("Unable to find the element when xpath is:"+xpath, "Fail");
				System.out.println("Unable to find the element when xpath is:"+xpath);
				return false;
				
			}
	}
		
		
		/**
		 * @author Sourav
		 * @PageDisplayMode Edit Page
		 * @Description Checks the checkbox field in Edit page 
		 * @return boolean
		 * @throws Exception
		 
		 */
		public boolean CheckBoxSelect() throws Exception
		{
		
		
		try
		{
			
			if(
					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
											&&
					(remoteDriver.getCurrentUrl().trim().contains("view"))
											&&
					(
						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
							                ||
					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
				    )
			  )
			{
				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
				{
					System.out.println("INLINE EDIT PAGE");
					xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
			
			
				}				
				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
				{
					System.out.println("DETAIL VIEW PAGE");	
													
				}			
				
			}
			
			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
			{
				System.out.println("---------EDIT VIEW-----------");
				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
				
				
			}
			if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
			{
				remoteDriver.findElement(By.xpath(xpath)).click();
				System.out.println("Successfully checked the checkbox for the field ("+fieldname+")");
				AddLogToCustomReport("Successfully checked the checkbox for the field ("+fieldname+")", "Pass");
				return true;
			}
			else if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
			{
				System.out.println("The Checkbox for the field ("+fieldname+") is already checked.");
				AddLogToCustomReport("The Checkbox for the field ("+fieldname+") is already checked.", "Pass");
				return true;
			}
			else
			{
				System.out.println("Unable to check the check box for field ("+fieldname+")");
				AddLogToCustomReport("Unable to check the check box for field ("+fieldname+"). Please verify the property value", "Fail");
				return false;
			}	
		
		}
		catch(Exception e)
		{
			System.out.println("Unable to find the element when xpath is: "+xpath);
			AddLogToCustomReport("Unable to find the element when xpath is:"+xpath,"Fail");
			return false;
		}
		}
		

		/**
		 * @author Sourav
		 * @PageDisplayMode Edit Page
		 * @Description UnChecks the checkbox field in Edit page 
		 * @return boolean
		 * @throws Exception
		 */
		public boolean CheckBoxDeSelect() throws Exception
		{
			
			try
			{	
				/*
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
						
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
					
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");

					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::input[@type='checkbox'][1]";
					
				}
				
				if(((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null)) || ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")!=null)))
				{
					remoteDriver.findElement(By.xpath(xpath)).click();
					System.out.println("Successfully unchecked the checkbox for the field ("+fieldname+")");
					AddLogToCustomReport("Successfully unchecked the checkbox for the field ("+fieldname+")", "Pass");
					return true;
				}
				else if ((remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("") || remoteDriver.findElement(By.xpath(xpath)).getAttribute("title").equals("Not Checked")) && (remoteDriver.findElement(By.xpath(xpath)).getAttribute("checked")==null))
				{
					System.out.println("Successfully unchecked the checkbox for the field ("+fieldname+")");
					AddLogToCustomReport("Successfully unchecked the checkbox for the field ("+fieldname+")", "Pass");
					return true;
				}
				else
				{
					System.out.println("Unable to uncheck the check box for field ("+fieldname+")");
					AddLogToCustomReport("Unable to uncheck the check box for field ("+fieldname+")", "Fail");
					return false;
				}
				
			}
			catch(Exception e)
			{
				System.out.println("Unable to find the element when xpath is: "+xpath);
				AddLogToCustomReport("Unable to find the element when xpath is:"+xpath,"Fail");
				return false;
			}
		}
		
		
		//Choose value from lookup
		
		/**
		 * @author Sourav
		 * @PageDisplayMode Edit Page
		 * @param LookUpValue
		 * @Description Selects the value from SFDC OOB lookup field. If the text box field is editable then it types the value in that field then clicks on the lookup icon and clicks on the hyperlink displayed in search lookup. In case the text box field is read only then directly clicks on the lookup icon and searches the expected value in the search lookup window and clicks on hyperlink. It also sets the focus to the parent window 
		 * @return boolean
		 * @throws Exception
		 */
		public boolean SelectFromLookup(String LookUpValue) throws Exception
        {
               
               String common_xpath = ""; 
               try
               {
            	   /*
                     if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
                     {
                            if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
                            {
                                   System.out.println("INLINE EDIT PAGE");
                                   xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
                                   common_xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/";
                            }             
                            //System.out.println("No inline edit page found");
                            
                     }
                     else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
                     {
                            System.out.println("EDIT PAGE");
                            xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
                            common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/"; 
                     }
                             
                      */
            	   
       			if(
    					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
    											&&
    					(remoteDriver.getCurrentUrl().trim().contains("view"))
    											&&
    					(
    						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
    							                ||
    					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
    				    )
    			  )
    			{
    				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
    				{
    					System.out.println("INLINE EDIT PAGE");
    					 xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
                         common_xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/";
                
    			
    			
    				}				
    				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
    				{
    					System.out.println("DETAIL VIEW PAGE");	
    													
    				}			
    				
    			}
    			
    			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
    			{
    				System.out.println("---------EDIT VIEW-----------");
    				xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
                    common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/"; 
           
    				
    				
    			}
                     ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
                     remoteDriver.findElement(By.xpath(xpath)).sendKeys(LookUpValue);
                     Thread.sleep(2000L);
                     //xpath = common_xpath +"../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]/following-sibling::div[contains(@class,'lookup')][1]/descendant-or-self::div[@class='primaryLabel' and normalize-space(@title)='"+LookUpValue+"'][1]";
                     //xpath = common_xpath + "../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]/following-sibling::div[contains(@class,'lookup')][1]/descendant::div[normalize-space(@class)='listContent'][1]/descendant::ul[contains(@class,'lookup') and contains(@class,'list') and contains(@class,'visible')][1]/li[1]/a[1]/div[contains(@class,'body')][1]/div[contains(@class,'primaryLabel')][1]";
                     //xpath = common_xpath + "../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]/following-sibling::div[1]/div[contains(@class,'listContent')][1]/descendant::ul[contains(@class,'lookup') and contains(@class,'list') and contains(@class,'visible')][1]/li[1]/a[1]/descendant::div[contains(@class,'primaryLabel')][1]";
                    // xpath = common_xpath + "../following-sibling::div[1]/descendant::li/a/descendant::div[contains(@class,'primaryLabel') and @title='"+LookUpValue+"'][1]/descendant::mark[text()='"+LookUpValue+"'][1]";
                     xpath = common_xpath + "ancestor::label[1]/following-sibling::div[1]/descendant::div[contains(@class,'searchButton') and contains(@class,'lookup')]/descendant::span[contains(@class,'itemLabel') and contains(@title,'"+LookUpValue+"')][1]";
                     System.out.println("xpath of exact match:"+xpath);  
                     
                     JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
                     js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
                     
                     
                     //remoteDriver.findElement(By.xpath(xpath)).click();
                     Thread.sleep(3000L);
                     xpath = "//div[contains(@class,'searchWrapper')][1]/descendant::a[text()='"+LookUpValue+"'][1]";
                     remoteDriver.findElement(By.xpath(xpath)).click();
                     System.out.println("Selected the value ("+LookUpValue+") from lookup field ("+fieldname+")");
                     AddLogToCustomReport("Selected the value ("+LookUpValue+") from lookup field ("+fieldname+")", "Pass");
                     return true;               
               }
               catch(Exception e)
               {
                     e.printStackTrace();
                     System.out.println("Unable to find the value from lookup "+fieldname+" when xpath is: "+xpath);
                     AddLogToCustomReport("Unable to find the value from lookup "+fieldname+" when xpath is: "+xpath,"Fail");
                     return false;
                     
               }
               
        }

		/**
		 * @return
		 * @throws Exception
		 */
		public boolean RemoveFromLookup() throws Exception
        {
               
               String common_xpath = ""; 
               try
               {
            	  
       			if(
    					(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
    											&&
    					(remoteDriver.getCurrentUrl().trim().contains("view"))
    											&&
    					(
    						remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
    							                ||
    					    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
    				    )
    			  )
    			{
    				if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
    				{
    					System.out.println("INLINE EDIT PAGE");
    				
    					//xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='\"+fieldname+\"'][1]/../following-sibling::div[1]/descendant::span[contains(@class,'delete')][1]";
                        //common_xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/";
                        xpath = "//div[contains(@class,'test-id__record-layout-container riseTransitionEnabled')][1]/following-sibling::div[contains(@class,'riseTransitionEnabled test-id__inline-edit-record-layout-container')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::span[contains(@class,'delete')][1]";
                               
    				}				
    				else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
    				{
    					System.out.println("DETAIL VIEW PAGE");	
    													
    				}			
    				
    			}
    			
    			if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
    			{
    				System.out.println("---------EDIT VIEW-----------");
    				 xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant::span[contains(@class,'delete')][1]";
                     //common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/"; 
    				 //ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
    				 //remoteDriver.findElement(By.xpath(xpath)).click();
    				
    			}
    			if(remoteDriver.findElement(By.xpath("//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::iframe")).isDisplayed()){
    				
    				xpath="";
    				
    			}
    			JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
                js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
         
                
                     
                     AddLogToCustomReport("Successfully deleted the existing lookup value.", "Pass");
                     System.out.println("Successfully deleted the existing lookup value.");
                     return true;
               }
               catch(Exception e)
               {
                     e.printStackTrace();
                     System.out.println("Unable to remore the existing value from lookup field "+fieldname+" when xpath is: "+xpath);
                     AddLogToCustomReport("Unable to remore the existing value from lookup field "+fieldname+" when xpath is: "+xpath,"Fail");
                     return false;
                     
               }
               
        }
		
		public boolean SelectFromLookup_CreateNew() throws Exception
		{
			
			
			String common_xpath = ""; 
			try
			{
				Thread.sleep(4000L);
				WaitForPageToLoad(30);
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
						common_xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/";
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
					common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/"; 
				}
				*/	
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
						common_xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/";
			
				
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
														
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]";
					common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::span[text()='"+fieldname+"'][1]/"; 
			
					
					
				}
				//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				//MouseScrol_Down();
				
				//remoteDriver.findElement(By.xpath(xpath)).click();
				JavascriptExecutor js = (JavascriptExecutor) remoteDriver;
                js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
         
				
				Thread.sleep(3000L);
				//xpath = common_xpath +"../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]/following-sibling::div[contains(@class,'lookup')][1]/descendant-or-self::div[@class='primaryLabel' and normalize-space(@title)='"+LookUpValue+"'][1]";
				xpath = common_xpath + "../following-sibling::div[1]/descendant-or-self::input[@aria-autocomplete='list' and @type='text'][1]/following-sibling::div[contains(@class,'lookup')][1]/descendant::div[contains(@class,'createNew itemContainer')][1]/descendant-or-self::span[contains(@class,'itemLabel')][1]";
				//remoteDriver.findElement(By.xpath(xpath)).click();
				
				js = (JavascriptExecutor) remoteDriver;
                js.executeScript("var evt = document.createEvent('MouseEvents');" + "evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" + "arguments[0].dispatchEvent(evt);", remoteDriver.findElement(By.xpath(xpath)));
         
                
				System.out.println("Clicked on lookup option to create new record against lookup field ("+fieldname+")");
				AddLogToCustomReport("Clicked on lookup option to create new record against lookup field ("+fieldname+")", "Pass");
				return true;			
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to find the Create New option from lookup "+fieldname+" when xpath is: "+xpath);
				AddLogToCustomReport("Unable to find the Create New option from lookup "+fieldname+" when xpath is: "+xpath,"Fail");
				return false;
				
			}
			
		}
		
		
		public boolean SelectFromDateLookup(String YYYY,String MONTH,String DAY) throws Exception
		{
			xpath = "//div[contains(@class,'DESKTOP') and contains(@class,'open active') and @aria-hidden='false'][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::a[contains(@class,'date')][1]";
			try
			{
				System.out.println(YYYY);
				System.out.println(MONTH);
				System.out.println(DAY);
				String common_xpath = "";
				/*
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") || remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals(""))
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::a[contains(@class,'date')][1]";
						common_xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/";
					}		
					//System.out.println("No inline edit page found");
					
				}
				else if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("EDIT PAGE");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::a[contains(@class,'date')][1]";
					common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/"; 
				}
				*/
				if(
						(!remoteDriver.getCurrentUrl().trim().contains("rlName"))
												&&
						(remoteDriver.getCurrentUrl().trim().contains("view"))
												&&
						(
							remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("visible") 
								                ||
						    remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().equals("")
					    )
				  )
				{
					if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("risen"))
					{
						System.out.println("INLINE EDIT PAGE");
						xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::a[contains(@class,'date')][1]";
						//common_xpath = xp_common_in_ed + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/";
						System.out.println("xpath:"+xpath);
						//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
						
				
					}				
					else if(remoteDriver.findElement(By.xpath(xp_common_in_ed_and_vd)).getAttribute("class").toString().contains("hideEl"))
					{
						System.out.println("DETAIL VIEW PAGE");	
						//not applicable here
					}			
					
				}
				
				if(remoteDriver.findElement(By.xpath("//body[normalize-space(@class)='desktop'][1]")).getAttribute("style").toString().contains("hidden"))
				{
					System.out.println("---------EDIT VIEW-----------");
					xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/../following-sibling::div[1]/descendant-or-self::a[contains(@class,'date')][1]";
					common_xpath = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/span[text()='"+fieldname+"'][1]/"; 
			
					
					
				}
				
				
				//ScrollToElement(remoteDriver.findElement(By.xpath(xpath)));
				remoteDriver.findElement(By.xpath(xpath)).click();
				Thread.sleep(1000L);
				
				//Selecting Month
				xpath = "//div[contains(@class,'visible') and contains(@class,'DESKTOP') and contains(@class,'Date')][1]/descendant-or-self::div[contains(@class,'month')]/descendant-or-self::h2[contains(@class,'month')][1]";
				int i = 0;
				do{
					if(!remoteDriver.findElement(By.xpath(xpath)).getText().equalsIgnoreCase(MONTH.trim()))
					{
						remoteDriver.findElement(By.xpath("//div[contains(@class,'visible') and contains(@class,'DESKTOP') and contains(@class,'Date')][1]/descendant-or-self::div[contains(@class,'month')]/descendant-or-self::div[contains(@class,'next')][1]/descendant-or-self::a[1]")).click();
				
					}
					else
					{
						i = 1;
						remoteDriver.findElement(By.xpath(xpath)).click();
					}
				}while(i==0);
					
				//Selecting Year
				xpath = "//div[contains(@class,'visible') and contains(@class,'DESKTOP') and contains(@class,'Date')][1]/descendant-or-self::select[1]";
				Select s = new Select(remoteDriver.findElement(By.xpath(xpath)));
				s.selectByVisibleText(YYYY);
				
				
				//Select day
				xpath = "//div[contains(@class,'visible') and contains(@class,'DESKTOP') and contains(@class,'Date')][1]/descendant-or-self::span[(contains(@class,'weekday') or contains(@class,'weekend')) and normalize-space(text())='"+DAY+"']";
				remoteDriver.findElement(By.xpath(xpath)).click();
				System.out.println("Successfully selected the date value YEAR("+YYYY+") MONTH("+MONTH+") DAY("+DAY+") from date lookup field ("+fieldname+")");
				AddLogToCustomReport("Successfully selected the date value YEAR("+YYYY+") MONTH("+MONTH+") DAY("+DAY+") from date lookup field ("+fieldname+")", "Pass");
				return true;	
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to select the date value from date lookup field ("+fieldname+") when xpath is: "+xpath);
				AddLogToCustomReport("Unable to select the date value from date lookup field ("+fieldname+") when xpath is: "+xpath,"Fail");
				return false;
				
			}
			
		}
		
		
	/**
	 * @author Sourav
	 * @Description Waits for specified time for the field to be displayed in the UI
	 * @param waitingTimeinSec
	 * @return boolean
	 * @throws Exception
	 */
	public boolean WaitForElement(long waitingTimeinSec) throws Exception
	{
		 xpath = "//*[normalize-space(text())='"+fieldname+"']";
		 try {
			 
			 if (remoteDriver.toString().contains("InternetExplorerDriver"))
     	 	 {
     	 			WebDriverWaitForElement(xpath,waitingTimeinSec);
     	 			return true;
     	 	 }
			 else
			 {
             remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinSec));
             List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
             if (myDynamicElement.size() > 0)
             {
            	 AddLogToCustomReport("The field ("+fieldname+") was available in the application.", "Pass");
            	 return true;
             }
             else
             {
            	 AddLogToCustomReport("Could not find the field ("+fieldname+") in the application.", "Fail");
            	 return false;
             }
			 }
             //System.out.println("The value of dynamic webelement is:"+myDynamicElement.isDisplayed());
             //return myDynamicElement.isDisplayed();
             }
         catch(NoSuchElementException e)
             {
             System.out.println("Could not find the element after waiting for specified time.");
             AddLogToCustomReport("Could not find the button ("+fieldname+") in the application.", "Fail");
             return false;
             //return false;
             }
	}
	
	
	/**
	 * @author Cognizant
	 * @param YesORNo
	 * @Description Verify if a field label is present in the View Details page
	 * @return
	 * @throws Exception
	 */
	public boolean IsDisplayed(String YesORNo) throws Exception
    {
           xpath = "//*[normalize-space(text())='"+fieldname+"']";
           
           //System.out.println();
           
           if (YesORNo.equalsIgnoreCase("Yes"))
           {
                  try
                  {
                  if((remoteDriver.findElement(By.xpath(xpath)).isDisplayed()))
                  {
                        System.out.println("Successfully verified the existence of the field ("+fieldname+").");
                        AddLogToCustomReport("Successfully verified the existence of the field ("+fieldname+").", "Pass");
                        return true;  
                  }
                  else
                  {
                        System.out.println("Could not find the field ("+fieldname+") in the application.");
                        AddLogToCustomReport("Could not find the field ("+fieldname+") in the application.", "Fail");
                        return false;
                  }
                  }catch(Exception e)
                  {
                        System.out.println("Could not find the field ("+fieldname+") in the application when xpath is:"+xpath);
                        AddLogToCustomReport("Could not find the field ("+fieldname+") in the application when xpath is:"+xpath, "Fail");
                        e.printStackTrace();
                        return false;
                  }
           }
           else if (YesORNo.equalsIgnoreCase("No"))
           {
                  try
                  {
                  if((remoteDriver.findElement(By.xpath(xpath)).isDisplayed()))
                  {
                        System.out.println("The field ("+fieldname+") is present in the UI when it is not expected to be.");
                        AddLogToCustomReport("The field ("+fieldname+") is present in the UI when it is not expected to be.", "Fail");
                        return false;
                  }
                  else
                  {
                        System.out.println("Successfully verified that the field ("+fieldname+") is not present in the UI.");
                        AddLogToCustomReport("Successfully verified that the field ("+fieldname+") is not present in the UI.", "Pass");
                        return true;
                  }
                  }catch(Exception e2)
                  {
                        System.out.println("Successfully verified that the field ("+fieldname+") is not present in the UI.");
                        AddLogToCustomReport("Successfully verified that the field ("+fieldname+") is not present in the UI.", "Pass");
                        return true;
                  }
           }
           else
           {
                  System.out.println("The input parameter supplied in IsDisplayed() function is not correct. It should be either Yes or No");
                  AddLogToCustomReport("The input parameter supplied in IsDisplayed() function is not correct. It should be either Yes or No", "Fail");
                  return false;
           }
    }

	
	/**
	 * @param element
	 * @Description Scroll vertically/ horizontally to make the element visible on the screen. 
	 * @throws Exception
	 */
	public void ScrollToElement(WebElement element) throws Exception
	{
		
		try
		{
			((JavascriptExecutor)remoteDriver).executeScript("arguments[0].scrollIntoView();", element);
			
			//Coordinates coordinate = ((Locatable) element).getCoordinates();
			//Point cord = element.getLocation();
			//cord.getY();
			//- 300;
			//Locatable
						
			//Point coordinates = element.getLocation();
			
			//Robot robot = new Robot();
			//robot.mouseWheel(1);
			
			
			
			//coordinate.onPage();
			//coordinate.onScreen();
			//coordinate.inViewPort();
					
			System.out.println("Successfully scrolled untill element.");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to scroll until elemnt");
		}
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param timeOutInSeconds
	 * @return void
	 * @throws Exception
	 * @Description Waits for the page to reach ready state 
	 * @Date Aug 7, 2014
	 */
	public void WaitForPageToLoad(int timeOutInSeconds) throws Exception
	{ 
		
		String command = "return document.readyState"; 

		try
		{
		for (int i=0; i<timeOutInSeconds; i++)
		{ 
			try
			{
				Thread.sleep(1000L);
			}
			catch (InterruptedException e)
			{
				System.out.println("Unable to load the webpage");				
				
			} 
			
			if (remoteDriver.executeScript(command).toString().equals("complete"))
			{ 
				//System.out.println("Inside WaitForPageToLoad(Success)");
				break; 
			} 
			
			
		} 
		}catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * @param Message
	 * @param Result
	 * @throws Exception
	 */
	public void AddLogToCustomReport(String Message, String Result) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param 1. xpath of the element. 2. Waiting Time in Second
	 * @return boolean
	 * @throws Exception
	 * @Description Waits for the specified time until the webelemnt is available to WebDriver
	 * @Date Aug 7, 2014
	 */
	public boolean WaitForElement(String xpath, long waitingTimeinsec) throws Exception
    {
         try {
        	 	        		
        	remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(waitingTimeinsec));
     		List<WebElement> myDynamicElement = remoteDriver.findElements(By.xpath(xpath));
     		if (myDynamicElement.size() > 0)
     		{
     			System.out.println("Success: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return true;
     		}
     		else
     		{
     			System.out.println("Unsuccess: WaitForElement->Number of Element present is: "+myDynamicElement.size());
     			return false;
     		} 
        }
         catch(NoSuchElementException e)
         {
        	 e.printStackTrace();
             System.out.println("Exception inside WaitForElement:"+xpath);
             return false;
         }
     }
	
	public void MouseScrol_Down() throws Exception
	{
		 Robot r = new Robot();
	     for(int i = 0; i < 20; i++){
	         //scroll and wait a bit to give the impression of smooth scrolling
	         r.mouseWheel(1);
	         try{ Thread.sleep(50); }catch(InterruptedException e){}
	     }
	}
	public void MouseScrol_Up() throws Exception
	{
		 Robot r = new Robot();
	     for(int i = 20; i > 0; i--){
	         //scroll and wait a bit to give the impression of smooth scrolling
	         r.mouseWheel(1);
	         try{ Thread.sleep(50); }catch(InterruptedException e){}
	     }
	}
     
	/**
	 * @author Sourav Mukherjee
	 * @Param NA
	 * @return void
	 * @throws Exception
	 * @Description Press TAB Key using Robot Class
	 * @Date Jan, 2015
	 */
	public void PressTABKeyOnWindowAlert() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			
			System.out.println("Pressed Tab Key on Window Alert.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
			System.out.println("Unable to press Tab key on Window Alert");
		}
		
	}
	public void PressF12Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_F12);
			robot.keyRelease(KeyEvent.VK_F12);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	public void PressPageUPKey() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_PAGE_UP);
			robot.keyRelease(KeyEvent.VK_PAGE_UP);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	
	public void PressPageDownKey() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	
	public void PressF5Key() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_F5);
			robot.keyRelease(KeyEvent.VK_F5);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
	
		}
		
	}
	
	/**
	 * @param we
	 * @throws Exception
	 */
	public void JavaScriptClick(WebElement we) throws Exception
	{
		try{
			
			remoteDriver.executeScript("arguments[0].click();", we);
			System.out.println("Successfully clicked by JS on element.");
			AddLogToCustomReport("Successfully clicked by JS on element.", "Pass");
			
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to click by JS on element.");
			AddLogToCustomReport("Unable to click by JS on element.", "Fail");
			
		}
	}
	/**
	 * @author Sourav Mukherjee
	 * @Param 1. xpath of the element, 2. Time specified in second
	 * @return WebElement
	 * @throws Exception
	 * @Description Waits for the specified time until the webelemnt is available to WebDriver. This uses WebDriverWait class 
	 * @Date Aug 7, 2014
	 */
	public WebElement WebDriverWaitForElement(String xpath, long waitingTimeinsec) throws Exception
    {
		WebElement element=null;
        try {
        	 	WebDriverWait wait = new WebDriverWait(remoteDriver, Duration.ofSeconds(waitingTimeinsec));
        	 	element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
        	 	return element;
           	 }
         	catch(NoSuchElementException e)
         	{
         		e.printStackTrace();
         		System.out.println("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec");
         		AddLogToCustomReport("Could not find the element even after waiting explicitly for ("+waitingTimeinsec+")sec", "Fail");
         		return element;
        	 
         	}
     }
}
