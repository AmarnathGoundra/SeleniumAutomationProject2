package SOURCE_CODE.SFDC;

import io.appium.java_client.AppiumDriver;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.MPException;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

public class MemberOfField extends PageBase {

	public String fieldname;
	public String xpath;
	public WebElement getsingleWebelement;

	public MemberOfField(RemoteWebDriver remoteDriver) {
		super(remoteDriver);	
	}
	
	public MemberOfField(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}
	
	
public boolean Type(String Value) throws Exception {
		
		xpath = "(//*[normalize-space(text())='" + fieldname
				+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[(local-name()='input' or local-name()='textarea') and @type !='hidden'])[1]";

		System.out.println("xpath for Type-" + xpath);
		try {

			getsingleWebelement = getElement(xpath);
			enterText(getsingleWebelement, Value, Value);

			System.out.println("Entered the value (" + Value + ") in the field (" + fieldname + ").");
			return true;
		} catch (Exception e) {
			System.out.println("Unable to enter the value (" + Value + ") in the field (" + fieldname
					+ ") when xpath is (" + xpath + ")");
			e.printStackTrace();
			return false;
		}
	}

	public boolean VerifyFieldErrorMsgOnEditPage(String ErrorMessage) throws Exception {
		xpath = "//*[contains(normalize-space(text()),'" + fieldname
				+ "')][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[contains(@class,'errorMsg')]";
		
		
		try {
			getsingleWebelement = getElement(xpath);
				// System.out.println("Inside Type:"+allposblefieldelements.size());
				if (getText(getsingleWebelement).trim().contains(ErrorMessage.trim())) {
					System.out.println("Successfully verified the error message (" + ErrorMessage + ") on field ("
							+ fieldname + ")");
					AddLogToCustomReport("Pass","Successfully verified the error message (" + ErrorMessage + ") on field ("
							+ fieldname + ")");
					return true;
				} else {
					System.out.println("Unable to verify the error message on field (" + fieldname
							+ "). Actual Error Message was (" + getText(getsingleWebelement).trim()
							+ ") when Expected Error Message is (" + ErrorMessage + ")");
					AddLogToCustomReport("Fail", "Unable to verify the error message on field (" + fieldname + "). Actual Error Message was (" + getText(getsingleWebelement).trim() + ") when Expected Error Message is (" + ErrorMessage + ")");
					return false;
				}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:" + xpath);
			AddLogToCustomReport("Fail", "Unable to verify the error message on field (" + fieldname + "). Actual Error Message was (" + getText(getsingleWebelement).trim() + ") when Expected Error Message is (" + ErrorMessage + ")");
			e.printStackTrace();
			return false;
		}
		// xpath =
				// "(//*[normalize-space(text())='"+fieldname+"'][1]/ancestor-or-self::*[local-name()='td'
				// or local-name()='th'][1])/following-sibling::*[local-name()='td' or
				// local-name()='th'][1]/descendant-or-self::*[@type !='hidden' and
				// contains(@class,'errorMsg')]";
	}
	
	public String GetViewOnlyValue() throws Exception {

		String Value = "";
		xpath = "//*[normalize-space(text())='" + fieldname
				+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]";
		try {
				Value = getText(getElement(xpath));
				AddLogToCustomReport("Pass", "The view only value of field ("+fieldname+") is ("+Value+")");
				System.out.println("The value of field (" + fieldname + ") is (" + Value + ")");
				return Value;

		} catch (Exception e) {
			AddLogToCustomReport("Fail","Unable to read the value of field ("+fieldname+")");
			System.out.println("Unable to find the element when xpath is: " + xpath);
			return "";

		}
	}
	
	public boolean VerifyViewOnlyValueEquals(String Value) throws Exception {
	
		xpath = "//*[normalize-space(text())='" + fieldname
				+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]";
		try {
				String text = getText(getElement(xpath));
				if (text.equals(Value)) {
					AddLogToCustomReport("Pass", "The value(" + Value + ") has been verified successfully for the field(" + fieldname + ")");
					System.out.println(
							"The value(" + Value + ") has been verified successfully for the field(" + fieldname + ")");
					return true;
				} else {
					AddLogToCustomReport("Fail", "Unable to verify the value in field ("+fieldname+")");
					System.out.println("Could not find the value(" + Value + ") for the field(" + fieldname
							+ "). Actual Value:" + text);
					return false;
				}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is: " + xpath);
			AddLogToCustomReport("Fail", "Unable to verify the value in field ("+fieldname+")");
			return false;

		}
	}
	

	
	/**
	 * @return
	 * @throws Exception
	 */
	//pending testing
	public boolean ClickONViewOnlyValue() throws Exception {
		
		xpath = "((//*[normalize-space(text())='" + fieldname
				+ "'])[1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1])/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]";

		try {
			getsingleWebelement = getElement(xpath);
			
			this.click(getsingleWebelement, fieldname);
			AddLogToCustomReport("Pass", "Clicked on view only value  of field ("+fieldname+")");
			return true;
			
		} catch (Exception e) {
			
			AddLogToCustomReport("Fail", "Unable to click on viewonly value in field ("+fieldname+")");
			e.printStackTrace();
			return false;
		}
	}
	

	/**
	 * @author Cognizant
	 * @Description Clicks on the hyperlink present beside a field in View Details
	 *              page
	 * @returns true if click is successful else returns false
	 * @throws Exception
	 */
	
	public boolean ClickONViewOnlyLinkValue() throws Exception {
		
		xpath = "((//*[normalize-space(text())='" + fieldname
				+ "'])[1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1])/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::a[1]";
		try {
			getsingleWebelement = getElement(xpath);
			
			this.click(getsingleWebelement, fieldname);
			AddLogToCustomReport("Pass", "Clicked on view only value  of field ("+fieldname+")");
			return true;
			
		} catch (Exception e) {
			
			AddLogToCustomReport("Fail", "Unable to click on viewonly value in field ("+fieldname+")");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Cognizant
	 * @Description Clicks on a particular field value in the Edit page
	 * @return
	 * @throws Exception
	 */
	public boolean Click() throws Exception {
		xpath = "((//*[normalize-space(text())='" + fieldname
				+ "'])[1]/ancestor-or-self::*[local-name()='td' or local-name()='th'  or local-name()='div'][1])/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[(local-name()='input' or local-name()='textarea') and @type !='hidden']";
		try {
			getsingleWebelement = getElement(xpath);
			
			this.click(getsingleWebelement, fieldname);
			AddLogToCustomReport("Pass", "Clicked on the edit field in ("+fieldname+")");
			return true;
			
		} catch (Exception e) {
			
			AddLogToCustomReport("Fail", "Unable to click on editfield ("+fieldname+")");
			e.printStackTrace();
			return false;
		}
	}
	

	

	/**
	 * @param Value
	 * @return boolean
	 * @throws Exception
	 * @Description Selects pick list field value by visible text
	 */
	public boolean SelectPL(String Value) throws Exception {
		// Working xpath =
		// "((//*[text()='"+fieldname+"'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='select']";
		xpath = "(//*[normalize-space(text())='" + fieldname+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[local-name()='select'])[1]";
	
		
		try {
			getsingleWebelement = getElement(xpath);
			if(getAttributeValue(getsingleWebelement, "type").toString().trim().equalsIgnoreCase("select-one") || getAttributeValue(getsingleWebelement, "tagName").toString().trim().equalsIgnoreCase("select"))
			{
				Select s = new Select(getsingleWebelement);
				s.selectByVisibleText(Value);
				AddLogToCustomReport("Pass","Selected picklist value ("+Value+") in field ("+fieldname+")");
				return true;
			}
			return false;
		}
		catch(Exception e)
		{
			AddLogToCustomReport("Fail", "Unable to select the picklist value("+Value+") in field ("+fieldname+")");
			e.printStackTrace();
			return false;
		}
	}
		
		
		

	public boolean SelectPL_StartsWith(String Value) throws Exception {
			xpath = "(//*[normalize-space(text())='" + fieldname
							+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[local-name()='select'])[1]";
	
		
		try {
			getsingleWebelement = getElement(xpath);
			if(getAttributeValue(getsingleWebelement, "type").toString().trim().equalsIgnoreCase("select-one") || getAttributeValue(getsingleWebelement, "tagName").toString().trim().equalsIgnoreCase("select"))
			{
					Select s = new Select(getsingleWebelement);
					List<WebElement> eachPLValue = s.getAllSelectedOptions();

					for (WebElement eo : eachPLValue) {

						if (eo.getText().trim().startsWith(Value)) {
							s.selectByVisibleText(eo.getText().trim());
							AddLogToCustomReport("Pass","Selected picklist value starts with ("+Value+") in field ("+fieldname+")");
							return true;
						}
					}
					
					return false;

			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			AddLogToCustomReport("Fail", "Unable to select the picklist value starts with ("+Value+") for field ("+fieldname+")");
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Description Selects the picklist value by index where index starts from zero
	 *              (0)
	 * @param Index
	 * @return boolean
	 * @throws Exception
	 */
	public boolean SelectPLValueByIndex(int Index) throws Exception {
		xpath = "(//*[normalize-space(text())='" + fieldname
				
				+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[local-name()='select'])[1]";
	
		
		try {
			getsingleWebelement = getElement(xpath);
			if(getAttributeValue(getsingleWebelement, "type").toString().trim().equalsIgnoreCase("select-one") || getAttributeValue(getsingleWebelement, "tagName").toString().trim().equalsIgnoreCase("select"))
			{
				Select s = new Select(getsingleWebelement);
				s.selectByIndex(Index);
				AddLogToCustomReport("Pass","Selected picklist value in index ("+Index+") in field ("+fieldname+")");
				return true;
			}
			return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Fail", "Unable to select the picklist value at index ("+Index+") for field ("+fieldname+")");
			return false;
		}
		
	}

	/**
	 * @param Value
	 *            semicolon separated value for multiple
	 * @return boolean
	 * @throws Exception
	 * @Description Selects multiple values in the multi-select picklist field and
	 *              adds to the Chosen list.
	 */
	//Pending Testing
	public boolean MultiSelectAdd(String Value) throws Exception {
		xpath = "((//*[normalize-space(text())='" + fieldname
				+ "'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='optgroup'][1]/ancestor::select[1]";
		try {
			getsingleWebelement = getElement(xpath);
			Select s = new Select(getsingleWebelement);
			List<String> eachPLValue = Arrays.asList(Value.split(";"));
			for (String str : eachPLValue) 
			{
					s.selectByVisibleText(str);
					click("((//*[text()='" + fieldname + "'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='img'][1]", fieldname);
					AddLogToCustomReport("Pass", "Added value ("+Value+") in MultiSelect field ("+fieldname+") ");
			}
			return true;
		}
		catch (Exception e) {
			AddLogToCustomReport("Fail", "Unable to add multi select value ("+Value+") in field ("+fieldname+") ");
			return false;
		}
	}

	/**
	 * @param Value
	 * @return boolean
	 * @throws Exception
	 * @Description Removes multiple values from chosen list to Available list of
	 *              multi-select pick list field.
	 * 
	 */
	//Pending Testing
	public boolean MultiSelectRemove(String Value) throws Exception {
		xpath = "((//*[normalize-space(text())='" + fieldname
				+ "'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='optgroup'][2]/ancestor::select[1]";
		try {
				getsingleWebelement = getElement(xpath);
				Select s = new Select(getsingleWebelement);

				List<String> eachPLValue = Arrays.asList(Value.split(";"));
				for (String str : eachPLValue) {
					s.selectByVisibleText(str);
					System.out.println("Multiselect pick list values are:" + str.trim());
				}

				click("((//*[text()='" + fieldname + "'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='img'][2]", "fieldname");
				AddLogToCustomReport("Pass", "Removed value("+Value+") from multi select field ("+fieldname+")");
				return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			AddLogToCustomReport("Fail", "Unable to remove value ("+Value+") from multi select field ("+fieldname+")");
			return false;
		}
	}

	/**
	 * @return boolean
	 * @throws Exception
	 * @Description Selects and Adds all the available values of multi-select pick
	 *              list field from Available List to Chosen List
	 */
	//Pending Testing
	public boolean MultiSelectAddAll() throws Exception {
		try {
			xpath = "((//*[normalize-space(text())='" + fieldname + "'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='optgroup'][1]/ancestor::select[1]";
			String allvalues = "";
			getsingleWebelement = getElement(xpath);
			Select s = new Select(getsingleWebelement);
			List<WebElement> options = s.getOptions();

			for (WebElement eachOption : options) {
				getsingleWebelement.sendKeys(Keys.CONTROL);
				s.selectByVisibleText(eachOption.getText().trim());

				if (allvalues.equals("")) {
					allvalues = eachOption.getText().trim();
				} else {
					allvalues = allvalues + "," + eachOption.getText().trim();
				}
				
				
			}
			
			click("((//*[text()='" + fieldname+ "'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='img'][1]", "MultiSelect");
			AddLogToCustomReport("Pass", "Added all values in multi select field (+fieldname+)");
			return true;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Fail", "Unable to add all values in multi select picklist field ("+fieldname+")");
			return false;
		}
		
	}
	
	/**
	 * @return boolean
	 * @throws Exception
	 * @Description Selects and Removes all the available values of multi-select
	 *              pick list field from Chosen List to Available List.
	 */
	//Pending Testing
	public boolean MultiSelectRemoveAll() throws Exception {
		xpath = "((//*[normalize-space(text())='" + fieldname
				+ "'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='optgroup'][2]/ancestor::select[1]";
		String allvalues = "";
		try {
			getsingleWebelement = getElement(xpath);
			Select s = new Select(getsingleWebelement);

			List<WebElement> options = s.getOptions();

			for (WebElement eachOption : options) {
				s.selectByVisibleText(eachOption.getText().trim());

				if (allvalues.equals("")) {
					allvalues = eachOption.getText().trim();
				} else {
					allvalues = allvalues + "," + eachOption.getText().trim();
				}
				getsingleWebelement.sendKeys(Keys.CONTROL);
				
			}
			click("((//*[text()='" + fieldname+ "'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='img'][2]", "MultiSelect");
			AddLogToCustomReport("Pass", "Removed all values from multi select field ("+fieldname+")");
			return true;
		} catch (Exception e) {
			AddLogToCustomReport("Fail", "Unable to remove all values from multiselect pick list ("+fieldname+")");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit
	 * @Description Verify selected/default value displayed in the pick list field
	 *              and sends the message to the Log
	 * @param Value
	 * @return boolean
	 * @throws Exception
	 * 
	 */
	public boolean VerifyPLDefaultValue(String Value) throws Exception {
			
			xpath = "(//*[normalize-space(text())='" + fieldname + "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[local-name()='select'])[1]";
			try {
				getsingleWebelement = getElement(xpath);
				if(getAttributeValue(getsingleWebelement, "type").toString().trim().equalsIgnoreCase("select-one") || getAttributeValue(getsingleWebelement, "tagName").toString().trim().equalsIgnoreCase("select"))
				{
					Select s = new Select(getsingleWebelement);
					if(s.getFirstSelectedOption().toString().trim().equals(Value))
					{
						AddLogToCustomReport("Pass", "Successully verified picklist default value ("+Value+") for field ("+fieldname+")");
						return true;
					}
					return false;
				}
				return false;
			}
			catch(Exception e)
			{
				e.printStackTrace();
				AddLogToCustomReport("Fail", "Unable to verify picklist default value ("+Value+") in field ("+fieldname+")");
				return false;
			}
	
	}

	/**
	 * @author Cognizant
	 * @PageDisplayMode Edit
	 * @Description Read the displayed value in the picklist field when the page is
	 *              opened in Edit mode and returns the value.
	 * @return Value displayed in the picklist field in Edit mode on success and
	 *         returns blank value on Failure
	 * @throws Exception
	 * 
	 */
	public String GetPLDefaultValue() throws Exception {
		
		xpath = "(//*[normalize-space(text())='" + fieldname + "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[local-name()='select'])[1]";
		try {
			getsingleWebelement = getElement(xpath);
			if(getAttributeValue(getsingleWebelement, "type").toString().trim().equalsIgnoreCase("select-one") || getAttributeValue(getsingleWebelement, "tagName").toString().trim().equalsIgnoreCase("select"))
			{
				Select s = new Select(getsingleWebelement);
				String value =s.getFirstSelectedOption().toString().trim();
				AddLogToCustomReport("Pass", "Successfully read the pickist displayed value in field ("+fieldname+")");
				return value;
			}
			return "";
		}
		catch(Exception e)
		{
			e.printStackTrace();
			AddLogToCustomReport("Fail", "Unable to read the displayed value in picklist field ("+fieldname+")");
			return "";
		}

	}

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit
	 * @Description Verify pick list field values from Edit page and sends the
	 *              message to the Log
	 * @param Values
	 * @return boolean
	 * @throws Exception
	 */
	public boolean VerifyPLValue(String Values) throws Exception {
		List<String> avail = new ArrayList<String>();

		xpath = "((//*[normalize-space(text())='" + fieldname
				+ "'])[1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1])/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[local-name()='select']";
		try {
			
			getsingleWebelement = getElement(xpath);
			if(getAttributeValue(getsingleWebelement, "type").toString().trim().equalsIgnoreCase("select-one") || getAttributeValue(getsingleWebelement, "tagName").toString().trim().equalsIgnoreCase("select"))
			{
					Select s = new Select(getsingleWebelement);
					List<WebElement> AllValues_elements = s.getOptions();
					for (WebElement eachElement : AllValues_elements) {
						avail.add(eachElement.getText().trim());

					}
			}
			List<String> ExpectedValues = Arrays.asList(Values.split(";"));
			String failedPLValue = "";

			for (String exp : ExpectedValues) {
				if (!avail.contains(exp)) {
					if (failedPLValue != "") {
						failedPLValue = failedPLValue + ";" + exp;
					} else {
						failedPLValue = exp;
					}
				}
			}

			if (failedPLValue == "") 
			{
				System.out.println("Successfully verified the Available List of Values(" + Values + ") from PickList field (" + fieldname + ")");
				AddLogToCustomReport("Pass", "Successfully verified the Available List of Values(" + Values + ") from PickList field (" + fieldname + ")");
				return true;
			}
			else
			{
				System.out.println("Could not find pick list values (" + failedPLValue+ ") in the available list of field(" + fieldname + ").");
				AddLogToCustomReport("Fail", "Could not find pick list values (" + failedPLValue+ ") in the available list of field(" + fieldname + ").");
				return false;
			}
		} catch (Exception e) {
			
			System.out.println("Unable to verify picklist values when xpath is (" + xpath + ")");
			AddLogToCustomReport("Fail", "Could not find pick list values in the available list of field(" + fieldname + ").");
			return false;

		}

	}

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit
	 * @Description Verify the values displayed in Available list of a Multi-Select
	 *              pick list field in Edit page
	 * @param Values
	 * @return boolean
	 * @throws Exception
	 */
	//Pending Testing
	public boolean VerifyMPLAvailable(String Values) throws Exception {
		xpath = "((//*[normalize-space(text())='" + fieldname + "'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='optgroup'][1]/ancestor::select[1]";
		try {
			getsingleWebelement = getElement(xpath);
			Select s = new Select(getsingleWebelement);
			List<WebElement> options = s.getOptions();
			List<String> avail = new ArrayList<String>();
			
			for (WebElement eachOption : options) {
					avail.add(eachOption.getText().trim());
					// System.out.println("eachOption: "+eachOption.getText().trim());
			}

			List<String> AllavailValues = Arrays.asList(Values.split(";"));
			String failedPLValue = "";
			for (String exp : AllavailValues) 
			{
				if (!avail.contains(exp))
				{
					if (failedPLValue != "")
					{
						failedPLValue = failedPLValue + ";" + exp;
					}
					else
					{
						failedPLValue = exp;
					}
				}
			}
			if (failedPLValue == "") 
			{
					System.out.println("Successfully verified the Available List of Values from Multiselect picklist field ("+ fieldname + ")");
					AddLogToCustomReport("Pass", "Successfully verified the Available List of Values from Multiselect picklist field ("+ fieldname + ")");
					return true;
			}
			else
			{
					System.out.println("Could not find multi select pick list values (" + failedPLValue	+ ") in the available list of field(" + fieldname + ").");
					AddLogToCustomReport("Fail", "Could not find multi select pick list values (" + failedPLValue	+ ") in the available list of field(" + fieldname + ").");
					return false;
			}

		}catch (Exception e) {
			System.out.println("Unable to find the element when xpath is:" + xpath);
			AddLogToCustomReport("Fail", "Could not find multi select pick list values in the available list of field(" + fieldname + ").");
			return false;

		}
	}

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit
	 * @Description Verify the values displayed in Chosen list of a Multi-Select
	 *              pick list field in Edit page
	 * @param Values
	 * @return boolean
	 * @throws Exception
	 */
	//Pending Testing
	public boolean VerifyMPLChosen(String Values) throws Exception {
		xpath = "((//*[normalize-space(text())='" + fieldname
				+ "'])[1]/ancestor::td[1])/following-sibling::td[1]/descendant-or-self::*[local-name()='optgroup'][2]/ancestor::select[1]";
		try{
			getsingleWebelement = getElement(xpath);
			Select s = new Select(getsingleWebelement);
			List<WebElement> options = s.getOptions();
			List<String> avail = new ArrayList<String>();
			
			for (WebElement eachOption : options) {
					avail.add(eachOption.getText().trim());
					// System.out.println("eachOption: "+eachOption.getText().trim());
			}

			List<String> AllavailValues = Arrays.asList(Values.split(";"));
			String failedPLValue = "";
			for (String exp : AllavailValues) 
			{
				if (!avail.contains(exp))
				{
					if (failedPLValue != "")
					{
						failedPLValue = failedPLValue + ";" + exp;
					}
					else
					{
						failedPLValue = exp;
					}
				}
			}
			if (failedPLValue == "") 
			{
					System.out.println("Successfully verified the Available List of Values from Multiselect picklist field ("+ fieldname + ")");
					AddLogToCustomReport("Pass", "Successfully verified the Available List of Values from Multiselect picklist field ("+ fieldname + ")");
					return true;
			}
			else
			{
					System.out.println("Could not find multi select pick list values (" + failedPLValue	+ ") in the available list of field(" + fieldname + ").");
					AddLogToCustomReport("Fail", "Could not find multi select pick list values (" + failedPLValue	+ ") in the available list of field(" + fieldname + ").");
					return false;
			}
			
		}catch (Exception e) {
			
			System.out.println("Unable to find the element when xpath is:" + xpath);
			AddLogToCustomReport("Fail", "Unable to find the element when xpath is:"+xpath);
			return false;

		}
	}

	


	/**
	 * @author Sourav
	 * @PageDisplayMode View Only
	 * @Description Verify if the field value contains supplied substring
	 * @return boolean
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueContains(String Value) throws Exception {
		xpath = "//*[normalize-space(text())='" + fieldname
				+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]";
		try {
				String text = getText(getElement(xpath));
				if (text.contains(Value)) {
					System.out.println("The value(" + Value + ") has been verified successfully for the field(" + fieldname + ")");
					AddLogToCustomReport("Pass", "The value(" + Value + ") has been verified successfully for the field(" + fieldname + ")");
					return true;
				} else {
					System.out.println("Could not find the value(" + Value + ") for the field(" + fieldname+ "). Actual Value:" + text);
					AddLogToCustomReport("Fail", "Could not find the value(" + Value + ") for the field(" + fieldname+ "). Actual Value:" + text);
					return false;
				}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is: " + xpath);
			AddLogToCustomReport("Fail", "Unable to find the element when xpath is: " + xpath);
			return false;

		}
	}


	/**
	 * @author Sourav
	 * @PageDisplayMode View Only
	 * @Description Verify if the field value starts with supplied substring
	 * @return boolean
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueStartsWith(String Value) throws Exception {
		xpath = "//*[normalize-space(text())='" + fieldname
				+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]";
		try {
				String text = getText(getElement(xpath));
				if (text.startsWith(Value)) {
					System.out.println("The value(" + Value + ") has been verified successfully for the field(" + fieldname + ")");
					AddLogToCustomReport("Pass", "The value(" + Value + ") has been verified successfully for the field(" + fieldname + ")");
					return true;
				} else {
					System.out.println("Could not find the value(" + Value + ") for the field(" + fieldname+ "). Actual Value:" + text);
					AddLogToCustomReport("Fail", "Could not find the value(" + Value + ") for the field(" + fieldname+ "). Actual Value:" + text);
					return false;
				}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is: " + xpath);
			AddLogToCustomReport("Fail", "Unable to find the element when xpath is: " + xpath); 
			
			return false;

		}
	}

	/**
	 * @author Sourav
	 * @PageDisplayMode View Only
	 * @Description Verify if the field value ends with supplied substring
	 * @return boolean
	 * @throws Exception
	 */
	public boolean VerifyViewOnlyValueEndsWith(String Value) throws Exception {

		xpath = "//*[normalize-space(text())='" + fieldname
				+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]";
		try {
				String text = getText(getElement(xpath));
				if (text.endsWith(Value)) {
					System.out.println("The value(" + Value + ") has been verified successfully for the field(" + fieldname + ")");
					AddLogToCustomReport("Pass", "The value(" + Value + ") has been verified successfully for the field(" + fieldname + ")"); 
					
					return true;
				} else {
					System.out.println("Could not find the value(" + Value + ") for the field(" + fieldname+ "). Actual Value:" + text);
					AddLogToCustomReport("Fail", "Could not find the value(" + Value + ") for the field(" + fieldname+ "). Actual Value:" + text);
					return false;
				}
		} catch (Exception e) {
			System.out.println("Unable to find the element when xpath is: " + xpath);
			AddLogToCustomReport("Fail", "Unable to find the element when xpath is: " + xpath);
			return false;

		}
	}

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit Page
	 * @Description Verify if the field(text, textarea) value is equal to the
	 *              supplied string in the displayed edit page
	 * @return boolean
	 * @throws Exception
	 */
	//Pending testing
	public boolean VerifyEditFieldValue(String Value) throws Exception {

		xpath = "((//*[normalize-space(text())='" + fieldname + "'])[1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1])/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[(local-name()='input' or local-name()='textarea') and @type !='hidden']";
		
		try {
			getsingleWebelement = getElement(xpath);
			String text = getAttributeValue(getsingleWebelement, "vaue").toString().trim();
			if(text.equals(Value))
			{
				AddLogToCustomReport("Pass", "Verified the edit field("+fieldname+") value("+Value+")");
				return true;
			}
			else
			{
				AddLogToCustomReport("Fail", "Unable to verify the edit field("+fieldname+") value ("+Value+")");
				return false;
			}		
			
		} catch (Exception e) {
					
			AddLogToCustomReport("Fail", "Uable able to find the element "+xpath);
			e.printStackTrace();
			return false;
		}
	
	}

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit Page
	 * @Description Reads the field (text,textarea) value displayed in the edit page
	 *              and returns the value
	 * @return Returns field value on success and returns blank value in case
	 *         failure
	 * @throws Exception
	 */
	//Pending testing
	public String GetEditFieldValue() throws Exception {
		

		xpath = "((//*[normalize-space(text())='" + fieldname + "'])[1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1])/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[(local-name()='input' or local-name()='textarea') and @type !='hidden']";
		
		try {
			getsingleWebelement = getElement(xpath);
			String text = getAttributeValue(getsingleWebelement, "value").toString().trim();
			AddLogToCustomReport("Pass", "Successfully read the value ("+text+") from editable field ("+fieldname+")");
			return text;
					
			
		} catch (Exception e) {
					
			AddLogToCustomReport("Fail", "Unabe to read  the field value from field ("+fieldname+").");
			e.printStackTrace();
			return "";
		}
	}

	/*******************************************************************************************//*
	// Following function verifies if the value of a check box in checked/unchecked
	// //
	// in view details page as well as Edit page //
	// //
	*//*******************************************************************************************//*
	*//**
	 * @author Sourav
	 * @PageDisplayMode View Only/Edit Page
	 * @Description Verify if the checkbox field is checked or not checked in Edit
	 *              as well as View only page
	 * @return boolean
	 * @throws Exception
	 * @param Checked
	 *            OR Not Checked
	 */
	//Pending testing
	public boolean VerifyChkBoxValue(String CheckedORNotChecked) throws Exception {

		xpath = "//*[text()='" + fieldname	+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[(local-name()='img' or local-name()='input')][1]";
		try {
			getsingleWebelement = getElement(xpath);
			if (CheckedORNotChecked.equalsIgnoreCase("Checked")) {
					if ((getAttributeValue(getsingleWebelement, "title").equals(""))
							&& (getAttributeValue(getsingleWebelement, "checked") != null)
							&& (getAttributeValue(getsingleWebelement, "checked").equals("true")))
					{
						AddLogToCustomReport("Pass", "Verify the checkbox field("+fieldname+") as supplied.");
						return true;
					} 
					else if((getAttributeValue(getsingleWebelement, "title").equals("Checked"))
							&& (getAttributeValue(getsingleWebelement, "checked") == null)) {
						AddLogToCustomReport("Pass", "Verify the checkbox field("+fieldname+") as supplied.");
						return true;
					} else {
						AddLogToCustomReport("Fail", "Unable to verify the checkbox field ("+fieldname+")");
						return false;
					}
				}
			if (CheckedORNotChecked.equalsIgnoreCase("Not Checked")) {
					if ((getAttributeValue(getsingleWebelement, "title").equals("Not Checked"))
							&& (getAttributeValue(getsingleWebelement, "checked") == null)) {
						AddLogToCustomReport("Pass", "Verify the checkbox field("+fieldname+") as supplied.");
						return true;
					} else if ((getAttributeValue(getsingleWebelement, "title").equals(""))
							&& (getAttributeValue(getsingleWebelement, "checked") == null)) {
						AddLogToCustomReport("Pass", "Verify the checkbox field("+fieldname+") as supplied.");
						return true;
					} else {
						AddLogToCustomReport("Fail", "Unable to verify the checkbox field ("+fieldname+")");
						return false;
					}

				}
				AddLogToCustomReport("Fail", "Unable to verify the checkbox field ("+fieldname+")");
				return false;

			 
		} catch (Exception e) {
			AddLogToCustomReport("Fail", "Unable to verify the checkbox field ("+fieldname+")");
			return false;
		}
	}

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit Page
	 * @Description Checks the checkbox field in Edit page
	 * @return boolean
	 * @throws Exception
	 * 
	 */
	//Pending testing
	public boolean CheckBoxSelect() throws Exception {

		xpath = "//*[text()='" + fieldname
				+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[(local-name()='img' or local-name()='input')][1]";
		try {
			getsingleWebelement = getElement(xpath);
			if((getAttributeValue(getsingleWebelement, "title").equals("") || getAttributeValue(getsingleWebelement, "title").equals("Not Checked")) && (getAttributeValue(getsingleWebelement, "checked") == null)) 
			{
					click(getsingleWebelement, "fieldname");
					AddLogToCustomReport("Pass", "Selected the checkbox field ("+fieldname+")");
					return true;
			}
			else if(((getAttributeValue(getsingleWebelement, "title").equals("Checked")) && (getAttributeValue(getsingleWebelement, "checked") == null)) || ((getAttributeValue(getsingleWebelement, "title").equals("")) && (getAttributeValue(getsingleWebelement, "checked") != null))) {
				AddLogToCustomReport("Pass", "Selected the checkbox field ("+fieldname+")");
					return true;
			}
			else {
					AddLogToCustomReport("Fail", "Unable to select the checkbox field ("+fieldname+")");
					return false;
			}
				
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit Page
	 * @Description Checks the checkbox field in Edit page in case checkbox element
	 *              displays before the field label.
	 * @return boolean
	 * @throws Exception
	 */
	public boolean PrecedingCheckBoxSelect() throws Exception {

		try {
			xpath = "//label[contains(normalize-space(text()),'" + fieldname + "')]/preceding-sibling::input[1]";
			getsingleWebelement = getElement(xpath);
			if (getAttributeValue(getsingleWebelement, "checked") == null) {
				click(xpath, fieldname);				
				AddLogToCustomReport("Pass", "Clicked on preceding checkbox field ("+fieldname+") to select");
				return true;
			}
			else
			{
				AddLogToCustomReport("Pass", "Clicked on preceding checkbox field ("+fieldname+") to select");
				return true;
			}
		} catch (Exception e)
		{
			AddLogToCustomReport("Fail", "Unable to select the preseding checkbox field ("+fieldname+")");
			return false;
		}
	}

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit Page
	 * @Description UnChecks the checkbox field in Edit page in case checkbox
	 *              element displays before the field label.
	 * @return boolean
	 * @throws Exception
	 */
	public boolean PrecedingCheckBoxDeSelect() throws Exception {
		try {
			xpath = "//label[contains(normalize-space(text()),'" + fieldname + "')]/preceding-sibling::input[1]";
			getsingleWebelement = getElement(xpath);
			if (getAttributeValue(getsingleWebelement, "checked") != null) 
			{
				click(xpath, fieldname);
				AddLogToCustomReport("Pass", "Clicked on preceding checkbox field ("+fieldname+") to deselect");
				return true;

			} else {
				AddLogToCustomReport("Pass", "Unable to deselect the preseding checkbox field ("+fieldname+")");
				return true;
			}
		} catch (Exception e) {
			AddLogToCustomReport("Fail", "Unable to deselect the preseding checkbox field ("+fieldname+")");
			return false;
		}
	}

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit Page
	 * @Description UnChecks the checkbox field in Edit page
	 * @return boolean
	 * @throws Exception
	 */
	//Pending testing
	public boolean CheckBoxDeSelect() throws Exception {
		xpath = "//*[text()='" + fieldname + "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::*[(local-name()='img' or local-name()='input')][1]";
		try {
				getsingleWebelement = getElement(xpath);
				
				if (((getAttributeValue(getsingleWebelement, "title").equals("Checked")) && (getAttributeValue(getsingleWebelement, "checked") == null)) || ((getAttributeValue(getsingleWebelement, "title").equals("")) && (getAttributeValue(getsingleWebelement, "checked") != null))) 
				{
					click(getsingleWebelement, fieldname);
					AddLogToCustomReport("Pass", "Clicked on checkbox field ("+fieldname+") to deselect");
					return true;
				}
				else if ((getAttributeValue(getsingleWebelement, "title").equals("") || getAttributeValue(getsingleWebelement, "title").equals("Not Checked")) && (getAttributeValue(getsingleWebelement, "checked") == null)) 
				{
					AddLogToCustomReport("Pass", "Clicked on checkbox field ("+fieldname+")  to deselect");
					return true;
				}
				else
				{
					AddLogToCustomReport("Fail", "Unable to deselect the checkbox field ("+fieldname+")");
					return false;
				}
		}catch (Exception e) {
			AddLogToCustomReport("Fail", "Unable to deselect the checkbox field ("+fieldname+")");
			return false;
		}
	}

	/**
	 * @author Sourav Mukherjee
	 * @Param NA
	 * @return void
	 * @throws Exception
	 * @Description Press TAB Key using Robot Class
	 * @Date Jan, 2015
	 */
	public  void PressTabKey() throws Exception
	{
		try 
		{
			Robot robot = new Robot(); 
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
			
		}
		
	}
	
	// Choose value from lookup

	/**
	 * @author Sourav
	 * @PageDisplayMode Edit Page
	 * @param LookUpValue
	 * @Description Selects the value from SFDC OOB lookup field. If the text box
	 *              field is editable then it types the value in that field then
	 *              clicks on the lookup icon and clicks on the hyperlink displayed
	 *              in search lookup. In case the text box field is read only then
	 *              directly clicks on the lookup icon and searches the expected
	 *              value in the search lookup window and clicks on hyperlink. It
	 *              also sets the focus to the parent window
	 * @return boolean
	 * @throws Exception
	 */
	public boolean SelectFromLookup(String LookUpValue) throws Exception {
		
		String parentwindowtitle = "";
		xpath = "((//*[normalize-space(text())='" + fieldname + "'])/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1])/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::span/input[1]";

		try {
			
			
			String mainwindow = remoteDriver.getWindowHandle();
			getsingleWebelement = getElement(xpath);

			System.out.println("getsingleWebelement.getAttribute: " + getsingleWebelement.getAttribute("readonly"));
			if (getsingleWebelement.getAttribute("readonly") == null) {

				getsingleWebelement.clear();
				getsingleWebelement.sendKeys(LookUpValue);
				
				
				//PressTabKey();
				//Thread.sleep(1000L);
				xpath = "((//*[normalize-space(text())='" + fieldname + "'])/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1])/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::span/descendant-or-self::img[contains(normalize-space(@alt),'New Window') or contains(normalize-space(@title),'New Window')]";
				getsingleWebelement = getElement(xpath);
				getsingleWebelement.click();
				//click(getsingleWebelement, fieldname);
				
				//Thread.sleep(1000L);
				//remoteDriver.switchTo().defaultContent();
				Set<String> s = remoteDriver.getWindowHandles();
				Iterator<String> ite = s.iterator();
				while (ite.hasNext()) {
					String popup = ite.next();
					if (!popup.equalsIgnoreCase(mainwindow)) {
						remoteDriver.switchTo().window(popup);
						System.out.println("Window Title is: " + remoteDriver.getTitle());
						break;
					}
				}

				//Thread.sleep(3000L);
				// autoFW.SelectWindow("Search");
				remoteDriver.switchTo().defaultContent();
				System.out.println("Currectly focused window is:" + remoteDriver.getTitle());
				remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("//frame[contains(normalize-space(@title),'Result')]")));
				System.out.println("Switching to frame works for Search Result");
				//Thread.sleep(3000L);
				
				remoteDriver.findElement(By.xpath("//a[normalize-space(text())='" + LookUpValue + "'][1]")).click();			
				System.out.println("after click--");
				remoteDriver.switchTo().window(mainwindow);
				System.out.println("after mainwindow--");
				remoteDriver.switchTo().defaultContent();
				System.out.println("after default content-");
				System.out.println("Selected the value ("+LookUpValue+") from lookup field ("+fieldname+")");
				AddLogToCustomReport("Pass", "Selected the value ("+LookUpValue+") from lookup field ("+fieldname+")");
				return true;

			}

			// Below code works if the field is read only
			// else if
			// (getsingleWebelement.getAttribute("readonly").equalsIgnoreCase("true") ||
			// (getsingleWebelement.getAttribute("readonly").equalsIgnoreCase("readonly")))
			else {
				mainwindow = remoteDriver.getWindowHandle();
				xpath = "((//*[normalize-space(text())='" + fieldname + "'])/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1])/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::span[contains(normalize-space(@class),'lookup')]/descendant-or-self::img[contains(normalize-space(@alt),'New Window')]";
				getsingleWebelement = remoteDriver.findElement(By.xpath(xpath));
				getsingleWebelement.click();
				//Thread.sleep(1000L);
				// autoFW.SelectWindow("Search");
				Set<String> s = remoteDriver.getWindowHandles();
				Iterator<String> ite = s.iterator();
				while (ite.hasNext()) {
					String popup = ite.next();
					if (!popup.equalsIgnoreCase(mainwindow)) {
						remoteDriver.switchTo().window(popup);
						System.out.println("Window Title is: " + remoteDriver.getTitle());
						break;
					}
				}
				remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("//frame[contains((@title),'Search')]")));
				System.out.println("Switching to Frame Works properly for Search box.");
				remoteDriver.findElement(By.xpath("//input[contains(normalize-space(@placeholder),'Search') and normalize-space(@type)='text']")).clear();
				remoteDriver.findElement(By.xpath("//input[contains(normalize-space(@placeholder),'Search') and normalize-space(@type)='text']")).sendKeys(LookUpValue);
				//Thread.sleep(1000L);
				remoteDriver.findElement(By.xpath("//input[contains(normalize-space(@placeholder),'Search') and normalize-space(@type)='text']")).sendKeys(Keys.ENTER);

				remoteDriver.switchTo().defaultContent();
				System.out.println("Currectly focused window is:" + remoteDriver.getTitle());
				remoteDriver.switchTo().frame(remoteDriver.findElement(By.xpath("//frame[contains(normalize-space(@title),'Result')]")));
				System.out.println("Switching to frame works for Search Result");
				//Thread.sleep(1000L);
				if (remoteDriver.findElement(By.linkText(LookUpValue)).isDisplayed()) {
					remoteDriver.findElement(By.linkText(LookUpValue)).click();
					
					remoteDriver.switchTo().window(mainwindow);
					remoteDriver.switchTo().defaultContent();
					AddLogToCustomReport("Pass", "Selected the value ("+LookUpValue+") from lookup field ("+fieldname+")");
					return true;
				} else {

					
					CloseWindow("Search");
					remoteDriver.switchTo().window(mainwindow);
					remoteDriver.switchTo().defaultContent();
					AddLogToCustomReport("Fail", "Unable to select the value ("+LookUpValue+") from lookup field ("+fieldname+")");
					return false;
				}

			}

		} catch (Exception e) {

			
			e.printStackTrace();
			CloseWindow("Search");
			SelectWindow(parentwindowtitle);
			remoteDriver.switchTo().defaultContent();
			AddLogToCustomReport("Fail", "Unable to select the value ("+LookUpValue+") from field ("+fieldname+")");
			return false;
		}

	}

	public void AddLogToCustomReport(String Result, String Message) throws Exception{
		try {
			
			if(Result.toString().trim().equalsIgnoreCase("Pass"))
			{
				ExtentUtility.getTest().log(LogStatus.PASS, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
			else if(Result.toString().trim().equalsIgnoreCase("Fail"))
			{
				ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				throw new Exception("Failure from custom exception");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new MPException("Failure from custom exception");
			ExtentUtility.getTest().log(LogStatus.FAIL, Message, ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			Assert.fail(Message);
			//throw new Exception("Failed");
		}
	}
	
	
	
	/**
	 * @author Sourav Mukherjee
	 * @Param UniqueStringinWindowTitle
	 * @return boolean
	 * @throws Exception
	 * @Description Selects the window opened by Selenium Webdriver.
	 * @Date Aug 7, 2014
	 */
	public boolean SelectWindow(String UniqueStringinWindowTitle) throws Exception
	{
		
		try
		{
			int c=0;
			String mainwindow = remoteDriver.getWindowHandle();   
			System.out.println("mainwindow:"+mainwindow);
			
			Set<String> s = remoteDriver.getWindowHandles(); 
	        Iterator<String> ite = s.iterator(); 
	        while(ite.hasNext()) 
	        { 
	            String popup = ite.next(); 
	            System.out.println("inside SelectWindow:"+popup);
	            if(!popup.equalsIgnoreCase(mainwindow))
	            { 
	            	remoteDriver.switchTo().window(popup); 
	                System.out.println("Window Title is: "+remoteDriver.getTitle());
	                if(remoteDriver.getWindowHandle().contains(popup))
	                {
	                	//mainwindow = null;
	                	//s=null;
	                	return true;
	                	
	                }
	                else
	                {
	                	c = c + 1;
	                }
	             }
	        }
	        if (c>0)
	        {
	        	
	        	return false;
	        }
	        else
	        {
	        	
	        	return true;
	        	
	        }
		/*	
		Set <String> handles = myWD.getWindowHandles();
		Iterator<String> it = handles.iterator();
		//iterate through your windows
		while (it.hasNext())
		{
			//String parent = it.next();
			String win = it.next();
			System.out.println("win:"+win);
			myWD.switchTo().window(win);
			if (myWD.getTitle().contains(UniqueStringinWindowTitle))
			{
				System.out.println("The title of the Selected window is:"+myWD.getTitle());
				return true;
			}
						
		}
		System.out.println("Could not find the window with title containing "+UniqueStringinWindowTitle);
		return false;
		*/
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Exception in SelectWindow Function while trying to select the window having title containing  "+UniqueStringinWindowTitle);
			return false;
		}
	}
	
	/**
	 * @author Sourav Mukherjee
	 * @Param UniqueStringinWindowTitle
	 * @return boolean
	 * @throws Exception
	 * @Description Whenever you call this function CloseWindow(), You must call SelectWindow() function after this function call to continue working on the next window, otherwise the focus to the next workable window will be lost.  
	 * @Date Aug 7, 2014
	 */
	public boolean CloseWindow(String UniqueStringinWindowTitle) throws Exception
	{
		try
		{
			
			String AlreadySelectedWindow = remoteDriver.getWindowHandle();   
			System.out.println("AlreadySelectedWindow:"+AlreadySelectedWindow);
			
			Set<String> s = remoteDriver.getWindowHandles(); 
	        Iterator<String> ite = s.iterator(); 
	        while(ite.hasNext()) 
	        { 
	            String popup = ite.next(); 
	            System.out.println("inside closewindow:"+popup);
	            if(popup.equalsIgnoreCase(AlreadySelectedWindow))
	            { 
	            	remoteDriver.switchTo().window(popup).close(); 
	                return true;
	            }
	            
	        }
		System.out.println("Could not find the window with title containing "+UniqueStringinWindowTitle+" while trying to close.");
		return false;
		}catch(Exception e) 
		{
			e.printStackTrace();
			System.out.println("Exception in CloseWindow Function while trying to close the window having title containing  "+UniqueStringinWindowTitle);
			return false;
		}
	}
	
	
	/**
	 * @author Sourav
	 * @Description Waits for specified time for the field to be displayed in the UI
	 * @param waitingTimeinSec
	 * @return boolean
	 * @throws Exception
	 *//*
	public boolean WaitForElement(long waitingTimeinSec) throws Exception {
		xpath = "//*[normalize-space(text())='" + fieldname + "']";
		try {

			if (myWD.toString().contains("InternetExplorerDriver")) {
				autoFW.WebDriverWaitForElement(xpath, waitingTimeinSec);
				return true;
			} else {
				myWD.manage().timeouts().implicitlyWait(waitingTimeinSec, TimeUnit.SECONDS);
				List<WebElement> myDynamicElement = myWD.findElements(By.xpath(xpath));
				if (myDynamicElement.size() > 0) {
					autoFW.AddToXLLogs("The field (" + fieldname + ") was available in the application.", "Pass");
					return true;
				} else {
					autoFW.AddToXLLogs("Could not find the field (" + fieldname + ") in the application.", "Fail");
					return false;
				}
			}
			// System.out.println("The value of dynamic webelement
			// is:"+myDynamicElement.isDisplayed());
			// return myDynamicElement.isDisplayed();
		} catch (NoSuchElementException e) {
			System.out.println("Could not find the element after waiting for specified time.");
			autoFW.AddToXLLogs("Could not find the button (" + fieldname + ") in the application.", "Fail");
			return false;
			// return false;
		}
	}

	/**
	 * @author Sourav 
	 * @param LinkPartialText
	 * @return boolean
	 * @Description Clicks on partial link displayed anywhere in the UI
	 * @throws Exception
	 */
	//Pending Testin
	public boolean LinkClick(String LinkPartialText) throws Exception {
		
		xpath = "(//*[normalize-space(text())='" + fieldname
				+ "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1])/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::a[contains(normalize-space(text()),'"
				+ LinkPartialText.trim() + "')][1]";
		try {
			
			getsingleWebelement = getElement(xpath);
			click(getsingleWebelement, fieldname);
			AddLogToCustomReport("Pass", "Clicked on link against field ("+fieldname+")");
			return true;
			}
			catch (Exception e) {
			AddLogToCustomReport("Fail", "Unable to click on the link against field ("+fieldname+")");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @return
	 * @throws Exception
	 * @Description Clicks on the first link present against the field on Edit page
	 */
	//Pending Testin
	public boolean LinkClick_EditPage() throws Exception {
		xpath = "(//*[normalize-space(text())='" + fieldname + "'][1]/ancestor-or-self::*[local-name()='td' or local-name()='th' or local-name()='div'][1])/following-sibling::*[local-name()='td' or local-name()='th' or local-name()='div'][1]/descendant-or-self::a[1][1]";
		try {
			
			getsingleWebelement = getElement(xpath);
			click(getsingleWebelement, fieldname);
			AddLogToCustomReport("Pass", "Clicked on link value from edit field ("+fieldname+")");
			return true;
			}
			catch (Exception e) {
			AddLogToCustomReport("Fail", "Unable to click on link value from edit field ("+fieldname+")");
			e.printStackTrace();
			return false;
		}
	}

	
	
}
