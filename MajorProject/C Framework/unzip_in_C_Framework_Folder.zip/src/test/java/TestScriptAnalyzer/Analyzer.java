package TestScriptAnalyzer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.reflections.Reflections;

import com.jayway.jsonpath.JsonPath;
import com.mop.qa.testbase.TestBase;

import SOURCE_CODE.SFDC.SFDCAutomationFW;

/**
 * Identifies all the impacted test cases that required modification based on
 * metadata changes. Stores all the calling method of test classes in a hashmap
 * as calling method as a key and test cases name as a string of set to remove
 * duplication. Search the impacted method on Object Repository of the impacted
 * class which identifies as per object change. Finds the corresponding method
 * in the map and displays the test class names.
 * 
 * @author Anindya Sundar Roy
 * @version 1.0
 *
 */

public class Analyzer {
	private static Map<String, Set<String>> map = new ConcurrentHashMap<>();
	private static XSSFWorkbook _workbook;
	private int _rowPosition = 0;
	private static String _userRepositoryPackagePath;
	private static String _testPackage;
	private static String _filePath;
	private static String _excelPath;

	// Project specific constants
	private static final String EXCEL_EXTENSION = ".xlsx";
	private static final String JSON_EXTENSION = ".json";
	private static final String OUTPUT_FILE = "/ImpactAnalyzerResult.xlsx";
	private static final String EXCEL_REGEX = "[\\[\\]]";
	private static final String JSON_REGEX = "[\"\\[\\]]";
	private static final String INIT = "<init>";
	private static final String LIGHTNING_EXTENSION = "_LUI";

	// Output excel file constants
	private static final String SHEET_NAME = "Mapping file";
	private static final String OBJECTS = "Objects";
	private static final String OBJECT_REPOSITORY = "Object Repository";
	private static final String CATEGORY = "Category";
	private static final String NAME_OF_METADATA = "Name Of Metadata";
	private static final String IMPACTED_TEST_SCRIPTS = "Impacted Test Scripts";

	// JsonPath constants
	private static final String COMMON_PATH = "$..[?(@.ObjectName=='%s')].['LayoutDetails'].[*].['%s']";
	private static final String OBJECT_PATH = "$..['ObjectName']";

	// Other constants
	private static final String BACKSLASH = "/";
	private static final String FULLSTOP = ".";
	private static final String COMMA = ",";
	private static final String NULL = "null";
	private static final int ZERO = 0;
	private static final int ONE = 1;
	private static final int TWO = 2;
	private static final int THREE = 3;
	private static final int FOUR = 4;
	private static final int FIVE = 5;
	private static final int EIGHT = 8;

	public enum Category {
		// Keep this list sorted
		BUTTON("Button", "Buttons"), 
		FIELD("Field", "Fields"), 
		RELATED_LIST("RL", "RelatedLists");

		private String RepoCategory;
		private String AnalyzerCategory;

		Category(String repoCategory, String analyzerCategory) {
			this.RepoCategory = repoCategory;
			this.AnalyzerCategory = analyzerCategory;
		}
	}

	/**
	 * Finds occurrence of methods in object repository classes based on text and
	 * calling method type and returns matching occurrence of methods in object
	 * repository classes and test classes.
	 * 
	 * @param cn         ClassNode
	 * @param className  ClassName
	 * @param text       Metadata Name
	 * @param methodName MethodName
	 */
	@SuppressWarnings("unchecked")
	private void objectRepositoryMethodOccurences(ClassNode cn, String className, List<String> texts, String methodName,
			String objectName) {
		List<MethodNode> methodNames = cn.methods;
		methodNames.stream().filter(node -> !node.name.equalsIgnoreCase(INIT)).forEach(nodeName -> {
			StringBuilder sb = new StringBuilder();
			InsnList mv1 = nodeName.instructions;
			List<String> testClassList = new ArrayList<>();
			String key = className.replace(FULLSTOP, BACKSLASH) + StringUtils.SPACE + nodeName.name + StringUtils.SPACE
					+ nodeName.desc;

			Stream<?> stream = StreamSupport
					.stream(Spliterators.spliteratorUnknownSize(mv1.iterator(), Spliterator.ORDERED), false);

			stream.filter(node -> node instanceof LdcInsnNode).forEach(node -> {
				String methodNameLui = methodName + LIGHTNING_EXTENSION;
				// If text is empty then check all the methods inside the class
				if (texts == null || texts.isEmpty()) {
					Object node1 = ((LdcInsnNode) node).getNext();
					if (node1 instanceof MethodInsnNode && (((MethodInsnNode) node1).name.equals(methodName)
							|| ((MethodInsnNode) node1).name.equals(methodNameLui))) {
						try {
							if (getOccurrence(key)) {
								testClassList.add(map.get(key).toString());
							}
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				} else if (methodName.equalsIgnoreCase(Category.RELATED_LIST.RepoCategory)) {
					String text = (String) ((LdcInsnNode) node).cst;
					if (texts != null && texts.contains(text)) {
						Object node3 = ((LdcInsnNode) node).getNext();
						if (node3 instanceof MethodInsnNode) {
							String innerClassName = ((MethodInsnNode) node3).owner;
							objectRepositoryMethodOccurences(getClassNode(innerClassName), innerClassName, null,
									methodName, objectName);
						}
					}
				} else if (texts.stream().anyMatch(value -> value.equals((String) ((LdcInsnNode) node).cst))) {
					sb.append((String) ((LdcInsnNode) node).cst);
					Object node1 = ((LdcInsnNode) node).getNext();
					if (node1 instanceof MethodInsnNode && (((MethodInsnNode) node1).name.equals(methodName)
							|| ((MethodInsnNode) node1).name.equals(methodNameLui))) {
						try {
							if (getOccurrence(key))
								testClassList.add(map.get(key).toString());
						} catch (IOException e) {
							e.printStackTrace();
						}
						return;
					}
				}
			});
			try {
				if (testClassList.size() > ZERO) {
					writeExcel(_excelPath, ZERO, objectName, className, methodName, sb.toString(),
							testClassList.toString());
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	/**
	 * Gets all the list of calling method occurrences inside the class and stores
	 * all the methods as a key and corresponding class name as a value.
	 * 
	 * @param cn                    ClassNode
	 * @param className             ClassName
	 * @param objectRepoPackageName ObjectRepoPackageName
	 */
	@SuppressWarnings("unchecked")
	private void callingMethodOccurrences(ClassNode cn, String className, final String objectRepoPackageName) {
		List<MethodNode> methodNames = cn.methods;
		methodNames.stream().filter(node -> !node.name.equalsIgnoreCase(INIT)).forEach(nodeName -> {
			InsnList mv1 = nodeName.instructions;

			Stream<?> stream = StreamSupport
					.stream(Spliterators.spliteratorUnknownSize(mv1.iterator(), Spliterator.ORDERED), false);

			stream.filter(node -> node instanceof MethodInsnNode)
					.filter(node -> ((MethodInsnNode) node).owner.contains(objectRepoPackageName)).forEach(node -> {
						String key = ((MethodInsnNode) node).owner + StringUtils.SPACE + ((MethodInsnNode) node).name
								+ StringUtils.SPACE + ((MethodInsnNode) node).desc;
						storeCallingMethods(key, className);
					});
		});
	}

	// Updates Test Impacted Column in the excel sheet with help of matching key for
	// number of matching occurrences.
	private boolean getOccurrence(String key) throws FileNotFoundException, IOException {
		if (map.containsKey(key)) {
			return true;
		}
		return false;
	}

	/**
	 * Stores method names, owner and description together as key and classname as
	 * value inside a HashSet to remove duplicate entry.
	 * 
	 * @param key       Key
	 * @param className ClassName
	 */
	private void storeCallingMethods(String key, String className) {
		Set<String> classSets = null;
		if (map.containsKey(key)) {
			classSets = map.get(key);
		} else {
			classSets = new HashSet<>();
		}

		classSets.add(className);
		map.put(key, classSets);
	}

	/**
	 * Gets all the list of classes inside the test package. Assuming all the test
	 * classes are extended by TestBase class.
	 * 
	 * @param packageName PackageName
	 * @return Set<Class<? extends TestBase>> Set<Class<? extends TestBase>>
	 */
	private Set<?> getAllTestClasses(String packageName, Class<?> _class) {
		Reflections reflections = new Reflections(packageName);
		return reflections.getSubTypesOf(_class);
	}

	// Reading Objects, category and fields value from excel sheet
	private List<String[]> readExcel(String path) throws FileNotFoundException, IOException {
		Stream<Row> rowStream = StreamSupport
				.stream(Spliterators.spliteratorUnknownSize(openSheet(path).iterator(), Spliterator.ORDERED), false);

		return rowStream.skip(ONE)
				.map(row -> StreamSupport
						.stream(Spliterators.spliteratorUnknownSize(row.cellIterator(), Spliterator.ORDERED), false)
						.limit(EIGHT).skip(TWO).map(Cell::getStringCellValue).toArray(String[]::new))
				.collect(Collectors.toList());
	}

	// Updating matching test case occurrences if any in excel sheet
	private synchronized void writeExcel(String path, int pos, String... values)
			throws FileNotFoundException, IOException {
		Row row = openSheet(path).createRow(++_rowPosition);
		for (String value : values) {
			row.createCell(pos++).setCellValue(value);
		}
		closeWorkbook(path);
	}

	// Opens Excel sheet
	private Sheet openSheet(String path) throws FileNotFoundException, IOException {
		_workbook = new XSSFWorkbook(new FileInputStream(new File(path)));
		return _workbook.getSheetAt(ZERO);
	}

	// Creates Excel sheet
	private void createExcelSheet(String excelFile) throws IOException {
		_workbook = new XSSFWorkbook();
		XSSFSheet sheet = _workbook.createSheet(SHEET_NAME);

		Row row = sheet.createRow(ZERO);
		row.createCell(ZERO).setCellValue(OBJECTS);
		row.createCell(ONE).setCellValue(OBJECT_REPOSITORY);
		row.createCell(TWO).setCellValue(CATEGORY);
		row.createCell(THREE).setCellValue(NAME_OF_METADATA);
		row.createCell(FOUR).setCellValue(IMPACTED_TEST_SCRIPTS);
		closeWorkbook(excelFile);
	}

	// Close Excel Sheet
	private void closeWorkbook(String path) throws IOException {
		FileOutputStream fileOut = new FileOutputStream(new File(path));
		_workbook.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

	// Gets Class Node
	private ClassNode getClassNode(String className) {
		try {
			ClassReader cr = new ClassReader(className);
			ClassNode cn = new ClassNode();
			cr.accept(cn, ZERO);
			return cn;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void callMethodOccurrences(Map<String, List<Object>> map,
			Set<Class<? extends SFDCAutomationFW>> allObjectReoClasses, String method) {
		map.entrySet().stream().forEach(value -> {
			String[] array = String.valueOf(value.getValue()).replaceAll(JSON_REGEX, StringUtils.EMPTY).split(COMMA);
			List<String> list = Arrays.stream(array).map(String::trim).collect(Collectors.toList());
			allObjectReoClasses.parallelStream()
					.filter(objectRepoClasses -> objectRepoClasses.getName().contains((String) value.getKey()))
					.forEach(objectRepoClasses -> {
						String className = objectRepoClasses.getName();
						objectRepositoryMethodOccurences(getClassNode(className), className, list, method,
								(String) value.getKey());
					});
		});
	}

	private Map<String, List<Object>> readExcel(String path, Map<String, List<Object>> map, int pos)
			throws FileNotFoundException, IOException {
		List<String[]> excelValues = readExcel(path);
		for (String[] datas : excelValues) {
			List<Object> list2 = new ArrayList<>();
			List<Object> list = new ArrayList<>();
			if (datas.length > pos) {
				String[] datas1 = datas[pos].replaceAll(EXCEL_REGEX, StringUtils.EMPTY).split(COMMA);
				for (String data : datas1) {
					if (!data.equalsIgnoreCase(NULL))
						list.add(data);
				}
				if (map.containsKey(datas[ZERO])) {
					List<Object> list1 = map.get(datas[ZERO]);
					list1.add(list);
					map.put(datas[ZERO], list1);
				} else {
					list2.add(list);
					map.put(datas[ZERO], list2);
				}
			}
		}
		return map;
	}

	/**
	 * Takes the report in excel format file path, user_space object repository
	 * package and test classes package as an input and finds the occurrences of
	 * impact methods in test classes and updates in Impacted Test Reports column in
	 * the same excel sheet.
	 * 
	 * @param filePath           Excel file Path
	 * @param userRepPackagePath User Repository Package Path
	 * @param testPackagePath    Test classes Package Path
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void analyzeImpactedScripts(String filePath, String userRepPackagePath, String testPackagePath)
			throws Exception {
		if (StringUtils.isBlank(filePath) || StringUtils.isBlank(userRepPackagePath)
				|| StringUtils.isBlank(testPackagePath))
			throw new Exception(
					"Unable to proceed further since one of these/all file path or user package path and test package path is/are null");

		_userRepositoryPackagePath = userRepPackagePath;
		_testPackage = testPackagePath;
		_filePath = filePath;
		_excelPath = new File(filePath).getParent() + OUTPUT_FILE;
		createExcelSheet(_excelPath);

		Set<Class<? extends TestBase>> allTestClasses = (Set<Class<? extends TestBase>>) getAllTestClasses(_testPackage,
				com.mop.qa.testbase.TestBase.class);
		Set<Class<? extends SFDCAutomationFW>> allObjectReoClasses = (Set<Class<? extends SFDCAutomationFW>>) getAllTestClasses(
				_userRepositoryPackagePath, SOURCE_CODE.SFDC.SFDCAutomationFW.class);

		allTestClasses.parallelStream().forEach(value -> {
			String className = value.getName();
			callingMethodOccurrences(getClassNode(className), className,
					_userRepositoryPackagePath.replace(FULLSTOP, BACKSLASH));
		});

		Map<String, List<Object>> buttonsMap = new HashMap<>();
		Map<String, List<Object>> fieldsMap = new HashMap<>();
		Map<String, List<Object>> relatedListMap = new HashMap<>();

		if (filePath.endsWith(JSON_EXTENSION)) {
			String jsonfile = JsonPath.parse(new File(_filePath)).jsonString();
			List<String> objectNameList = JsonPath.parse(jsonfile).read(OBJECT_PATH);
			Set<String> objectNameSet = objectNameList.stream().collect(Collectors.toSet());
			buttonsMap = objectNameSet.parallelStream().collect(Collectors.toMap((value) -> value, value -> JsonPath
					.parse(jsonfile).read(String.format(COMMON_PATH, value, Category.BUTTON.AnalyzerCategory))));

			fieldsMap = objectNameSet.parallelStream().collect(Collectors.toMap((value) -> value, value -> JsonPath
					.parse(jsonfile).read(String.format(COMMON_PATH, value, Category.FIELD.AnalyzerCategory))));

			relatedListMap = objectNameSet.parallelStream().collect(Collectors.toMap((value) -> value, value -> JsonPath
					.parse(jsonfile).read(String.format(COMMON_PATH, value, Category.RELATED_LIST.AnalyzerCategory))));
		} else if (filePath.endsWith(EXCEL_EXTENSION)) {
			buttonsMap = readExcel(filePath, buttonsMap, THREE);
			fieldsMap = readExcel(filePath, fieldsMap, FOUR);
			relatedListMap = readExcel(filePath, relatedListMap, FIVE);
		}

		callMethodOccurrences(buttonsMap, allObjectReoClasses, Category.BUTTON.RepoCategory);
		callMethodOccurrences(fieldsMap, allObjectReoClasses, Category.FIELD.RepoCategory);
		callMethodOccurrences(relatedListMap, allObjectReoClasses, Category.RELATED_LIST.RepoCategory);
	}
}