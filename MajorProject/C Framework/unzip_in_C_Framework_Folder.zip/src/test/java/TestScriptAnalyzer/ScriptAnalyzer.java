package TestScriptAnalyzer;

import java.awt.Button;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.text.PlainDocument;
import org.jdesktop.swingx.prompt.PromptSupport;

import com.jgoodies.forms.factories.DefaultComponentFactory;

public class ScriptAnalyzer extends PlainDocument {
	private static final long serialVersionUID = 1L;
	private JFrame frame;
	private JTable table;
	private JTextField txtAnalyzer;
	private String excelName;
	private String packages;
	private String objRepoName;

	private String getExcelName() {
		return excelName;
	}

	private void setExcelName(String excelName) {
		this.excelName = excelName;
	}

	private String getPackagesName() {
		return packages;
	}

	private void setPackagesName(String packages) {
		this.packages = packages;
	}

	private String getObjRepoName() {
		return objRepoName;
	}

	private void setObjRepoName(String objRepoName) {
		this.objRepoName = objRepoName;
	}

    // Launch the application
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ScriptAnalyzer window = new ScriptAnalyzer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

    // Create the application
	public ScriptAnalyzer() {
		initialize();
	}

    // Initialise the contents of the frame
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.textHighlight);
		frame.getContentPane().setLayout(null);
		JPanel panel = new JPanel();
		JTextArea textPane = new JTextArea();
		JTextArea textPane_1 = new JTextArea();

		panel.setBackground(SystemColor.inactiveCaption);
		panel.setBounds(6, 6, 299, 434);
		frame.getContentPane().add(panel);

		txtAnalyzer = new JTextField();
		txtAnalyzer.setEditable(false);
		txtAnalyzer.setBackground(Color.WHITE);
		txtAnalyzer.setHorizontalAlignment(SwingConstants.CENTER);
		txtAnalyzer.setText("ScriptAnalyzer");
		panel.add(txtAnalyzer);
		txtAnalyzer.setColumns(10);

		JLabel lblNewLabel = new JLabel("ScriptAnalyzer");
		lblNewLabel.setForeground(SystemColor.text);
		lblNewLabel.setIcon(new ImageIcon(
				System.getProperty("user.dir") + "/panel.png"));
		panel.add(lblNewLabel);

		Button button = new Button("Results");
		button.setForeground(SystemColor.controlText);
		button.setBackground(SystemColor.textInactiveText);
		button.setBounds(372, 370, 217, 42);
		frame.getContentPane().add(button);
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evnt) {
				try {
					new Analyzer().analyzeImpactedScripts(getExcelName(), getObjRepoName(), getPackagesName());
					JOptionPane.showMessageDialog(null,
							"Results Fetched!!" + "\n" + "Please check Source File for Impacted Tests");
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Error Fetching results, Please try again with valid Data");
					e.printStackTrace();
				}
			}
		});
		
		// "USER_SPACE.ObjectRepository"com.mop.qa.test
		Button btnImport = new Button("Import Source");
		btnImport.setBackground(SystemColor.textInactiveText);
		btnImport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent fileName) {
				JFileChooser jf = new JFileChooser();
				int result = jf.showOpenDialog(null);
				if (result == JFileChooser.APPROVE_OPTION) {
					String excel = jf.getSelectedFile().getAbsolutePath();
					setExcelName(excel);
					if (excel == null || excel.isEmpty()) {
						try {
							throw new Exception("No source file entered, Please select valid test source...");
						} catch (Exception e) {
							e.printStackTrace();
							//System.exit(2);
						}
					}
				}
			}
		});
		
		btnImport.setBounds(337, 41, 117, 29);
		frame.getContentPane().add(btnImport);

		JLabel lblNewJgoodiesTitle = DefaultComponentFactory.getInstance().createTitle("Packages to Analyze");
		lblNewJgoodiesTitle.setBounds(337, 107, 235, 16);
		frame.getContentPane().add(lblNewJgoodiesTitle);

		table = new JTable();
		table.setBounds(570, 233, -245, -74);
		frame.getContentPane().add(table);

		textPane.setBounds(338, 124, 194, 42);
		PromptSupport.setPrompt("Enter Parent Test Package : ", textPane);
		textPane.setLineWrap(true);
		textPane.setWrapStyleWord(true);
		textPane.setText("com.mop.qa.test");
		textPane.setCaretPosition(0);
		
		// Add key listener to change the TAB behavior in
		// JTextArea to transfer focus to other component forward
		// or backward.
		textPane.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_TAB) {
					if (e.getModifiersEx() > 0) {
						textPane.transferFocusBackward();
					} else {
						textPane.transferFocus();
					}
					e.consume();
				}
				if (textPane.getText().length() >= 75
						&& !(e.getKeyChar() == KeyEvent.VK_DELETE || e.getKeyChar() == KeyEvent.VK_BACK_SPACE)) {
					frame.getToolkit().beep();
					e.consume();
				}
				setPackagesName(textPane.getText());
			}
		});
		
		if (textPane.getText().toString().trim().equals("com.mop.qa.test")) {
			setPackagesName("com.mop.qa.test");
		}
		
		frame.getContentPane().add(textPane);
		JLabel lblNewJgoodiesTitle_1 = DefaultComponentFactory.getInstance().createTitle("Object Repo");
		lblNewJgoodiesTitle_1.setBounds(336, 216, 122, 16);
		frame.getContentPane().add(lblNewJgoodiesTitle_1);

		textPane_1.setBounds(338, 236, 194, 42);
		PromptSupport.setPrompt("Enter Object Repo Name", textPane_1);
		textPane_1.setLineWrap(true);
		textPane_1.setWrapStyleWord(true);
		textPane_1.setCaretPosition(0);
		textPane_1.setText("USER_SPACE.ObjectRepository");
		textPane_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_TAB) {
					if (e.getModifiersEx() > 0) {
						textPane_1.transferFocusBackward();
					} else {
						textPane_1.transferFocus();
					}
					e.consume();
				}
				if (textPane_1.getText().length() >= 75
						&& !(e.getKeyChar() == KeyEvent.VK_DELETE || e.getKeyChar() == KeyEvent.VK_BACK_SPACE)) {
					frame.getToolkit().beep();
					e.consume();
				}
				setObjRepoName(textPane_1.getText());
			}
		});
		
		if (textPane_1.getText().toString().trim().equals("USER_SPACE.ObjectRepository")) {
			setObjRepoName("USER_SPACE.ObjectRepository");
		}
		
		frame.getContentPane().add(textPane_1);
		frame.setBounds(100, 100, 655, 468);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}