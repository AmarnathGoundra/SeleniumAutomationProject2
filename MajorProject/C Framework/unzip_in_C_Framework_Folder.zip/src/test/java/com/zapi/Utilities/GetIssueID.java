package com.zapi.Utilities;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zapi.base.ZapiBase;

public class GetIssueID extends ZapiBase {

	public String searchUri;

	public GetIssueID(String currentTest) {
		super(currentTest);
		searchUri = SEARCH_ISSUE_URI.replace("{BASE}", JIRA_URL);
	}

	public GetIssueID() {
		super();
		searchUri = SEARCH_ISSUE_URI.replace("{BASE}", JIRA_URL);
	}

	/**
	 * This method is used to get the Issue ID
	 * 
	 * @param issueID
	 *            Issue Key of the Bug
	 * @return Issue ID
	 * @throws JSONException
	 */
	public String getIssueID(String issueID) throws JSONException {

		JSONObject jqlJsonObj = new JSONObject();
		jqlJsonObj.put("jql", "id = " + issueID);
		jqlJsonObj.put("startAt", 0);
		jqlJsonObj.put("maxResults", 21);
		jqlJsonObj.put("fieldsByKeys", false);

		byte[] bytesEncoded = Base64.encodeBase64((USERNAME + ":" + PASSWORD).getBytes());
		String authorizationHeader = "Basic " + new String(bytesEncoded);
		Header header = new BasicHeader(HttpHeaders.AUTHORIZATION, authorizationHeader);

		StringEntity jqlJSON = null;
		try {
			jqlJSON = new StringEntity(jqlJsonObj.toString());
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}

		HttpResponse response = null;
		HttpClient restClient = HttpClientBuilder.create().build();
		try {
			HttpPost createProjectReq = new HttpPost(searchUri);
			createProjectReq.addHeader(header);
			createProjectReq.addHeader("Content-Type", "application/json");
			createProjectReq.setEntity(jqlJSON);

			response = restClient.execute(createProjectReq);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		int statusCode = response.getStatusLine().getStatusCode();
		String id = null;
		if (statusCode >= 200 && statusCode < 300) {
			HttpEntity entity1 = response.getEntity();
			String issueString = null;
			try {
				issueString = EntityUtils.toString(entity1);
			} catch (ParseException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			JSONArray tempArr = new JSONArray();
			JSONObject tempObj = new JSONObject(issueString);
			tempArr = tempObj.getJSONArray("issues");
			tempObj = (JSONObject) tempArr.get(0);

			id = tempObj.getString("id");
		}

		return id;
	}

}
