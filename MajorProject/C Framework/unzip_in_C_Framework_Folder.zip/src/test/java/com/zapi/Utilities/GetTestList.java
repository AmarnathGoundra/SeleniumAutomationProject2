package com.zapi.Utilities;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zapi.base.ZapiBase;

public class GetTestList extends ZapiBase {

	public String getTestsUri;

	public GetTestList(String currentTest) {
		super(currentTest);
	}

	public GetTestList() {
		super();
	}

	/**
	 * This method is used to get the List of Tests available in a particular Cycle
	 * 
	 * @param cycleID
	 *            Cycle ID of the test
	 * @param projectID
	 *            Project ID
	 * @param versionID
	 *            Version ID of the execution
	 * @param accessKey
	 *            Access Key
	 * @return List of Tests in the current Cycle
	 * @throws URISyntaxException
	 * @throws JSONException
	 */
	public Map<String, String> getListOfTests(String cycleID, String projectID, String versionID, String accessKey)
			throws URISyntaxException, JSONException {
		Map<String, String> executionIds = new HashMap<String, String>();

		getTestsUri = GET_TESTS_IN_CYCLE_URI.replace("{BASE}", ZEPHYR_URL) + cycleID + "?projectId=" + projectID
				+ "&versionId=" + versionID;

		String jwt = generateJwtToken("GET", getTestsUri);

		HttpResponse response = null;
		HttpClient restClient = HttpClientBuilder.create().build();
		HttpGet httpGet = new HttpGet(getTestsUri);
		httpGet.setHeader("Authorization", jwt);
		httpGet.setHeader("zapiAccessKey", accessKey);

		try {
			response = restClient.execute(httpGet);
		} catch (ClientProtocolException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		int statusCode = response.getStatusLine().getStatusCode();

		if (statusCode >= 200 && statusCode < 300) {
			HttpEntity entity = response.getEntity();
			String sampleString = null;
			try {
				sampleString = EntityUtils.toString(entity);
			} catch (ParseException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			JSONObject allIssues = new JSONObject(sampleString);
			JSONArray IssuesArray = allIssues.getJSONArray("searchObjectList");
			if (IssuesArray.length() == 0) {
				return executionIds;
			}
			JSONObject issueObj = new JSONObject();
			for (int j = 0; j <= IssuesArray.length() - 1; j++) {
				JSONObject tempObj = IssuesArray.getJSONObject(j);
				issueObj = tempObj.getJSONObject("execution");
				String testExecutionID = issueObj.getString("id");
				long testID = issueObj.getLong("issueId");
				executionIds.put(testExecutionID, String.valueOf(testID));
			}
		}

		return executionIds;
	}

}
