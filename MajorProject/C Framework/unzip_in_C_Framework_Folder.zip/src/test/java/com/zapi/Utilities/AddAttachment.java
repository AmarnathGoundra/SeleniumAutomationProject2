package com.zapi.Utilities;

import java.io.File;
import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.HttpClientBuilder;

import com.zapi.base.ZapiBase;

public class AddAttachment extends ZapiBase {

	public String attachmentUri;

	public AddAttachment(String currentTest) {
		super(currentTest);
	}

	public AddAttachment() {
		super();
	}

	/**
	 * This method is used to attach a file into a test execution
	 * 
	 * @param projectID
	 *            Project ID
	 * @param versionID
	 *            Version ID of the cycle
	 * @param accessKey
	 *            Access Key
	 * @param cycleID
	 *            Cycle ID of cycle to be executed
	 * @param issueID
	 *            Issue ID of the test in cycle
	 * @param entityName
	 *            Execution or Test Step
	 * @param entityID
	 *            Execution ID or Step Execution ID
	 * @param filePath
	 *            Path to the file to be attached
	 * @param comment
	 *            Optional comment to be added to the test Execution
	 * @throws ParseException
	 * @throws IOException
	 */
	public void attachFile(String projectID, String versionID, String accessKey, String cycleID, String issueID,
			String entityName, String entityID, String filePath, String comment) throws ParseException, IOException {

		attachmentUri = ADD_ATTACHMENT_URI.replace("{BASE}", ZEPHYR_URL) + "?issueId=" + issueID + "&versionId="
				+ versionID + "&entityName=" + "execution" + "&cycleId=" + cycleID + "&entityId=" + entityID
				+ "&comment=" + comment + "&projectId=" + projectID;
		HttpResponse response = null;
		try {
			String jwt = generateJwtToken("POST", attachmentUri);

			HttpClient restClient = HttpClientBuilder.create().build();
			File fileupload = new File(filePath);
			MultipartEntity entity = new MultipartEntity();
			HttpPost addAttachmentReq = new HttpPost(attachmentUri);
			addAttachmentReq.addHeader("Authorization", jwt);
			addAttachmentReq.addHeader("zapiAccessKey", accessKey);
			entity.addPart("file", new FileBody(fileupload));

			addAttachmentReq.setEntity(entity);
			response = restClient.execute(addAttachmentReq);

		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode >= 200 && statusCode < 300) {
			System.out.println("Attachment added Successfully");
		} else {
			System.out.println("Failed to add attachment");
		}

	}
}
