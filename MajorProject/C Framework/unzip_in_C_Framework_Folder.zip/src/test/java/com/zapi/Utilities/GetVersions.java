package com.zapi.Utilities;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.zapi.base.ZapiBase;

public class GetVersions extends ZapiBase {

	public String getVersionsUri = null;

	public GetVersions(String currentTest) {
		super(currentTest);
		getVersionsUri = GET_VERSIONS_URI.replace("{BASE}", JIRA_URL).replace("{projectId}", projectID);
	}

	public GetVersions() {
		super();
		getVersionsUri = GET_VERSIONS_URI.replace("{BASE}", JIRA_URL).replace("{projectId}", projectID);
	}

	/**
	 * This method is used to get the list of versions available in Test Plan
	 * 
	 * @param accessKey
	 *            Access Key
	 * @return Map of version ID and version Name
	 */
	public Map<String, String> getVersionList(String accessKey) throws org.json.simple.parser.ParseException {

		Map<String, String> map = new HashMap<String, String>();
		JSONParser jsonParser = new JSONParser();

		byte[] bytesEncoded = Base64.encodeBase64((USERNAME + ":" + PASSWORD).getBytes());
		String authorizationHeader = "Basic " + new String(bytesEncoded);
		Header header = new BasicHeader(HttpHeaders.AUTHORIZATION, authorizationHeader);

		HttpResponse response = null;
		HttpClient restClient = HttpClientBuilder.create().build();
		try {
			HttpGet getVersionsRequest = new HttpGet(getVersionsUri);
			getVersionsRequest.addHeader(header);
			getVersionsRequest.addHeader("Content-Type", "application/json");

			response = restClient.execute(getVersionsRequest);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode >= 200 && statusCode < 300) {
			HttpEntity entity = response.getEntity();
			String sampleString = null;
			try {
				sampleString = EntityUtils.toString(entity);
			} catch (ParseException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			Object obj = jsonParser.parse(sampleString);
			JSONArray array = (JSONArray) obj;

			for (int i = 0; i < array.size(); i++) {
				JSONObject json = (JSONObject) array.get(i);
				String name = (String) json.get("name");
				String id = (String) json.get("id");
				map.put(id, name);
			}

		}
		return map;

	}

}
