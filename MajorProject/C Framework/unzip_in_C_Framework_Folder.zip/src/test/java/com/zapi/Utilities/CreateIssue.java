package com.zapi.Utilities;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.zapi.base.ZapiBase;

public class CreateIssue extends ZapiBase {

	public String createTestUri = null;

	public CreateIssue(String currentTest) {
		super(currentTest);
		createTestUri = CREATE_TEST_URI.replace("{BASE}", JIRA_URL);
	}
	
	public CreateIssue() {
		super();
		createTestUri = CREATE_TEST_URI.replace("{BASE}", JIRA_URL);
	}

	/**
	 * This method is used to create a Bug in JIRA
	 * 
	 * @param projectID
	 *            Project ID
	 * @param summary
	 *            Summary of the Bug to be created
	 * @return
	 * @throws JSONException
	 * @throws ParseException
	 * @throws IOException
	 */
	public String createIssue(String projectID, /* String issueType, String assigneeName, String reporterName, */
			String summary) throws JSONException, ParseException, IOException {

		JSONObject projectObj = new JSONObject();
		projectObj.put("id", projectID);

		JSONObject issueTypeObj = new JSONObject();
		issueTypeObj.put("name", "Bug");

		// JSONObject assigneeObj = new JSONObject();
		// assigneeObj.put("name", assigneeName);
		//
		// JSONObject reporterObj = new JSONObject();
		// reporterObj.put("name", reporterName);

		JSONObject fieldsObj = new JSONObject();
		fieldsObj.put("project", projectObj);
		fieldsObj.put("summary", summary);
		fieldsObj.put("issuetype", issueTypeObj);
		// fieldsObj.put("assignee", assigneeObj);
		// fieldsObj.put("reporter", reporterObj);

		JSONObject createTestObj = new JSONObject();
		createTestObj.put("fields", fieldsObj);

		byte[] bytesEncoded = Base64.encodeBase64((USERNAME + ":" + PASSWORD).getBytes());
		String authorizationHeader = "Basic " + new String(bytesEncoded);
		Header header = new BasicHeader(HttpHeaders.AUTHORIZATION, authorizationHeader);

		StringEntity createTestJSON = null;
		try {
			createTestJSON = new StringEntity(createTestObj.toString());
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}

		HttpResponse response = null;
		HttpClient restClient = HttpClientBuilder.create().build();
		try {
			HttpPost createTestRequest = new HttpPost(createTestUri);
			createTestRequest.addHeader(header);
			createTestRequest.addHeader("Content-Type", "application/json");
			createTestRequest.setEntity(createTestJSON);

			response = restClient.execute(createTestRequest);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String issueID = null;
		int statusCode = response.getStatusLine().getStatusCode();

		HttpEntity entity = response.getEntity();
		if (statusCode >= 200 && statusCode < 300) {

			String entityString = null;
			try {
				entityString = EntityUtils.toString(entity);
			} catch (ParseException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			JSONObject createTestResp = new JSONObject(entityString);
			issueID = createTestResp.getString("id");
			//System.out.println("Created a BUG with Id ---" + issueID);
		} else {

			try {
				String entityString = null;
				entityString = EntityUtils.toString(entity);
				JSONObject executionResponseObj = new JSONObject(entityString);
				//System.out.println("Error in creating test ---" + executionResponseObj.toString());
				throw new ClientProtocolException("Unexpected response status: " + statusCode);
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			}
		}
		return issueID;
	}

}
