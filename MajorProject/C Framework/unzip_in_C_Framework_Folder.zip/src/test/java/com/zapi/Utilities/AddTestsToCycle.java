package com.zapi.Utilities;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONException;
import org.json.JSONObject;

import com.zapi.base.ZapiBase;

public class AddTestsToCycle extends ZapiBase {

	public String addTestsUri;
	public String finalUri;

	public AddTestsToCycle() {
		super();
		addTestsUri = ADD_TESTS_URI.replace("{BASE}", ZEPHYR_URL);
	}

	/**
	 * This method is used to add tests to a cycle
	 * 
	 * @param projectID Project ID
	 * @param versionID Version ID
	 * @param accessKey Access Key
	 * @param cycleID Cycle ID
	 * @param issueId Issue ID
	 * @return
	 * @throws URISyntaxException
	 */
	public boolean addTestCycle(String projectID, String versionID, String accessKey, String cycleID, String[] issueId)
			throws URISyntaxException {

		Long versionId = Long.parseLong(versionID);
		JSONObject addTestsObj = new JSONObject();
		try {
			addTestsObj.put("issues", issueId);
			addTestsObj.put("method", "1");
			addTestsObj.put("projectId", projectID);
			addTestsObj.put("versionId", versionId);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		StringEntity addTestsJSON = null;
		try {
			addTestsJSON = new StringEntity(addTestsObj.toString());
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}

		finalUri = addTestsUri + cycleID;
		String jwt = generateJwtToken("POST", finalUri);

		HttpResponse response = null;
		HttpClient restClient = HttpClientBuilder.create().build();
		HttpPost addTestsReq = new HttpPost(finalUri);
		addTestsReq.addHeader("Content-Type", "application/json");
		addTestsReq.addHeader("Authorization", jwt);
		addTestsReq.addHeader("zapiAccessKey", accessKey);
		addTestsReq.setEntity(addTestsJSON);

		try {
			response = restClient.execute(addTestsReq);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode >= 200 && statusCode < 300) {
			return true;
		} else {
			try {
				throw new ClientProtocolException("Unexpected response status: " + statusCode);
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

}
