package com.zapi.Utilities;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.zapi.base.ZapiBase;

public class CloneExecution extends ZapiBase {

	public String updateExecutionUri;
	public String updateUri;

	public CloneExecution(String currentTest) {
		super(currentTest);
		updateExecutionUri = EXECUTE_TESTS_URI.replace("{BASE}", ZEPHYR_URL);
		System.out.println("updateExecutionUri" + updateExecutionUri);
	}

	public CloneExecution() {
		super();
		updateExecutionUri = EXECUTE_TESTS_URI.replace("{BASE}", ZEPHYR_URL);
	}

	/**
	 * This method is used to group up the parameters for updating a test execution
	 * in a cycle
	 * 
	 * @param code
	 *            Status code 1= Pass 2= Fail
	 * @param cycleID
	 *            Cycle ID of cycle to be executed
	 * @param projectID
	 *            Project ID
	 * @param versionID
	 *            Version ID of the cycle
	 * @param accessKey
	 *            Access Key
	 * @param comment
	 *            Optional comment to be added to the test Execution
	 * @param executionID
	 *            Test Execution ID
	 * @param issue
	 *            Issue parameterized or default
	 * @throws JSONException
	 * @throws URISyntaxException
	 * @throws ParseException
	 * @throws IOException
	 */
	public void updateExectionStatus(String code, String cycleID, String projectID, String versionID, String accessKey,
			String comment, String executionID, String issue)
			throws JSONException, URISyntaxException, ParseException, IOException {

		JSONObject statusObj = new JSONObject();

		/**
		 * Replace code by any of the following:
		 * 
		 * 1 = PASS, 2 = FAIL, 3 = WORK IN PROGRESS, 4 = BLOCKED
		 * 
		 */
		statusObj.put("id", code);

		JSONObject executeTestsObj = new JSONObject();
		executeTestsObj.put("status", statusObj);
		executeTestsObj.put("cycleId", cycleID);
		executeTestsObj.put("projectId", projectID);
		executeTestsObj.put("versionId", versionID);
		executeTestsObj.put("comment", comment);

		JSONObject object = executeTestsObj;
		object.put("issueId", issue);
		//System.out.println("object --- " + object);

		StringEntity executeTestsJSON = null;
		try {
			executeTestsJSON = new StringEntity(object.toString());
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		updateUri = updateExecutionUri + executionID;
		System.out.println(updateExecutions(updateUri, accessKey, executeTestsJSON));
		if (code.equals("2")) {

		}
	}

	/**
	 * This method updates the Test case with JSON object created
	 * 
	 * @param updateUri
	 *            Attachment URI for API call
	 * @param accessKey
	 *            Access Key
	 * @param executeTestsJSON
	 *            JSON object to be passed as request
	 * @return Execution Status
	 * @throws URISyntaxException
	 * @throws JSONException
	 * @throws ParseException
	 * @throws IOException
	 */
	public String updateExecutions(String updateUri, String accessKey, StringEntity executeTestsJSON)
			throws URISyntaxException, JSONException, ParseException, IOException {

		String jwt = generateJwtToken("PUT", updateUri);

		HttpResponse response = null;
		HttpClient restClient = HttpClientBuilder.create().build();

		HttpPut executeTest = new HttpPut(updateUri);
		executeTest.addHeader("Content-Type", "application/json");
		executeTest.addHeader("Authorization", jwt);
		executeTest.addHeader("zapiAccessKey", accessKey);
		executeTest.setEntity(executeTestsJSON);

		try {
			response = restClient.execute(executeTest);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		int statusCode = response.getStatusLine().getStatusCode();
		String executionStatus = "No Test Executed";
		HttpEntity entity = response.getEntity();

		if (statusCode >= 200 && statusCode < 300) {
			String string = null;
			try {
				string = EntityUtils.toString(entity);
				JSONObject executionResponseObj = new JSONObject(string);
				JSONObject descriptionResponseObj = executionResponseObj.getJSONObject("execution");
				JSONObject statusResponseObj = descriptionResponseObj.getJSONObject("status");
				executionStatus = statusResponseObj.getString("description");
			} catch (ParseException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				String sampleString = null;
				sampleString = EntityUtils.toString(entity);
				JSONObject executionResponseObj = new JSONObject(sampleString);
				System.out.println("executionResponseObj ---" + executionResponseObj.toString());
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			}
		}
		return executionStatus;

	}

}
