package com.zapi.Utilities;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.zapi.base.ZapiBase;

public class CreateCycle extends ZapiBase {

	public String createCycleUri;
	public String cycleID;

	public CreateCycle() {
		super();
		createCycleUri = CREATE_CYCLE_URI.replace("{BASE}", ZEPHYR_URL);
	}

	public String createCycle(String projectID, String versionID, String accessKey, String cycleName,
			String cycleDescription) throws JSONException {

		Long versionId = Long.parseLong(versionID);

		JSONObject createCycleObj = new JSONObject();
		try {
			createCycleObj.put("name", cycleName);
			createCycleObj.put("description", cycleDescription);
			createCycleObj.put("startDate", System.currentTimeMillis());
			createCycleObj.put("projectId", projectID);
			createCycleObj.put("versionId", versionId);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		StringEntity cycleJSON = null;
		try {
			cycleJSON = new StringEntity(createCycleObj.toString());
			cycleJSON.setContentType("application/json");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		String jwt = generateJwtToken("POST", createCycleUri);

		HttpResponse response = null;
		HttpClient restClient = HttpClientBuilder.create().build();

		HttpPost createCycleRequest = new HttpPost(createCycleUri);
		createCycleRequest.addHeader("Content-Type", "application/json");
		createCycleRequest.addHeader("Authorization", jwt);
		createCycleRequest.addHeader("zapiAccessKey", accessKey);
		createCycleRequest.setEntity(cycleJSON);

		try {
			response = restClient.execute(createCycleRequest);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode >= 200 && statusCode < 300) {
			HttpEntity entity = response.getEntity();
			String entityString = null;
			try {
				entityString = EntityUtils.toString(entity);
				JSONObject cycleObj = new JSONObject(entityString);
				cycleID = cycleObj.getString("id");
				System.out.println("Created test cycle : \"" + cycleName + "\" with Cycle ID : " + cycleID);
			} catch (ParseException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		} else {
			try {
				System.out.println("Failed to create Cycle");
				throw new ClientProtocolException("Unexpected response status: " + statusCode);
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			}
		}

		return cycleID;

	}

}
