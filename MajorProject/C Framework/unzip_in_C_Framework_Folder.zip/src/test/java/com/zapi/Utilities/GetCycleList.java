package com.zapi.Utilities;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zapi.base.ZapiBase;

public class GetCycleList extends ZapiBase {

	public String searchUri = null;

	public GetCycleList(String currentTest) {
		super(currentTest);
		searchUri = GET_CYCLES_URI.replace("{BASE}", ZEPHYR_URL);
	}

	public GetCycleList() {
		super();
		searchUri = GET_CYCLES_URI.replace("{BASE}", ZEPHYR_URL);
	}

	/**
	 * This method is used to get the cycles available in the specified version
	 * 
	 * @param projectID
	 *            Project ID
	 * @param versionID
	 *            Version ID of the current execution
	 * @param accessKey
	 *            Access Key
	 * @return List of cycles in the version
	 * @throws URISyntaxException
	 * @throws JSONException
	 */
	public Map<String, String> getCycleList(String projectID, String versionID, String accessKey)
			throws URISyntaxException, JSONException {

		Map<String, String> cycleIds = new HashMap<String, String>();
		Long versionId = Long.parseLong(versionID);

		String finalUri = searchUri + "versionId=" + versionId + "&projectId=" + projectID;

		String jwt = generateJwtToken("GET", finalUri);

		HttpResponse response = null;
		HttpClient restClient = HttpClientBuilder.create().build();
		HttpGet httpGet = new HttpGet(finalUri);
		httpGet.setHeader("Authorization", jwt);
		httpGet.setHeader("zapiAccessKey", accessKey);

		try {
			response = restClient.execute(httpGet);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode >= 200 && statusCode < 300) {
			HttpEntity entity = response.getEntity();
			String cycleList = null;
			try {
				cycleList = EntityUtils.toString(entity);
			} catch (ParseException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			JSONArray IssuesArray = new JSONArray(cycleList);
			if (IssuesArray.length() == 0) {
				return cycleIds;
			}
			for (int j = 0; j <= IssuesArray.length() - 1; j++) {
				JSONObject tempObj = IssuesArray.getJSONObject(j);
				String cycleId = tempObj.getString("id");
				String cycleName = tempObj.getString("name");
				cycleIds.put(cycleId, cycleName);
			}
		}
		return cycleIds;
	}

}
