package com.mop.qa.test.API;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.testbase.ServiceBase;
import com.mop.qa.testbase.TestBase;
import io.restassured.response.Response;

public class AccountValidation extends TestBase{
	
		@Test
		public void AccountValidation() throws Exception {

			//AccountAPI accountAPI = new AccountAPI();			
			ServiceBase restService = new ServiceBase();	
			ReadDataSheet readData = new ReadDataSheet();			
			Map<String, String> bodyParameters = new HashMap<>();
			Map<String, String> queryParams = new HashMap<>();
			
			String objName = readData.getValue("DATA", currentTest, "ObjectName");;
			String requestFilePath = requestFolder + "Request_" + ExtentUtility.timeStamp + "_" + currentTest + ".json";
			String responseFilePath = responseFolder + "Response_" + ExtentUtility.timeStamp + "_" + currentTest + ".json";
												
			//Fetching Data from Datasheet
			bodyParameters = restService.getBodyParameters(currentTest); 			
			
			//Functional API Call for Account Creation			
			Response response = restService.createSalesforceObject(objName, bodyParameters, requestFilePath, responseFilePath );
						
			//Response File parse 
			String files = restService.getJsonFile(responseFilePath);
			DocumentContext documentContext = JsonPath.parse(files);
			
			//Basic Assertions for the API response 
			String responseTime = getPropertyValue("responseTime");
			restService.basicAssertions(response, Integer.parseInt(responseTime));
						
			//Tester-Defined Assertions for the API response 
			restService.validateResponse(documentContext, currentTest, response);	
						
			
			//************** Validation Using Other API ************************//
			
			// Get Account ID for Above Created Account via API 
			JSONObject createTestResp = new JSONObject(response.body().print());
			String objID = createTestResp.getString("id");
						
			//Validate created account using GET method API 
			Response getResponse = restService.getSalesforceObject(objName, objID, requestFilePath, responseFilePath );
						
			//Update account using PUT method API
			Response updateResponse = restService.updateSalesforceObjectPATCH(objName, objID, bodyParameters, requestFilePath, responseFilePath );
					
			//Validate updated account using GET method API 
			Response getUpdatedResponse = restService.getSalesforceObject(objName, objID, requestFilePath, responseFilePath );
			
			//Validate updated account name using GET method API 
			JSONObject objResponseJSON = new JSONObject(getUpdatedResponse.body().print());
			String objUpdateName = objResponseJSON.getString("Name");
			System.out.println(objUpdateName);	
			
			//Delete above Created Account using DELETE method API 
			restService.deleteSalesforceObject(objName, objID, requestFilePath, responseFilePath);
					
			//Validate Account deleted successfully using GET method API
			Assert.assertTrue(restService.getDeletedSalesforceObjectDetails(objName, objID, requestFilePath, responseFilePath));		
									
		}

	}
