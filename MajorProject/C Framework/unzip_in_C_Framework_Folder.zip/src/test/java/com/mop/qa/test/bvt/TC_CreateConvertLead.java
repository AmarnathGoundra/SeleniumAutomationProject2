package com.mop.qa.test.bvt; 
 
 
import org.testng.annotations.Test; 
import com.mop.qa.testbase.TestBase; 
import SOURCE_CODE.SFDC.DB; 
import USER_SPACE.BusinessComponent.BC; 
import SOURCE_CODE.SFDC.SFDCAutomationFW; 
import USER_SPACE.TestPrerequisite.DataSetup; 
import USER_SPACE.ObjectRepository.LeadScreen; 


/* 
* 
* @Author: <Name of Test Script Creator> 
* @Description: <Please mention the scope of this test script> 
* @General Guidelines: Every Test Script must begin from Launching 
* URL of login screen and must end with browser closed 
*/ 

public class TC_CreateConvertLead extends TestBase { 


@Test 
public void createMyTest() { 

SFDCAutomationFW sfdc = null; 
LeadScreen leadScreen = null; 

String TCName = "TC_CreateConvertLead"; 
if (toolName.equalsIgnoreCase("Selenium")) { 
sfdc = new SFDCAutomationFW(remoteDriver, TCName);
leadScreen = new LeadScreen(remoteDriver); 
} else if (toolName.equalsIgnoreCase("Appium")) {
sfdc = new SFDCAutomationFW(appiumDriver, TCName);
leadScreen = new LeadScreen(appiumDriver); 
}
DB DB = new DB();
BC BC = new BC(remoteDriver);
DataSetup DataSetup = new DataSetup();

System.out.println("-----------Begin of TestScript-------------");



try { 
String NickNameofUser = "TestUser1"; 
// Login to SFDC 
sfdc.LoginToSFDC(NickNameofUser); 
// Selecting application 
BC.SelectApplication("Sales"); 
Thread.sleep(5000L); 
// Clicking on Leads Tab 
sfdc.Link("Leads").Click(); 
leadScreen.NewButton().Click(); 





leadScreen.FirstNameField().Type(sfdc.GetCurrentDateTimeStamp()); 
} 
catch (Exception e) { 
e.printStackTrace(); 
System.out.println("Exception(Exception) in main"); 
} finally { 
System.out.println("-----------End of TestScript-------------"); 
} 
} 
} 
