package com.mop.qa.test.Marketing; 
 
 
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.testbase.TestBase; 
import SOURCE_CODE.SFDC.DB; 
import USER_SPACE.BusinessComponent.BC; 
import SOURCE_CODE.SFDC.SFDCAutomationFW; 
import USER_SPACE.TestPrerequisite.DataSetup;
import USER_SPACE.ObjectRepository.AccountsScreen_LUI;
import USER_SPACE.ObjectRepository.AllAppsTabsScreen_LUI;
import USER_SPACE.ObjectRepository.CampaignsScreen_LUI;
import USER_SPACE.ObjectRepository.LeadScreen;
import USER_SPACE.ObjectRepository.LeadsScreen_LUI; 

/* 
* 
* @Author: <Name of Test Script Creator> 
* @Description: <Please mention the scope of this test script> 
* @General Guidelines: Every Test Script must begin from Launching 
* URL of login screen and must end with browser closed 
*/ 

public class TC_CreateCampaign_LUI extends TestBase { 

	/*
	@DataProvider(name = "TestUserList")	 
	  public static Object[][] LoginUsers()
	 {
	 	        return new Object[][] { 
	 	        						{ "TestUser1" },
	 	        						{ "TestUser3" }	 	        						
	 	        					  };	 
	  }
	
	*/
	
//@Test(dataProvider="TestUserList")
//public void createMyTest(String TestUserName) { 
@Test	
public void createMyTest() { 

	SFDCAutomationFW sfdc = null; 
	CampaignsScreen_LUI campaignsScreen = null; 
	AllAppsTabsScreen_LUI allTAppsObjectsScreen = null;
	String TC_CreateCampaign_LUI = "TC_CreateCampaign_LUI";

	String TCName = "TC_CreateCampaign_LUI"; 
	if (toolName.equalsIgnoreCase("Selenium"))
	{ 
		System.out.println("----------------->Inside Test Case");
		sfdc = new SFDCAutomationFW(remoteDriver, TCName);
		System.out.println("----------->Back to Test case");
		campaignsScreen = new CampaignsScreen_LUI(remoteDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(remoteDriver);
	}
	else if (toolName.equalsIgnoreCase("Appium"))
	{
		sfdc = new SFDCAutomationFW(appiumDriver, TCName);
		campaignsScreen = new CampaignsScreen_LUI(appiumDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(appiumDriver);
	}
	
	DB DB = new DB();
	BC BC = new BC(remoteDriver);
	DataSetup DataSetup = new DataSetup();

	System.out.println("-----------Begin of TestScript-------------");

	try { 
			 
		DB.Connect(DataSetup.TestData);
			
		//Reading the test data from external test data sheet
		String CAMPAIGN_NAME = DB.ReadXLData("CreateCampaign", "CAMPAIGN_NAME", "TESTCASENAME", TCName);
		String TYPE = DB.ReadXLData("CreateCampaign", "TYPE", "TESTCASENAME", TCName);
		String STATUS = DB.ReadXLData("CreateCampaign", "STATUS", "TESTCASENAME", TCName);
		String EXP_REV_IN_CAMP = DB.ReadXLData("CreateCampaign", "EXP_REV_IN_CAMP", "TESTCASENAME", TCName);
		String BUDGETED_COST_CAMP = DB.ReadXLData("CreateCampaign", "BUDGETED_COST_CAMP", "TESTCASENAME", TCName);
		
		
		
		//DB.Connect(DataSetup.Logininfo);
		ReadDataSheet rds = new ReadDataSheet();
		String OWNER =  rds.getValue("LoginInfo", SFDCLoginUserName, "Name");
				
		CAMPAIGN_NAME = CAMPAIGN_NAME + BC.GetCurrentDateTimeStamp();
		Thread.sleep(1000L);
		
		Thread.sleep(1000L);
		String mandatory_error = "Complete this field";
		
		// Login to SFDC 
		sfdc.LoginToSFDC(SFDCLoginUserName); //This variable is inherited from TestBase
		
		Thread.sleep(3000L);
		sfdc.SelectApplication_LUI("Marketing");
		Thread.sleep(3000L);
		
		allTAppsObjectsScreen.CampaignsTab().Click();
		
		campaignsScreen.NewButton().Click();
		
		Thread.sleep(4000L);
		
		campaignsScreen.SaveButton().Click();
		
		Thread.sleep(3000L);
		
		campaignsScreen.CampaignNameField().VerifyFieldErrorMsgOnEditPage(mandatory_error);
		sfdc.VerifyPageLevelErrorMessage_LUI("These required fields must be completed");
		
		//Verifying existence of field names 
		campaignsScreen.CampaignOwnerField().VerifyViewOnlyValueEquals(OWNER);
		campaignsScreen.CampaignNameField().IsDisplayed("Yes");
		campaignsScreen.ActiveField().IsDisplayed("Yes");
		campaignsScreen.TypeField().IsDisplayed("Yes");
		campaignsScreen.StatusField().IsDisplayed("Yes");
		campaignsScreen.StartDateField().IsDisplayed("Yes");
		campaignsScreen.EndDateField().IsDisplayed("Yes");
		campaignsScreen.ExpectedRevenueinCampaignField().IsDisplayed("Yes");
		campaignsScreen.ParentCampaignField().IsDisplayed("Yes");
		campaignsScreen.BudgetedCostinCampaignField().IsDisplayed("Yes");
		campaignsScreen.ActualCostinCampaignField().IsDisplayed("Yes");
		campaignsScreen.ExpectedResponseField().IsDisplayed("Yes");
		campaignsScreen.NumSentinCampaignField().IsDisplayed("Yes");
		
		//Entering data
		campaignsScreen.CampaignNameField().Type(CAMPAIGN_NAME);
		campaignsScreen.ActiveField().CheckBoxSelect();
		campaignsScreen.TypeField().SelectPL(TYPE);
		campaignsScreen.StatusField().SelectPL(STATUS);
		campaignsScreen.StartDateField().SelectFromDateLookup("2020", "October","7");
		Thread.sleep(1000);
		campaignsScreen.EndDateField().SelectFromDateLookup("2020", "October","20");
		campaignsScreen.ExpectedRevenueinCampaignField().Type(EXP_REV_IN_CAMP);
		campaignsScreen.BudgetedCostinCampaignField().Type(BUDGETED_COST_CAMP);
		campaignsScreen.ExpectedResponseField().Type("40");
		campaignsScreen.NumSentinCampaignField().Type("10");
			
		
		campaignsScreen.SaveButton().Click();
		
		Thread.sleep(5000L);
		
		sfdc.ClickONSubTab("Details");
		
		String cmpname = campaignsScreen.CampaignNameField().GetViewOnlyValue();
		
		DB.Connect(DataSetup.TestData);		
		
		//Update excel with full name
		DB.UpdateXLCell("CreateCampaign", cmpname, "CAMPAIGN_NAME_SAVED", "TESTCASENAME", TCName);
		
		
		sfdc.LogOff();
		
		remoteDriver.close();
	} 
	catch (Exception e) { 
		e.printStackTrace(); 
		System.out.println("Exception(Exception) in main"); 
	}
	finally { 
		System.out.println("-----------End of TestScript-------------"); 
	} 
	} 
} 
