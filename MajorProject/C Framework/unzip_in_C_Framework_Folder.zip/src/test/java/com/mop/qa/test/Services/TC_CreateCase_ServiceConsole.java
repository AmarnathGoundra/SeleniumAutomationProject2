package com.mop.qa.test.Services; 
 
 
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.testbase.TestBase; 
import SOURCE_CODE.SFDC.DB; 
import USER_SPACE.BusinessComponent.BC; 
import SOURCE_CODE.SFDC.SFDCAutomationFW; 
import USER_SPACE.TestPrerequisite.DataSetup;
import USER_SPACE.ObjectRepository.AllAppsTabsScreen_LUI;
import USER_SPACE.ObjectRepository.CasesScreen_LUI;
import USER_SPACE.ObjectRepository.LeadScreen;
import USER_SPACE.ObjectRepository.LeadsScreen_LUI; 

/* 
* 
* @Author: <Name of Test Script Creator> 
* @Description: <Please mention the scope of this test script> 
* @General Guidelines: Every Test Script must begin from Launching 
* URL of login screen and must end with browser closed 
*/ 

public class TC_CreateCase_ServiceConsole extends TestBase { 

	/*
	@DataProvider(name = "TestUserList")	 
	  public static Object[][] LoginUsers()
	 {
	 	        return new Object[][] { 
	 	        						{ "TestUser1" },
	 	        						{ "TestUser3" }	 	        						
	 	        					  };	 
	  }
	
	*/
	
//@Test(dataProvider="TestUserList")
//public void createMyTest(String TestUserName) { 
@Test	
public void createMyTest() { 

	SFDCAutomationFW sfdc = null; 
	CasesScreen_LUI casesScreen = null; 
	AllAppsTabsScreen_LUI allTAppsObjectsScreen = null;
	String TC_CreateCase_ServiceConsole = "TC_CreateCase_ServiceConsole";

	String TCName = "TC_CreateCase_ServiceConsole"; 
	if (toolName.equalsIgnoreCase("Selenium"))
	{ 
		System.out.println("----------------->Inside Test Case");
		sfdc = new SFDCAutomationFW(remoteDriver, TCName);
		System.out.println("----------->Back to Test case");
		casesScreen = new CasesScreen_LUI(remoteDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(remoteDriver);
	}
	else if (toolName.equalsIgnoreCase("Appium"))
	{
		sfdc = new SFDCAutomationFW(appiumDriver, TCName);
		casesScreen = new CasesScreen_LUI(appiumDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(appiumDriver);
	}
	
	DB DB = new DB();
	BC BC = new BC(remoteDriver);
	DataSetup DataSetup = new DataSetup();

	System.out.println("-----------Begin of TestScript-------------");

	try { 
			 
		DB.Connect(DataSetup.TestData);
			
		//Reading the test data from external test data sheet
		//String FIRSTNAME = DB.ReadXLData("CreateLead", "FIRSTNAME", "TESTCASENAME", TC_CreateLead_LUI);
		//String LASTNAME = DB.ReadXLData("CreateLead", "LASTNAME", "TESTCASENAME", TC_CreateLead_LUI);
		String TYPE = DB.ReadXLData("CreateCase", "TYPE", "TESTCASENAME", TCName);
		String CASE_REASON = DB.ReadXLData("CreateCase", "CASE_REASON", "TESTCASENAME", TCName);
		String CASE_ORIGIN = DB.ReadXLData("CreateCase", "CASE_ORIGIN", "TESTCASENAME", TCName);
		String PRIORITY = DB.ReadXLData("CreateCase", "PRIORITY", "TESTCASENAME", TCName);
			
		
		String CONTACT_NAME = DB.ReadXLData("CreateContact", "CONTACT_NAME", "TESTCASENAME" , "TC_CreateContact_LUI");
		String ACCOUNT_NAME	= DB.ReadXLData("TC_AccountSearch_Update_01", "Account_Name", "TESTCASENAME" , "TC_AccountSearch_Update_01");
		System.out.println("CONTACT_NAME:"+CONTACT_NAME);
				
		ReadDataSheet rds = new ReadDataSheet();
		String OWNER =  rds.getValue("LoginInfo", SFDCLoginUserName, "Name");
		
		
		
		String mandatory_error = "Complete this field";
		
		// Login to SFDC 
		sfdc.LoginToSFDC(SFDCLoginUserName); //This variable is inherited from TestBase
		
		//casesScreen.NewButton().Click(); //This is to click on New button.
		
		Thread.sleep(3000L);
		sfdc.SelectApplication_LUI("Service");
		Thread.sleep(5000L);
		
		allTAppsObjectsScreen.CasesTab().Click();
		Thread.sleep(5000L);
				
		casesScreen.NewButton().Click();
		
		Thread.sleep(5000L);
		
		casesScreen.SaveButton().Click();
		
		Thread.sleep(3000L);
		
		//
		
		sfdc.VerifyPageLevelErrorMessage_LUI("Review the following fields");
		
		casesScreen.CaseOriginField().VerifyFieldErrorMsgOnEditPage(mandatory_error);
		
		//Verifying existence of field names 
		casesScreen.CaseOwnerField().IsDisplayed("Yes");
		casesScreen.CaseNumberField().IsDisplayed("Yes");
		
		casesScreen.StatusField().IsDisplayed("Yes");
		casesScreen.PriorityField().IsDisplayed("Yes");
		casesScreen.AccountNameField().IsDisplayed("Yes");
		casesScreen.ContactNameField().IsDisplayed("Yes");
		
		//Verify Default Pick List Value
		casesScreen.CaseOwnerField().VerifyViewOnlyValueEquals(OWNER);
		casesScreen.StatusField().VerifyPLDefaultValue("New");
		casesScreen.PriorityField().VerifyPLDefaultValue("Medium");
		
		//Entering data
		casesScreen.TypeField().SelectPL(TYPE);
		casesScreen.CaseReasonField().SelectPL(CASE_REASON);
		casesScreen.CaseOriginField().SelectPL(CASE_ORIGIN);
		//casesScreen.AccountNameField().SelectFromLookup(ACCOUNT_NAME);
		//casesScreen.ContactNameField().SelectFromLookup(CONTACT_NAME);
		casesScreen.WebEmailField().Type("abcd@xyz.com");
		casesScreen.WebCompanyField().Type("xyz");
		casesScreen.WebNameField().Type("www.xyztechnology.com");
		casesScreen.WebPhoneField().Type("6545454533");
		casesScreen.InternalCommentsField().Type("This case is created by automation");
		
		casesScreen.SendnotificationemailtocontactField().ClickONAnyTextElementField();
		casesScreen.SendnotificationemailtocontactField().ClickONAnyPartialTextElementField();
		casesScreen.SaveButton().Click();
		
		
		Thread.sleep(5000L);
		
		sfdc.ClickONSubTab("Details");
			
		Thread.sleep(3000L);
		
		String CaseNumber = casesScreen.CaseNumberField().GetViewOnlyValue();
		
		
		//Verify the information from detail view page
		
		DB.Connect(DataSetup.TestData);		
		
		//Update excel with full name
		DB.UpdateXLCell("CreateCase", CaseNumber, "CASE_NUMBER", "TESTCASENAME", TCName);
		Thread.sleep(3000L);
		sfdc.LogOff();
		
		//remoteDriver.close();
	} 
	catch (Exception e) { 
		e.printStackTrace(); 
		System.out.println("Exception(Exception) in main"); 
	}
	finally { 
		System.out.println("-----------End of TestScript-------------"); 
	} 
	} 
} 
