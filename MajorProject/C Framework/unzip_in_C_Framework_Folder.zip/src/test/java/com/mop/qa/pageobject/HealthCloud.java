package com.mop.qa.pageobject;

import io.appium.java_client.AppiumDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import com.mop.qa.testbase.PageBase;

public class HealthCloud extends PageBase {

	public HealthCloud(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
	}

	public HealthCloud(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}

	@FindBy(xpath = "//input[normalize-space(@type)='email' and normalize-space(@id)='username'][1]")
	 WebElement username;
	
	@FindBy(xpath = "//input[normalize-space(@type)='password' and normalize-space(@id)='password'][1]")
	 WebElement password;
	
	@FindBy(xpath = "//input[contains(@class,'button') and @type='submit'][1]")
	 WebElement loginBtn;
	
	@FindBy(xpath= "//table[contains(@class,'leadMru')]/tbody/tr[2]/td[2]/descendant::button")
	WebElement Lead;
	
	@FindBy(id="ext-comp-1005")
	WebElement Frame;
	//form[contains(@name,'actionForm')]/div[2]/descendant::li/input[contains(@title,'New Lead')]
	@FindBy(xpath="//input[normalize-space(@type)='button' and normalize-space(@value)='New Lead'][1]")
	WebElement NewLead;
	
//	@FindBy(xpath= "//div[contains(@id,'navigatortab')]/div[contains(@class,'x-plain-bwrap')]/div/div[4]/div[2]/div[2]/div/div/div/iframe")
//	@FindBy(xpath="//iframe[contains(@src,'ObjectName=Lead&save')]")
	@FindBy(id="ext-comp-1015")
	WebElement FrameBody;
	
//	@FindBy(xpath= "//input[normalize-space(@type)='text' and normalize-space(@id)='name_firstlea2'][1]")
	@FindBy(xpath="//*[@id='00N2800000Igyqu']")
//	@FindBy(xpath="//*[@id='editPage']/div[contains(@id,'ep')]/div[2]/div[3]/table[contains(@class,'detailList')]/tbody/tr[2]/td[2]/input[@id='name_firstlea2']")
//	@FindBy(xpath="/html/body/form[@id='editPage']/div[contains(@id,'ep')]/div[2]/div[3]/table[contains(@class,'detailList')]/tbody/tr[2]/td[2]/input[@id='name_firstlea2']")
	WebElement FirstName;
	
	@FindBy(xpath= "//input[normalize-space(@type)='text' and normalize-space(@id)='name_lastlea2'][1]")
	WebElement LastName;
	
	@FindBy(xpath="//input[normalize-space(@type)='text' and normalize-space(@id)='lea3'][1]")
	WebElement Company; 
	
	public void enterUrl() throws Exception {
		enterUrl("https://abbvie-japac--abvprtlcpy.my.salesforce.com/console");
		Thread.sleep(9000);
		
		enterText(username, "abbvie.carecordinator@abbvie.com", "username");
		enterText(password, "abbvie@1", "password");
		click(loginBtn, "loginBtn");
		Thread.sleep(5000);
		
		click(Lead, "Lead");
		Thread.sleep(5000);
		
		switchToFrame(Frame);
		Thread.sleep(5000);
		
		click(NewLead, "NewLead");
		Thread.sleep(9000);
		
		switchToDefaultContent();
		
		switchToFrame(FrameBody);
		Thread.sleep(5000);
		
	}
	public void enterDetails() throws Exception{
		System.out.println("switched to frame");
//		enterText(LastName, "LastName", "LastName");
		enterText(FirstName, "123456", "FirstName");
		
		System.out.println("entered text in to frame");
	}
}
