package com.mop.qa.test.API;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.testbase.ServiceBase;
import com.mop.qa.testbase.TestBase;
import io.restassured.response.Response;

public class Account_Get_Details_Validation extends TestBase{
	
		@Test
		public void Account_Get_Details_Validation() throws Exception {

			//AccountAPI accountAPI = new AccountAPI();			
			ServiceBase restService = new ServiceBase();	
			ReadDataSheet readData = new ReadDataSheet();			
			Map<String, String> bodyParameters = new HashMap<>();
			Map<String, String> queryParams = new HashMap<>();
			
			String objName = readData.getValue("DATA", currentTest, "ObjectName");;
			String requestFilePath = requestFolder + "Request_" + ExtentUtility.timeStamp + "_" + currentTest + ".json";
			String responseFilePath = responseFolder + "Response_" + ExtentUtility.timeStamp + "_" + currentTest + ".json";
												
			//Fetching Data from Datasheet
			bodyParameters = restService.getBodyParameters(currentTest); 			
			
			//Functional API Call for Account Creation			
			Response response = restService.createSalesforceObject(objName, bodyParameters, requestFilePath, responseFilePath );
											
			// Get Account ID for Above Created Account via API 
			JSONObject createTestResp = new JSONObject(response.body().print());
			String objID = createTestResp.getString("id");
						
			//Validate created account using GET method API 
			Response getResponse = restService.getSalesforceObject(objName, objID, requestFilePath, responseFilePath );
						
			//Basic Assertions for the API response 
			String responseTime = getPropertyValue("responseTime");
			restService.basicAssertions(getResponse, Integer.parseInt(responseTime));
			
			//Response File parse 
			String files = restService.getJsonFile(responseFilePath);
			DocumentContext documentContext = JsonPath.parse(files);
						
			//Tester-Defined Assertions for the API response 
			restService.validateResponse(documentContext, currentTest, getResponse);	
							
		}

	}
