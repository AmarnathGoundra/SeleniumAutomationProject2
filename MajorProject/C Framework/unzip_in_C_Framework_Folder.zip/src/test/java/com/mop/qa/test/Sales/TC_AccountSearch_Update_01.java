package com.mop.qa.test.Sales; 
 
 
import org.testng.annotations.Test; 
import com.mop.qa.testbase.TestBase; 
import SOURCE_CODE.SFDC.DB; 
import USER_SPACE.BusinessComponent.BC; 
import SOURCE_CODE.SFDC.SFDCAutomationFW; 
import USER_SPACE.TestPrerequisite.DataSetup;
import USER_SPACE.ObjectRepository.AccountsScreen1;
import USER_SPACE.ObjectRepository.AllTabsScreen;
import USER_SPACE.ObjectRepository.AppLauncherScreen_LUI;
import USER_SPACE.ObjectRepository.LeadScreen; 


/* **************************************************************************************************************************************************
* 																																					*
* @Author: 				Cognizant QEA CRM Team 																										*
* @Description: 		Search an existing Account in Salesforce Classic and Update any two field and save the changes 								*
* @General Guidelines: 	Every Test Script File must begin from Launching URL of login screen and must end with browser closed 						*
*****************************************************************************************************************************************************/ 

public class TC_AccountSearch_Update_01 extends TestBase { 


	@Test 
	public void createMyTest() 
	{ 

		SFDCAutomationFW sfdc = null; 
		AccountsScreen1 AccountScreen = null; 
		AllTabsScreen AllTabScreen = null;
		
		String TCName = "TC_AccountSearch_Update_01"; 
		if (toolName.equalsIgnoreCase("Selenium")) 
		{ 
			sfdc = new SFDCAutomationFW(remoteDriver, TCName);
			AccountScreen = new AccountsScreen1(remoteDriver); 
			AllTabScreen = new AllTabsScreen(remoteDriver);
			
		}
		else if (toolName.equalsIgnoreCase("Appium")) 
		{
			sfdc = new SFDCAutomationFW(appiumDriver, TCName);
			AccountScreen = new AccountsScreen1(appiumDriver); 
		
		}
		
		DB DB = new DB();
		BC BC = new BC(remoteDriver);
		DataSetup DataSetup = new DataSetup();
		
		System.out.println("-----------Begin of TestScript-------------");
			
		try 
		{ 
			
			
			//******************** Connecting to excel data sheet to read external test data ***************
			DB.Connect(DataSetup.TestData);
					
			//************* Reading test data and ensuring parameterization ********************
			String AccountName = DB.ReadXLData(TCName, "Account_Name", "TESTCASENAME", TCName);
			String ParentAccount = DB.ReadXLData(TCName, "Parent_Account", "TESTCASENAME", TCName);
			
			/* **********************************************************
			*		Test User1 is a generic name of test user,			*
			*		we can always change the login credentials			*
			*		in excel DataSheet to ensure testing of 			*
			*		same scenario using other test users 				*
			*************************************************************/
			String NickNameofUser = "TestUser1"; 
			
			//***************  Login to SFDC ******************* 
			sfdc.LoginToSFDC(NickNameofUser); 
			
			Thread.sleep(10000);
			// *********** Selecting application **************
			sfdc.SelectApplication("Sales");	
			//*************************** Clicking on Account Tab ******************
			AllTabScreen.AccountsTab().Click();
			
			//**************** Searching for the account record as per test data provided in excel data sheet and Drill down to the record details ******************
			sfdc.GlobalSearch("Accounts", AccountName);
			
			//************************ Clicking on Edit button *************************
			AccountScreen.EditButton().Click();
			
			//***************** Changing the value of Parent Account *********************
			AccountScreen.ParentAccountField().SelectFromLookup(ParentAccount);
			
			//***************** Changing the value of Type field *********************
			AccountScreen.TypeField().SelectPL("Prospect");
			
			//********************* Clicking on Save button ***************************
			AccountScreen.SaveButton().Click();
			
			//************************ Logging out from Salesforce *********************
			sfdc.LogOff();

		} 
		catch (Exception e)
		{ 
			e.printStackTrace(); 
			System.out.println("Exception(Exception) in main"); 
		}
		finally
		{ 
			System.out.println("-----------End of TestScript-------------"); 
		} 
	} 
} 
