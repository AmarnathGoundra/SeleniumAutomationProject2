package com.mop.qa.testbase;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecuteResultHandler;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.opencv.core.Core;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ISuite;
import org.testng.ITestContext;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.test.bvt.SalesforceNeXT_TestCaseCreation;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.model.Log;
import com.relevantcodes.extentreports.model.TestAttribute;
//import com.zapi.base.ZapiBase;
import com.zapi.base.ZapiBase;

import io.appium.java_client.AppiumDriver;
import io.restassured.response.Response;

public class TestBase {

	public static long startTime;
	public static long totalTime;
	public static String totalTimeTaken;
	public static String osType = System.getProperty("os.name");
	public String toolName = "";
	public static String RUNNING_TEST_NAME = "";
	public static long TEST_STEP_NO_FOR_LAYOUT = 0;
	
	public String appType = "";
	public String RemoteUrl = "";
	public String browser = "";
	String localityType;
	String exeType;
	String platform_name = "";
	String TestResultOverall = "";
	String failure_reason ="";
	public AppiumDriver appiumDriver;
	public static RemoteWebDriver remoteDriver;
	public String udid = null;
	public String appium_port = null;
	public String currentTest = "";
	public String testClass = "";
	
	public String status = "2";
	public String comment = "";
	
	public static String templateFolder = "Template/";
	public static String requestFolder = "Request/";
	public static String responseFolder = "Response/";
	public String accessToken = null;
	public String instanceURL = null;
	public String salesforceUser = null;
	
	public String SFDCURL = null;
	public String SFDCLoginUserName = null;
	
	
	public ReadDataSheet rds = new ReadDataSheet();

	@BeforeSuite
	public void executeSuite(ITestContext ctx) {
		try {
			ExtentUtility.extent = ExtentUtility.getReporter();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void getSuiteName(ISuite ist) {

		try {
			System.out.println("" + ist.getName());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@BeforeTest
	public void startTestReport(ITestContext ctx) {

		try {
			if(getPropertyValue("Video_solution").equalsIgnoreCase("Yes"))
			System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
			browser = ctx.getCurrentXmlTest().getParameter("browser");
			toolName = ctx.getCurrentXmlTest().getParameter("toolName");
			exeType = ctx.getCurrentXmlTest().getParameter("ExecutionType");
			localityType = ctx.getCurrentXmlTest().getParameter("Locality");
			RemoteUrl = ctx.getCurrentXmlTest().getParameter("RemoteUrl");
			
			
			System.out.println("toolname is -->" + ctx.getCurrentXmlTest().getParameter("toolName"));
			ExtentUtility.test = ExtentUtility.startTest(ctx.getCurrentXmlTest().getParameter("testname"));
			currentTest= ctx.getCurrentXmlTest().getParameter("testname");
			testClass = ctx.getCurrentXmlTest().getParameter("testclasspackage");
			testClass = testClass.replace("."+ExtentUtility.getTest().getTest().getName().toString().replace("-Run1", "").replace("-Run2", ""),"");
			
			String[] arrOfStr = testClass.split("\\.");
			testClass = arrOfStr[arrOfStr.length-1];
			System.out.println("Test Package name is:"+testClass);
			
			//System.out.println(strval.length);
			//System.out.println("Test Package Name is:"+strval[(strval.length) - 1]);
			System.out.println(currentTest+ "is Running");
			RUNNING_TEST_NAME = currentTest.replace("-", "").replace("Run1", "").replace("Run2", "");
			//System.out.println("RUNNING_TEST_NAME-->"+RUNNING_TEST_NAME.trim());
			TEST_STEP_NO_FOR_LAYOUT = 0;
			String startURL = rds.getValue("DATA", currentTest, "URL");
			
			//Added by @185584
			SFDCLoginUserName = rds.getValue("DATA", currentTest, "TestUserName");
			System.out.println("TestUserName is :"+SFDCLoginUserName);
			
			if (toolName.equalsIgnoreCase("Services")) {
				
			} else if (toolName.equalsIgnoreCase("Appium")) {
				appium_port = getPort();
				if (exeType.equalsIgnoreCase("Parallel")) {
					appType = ctx.getCurrentXmlTest().getParameter("appType");
					System.out.println("App type is " + ctx.getCurrentXmlTest().getParameter("appType"));
					if (System.getProperty("os.name").contains("Win")) {
						System.out.println("appium parallel");
						udid = ctx.getCurrentXmlTest().getParameter("udid");

						String bootstrap_port = ctx.getCurrentXmlTest().getParameter("Bootstrap_port");
						String chrome_port = ctx.getCurrentXmlTest().getParameter("Chrome_port");
						platform_name = ctx.getCurrentXmlTest().getParameter("platformName");
						appium_port="5567";
						//startWindowsServer(udid, appium_port, platform_name, localityType);
						Thread.sleep(5000);
						initiateDriver(localityType, appium_port, browser, RemoteUrl, platform_name, toolName, appType,startURL);
					} else {
						if (ctx.getCurrentXmlTest().getParameter("platformName").equalsIgnoreCase("Android")) {
							udid = ctx.getCurrentXmlTest().getParameter("udid");
							platform_name = ctx.getCurrentXmlTest().getParameter("platformName");
							appType = ctx.getCurrentXmlTest().getParameter("appType");
							if(!localityType.equalsIgnoreCase("Cloud")){
							startIOSServerForiOSDevice(udid, appium_port);
							}
							initiateDriver(localityType, appium_port, browser, RemoteUrl, platform_name, toolName,
									appType,startURL);
						} else {
							udid = ctx.getCurrentXmlTest().getParameter("udid");
							platform_name = ctx.getCurrentXmlTest().getParameter("platformName");
							appType = ctx.getCurrentXmlTest().getParameter("appType");
							if(!localityType.equalsIgnoreCase("Cloud")){
								startIOSServerForiOSDevice(udid, appium_port);
							}
							initiateDriver(localityType, appium_port, browser, RemoteUrl, platform_name, toolName,
									appType,startURL);

						}
					}
				} else {
					if (toolName.equalsIgnoreCase("Appium")) {
						if (System.getProperty("os.name").contains("Win")) {
							appType = ctx.getCurrentXmlTest().getParameter("appType");

							udid = ctx.getCurrentXmlTest().getParameter("udid");
							platform_name = ctx.getCurrentXmlTest().getParameter("platformName");
							if(!localityType.equalsIgnoreCase("Cloud")){
								//startWindowsServer(udid, appium_port, platform_name, localityType);
							}
							appium_port="5567";
							Thread.sleep(5000);
							initiateDriver(localityType, appium_port, browser, RemoteUrl, platform_name, toolName,
									appType,startURL);

						} else {
							appType = ctx.getCurrentXmlTest().getParameter("appType");
							udid = ctx.getCurrentXmlTest().getParameter("udid");
							platform_name = ctx.getCurrentXmlTest().getParameter("platformName");
							System.out.println("platformName" + ctx.getCurrentXmlTest().getParameter("platformName"));
							//swamy
							if(!localityType.equalsIgnoreCase("Cloud")){
								startIOSServerForiOSDevice(udid, appium_port);
							}
							initiateDriver(localityType, appium_port, browser, RemoteUrl, platform_name, toolName,
									appType,startURL);

						}
					}
				}

			} else {

				System.out.println("browser is selenium" + ctx.getCurrentXmlTest().getParameter("browser"));
				System.out.println("-------------->startURL from TestBase:"+startURL);
				initiateDriver(localityType, appium_port, browser, RemoteUrl, platform_name, toolName, appType,startURL);

			}

			System.out.println("test name is " + ctx.getCurrentXmlTest().getParameter("testname1"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@AfterTest
	public void afterTest() throws Exception {

        PageBase pagebaseclass = new PageBase();

        if (toolName.equalsIgnoreCase("Appium")) {

                        if (appiumDriver != null) {

                                        ExtentUtility.extent.endTest(ExtentUtility.getTest());

                                        Thread.sleep(5000);

                                        //appiumDriver.close();

                        }

        } else if (toolName.equalsIgnoreCase("selenium")) {

                        if (remoteDriver != null) {

                                        ExtentUtility.extent.endTest(ExtentUtility.getTest());

                                        Thread.sleep(5000);

                                        //remoteDriver.close();

                        }

        } else {

                        ExtentUtility.extent.endTest(ExtentUtility.getTest());

        }
        
        
        ExtentUtility.extent.flush();
        String logstatus = ExtentUtility.getTest().getRunStatus().toString();
        zapiUpdate(logstatus);
        
        if (getPropertyValue("AllowReportIntegrationWithSalesforce").equalsIgnoreCase("Yes"))
        {
        	//******************* Below LOC is executed at the end of every test case execution *******************
            System.out.println("Test Name --" + ExtentUtility.getTest().getTest().getName());
            System.out.println("Run Status --" + ExtentUtility.getTest().getRunStatus());
            if (ExtentUtility.getTest().getRunStatus().toString().equalsIgnoreCase("pass")) {
            	
            	TestResultOverall = "Passed";
    		}
            else
    		{
            	TestResultOverall = "Failed";
    		}
            
            System.out.println("------------->"+ExtentUtility.getTest().getTest().getStartedTime());
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
            String strDate= formatter.format(ExtentUtility.getTest().getTest().getStartedTime());  
            System.out.println("Start Time --" + strDate);
            
            String endDate= formatter.format(ExtentUtility.getTest().getTest().getEndedTime());  
            System.out.println("End Time --" + endDate);       
            System.out.println("Duration --" + ExtentUtility.getTest().getTest().getRunDuration());
            
            System.out.println("Status --"+ExtentUtility.getTest().getRunStatus().toString());
            int count_pass = 0;
            int count_fail = 0;
            List<Log> AllLogs =  ExtentUtility.getTest().getTest().getLogList();
            for(Log elog:AllLogs)
            {
            	System.out.println("getStepName:"+elog.getStepName());
            	System.out.println("getStepName:"+elog.getDetails());
            	System.out.println("getStepName:"+elog.getLogStatus());  
            	if (elog.getLogStatus().toString().equalsIgnoreCase("pass")) 
            	{
            		count_pass = count_pass + 1;
    			}
            	else
            	{
            		count_fail = count_fail + 1;
            		failure_reason = elog.getStepName();
            		
            	}
            }
            System.out.println("Count of Pass:"+count_pass);
            System.out.println("Count of Fail:"+count_fail);
            System.out.println("Total Count of Steps:"+(count_pass+count_fail));
            System.out.println("-->"+osType);
    		System.out.println("-->"+toolName);
    		//System.out.println("-->"+appType);
    		//System.out.println("-->"+RemoteUrl);
    		System.out.println("-->"+browser);
    		System.out.println("-->"+localityType);
    		System.out.println("-->"+exeType);
    		//System.out.println("-->"+platform_name);
    		
    		
    		try {
    						
    			//************ Inserting the Test Case Execution Body Parameter into RequestParameters sheet
    			
    			HSSFWorkbook wb;
    			HSSFSheet ws;
    			try {
    				FileInputStream file = new FileInputStream(new File("./DataSheet.xls"));
    				wb = new HSSFWorkbook(file);
    				ws = wb.getSheet("RequestParameters");
    				for (int count = 1; count <= ws.getLastRowNum(); count++) {
    					HSSFRow row = ws.getRow(count);
    					if( row.getCell(0).toString().equalsIgnoreCase("SalesforceNeXT_TestCaseCreation-Run1")
    							&& row.getCell(1).toString().equalsIgnoreCase("BodyParameter"))
    					{
    						if (row.getCell(2).toString().equalsIgnoreCase("$.eascrm__Test_Case_Name__c")) 
    						{
    							row.getCell(3).setCellValue(ExtentUtility.getTest().getTest().getName().toString().replace("-Run1", "").replace("-Run2", ""));
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.eascrm__Execution_Status__c")) 
    						{
    							row.getCell(3).setCellValue(TestResultOverall);
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.eascrm__Start_Date_Time__c")) 
    						{
    							row.getCell(3).setCellValue(strDate);
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.eascrm__End_Date_Time__c")) 
    						{
    							row.getCell(3).setCellValue(endDate);
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.Automation_Tool__c")) 
    						{
    							row.getCell(3).setCellValue(toolName);
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.Browser_Used__c")) 
    						{
    							row.getCell(3).setCellValue(browser);
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.Locality__c")) 
    						{
    							row.getCell(3).setCellValue(localityType);
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.Number_of_Steps_Failed__c")) 
    						{
    							row.getCell(3).setCellValue(count_fail);
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.Number_of_Steps_Passed__c")) 
    						{
    							row.getCell(3).setCellValue(count_pass);
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.Total_Number_of_Steps__c")) 
    						{
    							row.getCell(3).setCellValue(count_pass+count_fail);
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.Operating_System__c")) 
    						{
    							row.getCell(3).setCellValue(osType);
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.eascrm__Result_Details__c")) 
    						{
    							row.getCell(3).setCellValue(failure_reason);
    						}
    						else if (row.getCell(2).toString().equalsIgnoreCase("$.eascrm__Module_Name__c")) 
    						{
    							row.getCell(3).setCellValue(testClass);
    						}
    													
    							
    					}
    				}
    				
    				file.close(); 
    				//Open FileOutputStream to write updates
    				FileOutputStream output_file =new FileOutputStream(new File("./DataSheet.xls"));  
    				 //write changes
    				wb.write(output_file);
    				//close the stream
    				output_file.close();
    				
    			} catch (Exception e) {
    				// TODO: handle exception
    				e.printStackTrace();
    			}
    			
    			
    			
    			
    			
    			//AccountAPI accountAPI = new AccountAPI();			
    			ServiceBase restService = new ServiceBase();	
    			ReadDataSheet readData = new ReadDataSheet();			
    			Map<String, String> bodyParameters = new HashMap<>();
    			Map<String, String> queryParams = new HashMap<>();
    			currentTest = "SalesforceNeXT_TestCaseCreation-Run1";
    			String objName = readData.getValue("DATA", currentTest, "ObjectName");;
    			String requestFilePath = requestFolder + "Request_" + ExtentUtility.timeStamp + "_" + currentTest + ".json";
    			String responseFilePath = responseFolder + "Response_" + ExtentUtility.timeStamp + "_" + currentTest + ".json";
    												
    			//Fetching Data from Datasheet
    			bodyParameters = restService.getBodyParameters(currentTest); 			
    			
    			//Functional API Call for Account Creation			
    			Response response = restService.createSalesforceObject(objName, bodyParameters, requestFilePath, responseFilePath );
    			System.out.println("response:"+response.toString());			
    			//Response File parse 
    			String files = restService.getJsonFile(responseFilePath);
    			DocumentContext documentContext = JsonPath.parse(files);
    			
    			//Basic Assertions for the API response 
    			String responseTime = getPropertyValue("responseTime");
    			restService.basicAssertions(response, Integer.parseInt(responseTime));
    						
    			//Tester-Defined Assertions for the API response 
    			restService.validateResponse(documentContext, currentTest, response);	
    			}
    			catch(Exception e)
    			{
    			e.printStackTrace();
    			ExtentUtility.getTest().log(LogStatus.FAIL, " Test Case Failed");
    			}

        	
			
		}
        	
}

	//

	@AfterSuite
	public void finishExecution() throws Exception {

		//System.out.println("after suite----------------------");
		try {
			if (toolName.equalsIgnoreCase("Appium")) {
				if (appiumDriver != null) {
				//	appiumDriver.close();
					//appiumDriver.quit();
				}
			} else {
					if (remoteDriver != null) {
						//remoteDriver.close();
						//remoteDriver.quit();
					}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			//
			//stopServer();
			//
			
			//appiumDriver.quit();
			if(remoteDriver!= null)	{
				//remoteDriver.close();
				//remoteDriver.quit();
			}
				
			if(appiumDriver!= null)	{
				//appiumDriver.close();
				//appiumDriver.quit();
			}
				
		}

	}

	public void startIOSServerForAndroidDevice() throws IOException, InterruptedException {
		System.out.println("generate report");
		try {

		} catch (Exception e) {
			// e.printStackTrace();
			return;
		}

	}

	// To start appium call this function
	public void startAppium(String port) throws Exception {
		String chromePort = getPort();
		String bootstrapPort = getPort();
		String command = "/Applications/Appium.app/Contents/Resources/node_modules/appium/bin/appium.js --session-override -p "
				+ port + " --chromedriver-port " + chromePort + " -bp " + bootstrapPort;
		System.out.println(command);
		String output = runCommand(command); // run command on terminal
		System.out.println("output" + output);
	}

	public void startAppiumServerIos(String udid, String port) {
		try {
			String chromePort = getPort();
			String bootstrapPort = getPort();

			CommandLine command = new CommandLine("/Applications/Appium.app/Contents/Resources/node/bin/node");
			command.addArgument("/Applications/Appium.app/Contents/Resources/node_modules/appium/bin/appium.js", false);
			command.addArgument("--address", false);
			command.addArgument("0.0.0.0");
			command.addArgument("--port", false);
			command.addArgument(port);
			command.addArgument("--session-override", false);
			command.addArgument("--bootstrap-port", false);
			command.addArgument(bootstrapPort);
			command.addArgument("--chromedriver-port", false);
			command.addArgument(chromePort);
			command.addArgument("-U", false);
			command.addArgument(udid);
			DefaultExecuteResultHandler resultHandler = new DefaultExecuteResultHandler();
			DefaultExecutor executor = new DefaultExecutor();
			executor.setExitValue(1);

			executor.execute(command, resultHandler);
			Thread.sleep(5000);
			System.out.println("Appium server started.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// This function will run command on terminal
	public String runCommand(String command) throws InterruptedException, IOException {
		Process proc = null;
		File wd = new File(".");
		proc = Runtime.getRuntime().exec("/bin/bash " + command);

		BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream()));

		String line = "";
		String allLine = "";
		while ((line = r.readLine()) != null) {
			allLine = allLine + "" + line + "\n";
			if (line.contains("started on"))
				break;
		}
		return allLine;
	}

	// This will check for free ports
	public String getPort() throws Exception {
		ServerSocket socket = new ServerSocket(0);
		socket.setReuseAddress(true);
		String port = Integer.toString(socket.getLocalPort());
		socket.close();
		return port;
	}

	public void startIOSServerForiOSDevice(String udid, String port) throws IOException, InterruptedException {

		try {
			String chromePort = getPort();
			String bootstrapPort = getPort();
			Thread.sleep(3000);
			CommandLine command = new CommandLine("/usr/local/bin/node");
			command.addArgument("/usr/local/bin/appium",
					false);
			command.addArgument("--address", false);
			command.addArgument("127.0.0.1");
			command.addArgument("--port", false);
			command.addArgument(port);
			command.addArgument("--session-override", false);
			command.addArgument("--bootstrap", false);
			command.addArgument(bootstrapPort);
			command.addArgument("--udid", false);
			command.addArgument(udid);
			DefaultExecuteResultHandler resultHandler = new DefaultExecuteResultHandler();
			DefaultExecutor executor = new DefaultExecutor();
			executor.setExitValue(1);

			executor.execute(command, resultHandler);
			
			Thread.sleep(20000);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread.sleep(10000);
	}

	public void initiateDriver(String localityType, String port, String browser, String RemoteUrl, String platform_name,
			String toolname, String appType, String startURL) {
		try {
			String devicePlatform = null;

			if (toolName.equalsIgnoreCase("Appium")) {
				System.out.println("driver start");
				PageBase pagebaseclass = new PageBase(appiumDriver);
				appiumDriver = pagebaseclass.launchApp(udid, localityType, RemoteUrl, toolname, appType, port,
						platform_name,startURL);
			}

			if (toolName.equalsIgnoreCase("selenium")) {
				PageBase pagebaseclass = new PageBase(remoteDriver);
				remoteDriver = pagebaseclass.launchSite(browser, localityType, RemoteUrl);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
	}

	public void startWindowsServer(String udid, String port, String platform_name, String localityType)
			throws Exception {
		String chromePort = getPort();
		String bootStrapPort = getPort();
		try {
			if (localityType.equalsIgnoreCase("Grid")) {
				String nodePath_windows = getPropertyValue("nodePath_windows");
				String appiumJSPath_windows = getPropertyValue("appiumJSPath_windows");
				System.out.println("nodePath_windows" + nodePath_windows);
				System.out.println("appiumJSPath_windows" + appiumJSPath_windows);
				
				CommandLine command = new CommandLine(nodePath_windows);
				command.addArgument(appiumJSPath_windows, false);
				DefaultExecuteResultHandler resultHandler = new DefaultExecuteResultHandler();
				DefaultExecutor executor = new DefaultExecutor();
				if (platform_name.equalsIgnoreCase("android")) {
					executor.setExitValue(1);
					executor.execute(command, resultHandler);
					Thread.sleep(10000);
				} else {
					command.addArgument("--udid", false);
					ProcessBuilder pb = new ProcessBuilder();
					Map<String, String> env = pb.environment();

					env.put("ANDROID_HOME", "C:\\Users\\426205\\AppData\\Local\\Android\\sdk");

					env.put("PATH",
							"/Users/mspiosteam/.rvm/gems/ruby-2.2.0/bin:/Users/mspiosteam/.rvm/gems/ruby-2.2.0@global/bin:/Users/mspiosteam/.rvm/rubies/ruby-2.2.0/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/Applications/android-sdk-macosx:/usr/local/git/bin:/usr/local/Cellar/libimobiledevice/1.2.0/bin:/Users/mspiosteam/.rvm/gems/ruby-2.2.0/bin:/Users/mspiosteam/.rvm/gems/ruby-2.2.0@global/bin:/Users/mspiosteam/.rvm/rubies/ruby-2.2.0/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/git/bin:/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Home/bin:/Applications/android-sdk-macosx/tools:/Applications/android-sdk-macosx/platform-tools:/Users/mspiosteam/.rvm/bin:/Users/mspiosteam/libimobiledevice-macosx:/Applications/android-sdk-macosx:/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Home/bin:/Applications/android-sdk-macosx/tools:/Applications/android-sdk-macosx/platform-tools:/Users/mspiosteam/.rvm/bin");
					executor.setExitValue(1);
					executor.execute(command, env, resultHandler);
				}
			} else if (localityType.equalsIgnoreCase("Hub")) {
				String nodePath_windows = getPropertyValue("nodePath_windows");
				String appiumJSPath_windows = getPropertyValue("appiumJSPath_windows");
				System.out.println("nodePath_windows" + nodePath_windows);
				System.out.println("appiumJSPath_windows" + appiumJSPath_windows);

				CommandLine command = new CommandLine(nodePath_windows);
				command.addArgument(appiumJSPath_windows, false);
				command.addArgument("--address", false);
				command.addArgument("127.0.0.1");
				command.addArgument("--port", false);
				command.addArgument(port);
				command.addArgument("--no-reset", false);
				command.addArgument("--session-override", false);
				command.addArgument("-U", false);
				command.addArgument(udid);
				command.addArgument("--bootstrap-port", false);
				command.addArgument(bootStrapPort);
				command.addArgument("--chromedriver-port", false);
				command.addArgument(chromePort);

				DefaultExecuteResultHandler resultHandler = new DefaultExecuteResultHandler();
				DefaultExecutor executor = new DefaultExecutor();
				if (platform_name.equalsIgnoreCase("android")) {
					executor.setExitValue(1);
					System.out.println("appium server" + appiumJSPath_windows);
					Thread.sleep(10000);
					executor.execute(command, resultHandler);
					Thread.sleep(10000);
				} else {
					command.addArgument("--udid", false);
					ProcessBuilder pb = new ProcessBuilder();
					Map<String, String> env = pb.environment();

					env.put("ANDROID_HOME", "C:\\Users\\426205\\AppData\\Local\\Android\\sdk");

					env.put("PATH",
							"/Users/mspiosteam/.rvm/gems/ruby-2.2.0/bin:/Users/mspiosteam/.rvm/gems/ruby-2.2.0@global/bin:/Users/mspiosteam/.rvm/rubies/ruby-2.2.0/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/Applications/android-sdk-macosx:/usr/local/git/bin:/usr/local/Cellar/libimobiledevice/1.2.0/bin:/Users/mspiosteam/.rvm/gems/ruby-2.2.0/bin:/Users/mspiosteam/.rvm/gems/ruby-2.2.0@global/bin:/Users/mspiosteam/.rvm/rubies/ruby-2.2.0/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/git/bin:/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Home/bin:/Applications/android-sdk-macosx/tools:/Applications/android-sdk-macosx/platform-tools:/Users/mspiosteam/.rvm/bin:/Users/mspiosteam/libimobiledevice-macosx:/Applications/android-sdk-macosx:/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Home/bin:/Applications/android-sdk-macosx/tools:/Applications/android-sdk-macosx/platform-tools:/Users/mspiosteam/.rvm/bin");
					executor.setExitValue(1);
					executor.execute(command, env, resultHandler);
				}
			}

			Thread.sleep(30000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void stopServer() {
		try {
			System.out.println("Stop server");
			String filePath = "";
			String filePath1 = "";
			if (System.getProperty("os.name").contains("Win")) {

				filePath = "taskkill /F /IM node.exe";
				Runtime.getRuntime().exec(filePath);
				filePath1 = "taskkill /F /IM chromedriver.exe ";
				Runtime.getRuntime().exec(filePath1);
			} else {

				Runtime.getRuntime().exec(new String[] { "bash", "-c", "killall node" });
				Runtime.getRuntime().exec(new String[] { "bash", "-c", "killall chrome" });
				Runtime.getRuntime().exec(new String[] { "bash", "-c", "killall safari" });
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String getPropertyValue(String key) throws IOException {
		String value = "";
		try {

			FileInputStream fileInputStream = new FileInputStream("data.properties");

			Properties property = new Properties();
			property.load(fileInputStream);

			value = property.getProperty(key);

			fileInputStream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;

	}

	public static void updateProperty(String updateTime, String startTime) {
		try {

			FileInputStream in = new FileInputStream("report.properties");
			Properties props = new Properties();
			props.load(in);
			in.close();

			FileOutputStream out = new FileOutputStream("report.properties");
			props.setProperty("TOTAL_TIME", totalTimeTaken.toString());
			props.setProperty("RUN_STARTED", startTime.toString());
			props.store(out, null);
			out.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public boolean isZapi() throws IOException {
		PageBase pagebaseclass = new PageBase(remoteDriver);
		if (pagebaseclass.getAppProperties("zapi").equalsIgnoreCase("yes")) {
			// System.out.println(pagebaseclass.getAppProperties("zapi"));
			return true;
		}
		return false;
	}
	
	//It returns the element as per supplied xpath
	public WebElement getElementByXPath(String xpath) throws Exception
	{
		WebElement elm = null;
		try {
			
			remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
			elm = remoteDriver.findElement(By.xpath(xpath));
			return elm;
			
		} catch (Exception e) {
			// TODO: handle exception
			return elm;
		}		
	}

	public String getVersionName() {
		try {
			String versionName = rds.getValue("DATA", currentTest, "JIRA_VersionName");
			System.out.println(versionName);
			return versionName;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	public String getIssueKey() {
		try {
			String issueKey = rds.getValue("DATA", currentTest, "JIRA_IssueKey");
			 System.out.println(issueKey);
			return issueKey;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

	public String getAppProperties(String key) throws IOException {
		String value = "";
		try {

			FileInputStream fileInputStream = new FileInputStream("data.properties");
			Properties property = new Properties();
			property.load(fileInputStream);

			value = property.getProperty(key);

			fileInputStream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}
	
	public String getCycleName() {
		try {
			String cycleName = rds.getValue("DATA", currentTest, "JIRA_CycleName");
			System.out.println(cycleName);
			return cycleName;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
	 public void zapiUpdate(String logstatus) throws Exception {

		 

         if (isZapi()) {



                         if (logstatus.equals("pass")) {

                                         status = Status.PASS.getValue();

                         } else if (logstatus.equals("fail")) {

                                         status = Status.FAIL.getValue();

                         }



                         ZapiBase zapi = new ZapiBase(currentTest);

                         String issueKey = getIssueKey();

                         System.out.println("Key--" + issueKey + " currentTest--" + currentTest);

                         String versionName = getVersionName();

                         String cycleName = getCycleName();

                         Map<String, Map<String, String>> cycleList = zapi.getListOfCycles(versionName);

                         Map<String, String> testList = zapi.getTestList(cycleList, cycleName);

                         if (status.equals("1")) {

                                         comment = currentTest + " Passed";

                         } else {

                                         comment = currentTest + " Failed";

                         }

                         zapi.cloneExecution(versionName, issueKey, comment, testList, cycleList, status);

                         zapi.addAttachment(testList, cycleList, ExtentUtility.reportPath, issueKey);



         }

}

	   /** Status IDs enum */

     public static enum Status {

                     PASS("1"), FAIL("2"), WIP("3"), BLOCKED("4"), UNEXECUTED("5");

                     private final String value;



                     private Status(final String value) {

                                     this.value = value;

                     }



                     public String getValue() {

                                     return value;

                     }

     }
}

