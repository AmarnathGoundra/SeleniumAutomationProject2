package com.mop.qa.test.Sales; 
 
 
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.testbase.TestBase; 
import SOURCE_CODE.SFDC.DB; 
import USER_SPACE.BusinessComponent.BC; 
import SOURCE_CODE.SFDC.SFDCAutomationFW; 
import USER_SPACE.TestPrerequisite.DataSetup;
import USER_SPACE.ObjectRepository.AllAppsTabsScreen_LUI;
import USER_SPACE.ObjectRepository.LeadScreen;
import USER_SPACE.ObjectRepository.LeadsScreen_LUI; 

/* 
* 
* @Author: <Name of Test Script Creator> 
* @Description: <Please mention the scope of this test script> 
* @General Guidelines: Every Test Script must begin from Launching 
* URL of login screen and must end with browser closed 
*/ 

public class TC_CreateLead_LUI extends TestBase { 

	/*
	@DataProvider(name = "TestUserList")	 
	  public static Object[][] LoginUsers()
	 {
	 	        return new Object[][] { 
	 	        						{ "TestUser1" },
	 	        						{ "TestUser3" }	 	        						
	 	        					  };	 
	  }
	
	*/
	
//@Test(dataProvider="TestUserList")
//public void createMyTest(String TestUserName) { 
@Test	
public void createMyTest() { 

	SFDCAutomationFW sfdc = null; 
	LeadsScreen_LUI leadScreen = null; 
	AllAppsTabsScreen_LUI allTAppsObjectsScreen = null;
	String TC_CreateLead_LUI = "TC_CreateLead_LUI";

	String TCName = "TC_CreateLead_LUI"; 
	if (toolName.equalsIgnoreCase("Selenium"))
	{ 
		System.out.println("----------------->Inside Test Case");
		sfdc = new SFDCAutomationFW(remoteDriver, TCName);
		System.out.println("----------->Back to Test case");
		leadScreen = new LeadsScreen_LUI(remoteDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(remoteDriver);
	}
	else if (toolName.equalsIgnoreCase("Appium"))
	{
		sfdc = new SFDCAutomationFW(appiumDriver, TCName);
		leadScreen = new LeadsScreen_LUI(appiumDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(appiumDriver);
	}
	
	DB DB = new DB();
	BC BC = new BC(remoteDriver);
	DataSetup DataSetup = new DataSetup();

	System.out.println("-----------Begin of TestScript-------------");

	try { 
			 
		DB.Connect(DataSetup.TestData);
			
		//Reading the test data from external test data sheet
		//String FIRSTNAME = DB.ReadXLData("CreateLead", "FIRSTNAME", "TESTCASENAME", TC_CreateLead_LUI);
		//String LASTNAME = DB.ReadXLData("CreateLead", "LASTNAME", "TESTCASENAME", TC_CreateLead_LUI);
		String PHONE_NUMBER = DB.ReadXLData("CreateLead", "PHONE_NUMBER", "TESTCASENAME", TC_CreateLead_LUI);
		String COMPANY = DB.ReadXLData("CreateLead", "COMPANY", "TESTCASENAME", TC_CreateLead_LUI);
		String LEAD_SOURCE = DB.ReadXLData("CreateLead", "LEAD_SOURCE", "TESTCASENAME", TC_CreateLead_LUI);
		String LEAD_STATUS = DB.ReadXLData("CreateLead", "LEAD_STATUS", "TESTCASENAME", TC_CreateLead_LUI);
		String RATING = DB.ReadXLData("CreateLead", "RATING", "TESTCASENAME", TC_CreateLead_LUI);
		String STREET = DB.ReadXLData("CreateLead", "STREET", "TESTCASENAME", TC_CreateLead_LUI);
		String CITY = DB.ReadXLData("CreateLead", "CITY", "TESTCASENAME", TC_CreateLead_LUI);
		String STATE = DB.ReadXLData("CreateLead", "STATE", "TESTCASENAME", TC_CreateLead_LUI);
		String ZIP = DB.ReadXLData("CreateLead", "ZIP", "TESTCASENAME", TC_CreateLead_LUI);
		String COUNTRY = DB.ReadXLData("CreateLead", "COUNTRY", "TESTCASENAME", TC_CreateLead_LUI);
		String DESCRIPTION = DB.ReadXLData("CreateLead", "DESCRIPTION", "TESTCASENAME", TC_CreateLead_LUI);
				
		
		//DB.Connect(DataSetup.Logininfo);
		ReadDataSheet rds = new ReadDataSheet();
		String OWNER =  rds.getValue("LoginInfo", SFDCLoginUserName, "Name");
				
		String FIRSTNAME = BC.GetCurrentDateTimeStamp();
		Thread.sleep(1000L);
		String LASTNAME = BC.GetCurrentDateTimeStamp();
		Thread.sleep(1000L);
		COMPANY = BC.GetCurrentDateTimeStamp();
		Thread.sleep(1000L);
		String mandatory_error = "Complete this field";
		
		// Login to SFDC 
		sfdc.LoginToSFDC(SFDCLoginUserName); //This variable is inherited from TestBase
		
				
		Thread.sleep(3000L);
		sfdc.SelectApplication_LUI("Sales");
		Thread.sleep(3000L);
				
		allTAppsObjectsScreen.LeadsTab().Click();
		Thread.sleep(15000L);
		leadScreen.NewButton().Click();
		Thread.sleep(4000L);
		leadScreen.SaveButton().Click();
		
		Thread.sleep(3000L);
		
		leadScreen.LastNameField().VerifyFieldErrorMsgOnEditPage(mandatory_error);
		leadScreen.CompanyField().VerifyFieldErrorMsgOnEditPage(mandatory_error);
		
		sfdc.VerifyPageLevelErrorMessage_LUI("Review the following fields");
		
		//Verifying existence of field names 
		leadScreen.LeadOwnerField().VerifyViewOnlyValueEquals(OWNER);
		leadScreen.PhoneField().IsDisplayed("Yes");
		leadScreen.MobileField().IsDisplayed("Yes");
		leadScreen.SalutationField().IsDisplayed("Yes");
		leadScreen.FirstNameField().IsDisplayed("Yes");
		leadScreen.LastNameField().IsDisplayed("Yes");
		leadScreen.CompanyField().IsDisplayed("Yes");
		leadScreen.FaxField().IsDisplayed("Yes");
		leadScreen.TitleField().IsDisplayed("Yes");
		
		leadScreen.LeadSourceField().IsDisplayed("Yes");
		leadScreen.WebsiteField().IsDisplayed("Yes");
		leadScreen.IndustryField().IsDisplayed("Yes");
		leadScreen.LeadStatusField().IsDisplayed("Yes");
		leadScreen.AnnualRevenueField().IsDisplayed("Yes");
		leadScreen.RatingField().IsDisplayed("Yes");
		leadScreen.NoofEmployeesField().IsDisplayed("Yes");
		leadScreen.StreetField().IsDisplayed("Yes");
		leadScreen.CityField().IsDisplayed("Yes");
		leadScreen.StateProvinceField().IsDisplayed("Yes");
		leadScreen.ZipPostalCodeField().IsDisplayed("Yes");
		leadScreen.CountryField().IsDisplayed("Yes");
		leadScreen.ProductInterestField().IsDisplayed("Yes");
		leadScreen.CurrentGeneratorsField().IsDisplayed("Yes");
		leadScreen.SICCodeField().IsDisplayed("Yes");
		leadScreen.PrimaryField().IsDisplayed("Yes");
		leadScreen.NumberofLocationsField().IsDisplayed("Yes");
		leadScreen.DescriptionField().IsDisplayed("Yes");
		
		leadScreen.PhoneField().Type(PHONE_NUMBER);
		leadScreen.MobileField().Type(PHONE_NUMBER);
		leadScreen.FirstNameField().Type(FIRSTNAME);
		leadScreen.LastNameField().Type(LASTNAME);
		leadScreen.CompanyField().Type(COMPANY);
		leadScreen.LeadSourceField().SelectPL(LEAD_SOURCE);
		leadScreen.IndustryField().SelectPL("Banking");
		leadScreen.LeadStatusField().SelectPL(LEAD_STATUS);
		leadScreen.RatingField().SelectPL(RATING);
		leadScreen.StreetField().Type(STREET);
		leadScreen.CityField().Type(CITY);
		leadScreen.StateProvinceField().Type(STATE);
		leadScreen.ZipPostalCodeField().Type(ZIP);
		leadScreen.CountryField().Type(COUNTRY);
		leadScreen.DescriptionField().Type(DESCRIPTION);
		leadScreen.SaveButton().Click();
		
		
		Thread.sleep(5000L);
		
		sfdc.ClickONSubTab("Details");
		Thread.sleep(5000L);		
		//Verify the information from detail view page
		String Name = FIRSTNAME + " " + LASTNAME;
		
		leadScreen.NameField().VerifyViewOnlyValueEquals(Name);
		/*
		leadScreen.CompanyField().VerifyViewOnlyValueEquals(COMPANY);
		leadScreen.LeadSourceField().VerifyViewOnlyValueEquals(LEAD_SOURCE);
		leadScreen.IndustryField().VerifyViewOnlyValueEquals("Banking");
		leadScreen.LeadStatusField().VerifyViewOnlyValueEquals(LEAD_STATUS);
		leadScreen.RatingField().VerifyViewOnlyValueEquals(RATING);
		leadScreen.AddressField().VerifyViewOnlyValueContains(STREET);
		leadScreen.AddressField().VerifyViewOnlyValueContains(CITY);
		leadScreen.AddressField().VerifyViewOnlyValueContains(STATE);
		leadScreen.AddressField().VerifyViewOnlyValueContains(COUNTRY);
		leadScreen.AddressField().VerifyViewOnlyValueContains(ZIP);
		*/
		leadScreen.DescriptionField().VerifyViewOnlyValueEquals(DESCRIPTION);
		leadScreen.CreatedByField().VerifyViewOnlyValueContains(OWNER);
		leadScreen.LastModifiedByField().VerifyViewOnlyValueContains(OWNER);
		
		DB.Connect(DataSetup.TestData);		
		
		//Update excel with full name
		DB.UpdateXLCell("CreateLead", Name, "NAME", "TESTCASENAME", TC_CreateLead_LUI);
		sfdc.LogOff();
		
		
	} 
	catch (Exception e) { 
		e.printStackTrace(); 
		System.out.println("Exception(Exception) in main"); 
	}
	finally { 
		System.out.println("-----------End of TestScript-------------"); 
		
	} 
	} 
} 
