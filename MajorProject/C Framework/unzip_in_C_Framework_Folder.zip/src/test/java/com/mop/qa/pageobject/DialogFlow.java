package com.mop.qa.pageobject;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

public class DialogFlow extends PageBase {

	public static org.openqa.selenium.Point location = null;
	public static float playx = 0;
	public static float playy = 0;
	public static org.openqa.selenium.Dimension size = null;

	public DialogFlow(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
	}

	public DialogFlow(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}

	//New changes
	@FindBy(xpath = "//*[@id='query']") 

	private WebElement txtEnterInput;


	//*[@id="result"]/div[2]

	public void enterUrl() throws Exception {
		enterUrl("https://bot.dialogflow.com/696fa31f-e7b7-42bb-9a26-66f0b72d8715");
		Thread.sleep(9000);
	}	

	public void enterCaseAssistanceDetails(String data) throws Exception{
		enterText(txtEnterInput, data, "EnterInput");

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(7000);
	}

	public void verifyDynamicCaseMsgs(String msg)throws Exception{

		System.out.println(remoteDriver.findElements(By.xpath("//td[@id='result']/descendant::div[text()]")).size());
		int j =remoteDriver.findElements(By.xpath("//td[@id='result']/descendant::div[text()]")).size();
		String displayedMsg=null ;
		boolean flag=false;
		for(int i=1;i<=j;i++){
			if(remoteDriver.findElement(By.xpath("//td[@id='result']/descendant::div[text()]["+i+"]")).getText().equals(msg)){
				displayedMsg = remoteDriver.findElement(By.xpath("//td[@id='result']/descendant::div[text()]["+i+"]")).getText();
				ExtentUtility.getTest().log(LogStatus.PASS, displayedMsg+" message is displayed successfully",
						ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				flag=true;
				break;
			}
		}
		if(flag==false){
			ExtentUtility.getTest().log(LogStatus.FAIL, msg+"message is not displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}
	}
	
	
}
