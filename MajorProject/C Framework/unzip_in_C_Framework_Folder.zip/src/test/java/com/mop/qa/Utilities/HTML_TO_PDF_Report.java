/**
 * 
 */
package com.mop.qa.Utilities;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.docx4j.org.xhtmlrenderer.layout.SharedContext;
import org.docx4j.org.xhtmlrenderer.pdf.ITextRenderer;
import org.jsoup.Jsoup;
import org.jsoup.helper.W3CDom;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Document.OutputSettings;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;


/**
 * @author 185584
 *
 */
public class HTML_TO_PDF_Report {

	/**
	 * Author: 185584 
	 * Description: 
	 * @param args
	 */
	
	public static void main(String[] args) throws Exception{
		
		// TODO Auto-generated method stub
		File inputHTML = new File("C:\\1_SOURAV\\WS_CAAS_23v6\\CAAS\\ReportGenerator\\HtmlReport_2024-02-01-22-40-36\\TestReport.html");
		File outputPDF = new File("C:\\1_SOURAV\\WS_CAAS_23v6\\CAAS\\ReportGenerator\\HtmlReport_2024-02-01-22-40-36\\TestReport.pdf");
		OutputStream os = new FileOutputStream("C:\\1_SOURAV\\WS_CAAS_23v6\\CAAS\\ReportGenerator\\HtmlReport_2024-02-01-22-40-36\\TestReport.pdf");
		Document document = Jsoup.parse(inputHTML, "UTF-8");
		OutputSettings xhtml = document.outputSettings().syntax(Document.OutputSettings.Syntax.xml);
		
		PdfRendererBuilder builder = new PdfRendererBuilder();
	    builder.withUri("C:\\1_SOURAV\\WS_CAAS_23v6\\CAAS\\ReportGenerator\\HtmlReport_2024-02-01-22-40-36\\TestReport.pdf");
	   
	    builder.toStream(os);
	    builder.withW3cDocument(new W3CDom().fromJsoup(document), "/");
	    builder.run();
	
	}

}
