package com.mop.qa.test.Sales; 
 
 
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.testbase.TestBase; 
import SOURCE_CODE.SFDC.DB; 
import USER_SPACE.BusinessComponent.BC; 
import SOURCE_CODE.SFDC.SFDCAutomationFW; 
import USER_SPACE.TestPrerequisite.DataSetup;
import USER_SPACE.ObjectRepository.AccountsScreen_LUI;
import USER_SPACE.ObjectRepository.AllAppPage_LUI;
import USER_SPACE.ObjectRepository.AllAppsTabsScreen_LUI;
import USER_SPACE.ObjectRepository.ContactsScreen_LUI;

/* 
* 
* @Author: <Name of Test Script Creator> 
* @Description: <Please mention the scope of this test script> 
* @General Guidelines: Every Test Script must begin from Launching 
* URL of login screen and must end with browser closed 
*/ 

public class TC_CreateContact_LUI extends TestBase { 

	/*
	@DataProvider(name = "TestUserList")	 
	  public static Object[][] LoginUsers()
	 {
	 	        return new Object[][] { 
	 	        						{ "TestUser1" },
	 	        						{ "TestUser3" }	 	        						
	 	        					  };	 
	  }
	
	*/
	
//@Test(dataProvider="TestUserList")
//public void createMyTest(String TestUserName) { 
@Test	
public void createMyTest() { 

	SFDCAutomationFW sfdc = null; 
	ContactsScreen_LUI contactsScreen = null; 
	AllAppPage_LUI allAppScreen = null;
	AccountsScreen_LUI accountScreen = null;
	AllAppsTabsScreen_LUI allTAppsObjectsScreen = null;
	String TC_CreateContact_LUI = "TC_CreateContact_LUI";

	String TCName = "TC_CreateContact_LUI"; 
	if (toolName.equalsIgnoreCase("Selenium"))
	{ 
		System.out.println("----------------->Inside Test Case");
		sfdc = new SFDCAutomationFW(remoteDriver, TCName);
		System.out.println("----------->Back to Test case");
		contactsScreen = new ContactsScreen_LUI(remoteDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(remoteDriver);
		accountScreen = new AccountsScreen_LUI(remoteDriver);
		allAppScreen = new AllAppPage_LUI(remoteDriver);
		
	}
	else if (toolName.equalsIgnoreCase("Appium"))
	{
		sfdc = new SFDCAutomationFW(appiumDriver, TCName);
		contactsScreen = new ContactsScreen_LUI(appiumDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(appiumDriver);
	}
	
	DB DB = new DB();
	BC BC = new BC(remoteDriver);
	DataSetup DataSetup = new DataSetup();

	System.out.println("-----------Begin of TestScript-------------");

	try { 
			 
		DB.Connect(DataSetup.TestData);
			
		//Reading the test data from external test data sheet
		//String FIRSTNAME = DB.ReadXLData("CreateLead", "FIRSTNAME", "TESTCASENAME", TC_CreateLead_LUI);
		//String LASTNAME = DB.ReadXLData("CreateLead", "LASTNAME", "TESTCASENAME", TC_CreateLead_LUI);
		String PHONE = DB.ReadXLData("CreateContact", "PHONE", "TESTCASENAME", TCName);
		String SALUTATION = DB.ReadXLData("CreateContact", "SALUTATION", "TESTCASENAME", TCName);
		String FIRST_NAME = DB.ReadXLData("CreateContact", "FIRST_NAME", "TESTCASENAME", TCName);
		String LAST_NAME = DB.ReadXLData("CreateContact", "LAST_NAME", "TESTCASENAME", TCName);
		String MOBILE = DB.ReadXLData("CreateContact", "MOBILE", "TESTCASENAME", TCName);
		String TITLE = DB.ReadXLData("CreateContact", "TITLE", "TESTCASENAME", TCName);
		String BIRTH_DAY = DB.ReadXLData("CreateLead", "BIRTH_DAY", "TESTCASENAME", TCName);
		String STREET = DB.ReadXLData("CreateContact", "STREET", "TESTCASENAME", TCName);
		String CITY = DB.ReadXLData("CreateContact", "CITY", "TESTCASENAME", TCName);
		String STATE = DB.ReadXLData("CreateContact", "STATE", "TESTCASENAME", TCName);
		String ZIP = DB.ReadXLData("CreateContact", "ZIP", "TESTCASENAME", TCName);
		String COUNTRY = DB.ReadXLData("CreateContact", "COUNTRY", "TESTCASENAME", TCName);
				
		
		//DB.Connect(DataSetup.Logininfo);
		//ReadDataSheet rds = new ReadDataSheet();
		//String OWNER =  rds.getValue("LoginInfo", SFDCLoginUserName, "Name");
				
		String FIRSTNAME = FIRST_NAME+BC.GetCurrentDateTimeStamp();
		Thread.sleep(1000L);
		String LASTNAME = LAST_NAME+BC.GetCurrentDateTimeStamp();
		Thread.sleep(1000L);
		String mandatory_error = "Complete this field";
		
		// Login to SFDC 
		sfdc.LoginToSFDC(SFDCLoginUserName); //This variable is inherited from TestBase
		
		
		//allAppScreen.SalesApp().Click();
		//allAppScreen.AccountsTab().Click();
		
		Thread.sleep(5000L);
		
		//Selecting Sales app from app launcher
		sfdc.SelectApplication_LUI("Sales");
		Thread.sleep(3000L);
		
		
		allTAppsObjectsScreen.ContactsTab().Click();
		
		contactsScreen.NewButton().Click();
		Thread.sleep(4000L);
		contactsScreen.SaveButton().Click();
		
		Thread.sleep(3000L);
		
		contactsScreen.LastNameField().VerifyFieldErrorMsgOnEditPage(mandatory_error);
		
		sfdc.VerifyPageLevelErrorMessage_LUI("Review the following fields");
		
		//contactsScreen.SkillsField().VerifyMPLAvailable("C++;Selenium;UFT;ALM");
		
		contactsScreen.SkillsField().MultiSelectAddAll();	
		contactsScreen.SkillsField().MultiSelectRemoveAll();
		contactsScreen.SkillsField().MultiSelectAdd("Java;C++");
		contactsScreen.SkillsField().MultiSelectRemove("Java;C++");
			
		
		
		contactsScreen.PhoneField().IsDisplayed("Yes");
		
		
		contactsScreen.HomePhoneField().IsDisplayed("Yes");
		
		contactsScreen.MobileField().IsDisplayed("Yes");
		contactsScreen.SalutationField().IsDisplayed("Yes");
		contactsScreen.FirstNameField().IsDisplayed("Yes");
		contactsScreen.AccountNameField().IsDisplayed("Yes");
		contactsScreen.TitleField().IsDisplayed("Yes");
		contactsScreen.BirthdateField().IsDisplayed("Yes");
							
		contactsScreen.SalutationField().SelectPL(SALUTATION);
		contactsScreen.FirstNameField().Type(FIRSTNAME);
		contactsScreen.LastNameField().Type(LASTNAME);
		contactsScreen.TitleField().Type(TITLE);
		contactsScreen.PhoneField().Type(PHONE);
		contactsScreen.MobileField().Type(MOBILE);
		contactsScreen.MailingStreetField().Type(STREET);
		contactsScreen.MailingCityField().Type(CITY);
		contactsScreen.MailingZipPostalCodeField().Type(ZIP);
		contactsScreen.MailingStateProvinceField().Type(STATE);
		contactsScreen.BirthdateField().SelectFromDateLookup("2020","October","20");
		contactsScreen.AccountNameField().SelectFromLookup("150222160611");
		Thread.sleep(2000);
				
		contactsScreen.SaveButton().Click();
				
		Thread.sleep(5000L);
		
		sfdc.ClickONSubTab("Details");
		Thread.sleep(3000L);		
		String NAME = contactsScreen.NameField().GetViewOnlyValue();
				
		DB.Connect(DataSetup.TestData);		
		
		//Update excel with full name
		//DB.UpdateXLCell("CreateContact", NAME, "CONTACT_NAME", "TESTCASENAME", TCName);
		
		contactsScreen.AccountNameField().ClickONViewOnlyLinkValue();
		
		accountScreen.RL_Contacts().RelatedListLink().Click();
		Thread.sleep(3000L);		
		
		sfdc.ReloadWebPage();
		
		sfdc.clickLinkText(FIRSTNAME + " "+ LASTNAME,"Contact Name");
		
		sfdc.ClickONSubTab("Details");
		Thread.sleep(3000L);		
		
		contactsScreen.MobileField().ClickToEnableInlineEditing();
		contactsScreen.HomePhoneField().Type("123465437");
		System.out.println("GetViewOnlyValue: -->"+contactsScreen.CreatedByField().GetViewOnlyValue());
		
		//************************ Verify the functions in Inline page ******************************
		contactsScreen.SkillsField().MultiSelectAddAll();	
		contactsScreen.SkillsField().MultiSelectRemoveAll();
		contactsScreen.SkillsField().MultiSelectAdd("Java;C++");
		contactsScreen.SkillsField().MultiSelectRemove("Java;C++");
		
			
		/*
		contactsScreen.PhoneField().IsDisplayed("Yes");
		contactsScreen.HomePhoneField().IsDisplayed("Yes");
		contactsScreen.MobileField().IsDisplayed("Yes");
		contactsScreen.SalutationField().IsDisplayed("Yes");
		contactsScreen.FirstNameField().IsDisplayed("Yes");
		contactsScreen.AccountNameField().IsDisplayed("Yes");
		contactsScreen.TitleField().IsDisplayed("Yes");
		contactsScreen.BirthdateField().IsDisplayed("Yes");
		*/
		sfdc.PressPageUPKey();
		Thread.sleep(1000);
		/*
		
		contactsScreen.LevelField().SelectPL("Primary");
		contactsScreen.FirstNameField().Type(FIRSTNAME);
		contactsScreen.LastNameField().Type(LASTNAME);
		contactsScreen.TitleField().Type(TITLE);
		contactsScreen.PhoneField().Type(PHONE);
		contactsScreen.MobileField().Type(MOBILE);
		contactsScreen.MailingStreetField().Type(STREET);
		contactsScreen.MailingCityField().Type(CITY);
		contactsScreen.MailingZipPostalCodeField().Type(ZIP);
		contactsScreen.MailingStateProvinceField().Type(STATE);
		contactsScreen.BirthdateField().SelectFromDateLookup("2020","October","21");
		contactsScreen.AccountNameField().SelectFromLookup("160421162525");
		Thread.sleep(2000);
		String Pho = contactsScreen.PhoneField().GetEditFieldValue();
		System.out.println("GetEditFieldValue = Success"+Pho);
		
		String pickdefault = contactsScreen.SalutationField().GetPLDefaultValue();
		System.out.println("GetPLDefaultValue = Success"+pickdefault);
		
		
		String lookup_val = contactsScreen.AccountNameField().GetLookupEditValue();
		System.out.println("GetLookupEditValue = Success"+lookup_val);
		
		String chkval = contactsScreen.KnownContactField().GetCheckBoxValue();
		System.out.println("GetCheckBoxValue = Success "+chkval);
		
		contactsScreen.ContactOwnerField().VerifyViewOnlyValueEquals("QEA CRM");
		contactsScreen.ContactOwnerField().VerifyViewOnlyValueContains("QEA");
		contactsScreen.ContactOwnerField().VerifyViewOnlyValueDoesNotContain("ABC");
		contactsScreen.ContactOwnerField().VerifyViewOnlyValueStartsWith("QEA");
		contactsScreen.ContactOwnerField().VerifyViewOnlyValueEndsWith("CRM");
		contactsScreen.MailingCityField().VerifyEditFieldValueEquals("Bangalore");
		contactsScreen.MailingCityField().VerifyEditFieldValueContains("galore");
		contactsScreen.MailingCityField().VerifyEditFieldValueStartsWith("Bang");
		contactsScreen.MailingCityField().VerifyEditFieldValueEndsWith("lore");
		contactsScreen.MailingCityField().VerifyEditFieldValueDoesNotContain("Kolkata");
		
		contactsScreen.KnownContactField().VerifyCheckBoxValue("Not Checked");
		
		contactsScreen.LeadSourceField().VerifyPLDefaultValue("--None--");
		contactsScreen.LeadSourceField().VerifyAllPLValue("--None--;Web;Phone Inquiry;Partner Referral;Purchased List;NewPicklist5thJan");
		*/		
		contactsScreen.SaveButton().Click();
		
		Thread.sleep(10000);
	
		contactsScreen.MenuButtonEditButton().MenuButtonClick();
		
		String Pho = contactsScreen.PhoneField().GetEditFieldValue();
		System.out.println("GetEditFieldValue = Success"+Pho);
		
		String pickdefault = contactsScreen.SalutationField().GetPLDefaultValue();
		System.out.println("GetPLDefaultValue = Success"+pickdefault);
		
		String lookup_val = contactsScreen.AccountNameField().GetLookupEditValue();
		System.out.println("GetLookupEditValue = Success"+lookup_val);
		
		String chkval = contactsScreen.KnownContactField().GetCheckBoxValue();
		System.out.println("GetCheckBoxValue = Success "+chkval);
		
		contactsScreen.ContactOwnerField().VerifyViewOnlyValueEquals("QEA CRM");
		contactsScreen.ContactOwnerField().VerifyViewOnlyValueContains("QEA");
		contactsScreen.ContactOwnerField().VerifyViewOnlyValueDoesNotContain("ABC");
		contactsScreen.ContactOwnerField().VerifyViewOnlyValueStartsWith("QEA");
		contactsScreen.ContactOwnerField().VerifyViewOnlyValueEndsWith("CRM");
		contactsScreen.MailingCityField().VerifyEditFieldValueEquals("Bangalore");
		contactsScreen.MailingCityField().VerifyEditFieldValueContains("galore");
		contactsScreen.MailingCityField().VerifyEditFieldValueStartsWith("Bang");
		contactsScreen.MailingCityField().VerifyEditFieldValueEndsWith("lore");
		contactsScreen.MailingCityField().VerifyEditFieldValueDoesNotContain("Kolkata");
		
		contactsScreen.KnownContactField().VerifyCheckBoxValue("Not Checked");
		
		contactsScreen.LeadSourceField().VerifyPLDefaultValue("--None--");
		contactsScreen.LeadSourceField().VerifyAllPLValue("--None--;Web;Phone Inquiry;Partner Referral;Purchased List;NewPicklist5thJan");
		
		contactsScreen.CancelButton().Click();
		
		contactsScreen.MenuButtonDeleteButton().MenuButtonClick();
		
		contactsScreen.DeleteButton().ClickButton_ConfirmationDialog();
		
		
		
		sfdc.LogOff();
		
		//remoteDriver.close();
	} 
	catch (Exception e) { 
		e.printStackTrace(); 
		System.out.println("Exception(Exception) in main"); 
	}
	finally { 
		System.out.println("-----------End of TestScript-------------"); 
	} 
	} 
} 
