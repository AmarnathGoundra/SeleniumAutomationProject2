package com.mop.qa.test.API;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.testbase.ServiceBase;
import com.mop.qa.testbase.TestBase;
import com.relevantcodes.extentreports.LogStatus;

import io.restassured.response.Response;

public class Opporunities_Delete_Validation extends TestBase{
	
		@Test
		public void Opporunities_Delete_Validation() throws Exception {
			try {	
			//AccountAPI accountAPI = new AccountAPI();			
			ServiceBase restService = new ServiceBase();	
			ReadDataSheet readData = new ReadDataSheet();			
			Map<String, String> bodyParameters = new HashMap<>();
			Map<String, String> queryParams = new HashMap<>();
			
			String objName = readData.getValue("DATA", currentTest, "ObjectName");;
			String requestFilePath = requestFolder + "Request_" + ExtentUtility.timeStamp + "_" + currentTest + ".json";
			String responseFilePath = responseFolder + "Response_" + ExtentUtility.timeStamp + "_" + currentTest + ".json";
												
			//Fetching Data from Datasheet
			bodyParameters = restService.getBodyParameters(currentTest); 			
			
			//Functional API Call for Account Creation			
			Response response = restService.createSalesforceObject(objName, bodyParameters, requestFilePath, responseFilePath );
						
			//Response File parse 
			String files = restService.getJsonFile(responseFilePath);
			DocumentContext documentContext = JsonPath.parse(files);
			
			// Get Account ID for Above Created Account via API 
			JSONObject createTestResp = new JSONObject(response.body().print());
			String objID = createTestResp.getString("id");
			
			//Delete above Created Account using DELETE method API 
			restService.deleteSalesforceObject(objName, objID, requestFilePath, responseFilePath);
					
			//Validate Account deleted successfully using GET method API
			Assert.assertTrue(restService.getDeletedSalesforceObjectDetails(objName, objID, requestFilePath, responseFilePath));	
			
			//Basic Assertions for the API response 
			String responseTime = getPropertyValue("responseTime");
			restService.basicAssertions(response, Integer.parseInt(responseTime));					
				
			}
			catch(Exception e)
			{
			e.printStackTrace();
			ExtentUtility.getTest().log(LogStatus.FAIL, " Test Case Failed");
			}
			finally
			{
				System.out.println("Test Case is Ended");
			}							
			}

	}
