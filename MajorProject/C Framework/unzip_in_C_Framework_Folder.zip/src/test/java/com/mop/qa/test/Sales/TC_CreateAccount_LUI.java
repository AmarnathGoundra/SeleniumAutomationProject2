package com.mop.qa.test.Sales; 
 
 
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.testbase.TestBase; 
import SOURCE_CODE.SFDC.DB; 
import USER_SPACE.BusinessComponent.BC; 
import SOURCE_CODE.SFDC.SFDCAutomationFW; 
import USER_SPACE.TestPrerequisite.DataSetup;
import USER_SPACE.ObjectRepository.AccountsScreen_LUI;
import USER_SPACE.ObjectRepository.AllAppsTabsScreen_LUI;
import USER_SPACE.ObjectRepository.LeadScreen;
import USER_SPACE.ObjectRepository.LeadsScreen_LUI; 

/* 
* 
* @Author: <Name of Test Script Creator> 
* @Description: <Please mention the scope of this test script> 
* @General Guidelines: Every Test Script must begin from Launching 
* URL of login screen and must end with browser closed 
*/ 

public class TC_CreateAccount_LUI extends TestBase { 

	/*
	@DataProvider(name = "TestUserList")	 
	  public static Object[][] LoginUsers()
	 {
	 	        return new Object[][] { 
	 	        						{ "TestUser1" },
	 	        						{ "TestUser3" }	 	        						
	 	        					  };	 
	  }
	
	*/
	
//@Test(dataProvider="TestUserList")
//public void createMyTest(String TestUserName) { 
@Test	
public void createMyTest() { 

	SFDCAutomationFW sfdc = null; 
	AccountsScreen_LUI accountsScreen = null; 
	AllAppsTabsScreen_LUI allTAppsObjectsScreen = null;
	String TC_CreateAccount_LUI = "TC_CreateAccount_LUI";

	String TCName = "TC_CreateAccount_LUI"; 
	if (toolName.equalsIgnoreCase("Selenium"))
	{ 
		System.out.println("----------------->Inside Test Case");
		sfdc = new SFDCAutomationFW(remoteDriver, TCName);
		System.out.println("----------->Back to Test case");
		accountsScreen = new AccountsScreen_LUI(remoteDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(remoteDriver);
	}
	else if (toolName.equalsIgnoreCase("Appium"))
	{
		sfdc = new SFDCAutomationFW(appiumDriver, TCName);
		accountsScreen = new AccountsScreen_LUI(appiumDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(appiumDriver);
	}
	
	DB DB = new DB();
	BC BC = new BC(remoteDriver);
	DataSetup DataSetup = new DataSetup();

	System.out.println("-----------Begin of TestScript-------------");

	try { 
			 
		DB.Connect(DataSetup.TestData);
			
		//Reading the test data from external test data sheet
		String ACCOUNT_NAME = DB.ReadXLData("CreateAccount", "ACCOUNT_NAME", "TESTCASENAME", TCName);
		String RATING = DB.ReadXLData("CreateAccount", "RATING", "TESTCASENAME", TCName);
		String PHONE = DB.ReadXLData("CreateAccount", "PHONE", "TESTCASENAME", TCName);
		String ACCOUNT_NUMBER = DB.ReadXLData("CreateAccount", "ACCOUNT_NUMBER", "TESTCASENAME", TCName);
		String ACCOUNT_SITE = DB.ReadXLData("CreateAccount", "ACCOUNT_SITE", "TESTCASENAME", TCName);
		String TYPE = DB.ReadXLData("CreateAccount", "TYPE", "TESTCASENAME", TCName);
		String INDUSTRY = DB.ReadXLData("CreateAccount", "INDUSTRY", "TESTCASENAME", TCName);
		String SLA = DB.ReadXLData("CreateAccount", "SLA", "TESTCASENAME", TCName);
		String ACTIVE = DB.ReadXLData("CreateAccount", "ACTIVE", "TESTCASENAME", TCName);
		String OWNERSHIP = DB.ReadXLData("CreateAccount", "OWNERSHIP", "TESTCASENAME", TCName);
		String UPSELL_OPPORTUNITY = DB.ReadXLData("CreateAccount", "UPSELL_OPPORTUNITY", "TESTCASENAME", TCName);
		String CUSTOMER_PRIORITY = DB.ReadXLData("CreateAccount", "CUSTOMER_PRIORITY", "TESTCASENAME", TCName);
				
				
		
		//DB.Connect(DataSetup.Logininfo);
		ReadDataSheet rds = new ReadDataSheet();
		String OWNER =  rds.getValue("LoginInfo", SFDCLoginUserName, "Name");
				
		ACCOUNT_NAME = ACCOUNT_NAME + BC.GetCurrentDateTimeStamp();
		Thread.sleep(1000L);
		
		Thread.sleep(1000L);
		String mandatory_error = "Complete this field";
		
		// Login to SFDC 
		sfdc.LoginToSFDC(SFDCLoginUserName); //This variable is inherited from TestBase
				
		
		Thread.sleep(3000L);
		sfdc.SelectApplication_LUI("Sales Console");
		Thread.sleep(5000L);
		
		allTAppsObjectsScreen.AccountsTab().Click();
		Thread.sleep(2000L);
		accountsScreen.NewButton().Click();
		Thread.sleep(4000L);
		accountsScreen.SLAExpirationDateField().ClickONInputField();
		sfdc.SelectFromDateLookupByIndex(0);
		Thread.sleep(1000L);
		accountsScreen.SLAExpirationDateField().ClickONInputField();
		sfdc.SelectFromDateLookupByIndex(1);
		Thread.sleep(1000L);
		accountsScreen.SLAExpirationDateField().ClickONInputField();
		sfdc.SelectFromDateLookupByIndex(2);
		Thread.sleep(1000L);
		accountsScreen.SLAExpirationDateField().ClickONInputField();
		sfdc.SelectFromDateLookupByIndex(3);
		Thread.sleep(1000L);
		accountsScreen.SLAExpirationDateField().ClickONInputField();
		sfdc.SelectFromDateLookupByIndex(4);
		Thread.sleep(1000L);
		accountsScreen.SLAExpirationDateField().ClickONInputField();
		sfdc.SelectFromDateLookupByIndex(8);
		Thread.sleep(1000L);
		accountsScreen.SLAExpirationDateField().ClickONInputField();
		sfdc.SelectFromDateLookupByIndex(-1);
		Thread.sleep(1000L);
		accountsScreen.SLAExpirationDateField().ClickONInputField();
		sfdc.SelectFromDateLookupByIndex(-2);
		Thread.sleep(1000L);
		accountsScreen.SLAExpirationDateField().ClickONInputField();
		sfdc.SelectFromDateLookupByIndex(-3);
		Thread.sleep(1000L);
		accountsScreen.SLAExpirationDateField().ClickONInputField();
		sfdc.SelectFromDateLookupByIndex(-4);
		Thread.sleep(1000L);
		accountsScreen.SLAExpirationDateField().ClickONInputField();
		sfdc.SelectFromDateLookupByIndex(-10);
		Thread.sleep(1000L);
		
				
		accountsScreen.SaveButton().Click();
		
		Thread.sleep(3000L);
		sfdc.VerifyPageLevelErrorMessage_LUI("Review the following fields");
		
		accountsScreen.AccountNameField().VerifyFieldErrorMsgOnEditPage(mandatory_error);
		
		//Verifying existence of field names 
		
		accountsScreen.AccountNameField().IsDisplayed("Yes");
		accountsScreen.AccountOwnerField().IsDisplayed("Yes");
		accountsScreen.AccountNumberField().IsDisplayed("Yes");
		accountsScreen.ParentAccountField().IsDisplayed("Yes");
		accountsScreen.AccountSiteField().IsDisplayed("Yes");
		accountsScreen.TypeField().IsDisplayed("Yes");
		accountsScreen.IndustryField().IsDisplayed("Yes");
		accountsScreen.AnnualRevenueField().IsDisplayed("Yes");
		accountsScreen.RatingField().IsDisplayed("Yes");
		accountsScreen.PhoneField().IsDisplayed("Yes");
		accountsScreen.FaxField().IsDisplayed("Yes");
		accountsScreen.WebsiteField().IsDisplayed("Yes");
		accountsScreen.TickerSymbolField().IsDisplayed("Yes");
		accountsScreen.OwnershipField().IsDisplayed("Yes");
		accountsScreen.SICCodeField().IsDisplayed("Yes");
		accountsScreen.EmployeesField().IsDisplayed("Yes");
		accountsScreen.BillingStreetField().IsDisplayed("Yes");
		accountsScreen.BillingCityField().IsDisplayed("Yes");
		accountsScreen.BillingZipPostalCodeField().IsDisplayed("Yes");
		accountsScreen.BillingStateProvinceField().IsDisplayed("Yes");
		accountsScreen.BillingCountryField().IsDisplayed("Yes");
		accountsScreen.ShippingStreetField().IsDisplayed("Yes");
		accountsScreen.ShippingCityField().IsDisplayed("Yes");
		accountsScreen.ShippingCountryField().IsDisplayed("Yes");
		accountsScreen.ShippingStateProvinceField().IsDisplayed("Yes");
		accountsScreen.ShippingZipPostalCodeField().IsDisplayed("Yes");
		accountsScreen.CustomerPriorityField().IsDisplayed("Yes");
		accountsScreen.SLAExpirationDateField().IsDisplayed("Yes");
		accountsScreen.NumberofLocationsField().IsDisplayed("Yes");
		accountsScreen.SLAField().IsDisplayed("Yes");
		accountsScreen.SLASerialNumberField().IsDisplayed("Yes");
		accountsScreen.UpsellOpportunityField().IsDisplayed("Yes");
		accountsScreen.IndustryField().IsDisplayed("Yes");
		accountsScreen.AnnualRevenueField().IsDisplayed("Yes");
		
		//Enter the data 
		accountsScreen.AccountNameField().Type(ACCOUNT_NAME);
		accountsScreen.AccountNumberField().Type(ACCOUNT_NUMBER);
		accountsScreen.AccountSiteField().Type(ACCOUNT_SITE);
		accountsScreen.PhoneField().Type(PHONE);
		Thread.sleep(1000);
		accountsScreen.RatingField().SelectPL(RATING);
		
		accountsScreen.TypeField().SelectPL(TYPE);
		accountsScreen.IndustryField().SelectPL(INDUSTRY);
		accountsScreen.OwnershipField().SelectPL(OWNERSHIP);
		accountsScreen.SLAField().SelectPL(SLA);		
		accountsScreen.UpsellOpportunityField().SelectPL(UPSELL_OPPORTUNITY);		
		accountsScreen.ActiveField().SelectPL(ACTIVE);		
		accountsScreen.CustomerPriorityField().SelectPL(CUSTOMER_PRIORITY);			
		accountsScreen.SaveButton().Click();		
		accountsScreen.RL_NotesAttachments().Owner();
		
		Thread.sleep(5000L);
		
		sfdc.ClickONSubTab("Details");
		
		//Verify Default Values and Prepopulated Values
		accountsScreen.AccountOwnerField().VerifyViewOnlyValueEquals(OWNER);
				
				
		String accname = accountsScreen.AccountNameField().GetViewOnlyValue();
		
		DB.Connect(DataSetup.TestData);		
		
		//Update excel with full name
		DB.UpdateXLCell("CreateAccount", accname, "ACCOUNT_NAME_SAVED", "TESTCASENAME", TCName);
		
		
		sfdc.LogOff();
		
		//remoteDriver.close();
	} 
	catch (Exception e) { 
		e.printStackTrace(); 
		System.out.println("Exception(Exception) in main"); 
	}
	finally { 
		System.out.println("-----------End of TestScript-------------"); 
	} 
	} 
} 
