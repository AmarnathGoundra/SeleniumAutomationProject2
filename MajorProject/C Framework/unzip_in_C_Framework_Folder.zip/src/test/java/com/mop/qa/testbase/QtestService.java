package com.mop.qa.testbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.maven.shared.invoker.SystemOutHandler;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.qas.api.Constants.ContentType;
import org.qas.qtest.api.auth.PropertiesQTestCredentials;
import org.qas.qtest.api.auth.QTestCredentials;
import org.qas.qtest.api.internal.QTestApiWebServiceClient;
import org.qas.qtest.api.internal.QTestService;
import org.qas.qtest.api.services.attachment.AttachmentService;
import org.qas.qtest.api.services.attachment.AttachmentServiceClient;
import org.qas.qtest.api.services.attachment.model.Attachment;
import org.qas.qtest.api.services.attachment.model.AttachmentRequest;
import org.qas.qtest.api.services.attachment.model.AttachmentType;
import org.qas.qtest.api.services.design.TestDesignService;
import org.qas.qtest.api.services.design.TestDesignServiceClient;
import org.qas.qtest.api.services.design.model.CreateTestCaseRequest;
import org.qas.qtest.api.services.design.model.CreateTestStepRequest;
import org.qas.qtest.api.services.design.model.GetTestCaseRequest;
import org.qas.qtest.api.services.design.model.GetTestStepRequest;
import org.qas.qtest.api.services.design.model.ListTestStepRequest;
import org.qas.qtest.api.services.design.model.TestCase;
import org.qas.qtest.api.services.design.model.TestStep;
import org.qas.qtest.api.services.execution.TestExecutionService;
import org.qas.qtest.api.services.execution.TestExecutionServiceClient;
import org.qas.qtest.api.services.execution.model.AutomationTestLog;
import org.qas.qtest.api.services.execution.model.AutomationTestLogRequest;
import org.qas.qtest.api.services.execution.model.CreateTestRunRequest;
import org.qas.qtest.api.services.execution.model.TestLog;
import org.qas.qtest.api.services.execution.model.TestRun;
import org.qas.qtest.api.services.execution.model.UpdateTestRunRequest;
import org.qas.qtest.api.services.project.ProjectService;
import org.qas.qtest.api.services.project.ProjectServiceClient;
import org.qas.qtest.api.services.project.model.ListProjectRequest;
import org.qas.qtest.api.services.project.model.Project;
import org.qas.qtest.api.services.project.model.transform.ListProjectRequestMarshaller;

public class QtestService {
	public Long myprojectid;
	public String qTestPropertyFilePath = "";

	public QTestCredentials credentials = null;
	public ProjectService projectService = null;
	public TestDesignService testDesignService = null;
	public TestExecutionService testExecutionService = null;
	public AttachmentService attachmentService = null;
	public TestLog testLog_futureattachment = null;
	
	public ArrayList<String> al_tc_name;
	public ArrayList<String> al_tc_desc;
	public ArrayList<String> al_tc_precond;
	public ArrayList<String> al_tc_step_desc;
	public ArrayList<String> al_tc_expected_result;
	public ArrayList<Integer> al_tc_no_of_steps;
	

	QtestService() {
		try {
			String myCurrentDir = System.getProperty("user.dir");
			System.out.println("myCurrentDir:" + myCurrentDir);
			qTestPropertyFilePath = myCurrentDir + "//qTestCredentials.properties";

			// Open the file as an input stream
			InputStream is = new FileInputStream(qTestPropertyFilePath);
			credentials = new PropertiesQTestCredentials(is);

			//The logic has been applied such that the array size of 
			//each of the below four arraylist will be always same and 
			//is applicable for a single test case 
			al_tc_name = new ArrayList<String>();
			al_tc_desc = new ArrayList<String>();
			al_tc_precond = new ArrayList<String>();
			al_tc_no_of_steps = new ArrayList<Integer>();
			
			//The logic applied such that size of below two array list will be same always 
			//Below arraylist contains entries for all the test steps of all the test cases
			al_tc_step_desc = new ArrayList<String>();
			al_tc_expected_result = new ArrayList<String>();
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		try {

			QtestService qtest = new QtestService();

			// TODO Auto-generated method stub
			qtest.setProjectServiceClient(); 
			qtest.getListOfQTestProjects();
			
			//qtest.setTestDesignServiceClient();
			//qtest.createATestCaseinQtest();
						
			qtest.setTestExecutionServiceClient();			
			//qtest.createTestRun();
			
			qtest.setAttachmentServiceClient();
			
			qtest.createAutomationLog();
			qtest.AddAttachment();
						
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Setting the end point for ProjectServiceClient
	public void setProjectServiceClient() throws Exception {
		try {

			// Getting the list of projects
			projectService = new ProjectServiceClient(credentials);
			System.out.println("ProjectService Client:" + projectService);

			projectService.setEndpoint(getPropertyValue("domain"));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Set the end point to Test Service Client service
	public void setTestDesignServiceClient() throws Exception {
		try {
			testDesignService = new TestDesignServiceClient(credentials);
			testDesignService.setEndpoint(getPropertyValue("domain"));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	// Get the list of QTest projects using Project Service Client
	public void getListOfQTestProjects() throws Exception {
		try {
			ListProjectRequest listProjectRequest = new ListProjectRequest();
			List<Project> projects = projectService.listProject(listProjectRequest);
			for (Project eachproj : projects) {
				System.out.println("Name:" + eachproj.getName());
				System.out.println("ProjectID:" + eachproj.getId());
				System.out.println("Project Description:" + eachproj.getDescription());
				myprojectid = eachproj.getId();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Create a test case in qTest 'Created via API' module in Test Design section
	public Long createATestCaseinQtest() throws Exception {
		Long qtest_tc_id = null;
		try {
			
			int pointer_of_design_expected_steps = 0;
			getAllTestCaseDeayilsToArrayList();
			System.out.println("Number of test case found in qTestmapping template is:"+al_tc_name.size());
			for(int i=0;i<al_tc_name.size();i++)
			{
				//Create a test case entry with name,description,precondition in qtest
				String current_tc_name = al_tc_name.get(i);
				String current_tc_desc = al_tc_desc.get(i);
				String current_tc_precond = al_tc_precond.get(i);
				TestCase testCase = new TestCase()
						.withName(current_tc_name)
						.withDescription(current_tc_desc)
						.withPrecondition(current_tc_precond);
						
				CreateTestCaseRequest createTestCaseRequest = new CreateTestCaseRequest()
						.withProjectId(myprojectid)
						.withTestCase(testCase);
								
				TestCase testCaseResult = testDesignService.createTestCase(createTestCaseRequest);
				Long testcaseId = testCaseResult.getId();
				Long testcasever = testCaseResult.getTestCaseVersionId();
				System.out.println("testcaseId:" + testcaseId);
				System.out.println("testcasever" + testcasever);
				System.out.println("-------------->"+i);
				System.out.println("-------------->"+al_tc_no_of_steps.size());
				System.out.println("-------------->"+al_tc_no_of_steps.get(i));
				//Adding all the steps for a each test case one by one
				for(int j=0;j<al_tc_no_of_steps.get(i);j++)
				{
					// Create a test step of a test case
					TestStep testStep = new TestStep()
							.withDescription(al_tc_step_desc.get(pointer_of_design_expected_steps))
							.withExpected(al_tc_expected_result.get(pointer_of_design_expected_steps));
					CreateTestStepRequest createTestStepRequest = new CreateTestStepRequest()
							.withProjectId(myprojectid)
							.withTestCaseId(testcaseId)
							.withTestStep(testStep);
							  
					TestStep testStepResult = testDesignService.createTestStep(createTestStepRequest); 
					pointer_of_design_expected_steps = pointer_of_design_expected_steps + 1;
				}
				System.out.println("***** successfully added all the steps of the test case ****"); 
				
						
			}			
		  
		  return qtest_tc_id;
		  	 
		} catch (Exception e) 
		{
			e.printStackTrace();
			return qtest_tc_id;
		}
	}
	
	// Set the end point to Test Execution Client Service 
	public void setTestExecutionServiceClient() throws Exception {
		try {
			testExecutionService = new TestExecutionServiceClient(credentials);
			testExecutionService.setEndpoint(getPropertyValue("domain"));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// Set the end point to AttachmentService Client 
	public void setAttachmentServiceClient() throws Exception {
		try {
			attachmentService = new AttachmentServiceClient(credentials);
			attachmentService.setEndpoint(getPropertyValue("domain"));
			
			
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	// Create Test Run by associating test cases with test suite within a Release and a cycle
	public void createTestRun() throws Exception {
		try {
		
			TestCase testCase = new TestCase()
					.withName("TC_CreateACase")
					.withId(670338L);
				
			
			TestRun testrun = new TestRun()
					.withName("mytest")
					.withTestCase(testCase);
					
			
			CreateTestRunRequest createTestRun = new CreateTestRunRequest()
					.withProjectId(myprojectid)
					.withTestRun(testrun);
								
			
			TestRun testRunResult = testExecutionService.createTestRun(createTestRun);
			
			System.out.println("Test Run is is:"+testRunResult.getId());
			
					
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// Create Automation Test Log
	public void createAutomationLog() throws Exception {
		try {
						
			AutomationTestLog automationTestLog = new AutomationTestLog()
					.withExecutionStartDate(new Date())
				    .withExecutionEndDate(new Date())
				    .withStatus("PASS")
				    .withSystemName("TestNG");
					
			AutomationTestLogRequest automationTestLogRequest =	new AutomationTestLogRequest()
					.withProjectId(myprojectid)
					.withTestRunId(1065227L)
					.withAutomationTestLog(automationTestLog);
			
			testLog_futureattachment =	testExecutionService.submitAutomationTestLog(automationTestLogRequest);
			System.out.println("Automation Test Log ID:"+testLog_futureattachment.getId());
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void AddAttachment()
	{
		try {
			
			File initialFile = new File("Resume.pdf");
		    InputStream targetStream = new FileInputStream(initialFile);
			
			AttachmentRequest attachmentRequest = new AttachmentRequest()
					.withType(AttachmentType.TESTLOG)
					.withProjectId(myprojectid)
					.withTypeId(testLog_futureattachment.getId())
					.withFileName("Resume.pdf")
					.withContentType("pdf")
					.withContent(targetStream);
			
			Attachment attachment = attachmentService.attach(attachmentRequest);					
			System.out.println("The result of the attachment is:"+attachment.getId());
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	// Reads the value of property from QTestCredentials.properties file only
	public String getPropertyValue(String key) throws IOException {
		String value = "";
		try {
			String myCurrentDir = System.getProperty("user.dir");
			System.out.println("myCurrentDir:" + myCurrentDir);
			qTestPropertyFilePath = myCurrentDir + "//qTestCredentials.properties";
			FileInputStream fileInputStream = new FileInputStream(qTestPropertyFilePath);

			Properties property = new Properties();
			property.load(fileInputStream);

			value = property.getProperty(key);

			fileInputStream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;

	}

	public void getAllTestCaseDeayilsToArrayList() throws Exception {

		try {
			int counter_tc_step = 0;
			FileInputStream file = new FileInputStream(new File("./qTestMappingTestCaseTemplate.xlsx"));
			Workbook workbook = new XSSFWorkbook(file);
			Sheet sheet = workbook.getSheetAt(0);
			Iterator<Row> rowIterator = sheet.iterator();
			// Traversing over each row of XLSX file 
			while (rowIterator.hasNext())
			{
				Row row = rowIterator.next(); 
				
				// For each row, iterate through each columns 
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext())
				{ 
					Cell cell = cellIterator.next(); 
					
					System.out.println("\n column_index:"+cell.getColumnIndex());
					System.out.println("\n row_index:"+cell.getRowIndex());
					
					//Getting the test case name
					if (cell.getColumnIndex()==0 && cell.getRowIndex() > 0){
						System.out.println("Found a Test Case Starting Row Index:"+cell.getRowIndex());
						al_tc_name.add(cell.getStringCellValue());
						if (cell.getRowIndex()>1) {
							System.out.println("number of steps in the above test case is:"+counter_tc_step);
							al_tc_no_of_steps.add(counter_tc_step);
						}
						counter_tc_step = 0; //Every time for a new test case counter will reset to 0
											
					}
					//Getting the test case description
					if (cell.getColumnIndex()==1 && cell.getRowIndex() > 0){
						System.out.println("Test Case Description at Row Index:"+cell.getRowIndex());
						al_tc_desc.add(cell.getStringCellValue());
					}
					//Getting the test case precondition
					if (cell.getColumnIndex()==2 && cell.getRowIndex() > 0){
						System.out.println("Test Case precondition at Row Index:"+cell.getRowIndex());
						al_tc_precond.add(cell.getStringCellValue());
					}
					//Getting the test case step description
					if (cell.getColumnIndex()==3 && cell.getRowIndex() > 0){
						System.out.println("Test Case step description at Row Index:"+cell.getRowIndex());
						al_tc_step_desc.add(cell.getStringCellValue());
					}
					//Getting the test case step expected result
					if (cell.getColumnIndex()==4 && cell.getRowIndex() > 0){
						System.out.println("Test Case expected result at Row Index:"+cell.getRowIndex());
						al_tc_expected_result.add(cell.getStringCellValue());
						counter_tc_step = counter_tc_step + 1;
					}
					
					switch (cell.getCellType())
					{
						case Cell.CELL_TYPE_STRING:
							System.out.print(cell.getStringCellValue() + "\t");
							break;
						case Cell.CELL_TYPE_NUMERIC:
							System.out.print(cell.getNumericCellValue() + "\t");
							break;
						case Cell.CELL_TYPE_BOOLEAN:
							System.out.print(cell.getBooleanCellValue() + "\t");
							break;
						default :
					}
				}
				System.out.println(" \n ************** One row printing done ***************** \n");
				}
				al_tc_no_of_steps.add(counter_tc_step);
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}
	

}
