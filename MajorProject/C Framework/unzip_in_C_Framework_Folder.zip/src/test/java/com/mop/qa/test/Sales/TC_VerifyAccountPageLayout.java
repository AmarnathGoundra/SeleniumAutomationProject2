package com.mop.qa.test.Sales; 
 
 
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.Duration;

import javax.activation.MimeType;
import javax.imageio.ImageIO;

import org.monte.media.av.Format;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.common.base.Function;
import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.pageobject.HomePageLayout;
import com.mop.qa.testbase.TestBase; 
import SOURCE_CODE.SFDC.DB; 
import USER_SPACE.BusinessComponent.BC; 
import SOURCE_CODE.SFDC.SFDCAutomationFW; 
import USER_SPACE.TestPrerequisite.DataSetup;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;
import ru.yandex.qatools.ashot.coordinates.WebDriverCoordsProvider;
import USER_SPACE.ObjectRepository.AccountsScreen_LUI;
import USER_SPACE.ObjectRepository.AllAppsTabsScreen_LUI;
import USER_SPACE.ObjectRepository.LeadScreen;
import USER_SPACE.ObjectRepository.LeadsScreen_LUI; 

/* 
* 
* @Author: <Name of Test Script Creator> 
* @Description: <Please mention the scope of this test script> 
* @General Guidelines: Every Test Script must begin from Launching 
* URL of login screen and must end with browser closed 
*/ 

public class TC_VerifyAccountPageLayout extends TestBase { 
	
	
	/*
	@DataProvider(name = "TestUserList")	 
	  public static Object[][] LoginUsers()
	 {
	 	        return new Object[][] { 
	 	        						{ "TestUser1" },
	 	        						{ "TestUser3" }	 	        						
	 	        					  };	 
	  }
	
	*/
	
//@Test(dataProvider="TestUserList")
//public void createMyTest(String TestUserName) { 
@Test	
public void createMyTest() throws Exception{ 

	
	SFDCAutomationFW sfdc = null; 
	AccountsScreen_LUI accountsScreen = null; 
	AllAppsTabsScreen_LUI allTAppsObjectsScreen = null;
	String TC_VerifyAccountPageLayout = "TC_VerifyAccountPageLayout";

	String TCName = "TC_VerifyAccountPageLayout"; 
	if (toolName.equalsIgnoreCase("Selenium"))
	{ 
		System.out.println("----------------->Inside Test Case");
		sfdc = new SFDCAutomationFW(remoteDriver, TCName);
		System.out.println("----------->Back to Test case");
		accountsScreen = new AccountsScreen_LUI(remoteDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(remoteDriver);
	}
	else if (toolName.equalsIgnoreCase("Appium"))
	{
		sfdc = new SFDCAutomationFW(appiumDriver, TCName);
		accountsScreen = new AccountsScreen_LUI(appiumDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(appiumDriver);
	}
	
	DB DB = new DB();
	BC BC = new BC(remoteDriver);
	DataSetup DataSetup = new DataSetup();

	System.out.println("-----------Begin of TestScript-------------");

	try { 
		
		
		
		//DB.Connect(DataSetup.Logininfo);
		ReadDataSheet rds = new ReadDataSheet();
		String OWNER =  rds.getValue("LoginInfo", SFDCLoginUserName, "Name");
		
		// Login to SFDC 
		sfdc.LoginToSFDC(SFDCLoginUserName); //This variable is inherited from TestBase
		
		sfdc.AddToLayoutVerificationPoint(getElementByXPath(HomePageLayout.Home_Menus_XP));
		
		sfdc.AddToLayoutVerificationPoint(getElementByXPath(HomePageLayout.Home_VIEWPORT_XP));
		
		sfdc.AddToLayoutVerificationPoint(getElementByXPath(HomePageLayout.Home_RECENT_RECORD_SECTION));
		
		
		allTAppsObjectsScreen.AccountsTab().Click();
		
		sfdc.GlobalSearch_LUI("Accounts", "ACCT_240124220437");
		
		sfdc.ClickONSubTab("Details");
		
		sfdc.AddToLayoutVerificationPoint(getElementByXPath(HomePageLayout.ACC_RECORD_DETAIL_VIEW));
		
		
//		WebElement elmnt = remoteDriver.findElement(By.xpath(xp));
//		BufferedImage expectedImage = ImageIO.read(new File(System.getProperty("user.dir") +"\\LayoutStorage\\Menu.png"));
//		Screenshot logoImageScreenshot = new AShot().coordsProvider(new WebDriverCoordsProvider()).takeScreenshot(remoteDriver, elmnt);
//		BufferedImage actualImage = logoImageScreenshot.getImage();  
//		String img_file_path = System.getProperty("user.dir")+"\\LayoutStorage\\ActualMenu.png";
//      ImageIO.write(actualImage,"png",new File(img_file_path));
//        
//      //Comparison
//      ImageDiffer imgDiff = new ImageDiffer();
//		ImageDiff diff = imgDiff.makeDiff(actualImage, expectedImage);
//		Assert.assertFalse(diff.hasDiff(),"Result of Image comparsion");
//		System.out.println("Images Compared Sucesfully");
//        
//      File f = new File(img_file_path);
//      if(f.exists())
//      {
//      	System.out.println("Image File Captured");
//      }
//      else
//      {
//        System.out.println("Image File NOT exist");
//      }
//  
//		
		
		//remoteDriver.close();
	} 
	catch (Exception e) { 
		e.printStackTrace(); 
		System.out.println("Exception(Exception) in main"); 
	}
	finally { 
		System.out.println("-----------End of TestScript-------------");
	} 
	} 
} 
