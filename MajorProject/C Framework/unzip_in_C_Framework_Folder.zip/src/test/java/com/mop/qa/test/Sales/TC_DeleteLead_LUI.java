package com.mop.qa.test.Sales; 
 
 
import org.testng.annotations.Test; 
import com.mop.qa.testbase.TestBase; 
import SOURCE_CODE.SFDC.DB; 
import USER_SPACE.BusinessComponent.BC; 
import SOURCE_CODE.SFDC.SFDCAutomationFW; 
import USER_SPACE.TestPrerequisite.DataSetup;
import USER_SPACE.ObjectRepository.AllAppsTabsScreen_LUI;
import USER_SPACE.ObjectRepository.LeadScreen;
import USER_SPACE.ObjectRepository.LeadsScreen_LUI; 

/* 
* 
* @Author: <Name of Test Script Creator> 
* @Description: <Please mention the scope of this test script> 
* @General Guidelines: Every Test Script must begin from Launching 
* URL of login screen and must end with browser closed 
*/ 

public class TC_DeleteLead_LUI extends TestBase { 

@Test 
public void createMyTest() { 

	String TCName = "TC_DeleteLead_LUI"; 
	
	SFDCAutomationFW sfdc = null; 
	LeadsScreen_LUI leadScreen = null; 
	AllAppsTabsScreen_LUI allTAppsObjectsScreen = null;
	
	
	
	if (toolName.equalsIgnoreCase("Selenium"))
	{ 
		sfdc = new SFDCAutomationFW(remoteDriver, TCName);
		leadScreen = new LeadsScreen_LUI(remoteDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(remoteDriver);
	}
	else if (toolName.equalsIgnoreCase("Appium"))
	{
		sfdc = new SFDCAutomationFW(appiumDriver, TCName);
		leadScreen = new LeadsScreen_LUI(appiumDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(appiumDriver);
	}
	
	DB DB = new DB();
	BC BC = new BC(remoteDriver);
	DataSetup DataSetup = new DataSetup();

	System.out.println("-----------Begin of TestScript-------------");

	try { 
	
		String TestUserName = "TestUser1"; 
		DB.Connect(DataSetup.TestData);
			
		//Reading the test data from external test data sheet
		String NAME = DB.ReadXLData("CreateLead", "NAME", "TESTCASENAME", "TC_CreateLead_LUI");
		
		String uniqno = BC.GetCurrentDateTimeStamp();
				
		// Login to SFDC 
		sfdc.LoginToSFDC(TestUserName); 
				
		sfdc.SelectApplication_LUI("Sales");
		
		Thread.sleep(2000L);
		
		allTAppsObjectsScreen.LeadsTab().Click();
		
		sfdc.GlobalSearch_LUI("Leads", NAME);
		
		Thread.sleep(5000L);
		
		sfdc.ClickONSubTab("Details");
		
		Thread.sleep(2000L);
		
		leadScreen.MenuButtonDeleteButton().MenuButtonClick();
		
		
		sfdc.Field_LUI("Are you sure you want to delete this lead?").IsDisplayed("Yes");
		
		leadScreen.DeleteButton().Click();
		
		
		sfdc.LogOff();
		
		sfdc.Quit();		
			
	} 
	catch (Exception e) { 
		e.printStackTrace(); 
		System.out.println("Exception(Exception) in main"); 
	}
	finally { 
		System.out.println("-----------End of TestScript-------------"); 
	} 
	} 
} 
