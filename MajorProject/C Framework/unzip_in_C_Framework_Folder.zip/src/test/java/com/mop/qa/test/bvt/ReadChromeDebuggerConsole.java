package com.mop.qa.test.bvt;

import java.util.logging.Level;

import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;

public class ReadChromeDebuggerConsole {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//System.setProperty("webdriver.chrome.driver", getChromeDriverLocation());

		LoggingPreferences loggingprefs = new LoggingPreferences();
		loggingprefs.enable(LogType.BROWSER, Level.WARNING);
		loggingprefs.enable(LogType.PERFORMANCE, Level.WARNING);


}
}
