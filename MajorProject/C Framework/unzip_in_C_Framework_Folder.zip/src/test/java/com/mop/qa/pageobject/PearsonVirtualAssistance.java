package com.mop.qa.pageobject;

import io.appium.java_client.AppiumDriver;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.testbase.PageBase;
import com.relevantcodes.extentreports.LogStatus;

public class PearsonVirtualAssistance extends PageBase {

	public static org.openqa.selenium.Point location = null;
	public static float playx = 0;
	public static float playy = 0;
	public static org.openqa.selenium.Dimension size = null;

	public PearsonVirtualAssistance(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
	}

	public PearsonVirtualAssistance(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}

	//New changes
	@FindBy(xpath = "//*[@name='customer']") 

	private WebElement lstCustomerType;
	
	@FindBy(xpath = "//*[@name='issue']") 

	private WebElement lstCategoryType;
	
	//	@FindBy(xpath = "//button[@class='flatButton']") //span[@class='message']
	@FindBy(xpath = "//span[@class='message']") 

	private WebElement btnPearSonVirtualChat;

	@FindBy(id = "prechat-firstname")

	private WebElement txtFirstName;

	@FindBy(id = "prechat-lastname")

	private WebElement txtLastName;

	@FindBy(id = "prechat-email")

	private WebElement txtEmail;

	@FindBy(xpath = "//button[@class='startChatButton slds-button slds-button_neutral']")

	private WebElement btnStartChatting;

	//Welcome Messages

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][1]")

	private WebElement labelHellomsg1;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][2]")

	private WebElement labelHellomsg2;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][3]")

	private WebElement labelHellomsg3;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][5]")

	private WebElement labelAssignmentMsg1;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][6]")

	private WebElement labelAssignmentMsg2;

//	@FindBy(xpath = "//div[@class='chasitorControls']/descendant::textarea[contains(@class,'chasitorText  textarea')]")
	
	@FindBy(xpath = "/html/body/div[4]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div/div/textarea")
	private WebElement txtYourMsg;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')][1]")

	private WebElement btnChromeOptYes;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')][2]")

	private WebElement btnChromeOptNo;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')][3]")

	private WebElement btnGuideOptYes;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')][4]")

	private WebElement btnGuideOptNo;

	//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')][5]

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')][5]")

	private WebElement btnAccessCode;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')][6]")

	private WebElement btnAccountID;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')][7]")

	private WebElement btnOrderID;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')][8]")

	private WebElement btnIdontHavethis;


	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][8]")

	private WebElement labelGuideMsg1;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][9]")

	private WebElement labelGuideMsg2;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][10]")

	private WebElement labelGuideMsg3;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][12]")

	private WebElement labelAdditionalMsg1;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][13]")

	private WebElement labelAdditionalMsg2;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][15]")

	private WebElement labelAccessCodeMsg1;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][17]")

	private WebElement labelOrderIDMsg1;

	//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][19]

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][19]")

	private WebElement labelHelpMsg1;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][20]")

	private WebElement labelHelpMsg2;
	
	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][22]")

	private WebElement labelInstituteMsg1;

	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')][9]")

	private WebElement btnStudent;
	
	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')][10]")

	private WebElement btnEducator;
	
	@FindBy(xpath = "//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][24]")

	private WebElement labelCaseCreatedMsg1;
	

	public void enterUrl() throws Exception {
		enterUrl("https://preprod-pearsoncommunity.cs80.force.com/getsupport/s/contactsupport");
		Thread.sleep(9000);
	}

	public void clickLiveAssistance() throws Exception{
		selectOPtionByVisibleText(lstCustomerType, "College Student");
		selectOPtionByVisibleText(lstCategoryType, "Assignments");
		Thread.sleep(7000);
		click(btnPearSonVirtualChat, "PearSonVirtualChat Button");
		Thread.sleep(7000);
	}

	public void enterLiveAssistanceDetails() throws Exception{
		enterText(txtFirstName, "Sangeetha", "FirstName");
		enterText(txtLastName, "Kothakapu", "Lastname");
		enterText(txtEmail, "Sangeetha@gmail.com", "Email");
	}

	public void clickStartChatting() throws Exception{
		click(btnStartChatting, "Start Chatting");
		Thread.sleep(8000);
	}
	//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText'][1]

	public void verifyWelcomeMessages() throws Exception{
		Thread.sleep(7000);
		System.out.println(labelHellomsg1.getText());
		System.out.println(labelHellomsg1.getText().trim());
		System.out.println(labelHellomsg1.getText().replace("?", "'"));
		System.out.println("Hello! I\'m the Pearson Virtual Assistant, a new way to quickly get help with registration, access code, sign-in or assignment issues.");
		
		if(labelHellomsg1.getText().trim().contains("the Pearson Virtual Assistant, a new way to quickly get help with registration, access code, sign-in or assignment issues.")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelHellomsg1.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelHellomsg1.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}

		if(labelHellomsg2.getText().trim().contains("answer your question or resolve your issue, I can get you to a live agent who will assist you.")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelHellomsg2.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelHellomsg2.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}

		if(labelHellomsg3.isDisplayed()
				&& labelHellomsg3.getText().equals("Now, ask away!")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelHellomsg3.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelHellomsg3.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}
	}

	public void enterYourMessage(String msg)throws Exception{
		Thread.sleep(3000);
		//html/body/div[4]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div/div/textarea
		enterText(txtYourMsg, msg, "TypeYourMessage");
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(7000);
		
	}

	public void verifyAssignmentErrMsg() throws Exception{

		if(labelAssignmentMsg1.isDisplayed()
				&& labelAssignmentMsg1.getText().equals("Assignment problems are typically caused by browser settings.")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelAssignmentMsg1.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelAssignmentMsg1.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}

		if(labelAssignmentMsg2.isDisplayed()
				&& labelAssignmentMsg2.getText().equals("To help troubleshoot, can you confirm that your browser is Chrome?")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelAssignmentMsg2.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelAssignmentMsg2.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}

	}

	public void selectChromeOptionYesNo()throws Exception{
		click(btnChromeOptYes, "Chrome Yes opt");
		Thread.sleep(7000);
	}

	public void verifyGuideMessages() throws Exception{
		Thread.sleep(7000);
		if(labelGuideMsg1.isDisplayed()
				&& labelGuideMsg1.getText().equals("Follow this guide to troubleshoot.")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelGuideMsg1.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelGuideMsg1.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}

		if(labelGuideMsg2.isDisplayed()
				&& labelGuideMsg2.getText().equals("https://support.pearson.com/getsupport/s/Guided-Assistance?page=device/pearson/troubleshooter/topic/browser-usecases/turn-off-pop-up-blockers-chrome/1")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelGuideMsg2.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelGuideMsg2.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}

		if(labelGuideMsg3.isDisplayed()
				&& labelGuideMsg3.getText().equals("Did this guide help resolve your issues?")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelGuideMsg3.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelGuideMsg3.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}
	}
	public void selectGuideOptionYesNo()throws Exception{
		click(btnGuideOptNo, "Guide No opt");
		Thread.sleep(7000);
	}

	public void verifyAdditionalMsg() throws Exception{
		Thread.sleep(3000);
		if(labelAdditionalMsg1.isDisplayed()
				&& labelAdditionalMsg1.getText().equals("Let's collect some additional information to assist you.")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelAdditionalMsg1.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelAdditionalMsg1.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}

		if(labelAdditionalMsg2.isDisplayed()
				&& labelAdditionalMsg2.getText().equals("What is the username associated with your Pearson account?")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelAdditionalMsg2.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelAdditionalMsg2.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}
	}

	public void verifyAccessCodeMsg() throws Exception{

		if(labelAccessCodeMsg1.isDisplayed()
				&& labelAccessCodeMsg1.getText().equals("Please provide your access code, account ID, or order ID.")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelAccessCodeMsg1.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelAccessCodeMsg1.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}

	}

	public void clickOrderID() throws Exception{
		click(btnOrderID, "Order ID");
		Thread.sleep(7000);
	}

	public void verifyOrderIDMsg() throws Exception{

		if(labelOrderIDMsg1.isDisplayed()
				&& labelOrderIDMsg1.getText().equals("Please provide your OrderId, this is found in the confirmation e-mail sent after registration.")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelOrderIDMsg1.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelOrderIDMsg1.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}

	}

	public void verifyHelpMsg() throws Exception{

		if(labelHelpMsg1.isDisplayed()
				&& labelHelpMsg1.getText().equals("Let's get you to someone who can help.")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelHelpMsg1.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelHelpMsg1.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}

		if(labelHelpMsg2.isDisplayed()
				&& labelHelpMsg2.getText().equals("What is the name of your school or institution?")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelHelpMsg2.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelHelpMsg2.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}
	}
	public void verifyInstituteMsg() throws Exception{

		if(labelInstituteMsg1.isDisplayed()
				&& labelInstituteMsg1.getText().equals("And are you a student or educator?")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelInstituteMsg1.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelInstituteMsg1.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}

	}
	public void clickStudent() throws Exception{
		click(btnStudent, "Student Button");
		Thread.sleep(7000);
	}
	public void verifyCaseCreatedMsg() throws Exception{

		if(labelCaseCreatedMsg1.isDisplayed()
				&& labelCaseCreatedMsg1.getText().contains("None of our support representatives are available right now, but I've created case for you. We will get in touch with you within 24 hours.")){
			ExtentUtility.getTest().log(LogStatus.PASS, labelCaseCreatedMsg1.getText()+" message is displayed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}else{
			ExtentUtility.getTest().log(LogStatus.FAIL, labelCaseCreatedMsg1.getText()+" message is not disaplyed successfully",
					ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
		}
		
		String CaseID =null;
		CaseID= labelCaseCreatedMsg1.getText().split("Case Number: ")[1];
		System.out.println("Created Case ID : "+CaseID);
		ExtentUtility.getTest().log(LogStatus.PASS, "Created Case ID: "+CaseID,
				ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
	}
	
	public void verifyDynamicErrorMsg(String msg)throws Exception{
		
		System.out.println(remoteDriver.findElements(By.xpath("//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText']")).size());
		int j =remoteDriver.findElements(By.xpath("//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText']")).size();
		String displayedMsg=null ;
		boolean flag=false;
		for(int i=1;i<=j;i++){
			if(remoteDriver.findElement(By.xpath("//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText']["+i+"]")).getText().equals(msg)){
				displayedMsg = remoteDriver.findElement(By.xpath("//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText']["+i+"]")).getText();
				ExtentUtility.getTest().log(LogStatus.PASS, displayedMsg+" message is displayed successfully",
						ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				flag=true;
				break;
			}
		}
		if(flag==false){
				ExtentUtility.getTest().log(LogStatus.FAIL, msg+"message is not disaplyed successfully",
						ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
		}
	public void clickOnButton(String btnName)throws Exception{
		
		System.out.println(remoteDriver.findElements(By.xpath("//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')]")).size());
		int j =remoteDriver.findElements(By.xpath("//ul[@class='messageWrapper']/descendant::div[@class='uiOutputRichText']")).size();
		String buttonname=null ;
		boolean flag=false;
		for(int i=1;i<=j;i++){
			if(remoteDriver.findElement(By.xpath("//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')]["+i+"]")).getText().equals(btnName)){
				buttonname=remoteDriver.findElement(By.xpath("//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')]["+i+"]")).getText();
				remoteDriver.findElement(By.xpath("//ul[@class='messageWrapper']/descendant::span[contains(@class,' label bBody')]["+i+"]")).click();
				Thread.sleep(7000);
				ExtentUtility.getTest().log(LogStatus.PASS, buttonname+" button is clicked successfully",
						ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
				flag=true;
				break;
			}
		}
		if(flag==false){
				ExtentUtility.getTest().log(LogStatus.FAIL, buttonname+"button is not clicked successfully",
						ExtentUtility.getTest().addScreenCapture(takeScreenShot()));
			}
		}





















}