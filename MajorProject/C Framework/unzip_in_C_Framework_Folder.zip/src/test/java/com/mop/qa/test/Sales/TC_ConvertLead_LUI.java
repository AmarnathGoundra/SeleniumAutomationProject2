package com.mop.qa.test.Sales; 
 
 
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.testbase.TestBase; 
import SOURCE_CODE.SFDC.DB; 
import USER_SPACE.BusinessComponent.BC; 
import SOURCE_CODE.SFDC.SFDCAutomationFW; 
import USER_SPACE.TestPrerequisite.DataSetup;
import USER_SPACE.ObjectRepository.AllAppsTabsScreen_LUI;
import USER_SPACE.ObjectRepository.ContactsScreen_LUI;
import USER_SPACE.ObjectRepository.LeadScreen;
import USER_SPACE.ObjectRepository.LeadsScreen_LUI; 

/* 
* 
* @Author: <Name of Test Script Creator> 
* @Description: <Please mention the scope of this test script> 
* @General Guidelines: Every Test Script must begin from Launching 
* URL of login screen and must end with browser closed 
*/ 

public class TC_ConvertLead_LUI extends TestBase { 

	/*
	@DataProvider(name = "TestUserList")	 
	  public static Object[][] LoginUsers()
	 {
	 	        return new Object[][] { 
	 	        						{ "TestUser1" },
	 	        						{ "TestUser3" }	 	        						
	 	        					  };	 
	  }
	
	*/
	
//@Test(dataProvider="TestUserList")
//public void createMyTest(String TestUserName) { 
@Test	
public void createMyTest() { 

	SFDCAutomationFW sfdc = null; 
	LeadsScreen_LUI leadScreen = null; 
	ContactsScreen_LUI contactScreen = null;
	AllAppsTabsScreen_LUI allTAppsObjectsScreen = null;
	String TC_CreateLead_LUI = "TC_CreateLead_LUI";

	String TCName = "TC_ConvertLead_LUI"; 
	if (toolName.equalsIgnoreCase("Selenium"))
	{ 
		System.out.println("----------------->Inside Test Case");
		sfdc = new SFDCAutomationFW(remoteDriver, TCName);
		System.out.println("----------->Back to Test case");
		leadScreen = new LeadsScreen_LUI(remoteDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(remoteDriver);
		contactScreen = new ContactsScreen_LUI(remoteDriver);
	}
	else if (toolName.equalsIgnoreCase("Appium"))
	{
		sfdc = new SFDCAutomationFW(appiumDriver, TCName);
		leadScreen = new LeadsScreen_LUI(appiumDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(appiumDriver);
		contactScreen = new ContactsScreen_LUI(appiumDriver);
	}
	
	DB DB = new DB();
	BC BC = new BC(remoteDriver);
	DataSetup DataSetup = new DataSetup();

	System.out.println("-----------Begin of TestScript-------------");

	try{ 
			 
		String TestUserName = "TestUser1"; 
		DB.Connect(DataSetup.TestData);
			
		//Reading the test data from external test data sheet
		String NAME = DB.ReadXLData("CreateLead", "NAME", "TESTCASENAME", "TC_CreateLead_LUI");
		
		String uniqno = BC.GetCurrentDateTimeStamp();
				
		// Login to SFDC 
		sfdc.LoginToSFDC(TestUserName); 
				
		//sfdc.SelectApplication_LUI("Sales");
		
		Thread.sleep(5000L);
		
		
		allTAppsObjectsScreen.LeadsTab().Click();
		
		sfdc.GlobalSearch_LUI("Leads", NAME);
		
		Thread.sleep(5000L);
		
		sfdc.ClickONSubTab("Details");
		
		Thread.sleep(5000L);
		
		leadScreen.MenuButtonConvertButton().MenuButtonClick();
		
		Thread.sleep(5000L);
		
		leadScreen.ConvertButton().ClickFooterDialog();
		
		leadScreen.GotoLeadsButton().ClickButton_ConfirmationDialog();
				
		DB.Connect(DataSetup.TestData);		
		
		//Update excel with full name
		DB.UpdateXLCell("CreateLead", NAME, "CONTACT_NAME", "TESTCASENAME", TC_CreateLead_LUI);
		
				
		allTAppsObjectsScreen.ContactsTab().Click();
		
		Thread.sleep(4000L);
				
		sfdc.GlobalSearch_LUI("Contacts", NAME); //Since contact name = Lead name 
		
		Thread.sleep(4000L);
		
		//sfdc.ClickONSubTab("Related");
		
		Thread.sleep(2000L);
		
		
		contactScreen.RL_Opportunities().RelatedListLink().Click();
	
		contactScreen.RL_Opportunities().OpportunityName().Click(1);
	
		sfdc.LogOff();
		
	} 
	catch (Exception e) { 
		e.printStackTrace(); 
		System.out.println("Exception(Exception) in main"); 
	}
	finally { 
		System.out.println("-----------End of TestScript-------------"); 
	} 
	} 
} 
