package com.mop.qa.pageobject;

public class HomePageLayout {

	public static String Home_Menus_XP = "//div[contains(@class,'slds-no-print')][1]";
	public static String Home_VIEWPORT_XP = "//div[@class='viewport'][1]";
	public static String Home_RECENT_RECORD_SECTION = "//div[contains(@class,'tree_container')][1]";	
	public static String ACC_RECORD_DETAIL_VIEW = "//div[@class='record-body-container'][1]";
			
}
