package com.mop.qa.test.API;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.mop.qa.Utilities.ExtentUtility;
import com.mop.qa.Utilities.ReadDataSheet;
import com.mop.qa.testbase.ServiceBase;
import com.mop.qa.testbase.TestBase;
import com.relevantcodes.extentreports.LogStatus;

import io.restassured.response.Response;

public class Account_Creation_Validation extends TestBase{
	
		@Test
		public void Account_Creation_Validation() throws Exception {
			try {
			//AccountAPI accountAPI = new AccountAPI();			
			ServiceBase restService = new ServiceBase();	
			ReadDataSheet readData = new ReadDataSheet();			
			Map<String, String> bodyParameters = new HashMap<>();
			Map<String, String> queryParams = new HashMap<>();
			System.out.println("currentTest:"+currentTest);
			String objName = readData.getValue("DATA", currentTest, "ObjectName");;
			String requestFilePath = requestFolder + "Request_" + ExtentUtility.timeStamp + "_" + currentTest + ".json";
			String responseFilePath = responseFolder + "Response_" + ExtentUtility.timeStamp + "_" + currentTest + ".json";
												
			//Fetching Data from Datasheet
			bodyParameters = restService.getBodyParameters(currentTest); 			
			System.out.println("bodyParameters:"+bodyParameters);
			//Functional API Call for Account Creation			
			Response response = restService.createSalesforceObject(objName, bodyParameters, requestFilePath, responseFilePath );
			System.out.println("response:"+response.toString());			
			//Response File p/arse 
			String files = restService.getJsonFile(responseFilePath);
			DocumentContext documentContext = JsonPath.parse(files);
			
			//Basic Assertions for the API response 
			String responseTime = getPropertyValue("responseTime");
			restService.basicAssertions(response, Integer.parseInt(responseTime));
						
			//Tester-Defined Assertions for the API response 
			restService.validateResponse(documentContext, currentTest, response);	
			}
			catch(Exception e)
			{
			e.printStackTrace();
			ExtentUtility.getTest().log(LogStatus.FAIL, " Test Case Failed");
			}
			finally
			{
				System.out.println("Test Case is Ended");
			}					
		}

	}
