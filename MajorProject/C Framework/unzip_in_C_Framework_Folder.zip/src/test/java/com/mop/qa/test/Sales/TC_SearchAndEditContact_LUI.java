package com.mop.qa.test.Sales; 
 
 
import org.testng.annotations.Test; 
import com.mop.qa.testbase.TestBase; 
import SOURCE_CODE.SFDC.DB; 
import USER_SPACE.BusinessComponent.BC; 
import SOURCE_CODE.SFDC.SFDCAutomationFW; 
import USER_SPACE.TestPrerequisite.DataSetup;
import USER_SPACE.ObjectRepository.AllAppsTabsScreen_LUI;
import USER_SPACE.ObjectRepository.ContactScreen_LUI;
import USER_SPACE.ObjectRepository.LeadScreen;
import USER_SPACE.ObjectRepository.LeadsScreen_LUI; 

/* 
* 
* @Author: <Name of Test Script Creator> 
* @Description: <Please mention the scope of this test script> 
* @General Guidelines: Every Test Script must begin from Launching 
* URL of login screen and must end with browser closed 
*/ 

public class TC_SearchAndEditContact_LUI extends TestBase { 

@Test 
public void createMyTest() { 

	SFDCAutomationFW sfdc = null; 
	ContactScreen_LUI contactsScreen = null; 
	AllAppsTabsScreen_LUI allTAppsObjectsScreen = null;
	String TC_SearchAndEditContact_LUI_2020 = "TC_SearchAndEditContact_LUI";

	String TCName = "TC_SearchAndEditContact_LUI"; 
	if (toolName.equalsIgnoreCase("Selenium"))
	{ 
		sfdc = new SFDCAutomationFW(remoteDriver, TCName);
		contactsScreen = new ContactScreen_LUI(remoteDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(remoteDriver);
	}
	else if (toolName.equalsIgnoreCase("Appium"))
	{
		sfdc = new SFDCAutomationFW(appiumDriver, TCName);
		contactsScreen = new ContactScreen_LUI(appiumDriver); 
		allTAppsObjectsScreen = new AllAppsTabsScreen_LUI(appiumDriver);
	}
	
	DB DB = new DB();
	BC BC = new BC(remoteDriver);
	DataSetup DataSetup = new DataSetup();

	System.out.println("-----------Begin of TestScript-------------");

	try { 
	
		String TestUserName = "TestUser1"; 
		DB.Connect(DataSetup.TestData);
			
		//Reading the test data from external test data sheet
		String NAME = DB.ReadXLData("CreateContact", "CONTACT_NAME", "TESTCASENAME", "TC_CreateContact_LUI");
		
		String uniqno = BC.GetCurrentDateTimeStamp();
				
		// Login to SFDC 
		sfdc.LoginToSFDC(TestUserName); 
				
		sfdc.SelectApplication_LUI("Sales");
		
		allTAppsObjectsScreen.ContactsTab().Click();
		
		sfdc.GlobalSearch_LUI("Contacts", NAME);
		
		Thread.sleep(5000L);
		
		sfdc.ClickONSubTab("Details");
		
		Thread.sleep(2000L);
		contactsScreen.MenuButtonEditButton().MenuButtonClick();	
		
		Thread.sleep(2000L);
		
		contactsScreen.LeadSourceField().SelectPL("Web");
		
		contactsScreen.SaveButton().Click();
		
		Thread.sleep(5000L);
		
		sfdc.ClickONSubTab("Details");
		
		contactsScreen.LeadSourceField().VerifyViewOnlyValueEquals("Web");
		
		
		sfdc.LogOff();
		
		sfdc.Quit();
		
			
	} 
	catch (Exception e) { 
		e.printStackTrace(); 
		System.out.println("Exception(Exception) in main"); 
	}
	finally { 
		System.out.println("-----------End of TestScript-------------"); 
	} 
	} 
} 
