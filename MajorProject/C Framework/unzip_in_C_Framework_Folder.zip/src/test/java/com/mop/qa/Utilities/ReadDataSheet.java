package com.mop.qa.Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.testng.TestListenerAdapter;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

public class ReadDataSheet {
	public WebDriver dr;
	public HSSFWorkbook wb;
	public HSSFSheet ws;
	public int rowCount;
	public String className;
	public String sheetName;
	public String colName;
	public String value;

	List<TestParameter> list;

	public int getRownumber(String testCaseName, String colHeader) throws MPException {
		int rownumber = 0;
		rowCount = ws.getLastRowNum();

		for (int j = 1; j <= rowCount; j++) {
			HSSFRow row = ws.getRow(j);
			if (row.getCell(0).getStringCellValue().equalsIgnoreCase(testCaseName)) {
				rownumber = j;
				break;
			}

		}
		if (rownumber == 0) {
			throw new MPException("Class Entry missing in DataSheet");
		}

		getColumnNumber(colHeader);
		return rownumber;
	}

	public int getColumnNumber(String columnHeader) throws MPException {
		HSSFRow row = ws.getRow(0);
		int columnNumber = 0;
		int isValid = 0;
		for (int j = ws.getFirstRowNum(); j < row.getPhysicalNumberOfCells(); j++) {
			if (row.getCell(j).toString().equalsIgnoreCase(columnHeader)) {
				columnNumber = j;
				isValid = 1;
				break;
			}

		}
		if (isValid == 0) {
			throw new MPException("Enter proper column in DataSheet");
		}
		// System.out.println("column number is " + columnNumber);
		return columnNumber;

	}

	public String getValue(String SheetName, String className, String columnHeader) throws MPException {

		try {
			FileInputStream file = new FileInputStream(new File("./DataSheet.xls"));

			wb = new HSSFWorkbook(file);

			ws = wb.getSheet(SheetName);
			int rownumber = getRownumber(className, columnHeader);
			int columnNumber = getColumnNumber(columnHeader);
			HSSFCell cell = ws.getRow(rownumber).getCell(columnNumber);
			if (cell != null) {
				value = cell.toString();
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;

	}
	
	public synchronized void setCellValue(String workbookPath, String sheetName, String columnName, String value)	{
		synchronized (this) {
			
			try {
				
				FileInputStream inputStream = new FileInputStream(new File(workbookPath));

				XSSFWorkbook wb = new XSSFWorkbook(inputStream);
				XSSFSheet ws = wb.getSheet(sheetName);
				
				int lastRow = ws.getLastRowNum();
				int columnNumber = 0;
				
				XSSFRow row = ws.getRow(0);
				for (int j = ws.getFirstRowNum(); j < row.getPhysicalNumberOfCells(); j++) {
					if (row.getCell(j).toString().equalsIgnoreCase(columnName)) {
						columnNumber = j;
						break;
					}

				}
				
				System.out.println("lastRow--" + lastRow  + " columnNumber--" + columnNumber);
				Cell cell = null;
				int i = 1;
				for(i = 1; i <= lastRow; i++)	{
					
					cell = ws.getRow(i).getCell(columnNumber);
					System.out.println(cell.getStringCellValue());
					if(cell != null)	{
						if(cell.getStringCellValue().equals(value))	{
							System.out.println("Cell value present");
							return;
						}
					}
					
				}
				System.out.println("Cell value not present. Creating new Row with value -" + value);
				
				XSSFRow row1 = ws.createRow(i);
				XSSFCell r1c1 = row1.createCell(columnNumber);
				r1c1.setCellValue(value);
//				cell = ws.createRow(i).createCell(columnNumber);
//				System.out.println(cell.getRowIndex() + " " + cell.getColumnIndex());
//				cell.setCellValue(value);
				
				inputStream.close();
				
				FileOutputStream outputStream = new FileOutputStream(new File(workbookPath));
				wb.write(outputStream);
				outputStream.close();
				
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e.getMessage());
			}
			
		}
	}
	
	public String getSetUpValue(String SheetName, String className, String columnHeader) throws MPException {

		try {
			FileInputStream file = new FileInputStream(new File("./TestRunner.xls"));

			wb = new HSSFWorkbook(file);

			ws = wb.getSheet(SheetName);

			int rownumber = getRownumber(className, columnHeader);
			int columnNumber = getColumnNumber(columnHeader);
			HSSFCell cell = ws.getRow(rownumber).getCell(columnNumber);
			if (cell != null) {
				value = cell.toString();
			}
			// List<> testName = new ArrayList<>();

			for (int i = 2; i <= 3; i++) {
				for (int j = 1; j <= 3; j++) {
					HSSFCell cell1 = ws.getRow(i).getCell(j);
				}
			}

			// System.out.println("value is " + value);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;

	}
	public String getAppProperties(String key) throws IOException {
		String value = "";
		try {

			FileInputStream fileInputStream = new FileInputStream("data.properties");
			Properties property = new Properties();
			property.load(fileInputStream);

			value = property.getProperty(key);

			fileInputStream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;

	}

	private String getCellValueAsString(HSSFCell cell, FormulaEvaluator formulaEvaluator) {
		if ((cell == null) || (cell.getCellType() == 3)) {
			return "";
		}
		if (formulaEvaluator.evaluate(cell).getCellType() == 5) {
			// throw new FrameworkException("Error in formula within this cell!
			// Error code: " +
			// cell.getErrorCellValue());
		}
		DataFormatter dataFormatter = new DataFormatter();
		return dataFormatter.formatCellValue(formulaEvaluator.evaluateInCell(cell));
	}

	public String getNumericValue(String SheetName, String className,
            String columnHeader) throws MPException {
        
        try {
            FileInputStream file = new FileInputStream(new File("./DataSheet.xls"));
            
            wb = new HSSFWorkbook(file);

            ws = wb.getSheet(SheetName);
            int rownumber = getRownumber(className, columnHeader);
            int columnNumber = getColumnNumber(columnHeader);
            HSSFCell cell = ws.getRow(rownumber).getCell(columnNumber);
            if(cell != null){
                Long i = (long) cell.getNumericCellValue();
                value = i.toString();
            }
            
        } 
        catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return value;

    }


}
