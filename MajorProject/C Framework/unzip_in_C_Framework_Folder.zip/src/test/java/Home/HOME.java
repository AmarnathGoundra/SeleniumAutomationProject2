package Home;

import SOURCE_CODE.SFDC.GUIFORFRAMEWORK;

public class HOME {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		new GUIFORFRAMEWORK(); 
		}catch(Exception e)
		{e.printStackTrace();}
	}

}