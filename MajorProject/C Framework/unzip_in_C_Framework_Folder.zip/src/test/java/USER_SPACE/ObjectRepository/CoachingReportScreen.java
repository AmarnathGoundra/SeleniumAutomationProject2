package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class CoachingReportScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public CoachingReportScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public CoachingReportScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


public MemberOfTab AccountsTab() throws Exception{ 
	return sfdc.Tab("Accounts"); 
} 
public MemberOfTab LeadsTab() throws Exception{ 
	return sfdc.Tab("Leads"); 
} 
public MemberOfTab AccountTerritoryLoadersTab() throws Exception{ 
	return sfdc.Tab("Account Territory Loaders"); 
} 
public MemberOfTab ListEmailsTab() throws Exception{ 
	return sfdc.Tab("List Emails"); 
} 
public MemberOfTab AlertsTab() throws Exception{ 
	return sfdc.Tab("Alerts"); 
} 
public MemberOfTab LookupQualificationTab() throws Exception{ 
	return sfdc.Tab("Lookup Qualification"); 
} 
public MemberOfTab AlignmentHistoriesTab() throws Exception{ 
	return sfdc.Tab("Alignment Histories"); 
} 
public MemberOfTab LookupTableTab() throws Exception{ 
	return sfdc.Tab("Lookup Table"); 
} 
public MemberOfTab AnalyticsDataChannelsTab() throws Exception{ 
	return sfdc.Tab("Analytics Data Channels"); 
} 
public MemberOfTab LookupTableRoleTab() throws Exception{ 
	return sfdc.Tab("Lookup Table Role"); 
} 
public MemberOfTab AnalyticsProductGroupsTab() throws Exception{ 
	return sfdc.Tab("Analytics Product Groups"); 
} 
public MemberOfTab LookupTableTypeTab() throws Exception{ 
	return sfdc.Tab("Lookup Table Type"); 
} 
public MemberOfTab AppLauncherTab() throws Exception{ 
	return sfdc.Tab("App Launcher"); 
} 
public MemberOfTab LotCatalogTab() throws Exception{ 
	return sfdc.Tab("Lot Catalog"); 
} 
public MemberOfTab ApplicationLabelsTab() throws Exception{ 
	return sfdc.Tab("Application Labels"); 
} 
public MemberOfTab MacrosTab() throws Exception{ 
	return sfdc.Tab("Macros"); 
} 
public MemberOfTab ApprovedDocumentsTab() throws Exception{ 
	return sfdc.Tab("Approved Documents"); 
} 
public MemberOfTab MaterialOrdersTab() throws Exception{ 
	return sfdc.Tab("Material Orders"); 
} 
public MemberOfTab ApprovedEmailAdministrationTab() throws Exception{ 
	return sfdc.Tab("Approved Email Administration"); 
} 
public MemberOfTab MCCPAdminTab() throws Exception{ 
	return sfdc.Tab("MCCP Admin"); 
} 
public MemberOfTab ApprovedEmailConfigurationCheckerTab() throws Exception{ 
	return sfdc.Tab("Approved Email Configuration Checker"); 
} 
public MemberOfTab MCCyclePlansTab() throws Exception{ 
	return sfdc.Tab("MC Cycle Plans"); 
} 
public MemberOfTab ApprovedEmailLicenseManagementTab() throws Exception{ 
	return sfdc.Tab("Approved Email License Management"); 
} 
public MemberOfTab MCCyclesTab() throws Exception{ 
	return sfdc.Tab("MC Cycles"); 
} 
public MemberOfTab AssetsTab() throws Exception{ 
	return sfdc.Tab("Assets"); 
} 
public MemberOfTab MedicalEventsTab() throws Exception{ 
	return sfdc.Tab("Medical Events"); 
} 
public MemberOfTab AttendeesTab() throws Exception{ 
	return sfdc.Tab("Attendees"); 
} 
public MemberOfTab MedicalInquiryFulfillmentTab() throws Exception{ 
	return sfdc.Tab("Medical Inquiry Fulfillment"); 
} 
public MemberOfTab BenefitDesignLinesTab() throws Exception{ 
	return sfdc.Tab("Benefit Design Lines"); 
} 
public MemberOfTab MedicalInquiryFulfillmentResponsesTab() throws Exception{ 
	return sfdc.Tab("Medical Inquiry Fulfillment Responses"); 
} 
public MemberOfTab BenefitDesignsTab() throws Exception{ 
	return sfdc.Tab("Benefit Designs"); 
} 
public MemberOfTab MetadataCacheManagerTab() throws Exception{ 
	return sfdc.Tab("Metadata Cache Manager"); 
} 
public MemberOfTab BusinessEventsTab() throws Exception{ 
	return sfdc.Tab("Business Events"); 
} 
public MemberOfTab MetricConfigurationsTab() throws Exception{ 
	return sfdc.Tab("Metric Configurations"); 
} 
public MemberOfTab CallClickstreamsTab() throws Exception{ 
	return sfdc.Tab("Call Clickstreams"); 
} 
public MemberOfTab MSDSettingsTab() throws Exception{ 
	return sfdc.Tab("MSD Settings"); 
} 
public MemberOfTab CallErrorsTab() throws Exception{ 
	return sfdc.Tab("Call Errors"); 
} 
public MemberOfTab MultichannelActivitiesTab() throws Exception{ 
	return sfdc.Tab("Multichannel Activities"); 
} 
public MemberOfTab CallExpensesTab() throws Exception{ 
	return sfdc.Tab("Call Expenses"); 
} 
public MemberOfTab MultichannelConsentAdministrationTab() throws Exception{ 
	return sfdc.Tab("Multichannel Consent Administration"); 
} 
public MemberOfTab CallFollowupTemplatesTab() throws Exception{ 
	return sfdc.Tab("Call Followup Templates"); 
} 
public MemberOfTab MultichannelContentTab() throws Exception{ 
	return sfdc.Tab("Multichannel Content"); 
} 
public MemberOfTab CallsTab() throws Exception{ 
	return sfdc.Tab("Calls"); 
} 
public MemberOfTab MyAccountsTab() throws Exception{ 
	return sfdc.Tab("My Accounts"); 
} 
public MemberOfTab CallSamplesTab() throws Exception{ 
	return sfdc.Tab("Call Samples"); 
} 
public MemberOfTab MySamplesTab() throws Exception{ 
	return sfdc.Tab("My Samples"); 
} 
public MemberOfTab CampaignsTab() throws Exception{ 
	return sfdc.Tab("Campaigns"); 
} 
public MemberOfTab TellmemoreTab() throws Exception{ 
	return sfdc.Tab("Tell me more!"); 
} 
public MemberOfTab MyScheduleTab() throws Exception{ 
	return sfdc.Tab("My Schedule"); 
} 
public MemberOfTab CasesTab() throws Exception{ 
	return sfdc.Tab("Cases"); 
} 
public MemberOfTab MySetupTab() throws Exception{ 
	return sfdc.Tab("My Setup"); 
} 
public MemberOfTab ClearVeevaCacheTab() throws Exception{ 
	return sfdc.Tab("Clear Veeva Cache"); 
} 
public MemberOfTab MySetupProductsTab() throws Exception{ 
	return sfdc.Tab("My Setup Products"); 
} 
public MemberOfTab ClinicalTrialsTab() throws Exception{ 
	return sfdc.Tab("Clinical Trials"); 
} 
public MemberOfTab NetworkAdministrationTab() throws Exception{ 
	return sfdc.Tab("Network Administration"); 
} 
public MemberOfTab CLMAdministrationTab() throws Exception{ 
	return sfdc.Tab("CLM Administration"); 
} 
public MemberOfTab OpportunitiesTab() throws Exception{ 
	return sfdc.Tab("Opportunities"); 
} 
public MemberOfTab CLMPresentationsTab() throws Exception{ 
	return sfdc.Tab("CLM Presentations"); 
} 
public MemberOfTab OrderCampaignsTab() throws Exception{ 
	return sfdc.Tab("Order Campaigns"); 
} 
public MemberOfTab CoachingReportsTab() throws Exception{ 
	return sfdc.Tab("Coaching Reports"); 
} 
public MemberOfTab OrdersTab() throws Exception{ 
	return sfdc.Tab("Orders"); 
} 
public MemberOfTab CommonKPITab() throws Exception{ 
	return sfdc.Tab("Common KPI"); 
} 
public MemberOfTab PreferencesTab() throws Exception{ 
	return sfdc.Tab("Preferences"); 
} 
public MemberOfTab ConsentHeadersTab() throws Exception{ 
	return sfdc.Tab("Consent Headers"); 
} 
public MemberOfTab PriceBooksTab() throws Exception{ 
	return sfdc.Tab("Price Books"); 
} 
public MemberOfTab ConsentLinesTab() throws Exception{ 
	return sfdc.Tab("Consent Lines"); 
} 
public MemberOfTab PricingRulesTab() throws Exception{ 
	return sfdc.Tab("Pricing Rules"); 
} 
public MemberOfTab ConsentTypesTab() throws Exception{ 
	return sfdc.Tab("Consent Types"); 
} 
public MemberOfTab ProductCatalogTab() throws Exception{ 
	return sfdc.Tab("Product Catalog"); 
} 
public MemberOfTab ConsoleTab() throws Exception{ 
	return sfdc.Tab("Console"); 
} 
public MemberOfTab ProductGroupsTab() throws Exception{ 
	return sfdc.Tab("Product Groups"); 
} 
public MemberOfTab ContactRequestsTab() throws Exception{ 
	return sfdc.Tab("Contact Requests"); 
} 
public MemberOfTab ProductMetricsTab() throws Exception{ 
	return sfdc.Tab("Product Metrics"); 
} 
public MemberOfTab ContactsTab() throws Exception{ 
	return sfdc.Tab("Contacts"); 
} 
public MemberOfTab ProductOrderAllocationTab() throws Exception{ 
	return sfdc.Tab("Product Order Allocation"); 
} 
public MemberOfTab ContractsTab() throws Exception{ 
	return sfdc.Tab("Contracts"); 
} 
public MemberOfTab ProductPlansTab() throws Exception{ 
	return sfdc.Tab("Product Plans"); 
} 
public MemberOfTab ProductsTab() throws Exception{ 
	return sfdc.Tab("Products"); 
} 
public MemberOfTab CountriesTab() throws Exception{ 
	return sfdc.Tab("Countries"); 
} 
public MemberOfTab PublicationsTab() throws Exception{ 
	return sfdc.Tab("Publications"); 
} 
public MemberOfTab DashboardsTab() throws Exception{ 
	return sfdc.Tab("Dashboards"); 
} 
public MemberOfTab ReportsTab() throws Exception{ 
	return sfdc.Tab("Reports"); 
} 
public MemberOfTab DataChangeRequestLinesTab() throws Exception{ 
	return sfdc.Tab("Data Change Request Lines"); 
} 
public MemberOfTab RepRosterTab() throws Exception{ 
	return sfdc.Tab("Rep Roster"); 
} 
public MemberOfTab DataChangeRequestsTab() throws Exception{ 
	return sfdc.Tab("Data Change Requests"); 
} 
public MemberOfTab SalesTeamsTab() throws Exception{ 
	return sfdc.Tab("Sales Teams"); 
} 
public MemberOfTab DataMapTemplatesTab() throws Exception{ 
	return sfdc.Tab("Data Map Templates"); 
} 
public MemberOfTab SampleInventoriesTab() throws Exception{ 
	return sfdc.Tab("Sample Inventories"); 
} 
public MemberOfTab DCRFieldTypesTab() throws Exception{ 
	return sfdc.Tab("DCR Field Types"); 
} 
public MemberOfTab SampleLimitsTab() throws Exception{ 
	return sfdc.Tab("Sample Limits"); 
} 
public MemberOfTab DCRFORAPPROVALTab() throws Exception{ 
	return sfdc.Tab("DCR FOR APPROVAL"); 
} 
public MemberOfTab SampleLotsTab() throws Exception{ 
	return sfdc.Tab("Sample Lots"); 
} 
public MemberOfTab DirectoriesTab() throws Exception{ 
	return sfdc.Tab("Directories"); 
} 
public MemberOfTab SampleOrderTransactionTab() throws Exception{ 
	return sfdc.Tab("Sample Order Transaction"); 
} 
public MemberOfTab DocumentsTab() throws Exception{ 
	return sfdc.Tab("Documents"); 
} 
public MemberOfTab SampleTransactionsTab() throws Exception{ 
	return sfdc.Tab("Sample Transactions"); 
} 
public MemberOfTab DuplicateRecordSetsTab() throws Exception{ 
	return sfdc.Tab("Duplicate Record Sets"); 
} 
public MemberOfTab ScorecardsTab() throws Exception{ 
	return sfdc.Tab("Scorecards"); 
} 
public MemberOfTab EMEventSummariesTab() throws Exception{ 
	return sfdc.Tab("EM Event Summaries"); 
} 
public MemberOfTab SignaturePagesTab() throws Exception{ 
	return sfdc.Tab("Signature Pages"); 
} 
public MemberOfTab EMEventSummaryErrorsTab() throws Exception{ 
	return sfdc.Tab("EM Event Summary Errors"); 
} 
public MemberOfTab SignupRequestsTab() throws Exception{ 
	return sfdc.Tab("Signup Requests"); 
} 
public MemberOfTab EngageContentAdministrationTab() throws Exception{ 
	return sfdc.Tab("Engage Content Administration"); 
} 
public MemberOfTab SocialPersonasTab() throws Exception{ 
	return sfdc.Tab("Social Personas"); 
} 
public MemberOfTab EngageMeetingProcessAdministrationTab() throws Exception{ 
	return sfdc.Tab("Engage Meeting Process Administration"); 
} 
public MemberOfTab SocialPostsTab() throws Exception{ 
	return sfdc.Tab("Social Posts"); 
} 
public MemberOfTab EngageMeetingsAdministrationTab() throws Exception{ 
	return sfdc.Tab("Engage Meetings Administration"); 
} 
public MemberOfTab SolutionsTab() throws Exception{ 
	return sfdc.Tab("Solutions"); 
} 
public MemberOfTab EngageMetadataAdministrationTab() throws Exception{ 
	return sfdc.Tab("Engage Metadata Administration"); 
} 
public MemberOfTab SpeakerEvaluationsTab() throws Exception{ 
	return sfdc.Tab("Speaker Evaluations"); 
} 
public MemberOfTab FilesTab() throws Exception{ 
	return sfdc.Tab("Files"); 
} 
public MemberOfTab StreamingChannelsTab() throws Exception{ 
	return sfdc.Tab("Streaming Channels"); 
} 
public MemberOfTab ForecastsTab() throws Exception{ 
	return sfdc.Tab("Forecasts"); 
} 
public MemberOfTab SynchronizationTrackingsTab() throws Exception{ 
	return sfdc.Tab("Synchronization Trackings"); 
} 
public MemberOfTab GASCriteriaBasedFiltersTab() throws Exception{ 
	return sfdc.Tab("GAS Criteria-Based Filters"); 
} 
public MemberOfTab TerritoryBudgetsTab() throws Exception{ 
	return sfdc.Tab("Territory Budgets"); 
} 
public MemberOfTab GlobalAccountSearchTab() throws Exception{ 
	return sfdc.Tab("Global Account Search"); 
} 
public MemberOfTab TerritoryFieldsTab() throws Exception{ 
	return sfdc.Tab("Territory Fields"); 
} 
public MemberOfTab HomeTab() throws Exception{ 
	return sfdc.Tab("Home"); 
} 
public MemberOfTab TerritoryUtilitiesTab() throws Exception{ 
	return sfdc.Tab("Territory Utilities"); 
} 
public MemberOfTab HTMLReportsTab() throws Exception{ 
	return sfdc.Tab("HTML Reports"); 
} 
public MemberOfTab TimeOffTerritoryTab() throws Exception{ 
	return sfdc.Tab("Time Off Territory"); 
} 
public MemberOfTab IdeasTab() throws Exception{ 
	return sfdc.Tab("Ideas"); 
} 
public MemberOfTab UnsubscribesTab() throws Exception{ 
	return sfdc.Tab("Unsubscribes"); 
} 
public MemberOfTab InitiativesTab() throws Exception{ 
	return sfdc.Tab("Initiatives"); 
} 
public MemberOfTab UserProvisioningRequestsTab() throws Exception{ 
	return sfdc.Tab("User Provisioning Requests"); 
} 
public MemberOfTab InsightsTab() throws Exception{ 
	return sfdc.Tab("Insights"); 
} 
public MemberOfTab ValidationRuleAdminTab() throws Exception{ 
	return sfdc.Tab("Validation Rule Admin"); 
} 
public MemberOfTab InsightsAdminTab() throws Exception{ 
	return sfdc.Tab("Insights Admin"); 
} 
public MemberOfTab VeevaMessagesTab() throws Exception{ 
	return sfdc.Tab("Veeva Messages"); 
} 
public MemberOfTab InventoryOrderAllocationsTab() throws Exception{ 
	return sfdc.Tab("Inventory Order Allocations"); 
} 
public MemberOfTab VeevaProcessSchedulerTab() throws Exception{ 
	return sfdc.Tab("Veeva Process Scheduler"); 
} 
public MemberOfTab InventoryOrderLinesTab() throws Exception{ 
	return sfdc.Tab("Inventory Order Lines"); 
} 
public MemberOfTab VMobileHomePageLayoutsTab() throws Exception{ 
	return sfdc.Tab("VMobile Home Page Layouts"); 
} 
public MemberOfTab InventoryOrdersTab() throws Exception{ 
	return sfdc.Tab("Inventory Orders"); 
} 
public MemberOfTab VMobileObjectConfigurationsTab() throws Exception{ 
	return sfdc.Tab("VMobile Object Configurations"); 
} 
public MemberOfTab KeyMedicalInsightTab() throws Exception{ 
	return sfdc.Tab("Key Medical Insight"); 
} 
public MemberOfTab ZiptoTerrsTab() throws Exception{ 
	return sfdc.Tab("Zip to Terrs"); 
} 
public MemberOfTab KeyMessagesTab() throws Exception{ 
	return sfdc.Tab("Key Messages"); 
} 
//************************* Functions for List Views***************************** // 
 


 public Columns_ListView ListView() throws Exception{ 
return new Columns_ListView(); 
} 
public class Columns_ListView{ 
public MemberOfLV Action(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Action",RowIndex); 
}
public MemberOfLV Action() throws Exception 
{ 
return sfdc.LV("Action"); 
}

public MemberOfLV CoachingReportName(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Coaching Report Name",RowIndex); 
}
public MemberOfLV CoachingReportName() throws Exception 
{ 
return sfdc.LV("Coaching Report Name"); 
}

}

//************************* Functions for Buttons***************************** // 
 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton NewCoachingReportButton() throws Exception{ 
return sfdc.Button("New Coaching Report"); 
} 
public MemberOfButton ChangeOwnerButton() throws Exception{ 
return sfdc.Button("Change Owner"); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton CancelButton() throws Exception{ 
return sfdc.Button("Cancel"); 
} 
public MemberOfButton EditButton() throws Exception{ 
return sfdc.Button("Edit"); 
} 
public MemberOfButton DeleteButton() throws Exception{ 
return sfdc.Button("Delete"); 
} 
public MemberOfButton CloneButton() throws Exception{ 
return sfdc.Button("Clone"); 
} 
public MemberOfButton SharingButton() throws Exception{ 
return sfdc.Button("Sharing"); 
} 
public MemberOfButton OKButton() throws Exception{ 
return sfdc.Button("OK"); 
} 
public MemberOfButton SaveNewButton() throws Exception{ 
return sfdc.Button("Save & New"); 
} 

//************************* Functions for Field Names ***************************** // 
 
public MemberOfField CoachingReportNameField() throws Exception{ 
	return sfdc.Field("Coaching Report Name"); 
} 
public MemberOfField ReviewDateField() throws Exception{ 
	return sfdc.Field("Review Date"); 
} 
public MemberOfField ManagerField() throws Exception{ 
	return sfdc.Field("Manager"); 
} 
public MemberOfField ReviewPeriodField() throws Exception{ 
	return sfdc.Field("Review Period"); 
} 
public MemberOfField EmployeeField() throws Exception{ 
	return sfdc.Field("Employee"); 
} 
public MemberOfField StatusField() throws Exception{ 
	return sfdc.Field("Status"); 
} 
public MemberOfField OverallRatingField() throws Exception{ 
	return sfdc.Field("Overall Rating"); 
} 
public MemberOfField CommentsField() throws Exception{ 
	return sfdc.Field("Comments"); 
} 
public MemberOfField StrategicPlanningField() throws Exception{ 
	return sfdc.Field("Strategic Planning"); 
} 
public MemberOfField KnowledgeExpertiseField() throws Exception{ 
	return sfdc.Field("Knowledge Expertise"); 
} 
public MemberOfField CustomerFocusField() throws Exception{ 
	return sfdc.Field("Customer Focus"); 
} 
public MemberOfField BusinessAccountPlanningField() throws Exception{ 
	return sfdc.Field("Business Account Planning"); 
} 
public MemberOfField CallProductivityField() throws Exception{ 
	return sfdc.Field("Call Productivity"); 
} 
public MemberOfField CreatedByField() throws Exception{ 
	return sfdc.Field("Created By"); 
} 
public MemberOfField LastModifiedByField() throws Exception{ 
	return sfdc.Field("Last Modified By"); 
} 
//************************* Functions for Section Name***************************** // 
 
public MemberOfSEC SEC_CoachingReportDetail_CoachingReportNameField() throws Exception { 
return sfdc.Section("Coaching Report Detail", "Coaching Report Name"); 
}
public MemberOfSEC SEC_CoachingReportDetail_ReviewDateField() throws Exception { 
return sfdc.Section("Coaching Report Detail", "Review Date"); 
}
public MemberOfSEC SEC_CoachingReportDetail_ManagerField() throws Exception { 
return sfdc.Section("Coaching Report Detail", "Manager"); 
}
public MemberOfSEC SEC_CoachingReportDetail_ReviewPeriodField() throws Exception { 
return sfdc.Section("Coaching Report Detail", "Review Period"); 
}
public MemberOfSEC SEC_CoachingReportDetail_EmployeeField() throws Exception { 
return sfdc.Section("Coaching Report Detail", "Employee"); 
}
public MemberOfSEC SEC_CoachingReportDetail_StatusField() throws Exception { 
return sfdc.Section("Coaching Report Detail", "Status"); 
}
//************************* Functions for Related List***************************** // 
 
}

