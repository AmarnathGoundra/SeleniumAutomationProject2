package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class ConvertLeadScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public ConvertLeadScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public ConvertLeadScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI CreateNewField() throws Exception{  
return sfdc.Field_LUI("Create New"); 
} 
 
public MemberOfField_LUI AccountNameField() throws Exception{  
return sfdc.Field_LUI("Account Name"); 
} 
 
public MemberOfField_LUI ChooseExistingField() throws Exception{  
return sfdc.Field_LUI("Choose Existing"); 
} 
 
public MemberOfField_LUI AccountSearchField() throws Exception{  
return sfdc.Field_LUI("Account Search"); 
} 
 
public MemberOfField_LUI RecordOwnerField() throws Exception{  
return sfdc.Field_LUI("Record Owner"); 
} 
 
public MemberOfField_LUI ConvertedStatusField() throws Exception{  
return sfdc.Field_LUI("Converted Status"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 // ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewCaseButton() throws Exception{ 
return sfdc.Button_LUI("New Case"); 
} 
public MemberOfButton_LUI NewNoteButton() throws Exception{ 
return sfdc.Button_LUI("New Note"); 
} 
public MemberOfButton_LUI SubmitforApprovalButton() throws Exception{ 
return sfdc.Button_LUI("Submit for Approval"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI ConvertButton() throws Exception{ 
return sfdc.Button_LUI("Convert"); 
} 
//************************* Functions for All Apps ***************************** // 
 
//************************* Functions for Tabs List ***************************** // 
 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Searchbyobjecttype_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search by object type"); 
} 
public MemberOfHealthCloud_LUI SearchLeadsandmore_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Leads and more"); 
} 
public MemberOfHealthCloud_LUI CreateNew_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Create New"); 
} 
public MemberOfHealthCloud_LUI AccountName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Account Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI ChooseExisting_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Choose Existing"); 
} 
public MemberOfHealthCloud_LUI AccountSearch_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Account Search"); 
} 
public MemberOfHealthCloud_LUI RecordOwner_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Record Owner"); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
