package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class AppLauncherScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public AppLauncherScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public AppLauncherScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}
 
 
//************************* Functions for All Apps ***************************** // 
 
public MemberOfAllApps_LUI ServiceApp() throws Exception{ 
return sfdc.AllApps_LUI("Service"); 
} 
public MemberOfAllApps_LUI MarketingApp() throws Exception{ 
return sfdc.AllApps_LUI("Marketing"); 
} 
public MemberOfAllApps_LUI CommunityApp() throws Exception{ 
return sfdc.AllApps_LUI("Community"); 
} 
public MemberOfAllApps_LUI SitecomApp() throws Exception{ 
return sfdc.AllApps_LUI("Site.com"); 
} 
public MemberOfAllApps_LUI SalesforceChatterApp() throws Exception{ 
return sfdc.AllApps_LUI("Salesforce Chatter"); 
} 
public MemberOfAllApps_LUI ContentApp() throws Exception{ 
return sfdc.AllApps_LUI("Content"); 
} 
public MemberOfAllApps_LUI BFSApp() throws Exception{ 
return sfdc.AllApps_LUI("BFS"); 
} 
public MemberOfAllApps_LUI InsuranceApp() throws Exception{ 
return sfdc.AllApps_LUI("Insurance"); 
} 
public MemberOfAllApps_LUI VEEVALifeSciencesApp() throws Exception{ 
return sfdc.AllApps_LUI("VEEVA-Life Sciences"); 
} 
public MemberOfAllApps_LUI HealthCareApp() throws Exception{ 
return sfdc.AllApps_LUI("Health Care"); 
} 
public MemberOfAllApps_LUI EasyDescribeApp() throws Exception{ 
return sfdc.AllApps_LUI("EasyDescribe"); 
} 
public MemberOfAllApps_LUI CWBToolApp() throws Exception{ 
return sfdc.AllApps_LUI("CWB Tool"); 
} 
public MemberOfAllApps_LUI DreamHouseApp() throws Exception{ 
return sfdc.AllApps_LUI("DreamHouse"); 
} 
public MemberOfAllApps_LUI SalesApp() throws Exception{ 
return sfdc.AllApps_LUI("Sales"); 
} 
public MemberOfAllApps_LUI LightningUsageAppApp() throws Exception{ 
return sfdc.AllApps_LUI("Lightning Usage App"); 
} 
//************************* Functions for Tabs List ***************************** // 
 
public MemberOfTab_LUI AccountsTab() throws Exception{ 
return sfdc.Tab_LUI("Accounts"); 
} 
public MemberOfTab_LUI AppLauncherTab() throws Exception{ 
return sfdc.Tab_LUI("App Launcher"); 
} 
public MemberOfTab_LUI ApprovalRequestsTab() throws Exception{ 
return sfdc.Tab_LUI("Approval Requests"); 
} 
public MemberOfTab_LUI AssetsTab() throws Exception{ 
return sfdc.Tab_LUI("Assets"); 
} 
public MemberOfTab_LUI AuthorizationFormTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form"); 
} 
public MemberOfTab_LUI AuthorizationFormConsentTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form Consent"); 
} 
public MemberOfTab_LUI AuthorizationFormDataUseTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form Data Use"); 
} 
public MemberOfTab_LUI AuthorizationFormTextTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form Text"); 
} 
public MemberOfTab_LUI AutomationHelpersTab() throws Exception{ 
return sfdc.Tab_LUI("Automation Helpers"); 
} 
public MemberOfTab_LUI BotCommandsTab() throws Exception{ 
return sfdc.Tab_LUI("Bot Commands"); 
} 
public MemberOfTab_LUI BrokersTab() throws Exception{ 
return sfdc.Tab_LUI("Brokers"); 
} 
public MemberOfTab_LUI CMSHomeTab() throws Exception{ 
return sfdc.Tab_LUI("CMS Home"); 
} 
public MemberOfTab_LUI CWBSetupTab() throws Exception{ 
return sfdc.Tab_LUI("CWB Setup"); 
} 
public MemberOfTab_LUI CWBToolTab() throws Exception{ 
return sfdc.Tab_LUI("CWB Tool"); 
} 
public MemberOfTab_LUI CalendarTab() throws Exception{ 
return sfdc.Tab_LUI("Calendar"); 
} 
public MemberOfTab_LUI CampaignsTab() throws Exception{ 
return sfdc.Tab_LUI("Campaigns"); 
} 
public MemberOfTab_LUI CasesTab() throws Exception{ 
return sfdc.Tab_LUI("Cases"); 
} 
public MemberOfTab_LUI ChatterTab() throws Exception{ 
return sfdc.Tab_LUI("Chatter"); 
} 
public MemberOfTab_LUI ClientTab() throws Exception{ 
return sfdc.Tab_LUI("Client"); 
} 
public MemberOfTab_LUI CommandCenterTab() throws Exception{ 
return sfdc.Tab_LUI("Command Center"); 
} 
public MemberOfTab_LUI ConsumptionSchedulesTab() throws Exception{ 
return sfdc.Tab_LUI("Consumption Schedules"); 
} 
public MemberOfTab_LUI ContactPointTypeConsentTab() throws Exception{ 
return sfdc.Tab_LUI("Contact Point Type Consent"); 
} 
public MemberOfTab_LUI ContactsTab() throws Exception{ 
return sfdc.Tab_LUI("Contacts"); 
} 
public MemberOfTab_LUI ContractsTab() throws Exception{ 
return sfdc.Tab_LUI("Contracts"); 
} 
public MemberOfTab_LUI DashboardsTab() throws Exception{ 
return sfdc.Tab_LUI("Dashboards"); 
} 
public MemberOfTab_LUI DataImportTab() throws Exception{ 
return sfdc.Tab_LUI("Data Import"); 
} 
public MemberOfTab_LUI DataUseLegalBasisTab() throws Exception{ 
return sfdc.Tab_LUI("Data Use Legal Basis"); 
} 
public MemberOfTab_LUI DataUsePurposeTab() throws Exception{ 
return sfdc.Tab_LUI("Data Use Purpose"); 
} 
public MemberOfTab_LUI DuplicateRecordSetsTab() throws Exception{ 
return sfdc.Tab_LUI("Duplicate Record Sets"); 
} 
public MemberOfTab_LUI EasyDescribeTab() throws Exception{ 
return sfdc.Tab_LUI("EasyDescribe"); 
} 
public MemberOfTab_LUI EinsteinVisionTab() throws Exception{ 
return sfdc.Tab_LUI("Einstein Vision"); 
} 
public MemberOfTab_LUI EmailTemplatesTab() throws Exception{ 
return sfdc.Tab_LUI("Email Templates"); 
} 
public MemberOfTab_LUI EnhancedLetterheadsTab() throws Exception{ 
return sfdc.Tab_LUI("Enhanced Letterheads"); 
} 
public MemberOfTab_LUI FilesTab() throws Exception{ 
return sfdc.Tab_LUI("Files"); 
} 
public MemberOfTab_LUI FinancialAccountTab() throws Exception{ 
return sfdc.Tab_LUI("Financial Account"); 
} 
public MemberOfTab_LUI ForecastsTab() throws Exception{ 
return sfdc.Tab_LUI("Forecasts"); 
} 
public MemberOfTab_LUI GroupsTab() throws Exception{ 
return sfdc.Tab_LUI("Groups"); 
} 
public MemberOfTab_LUI GurpreetsTab() throws Exception{ 
return sfdc.Tab_LUI("Gurpreets"); 
} 
public MemberOfTab_LUI HeatMapTab() throws Exception{ 
return sfdc.Tab_LUI("Heat Map"); 
} 
public MemberOfTab_LUI HeatMapDemoTab() throws Exception{ 
return sfdc.Tab_LUI("Heat Map (Demo)"); 
} 
public MemberOfTab_LUI HomeTab() throws Exception{ 
return sfdc.Tab_LUI("Home"); 
} 
public MemberOfTab_LUI HouseExplorerTab() throws Exception{ 
return sfdc.Tab_LUI("House Explorer"); 
} 
public MemberOfTab_LUI LeadsTab() throws Exception{ 
return sfdc.Tab_LUI("Leads"); 
} 
public MemberOfTab_LUI LightningBoltSolutionsTab() throws Exception{ 
return sfdc.Tab_LUI("Lightning Bolt Solutions"); 
} 
public MemberOfTab_LUI LightningUsageTab() throws Exception{ 
return sfdc.Tab_LUI("Lightning Usage"); 
} 
public MemberOfTab_LUI ListEmailsTab() throws Exception{ 
return sfdc.Tab_LUI("List Emails"); 
} 
public MemberOfTab_LUI MacrosTab() throws Exception{ 
return sfdc.Tab_LUI("Macros"); 
} 
public MemberOfTab_LUI MyAccountsTab() throws Exception{ 
return sfdc.Tab_LUI("My Accounts"); 
} 
public MemberOfTab_LUI OpportunitiesTab() throws Exception{ 
return sfdc.Tab_LUI("Opportunities"); 
} 
public MemberOfTab_LUI OrdersTab() throws Exception{ 
return sfdc.Tab_LUI("Orders"); 
} 
public MemberOfTab_LUI OrgMetricsTab() throws Exception{ 
return sfdc.Tab_LUI("Org Metrics"); 
} 
public MemberOfTab_LUI PatientsTab() throws Exception{ 
return sfdc.Tab_LUI("Patients"); 
} 
public MemberOfTab_LUI PeopleTab() throws Exception{ 
return sfdc.Tab_LUI("People"); 
} 
public MemberOfTab_LUI PhysicianTab() throws Exception{ 
return sfdc.Tab_LUI("Physician"); 
} 
public MemberOfTab_LUI PriceBooksTab() throws Exception{ 
return sfdc.Tab_LUI("Price Books"); 
} 
public MemberOfTab_LUI ProductsTab() throws Exception{ 
return sfdc.Tab_LUI("Products"); 
} 
public MemberOfTab_LUI PropertiesTab() throws Exception{ 
return sfdc.Tab_LUI("Properties"); 
} 
public MemberOfTab_LUI PropertyExplorerTab() throws Exception{ 
return sfdc.Tab_LUI("Property Explorer"); 
} 
public MemberOfTab_LUI QuickTextTab() throws Exception{ 
return sfdc.Tab_LUI("Quick Text"); 
} 
public MemberOfTab_LUI RecycleBinTab() throws Exception{ 
return sfdc.Tab_LUI("Recycle Bin"); 
} 
public MemberOfTab_LUI RepNumberTab() throws Exception{ 
return sfdc.Tab_LUI("Rep Number"); 
} 
public MemberOfTab_LUI RepNumberUserTab() throws Exception{ 
return sfdc.Tab_LUI("Rep Number User"); 
} 
public MemberOfTab_LUI ReportsTab() throws Exception{ 
return sfdc.Tab_LUI("Reports"); 
} 
public MemberOfTab_LUI StreamingChannelsTab() throws Exception{ 
return sfdc.Tab_LUI("Streaming Channels"); 
} 
public MemberOfTab_LUI SubhrosTab() throws Exception{ 
return sfdc.Tab_LUI("Subhros"); 
} 
public MemberOfTab_LUI SurveysTab() throws Exception{ 
return sfdc.Tab_LUI("Surveys"); 
} 
public MemberOfTab_LUI TasksTab() throws Exception{ 
return sfdc.Tab_LUI("Tasks"); 
} 
public MemberOfTab_LUI TestPlanningExecutionTab() throws Exception{ 
return sfdc.Tab_LUI("Test Planning/Execution"); 
} 
public MemberOfTab_LUI UserProvisioningRequestsTab() throws Exception{ 
return sfdc.Tab_LUI("User Provisioning Requests"); 
} 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Searchbyobjecttype_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search by object type"); 
} 
public MemberOfHealthCloud_LUI SearchSalesforce_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Salesforce"); 
} 
public MemberOfHealthCloud_LUI Searchappsoritems_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search apps or items..."); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
