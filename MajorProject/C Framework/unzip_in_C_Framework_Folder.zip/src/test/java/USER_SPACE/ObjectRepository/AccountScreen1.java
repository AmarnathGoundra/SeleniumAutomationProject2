package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class AccountScreen1 extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public AccountScreen1(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public AccountScreen1(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


//************************* Functions for List Views***************************** // 
 
//************************* Functions for Buttons***************************** // 
 
public MemberOfButton InsertSelectedButton() throws Exception{ 
return sfdc.Button("Insert Selected"); 
} 
public MemberOfButton NewButton() throws Exception{ 
return sfdc.Button("New"); 
} 
public MemberOfButton ScheduleaCallButton() throws Exception{ 
return sfdc.Button("Schedule a Call"); 
} 
public MemberOfButton MoreActionsButton() throws Exception{ 
return sfdc.Button("More Actions ?"); 
} 
public MemberOfButton OKButton() throws Exception{ 
return sfdc.Button("OK"); 
} 
public MemberOfButton CancelButton() throws Exception{ 
return sfdc.Button("Cancel"); 
} 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton HCP360Button() throws Exception{ 
return sfdc.Button("HCP 360"); 
} 
public MemberOfButton CalendarButton() throws Exception{ 
return sfdc.Button("Calendar"); 
} 
public MemberOfButton ViewOverviewButton() throws Exception{ 
return sfdc.Button("View Overview"); 
} 
public MemberOfButton ViewHierarchyButton() throws Exception{ 
return sfdc.Button("View Hierarchy"); 
} 
public MemberOfButton ReportaCallButton() throws Exception{ 
return sfdc.Button("Report a Call"); 
} 
public MemberOfButton ConsentCaptureButton() throws Exception{ 
return sfdc.Button("Consent Capture"); 
} 
public MemberOfButton SendEmailButton() throws Exception{ 
return sfdc.Button("Send Email"); 
} 
public MemberOfButton StartCoBrowseButton() throws Exception{ 
return sfdc.Button("Start CoBrowse"); 
} 
public MemberOfButton NewMedicalInquiryButton() throws Exception{ 
return sfdc.Button("New Medical Inquiry"); 
} 
public MemberOfButton ChangeRequestButton() throws Exception{ 
return sfdc.Button("Change Request"); 
} 
public MemberOfButton ViewReportsButton() throws Exception{ 
return sfdc.Button("View Reports"); 
} 
public MemberOfButton VeevaDCRNewParentAccountButton() throws Exception{ 
return sfdc.Button("Veeva DCR New Parent Account"); 
} 
public MemberOfButton ViewSignaturesButton() throws Exception{ 
return sfdc.Button("View Signatures"); 
} 
public MemberOfButton NewNoteButton() throws Exception{ 
return sfdc.Button("New Note"); 
} 
public MemberOfButton AttachFileButton() throws Exception{ 
return sfdc.Button("Attach File"); 
} 
//************************* Functions for Field Names ***************************** // 
 
public MemberOfField AccountRecordTypeField() throws Exception{ 
	return sfdc.Field("Account Record Type"); 
} 
public MemberOfField PrimaryParentField() throws Exception{ 
	return sfdc.Field("Primary Parent"); 
} 
public MemberOfField NameField() throws Exception{ 
	return sfdc.Field("Name"); 
} 
public MemberOfField CertifiedByField() throws Exception{ 
	return sfdc.Field("Certified By"); 
} 
public MemberOfField MiddleField() throws Exception{ 
	return sfdc.Field("Middle"); 
} 
public MemberOfField BirthdateField() throws Exception{ 
	return sfdc.Field("Birthdate"); 
} 
public MemberOfField FormattedNameField() throws Exception{ 
	return sfdc.Field("Formatted Name"); 
} 
public MemberOfField LanguageField() throws Exception{ 
	return sfdc.Field("Language"); 
} 
public MemberOfField TitleField() throws Exception{ 
	return sfdc.Field("Title"); 
} 
public MemberOfField RegionalClusterField() throws Exception{ 
	return sfdc.Field("Regional Cluster"); 
} 
public MemberOfField GradeField() throws Exception{ 
	return sfdc.Field("Grade"); 
} 
public MemberOfField LocalSpecialtyField() throws Exception{ 
	return sfdc.Field("Local Specialty"); 
} 
public MemberOfField IndividualTypeField() throws Exception{ 
	return sfdc.Field("Individual Type"); 
} 
public MemberOfField Specialty1Field() throws Exception{ 
	return sfdc.Field("Specialty 1"); 
} 
public MemberOfField GenderField() throws Exception{ 
	return sfdc.Field("Gender"); 
} 
public MemberOfField Specialty2Field() throws Exception{ 
	return sfdc.Field("Specialty 2"); 
} 
public MemberOfField GraduationYearField() throws Exception{ 
	return sfdc.Field("Graduation Year"); 
} 
public MemberOfField Specialty3Field() throws Exception{ 
	return sfdc.Field("Specialty 3"); 
} 
public MemberOfField QualificationYearField() throws Exception{ 
	return sfdc.Field("Qualification Year"); 
} 
public MemberOfField QualificationField() throws Exception{ 
	return sfdc.Field("Qualification"); 
} 
public MemberOfField PlaceofQualificationField() throws Exception{ 
	return sfdc.Field("Place of Qualification"); 
} 
public MemberOfField AccountStatusField() throws Exception{ 
	return sfdc.Field("Account Status"); 
} 
public MemberOfField ReceptionistAssistantNameField() throws Exception{ 
	return sfdc.Field("Receptionist/Assistant Name"); 
} 
public MemberOfField RoleField() throws Exception{ 
	return sfdc.Field("Role"); 
} 
public MemberOfField ReceptionistAssistantPhoneField() throws Exception{ 
	return sfdc.Field("Receptionist/Assistant Phone"); 
} 
public MemberOfField MDMLocationField() throws Exception{ 
	return sfdc.Field("MDM Location"); 
} 
public MemberOfField MDMJuridicGroupField() throws Exception{ 
	return sfdc.Field("MDM Juridic Group"); 
} 
public MemberOfField MDMSectorOfCareField() throws Exception{ 
	return sfdc.Field("MDM Sector Of Care"); 
} 
public MemberOfField PreferredFirstNameField() throws Exception{ 
	return sfdc.Field("Preferred First Name"); 
}
public MemberOfField FirstNameField() throws Exception{ 
	return sfdc.Field("First Name"); 
} 

public MemberOfField CountryField() throws Exception{ 
	return sfdc.Field("Country"); 
} 
public MemberOfField PreferredLastNameField() throws Exception{ 
	return sfdc.Field("Preferred Last Name"); 
} 
public MemberOfField AvailabilityField() throws Exception{ 
	return sfdc.Field("Availability"); 
} 
public MemberOfField JanrainIdField() throws Exception{ 
	return sfdc.Field("Janrain Id"); 
} 
public MemberOfField TestContactField() throws Exception{ 
	return sfdc.Field("Test Contact"); 
} 
public MemberOfField UnivadisUserField() throws Exception{ 
	return sfdc.Field("Univadis User"); 
} 
public MemberOfField ReceptionistAssistantEmailField() throws Exception{ 
	return sfdc.Field("Receptionist/Assistant Email"); 
} 
public MemberOfField ChannelOpennessField() throws Exception{ 
	return sfdc.Field("Channel Openness"); 
} 
public MemberOfField PrimaryAddressline1Field() throws Exception{ 
	return sfdc.Field("Primary Address line 1"); 
} 
public MemberOfField PrimaryPostalCodeField() throws Exception{ 
	return sfdc.Field("Primary Postal Code"); 
} 
public MemberOfField PrimaryAddressline2Field() throws Exception{ 
	return sfdc.Field("Primary Address line 2"); 
} 
public MemberOfField PrimaryCityField() throws Exception{ 
	return sfdc.Field("Primary City"); 
} 
public MemberOfField EmailField() throws Exception{ 
	return sfdc.Field("Email"); 
} 
public MemberOfField MobileField() throws Exception{ 
	return sfdc.Field("Mobile"); 
} 
public MemberOfField PhoneField() throws Exception{ 
	return sfdc.Field("Phone"); 
} 
public MemberOfField FaxField() throws Exception{ 
	return sfdc.Field("Fax"); 
} 
public MemberOfField MedicalIDField() throws Exception{ 
	return sfdc.Field("Medical ID"); 
} 
public MemberOfField CertifieduseofinfoField() throws Exception{ 
	return sfdc.Field("Certified use of info"); 
} 
public MemberOfField TaxIdField() throws Exception{ 
	return sfdc.Field("Tax Id"); 
} 
public MemberOfField DataProviderIdField() throws Exception{ 
	return sfdc.Field("Data Provider Id"); 
} 
public MemberOfField MDMIDField() throws Exception{ 
	return sfdc.Field("MDM ID"); 
} 
public MemberOfField SAPCODEField() throws Exception{ 
	return sfdc.Field("SAP CODE"); 
} 
public MemberOfField GCMIDField() throws Exception{ 
	return sfdc.Field("GCM ID"); 
} 
public MemberOfField ExternalIDField() throws Exception{ 
	return sfdc.Field("External ID"); 
} 
public MemberOfField LegacySystemIDField() throws Exception{ 
	return sfdc.Field("Legacy System ID"); 
} 
public MemberOfField ApprovedforSamplingField() throws Exception{ 
	return sfdc.Field("Approved for Sampling"); 
} 
public MemberOfField ApprovedforSamplingDateField() throws Exception{ 
	return sfdc.Field("Approved for Sampling Date"); 
} 
public MemberOfField StopSamplingField() throws Exception{ 
	return sfdc.Field("Stop Sampling"); 
} 
public MemberOfField ApprovedforSamplingLastUpdatedByField() throws Exception{ 
	return sfdc.Field("Approved for Sampling Last Updated By"); 
} 
public MemberOfField ScientificLeaderField() throws Exception{ 
	return sfdc.Field("Scientific Leader"); 
} 
public MemberOfField SpeakerField() throws Exception{ 
	return sfdc.Field("Speaker?"); 
} 
public MemberOfField FCPAValueField() throws Exception{ 
	return sfdc.Field("FCPA Value"); 
} 
public MemberOfField DPSSField() throws Exception{ 
	return sfdc.Field("DPSS"); 
} 
public MemberOfField FCPALastUpdatedDateField() throws Exception{ 
	return sfdc.Field("FCPA Last Updated Date"); 
} 
public MemberOfField DPSSEffectiveDateField() throws Exception{ 
	return sfdc.Field("DPSS Effective Date"); 
} 
public MemberOfField FCPALastUpdatedByField() throws Exception{ 
	return sfdc.Field("FCPA Last Updated By"); 
} 
public MemberOfField DueDiligenceDateField() throws Exception{ 
	return sfdc.Field("Due Diligence Date"); 
} 
public MemberOfField DueDiligenceexpirationDateField() throws Exception{ 
	return sfdc.Field("Due Diligence expiration Date"); 
} 
public MemberOfField KeyCustomerField() throws Exception{ 
	return sfdc.Field("Key Customer"); 
} 
public MemberOfField PrescriberField() throws Exception{ 
	return sfdc.Field("Prescriber"); 
} 
public MemberOfField TargetField() throws Exception{ 
	return sfdc.Field("Target?"); 
} 
public MemberOfField KOLField() throws Exception{ 
	return sfdc.Field("KOL?"); 
} 
public MemberOfField CertifieduseofinfolastupdatedField() throws Exception{ 
	return sfdc.Field("Certified use of info last updated"); 
} 
public MemberOfField CertifieduseofinfoexpiryField() throws Exception{ 
	return sfdc.Field("Certified use of info expiry"); 
} 
public MemberOfField TerritoriesField() throws Exception{ 
	return sfdc.Field("Territories"); 
} 
public MemberOfField CreatedByField() throws Exception{ 
	return sfdc.Field("Created By"); 
} 
public MemberOfField LastModifiedByField() throws Exception{ 
	return sfdc.Field("Last Modified By"); 
} 
//************************* Functions for Section Name***************************** // 
 
public MemberOfSEC SEC_AccountDetail_AccountRecordTypeField() throws Exception { 
return sfdc.Section("Account Detail", "Account Record Type"); 
}
public MemberOfSEC SEC_AccountDetail_PrimaryParentField() throws Exception { 
return sfdc.Section("Account Detail", "Primary Parent"); 
}
public MemberOfSEC SEC_AccountDetail_NameField() throws Exception { 
return sfdc.Section("Account Detail", "Name"); 
}
public MemberOfSEC SEC_AccountDetail_CertifiedByField() throws Exception { 
return sfdc.Section("Account Detail", "Certified By"); 
}
public MemberOfSEC SEC_AccountDetail_MiddleField() throws Exception { 
return sfdc.Section("Account Detail", "Middle"); 
}
public MemberOfSEC SEC_AccountDetail_BirthdateField() throws Exception { 
return sfdc.Section("Account Detail", "Birthdate"); 
}
public MemberOfSEC SEC_AccountDetail_FormattedNameField() throws Exception { 
return sfdc.Section("Account Detail", "Formatted Name"); 
}
public MemberOfSEC SEC_AccountDetail_LanguageField() throws Exception { 
return sfdc.Section("Account Detail", "Language"); 
}
public MemberOfSEC SEC_AccountDetail_TitleField() throws Exception { 
return sfdc.Section("Account Detail", "Title"); 
}
public MemberOfSEC SEC_AccountDetail_RegionalClusterField() throws Exception { 
return sfdc.Section("Account Detail", "Regional Cluster"); 
}
public MemberOfSEC SEC_AccountDetail_GradeField() throws Exception { 
return sfdc.Section("Account Detail", "Grade"); 
}
public MemberOfSEC SEC_AccountDetail_LocalSpecialtyField() throws Exception { 
return sfdc.Section("Account Detail", "Local Specialty"); 
}
public MemberOfSEC SEC_AccountDetail_IndividualTypeField() throws Exception { 
return sfdc.Section("Account Detail", "Individual Type"); 
}
public MemberOfSEC SEC_AccountDetail_Specialty1Field() throws Exception { 
return sfdc.Section("Account Detail", "Specialty 1"); 
}
public MemberOfSEC SEC_AccountDetail_GenderField() throws Exception { 
return sfdc.Section("Account Detail", "Gender"); 
}
public MemberOfSEC SEC_AccountDetail_Specialty2Field() throws Exception { 
return sfdc.Section("Account Detail", "Specialty 2"); 
}
public MemberOfSEC SEC_AccountDetail_GraduationYearField() throws Exception { 
return sfdc.Section("Account Detail", "Graduation Year"); 
}
public MemberOfSEC SEC_AccountDetail_Specialty3Field() throws Exception { 
return sfdc.Section("Account Detail", "Specialty 3"); 
}
public MemberOfSEC SEC_AccountDetail_QualificationYearField() throws Exception { 
return sfdc.Section("Account Detail", "Qualification Year"); 
}
public MemberOfSEC SEC_AccountDetail_QualificationField() throws Exception { 
return sfdc.Section("Account Detail", "Qualification"); 
}
public MemberOfSEC SEC_AccountDetail_PlaceofQualificationField() throws Exception { 
return sfdc.Section("Account Detail", "Place of Qualification"); 
}
public MemberOfSEC SEC_AccountDetail_AccountStatusField() throws Exception { 
return sfdc.Section("Account Detail", "Account Status"); 
}
public MemberOfSEC SEC_AccountDetail_ReceptionistAssistantNameField() throws Exception { 
return sfdc.Section("Account Detail", "Receptionist/Assistant Name"); 
}
public MemberOfSEC SEC_AccountDetail_RoleField() throws Exception { 
return sfdc.Section("Account Detail", "Role"); 
}
public MemberOfSEC SEC_AccountDetail_ReceptionistAssistantPhoneField() throws Exception { 
return sfdc.Section("Account Detail", "Receptionist/Assistant Phone"); 
}
public MemberOfSEC SEC_AccountDetail_MDMLocationField() throws Exception { 
return sfdc.Section("Account Detail", "MDM Location"); 
}
public MemberOfSEC SEC_AccountDetail_MDMJuridicGroupField() throws Exception { 
return sfdc.Section("Account Detail", "MDM Juridic Group"); 
}
public MemberOfSEC SEC_AccountDetail_MDMSectorOfCareField() throws Exception { 
return sfdc.Section("Account Detail", "MDM Sector Of Care"); 
}
public MemberOfSEC SEC_AccountDetail_PreferredFirstNameField() throws Exception { 
return sfdc.Section("Account Detail", "Preferred First Name"); 
}
public MemberOfSEC SEC_AccountDetail_CountryField() throws Exception { 
return sfdc.Section("Account Detail", "Country"); 
}
public MemberOfSEC SEC_AccountDetail_PreferredLastNameField() throws Exception { 
return sfdc.Section("Account Detail", "Preferred Last Name"); 
}
public MemberOfSEC SEC_AccountDetail_AvailabilityField() throws Exception { 
return sfdc.Section("Account Detail", "Availability"); 
}
public MemberOfSEC SEC_AccountDetail_JanrainIdField() throws Exception { 
return sfdc.Section("Account Detail", "Janrain Id"); 
}
public MemberOfSEC SEC_AccountDetail_TestContactField() throws Exception { 
return sfdc.Section("Account Detail", "Test Contact"); 
}
public MemberOfSEC SEC_AccountDetail_UnivadisUserField() throws Exception { 
return sfdc.Section("Account Detail", "Univadis User"); 
}
public MemberOfSEC SEC_AccountDetail_ReceptionistAssistantEmailField() throws Exception { 
return sfdc.Section("Account Detail", "Receptionist/Assistant Email"); 
}
public MemberOfSEC SEC_AccountDetail_ChannelOpennessField() throws Exception { 
return sfdc.Section("Account Detail", "Channel Openness"); 
}
//************************* Functions for Related List***************************** // 
 


 public Columns_Addresses RL_Addresses() throws Exception{ 
return new Columns_Addresses("Addresses"); 
} 
public class Columns_Addresses{ 
Columns_Addresses(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Addressline1(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Address line 1",RowIndex); 
}
public MemberOfRL Addressline1() throws Exception 
{ 
return sfdc.RL(RList,"Address line 1"); 
}

public MemberOfRL Addressline2(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Address line 2",RowIndex); 
}
public MemberOfRL Addressline2() throws Exception 
{ 
return sfdc.RL(RList,"Address line 2"); 
}

public MemberOfRL AddressLine3(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Address Line 3",RowIndex); 
}
public MemberOfRL AddressLine3() throws Exception 
{ 
return sfdc.RL(RList,"Address Line 3"); 
}

public MemberOfRL Building(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Building",RowIndex); 
}
public MemberOfRL Building() throws Exception 
{ 
return sfdc.RL(RList,"Building"); 
}

public MemberOfRL City(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"City",RowIndex); 
}
public MemberOfRL City() throws Exception 
{ 
return sfdc.RL(RList,"City"); 
}

public MemberOfRL State(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"State",RowIndex); 
}
public MemberOfRL State() throws Exception 
{ 
return sfdc.RL(RList,"State"); 
}

public MemberOfRL Zip(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Zip",RowIndex); 
}
public MemberOfRL Zip() throws Exception 
{ 
return sfdc.RL(RList,"Zip"); 
}

public MemberOfRL Brick(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Brick",RowIndex); 
}
public MemberOfRL Brick() throws Exception 
{ 
return sfdc.RL(RList,"Brick"); 
}

public MemberOfRL Primary(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Primary",RowIndex); 
}
public MemberOfRL Primary() throws Exception 
{ 
return sfdc.RL(RList,"Primary"); 
}

public MemberOfRL Inactive(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Inactive",RowIndex); 
}
public MemberOfRL Inactive() throws Exception 
{ 
return sfdc.RL(RList,"Inactive"); 
}

}



 public Columns_SentEmail RL_SentEmail() throws Exception{ 
return new Columns_SentEmail("Sent Email"); 
} 
public class Columns_SentEmail{ 
Columns_SentEmail(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL SentEmailName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Sent Email Name",RowIndex); 
}
public MemberOfRL SentEmailName() throws Exception 
{ 
return sfdc.RL(RList,"Sent Email Name"); 
}

public MemberOfRL ProductDisplay(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Product Display",RowIndex); 
}
public MemberOfRL ProductDisplay() throws Exception 
{ 
return sfdc.RL(RList,"Product Display"); 
}

public MemberOfRL SentDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Sent Date",RowIndex); 
}
public MemberOfRL SentDate() throws Exception 
{ 
return sfdc.RL(RList,"Sent Date"); 
}

public MemberOfRL Status(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Status",RowIndex); 
}
public MemberOfRL Status() throws Exception 
{ 
return sfdc.RL(RList,"Status"); 
}

public MemberOfRL TotalOpens(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Total Opens",RowIndex); 
}
public MemberOfRL TotalOpens() throws Exception 
{ 
return sfdc.RL(RList,"Total Opens"); 
}

public MemberOfRL LastOpen(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Open",RowIndex); 
}
public MemberOfRL LastOpen() throws Exception 
{ 
return sfdc.RL(RList,"Last Open"); 
}

public MemberOfRL TotalClicks(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Total Clicks",RowIndex); 
}
public MemberOfRL TotalClicks() throws Exception 
{ 
return sfdc.RL(RList,"Total Clicks"); 
}

public MemberOfRL LastClick(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Click",RowIndex); 
}
public MemberOfRL LastClick() throws Exception 
{ 
return sfdc.RL(RList,"Last Click"); 
}

public MemberOfRL DocumentViews(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Document Views",RowIndex); 
}
public MemberOfRL DocumentViews() throws Exception 
{ 
return sfdc.RL(RList,"Document Views"); 
}

}



 public Columns_MemberOf RL_MemberOf() throws Exception{ 
return new Columns_MemberOf("Member Of"); 
} 
public class Columns_MemberOf{ 
Columns_MemberOf(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Name(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Name",RowIndex); 
}
public MemberOfRL Name() throws Exception 
{ 
return sfdc.RL(RList,"Name"); 
}

public MemberOfRL ParentAccount(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Parent Account",RowIndex); 
}
public MemberOfRL ParentAccount() throws Exception 
{ 
return sfdc.RL(RList,"Parent Account"); 
}

public MemberOfRL Primary(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Primary",RowIndex); 
}
public MemberOfRL Primary() throws Exception 
{ 
return sfdc.RL(RList,"Primary"); 
}

public MemberOfRL CreatedDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Created Date",RowIndex); 
}
public MemberOfRL CreatedDate() throws Exception 
{ 
return sfdc.RL(RList,"Created Date"); 
}

}



 public Columns_AffiliationsFromAccount RL_AffiliationsFromAccount() throws Exception{ 
return new Columns_AffiliationsFromAccount("Affiliations (From Account)"); 
} 
public class Columns_AffiliationsFromAccount{ 
Columns_AffiliationsFromAccount(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_Initiatives RL_Initiatives() throws Exception{ 
return new Columns_Initiatives("Initiatives"); 
} 
public class Columns_Initiatives{ 
Columns_Initiatives(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL InitiativeId(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Initiative Id",RowIndex); 
}
public MemberOfRL InitiativeId() throws Exception 
{ 
return sfdc.RL(RList,"Initiative Id"); 
}

public MemberOfRL Status(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Status",RowIndex); 
}
public MemberOfRL Status() throws Exception 
{ 
return sfdc.RL(RList,"Status"); 
}

public MemberOfRL Type(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Type",RowIndex); 
}
public MemberOfRL Type() throws Exception 
{ 
return sfdc.RL(RList,"Type"); 
}

public MemberOfRL CreatedBy(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Created By",RowIndex); 
}
public MemberOfRL CreatedBy() throws Exception 
{ 
return sfdc.RL(RList,"Created By"); 
}

public MemberOfRL LastModifiedBy(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Modified By",RowIndex); 
}
public MemberOfRL LastModifiedBy() throws Exception 
{ 
return sfdc.RL(RList,"Last Modified By"); 
}

}



 public Columns_CallsAccount RL_CallsAccount() throws Exception{ 
return new Columns_CallsAccount("Calls (Account)"); 
} 
public class Columns_CallsAccount{ 
Columns_CallsAccount(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Datetime(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Datetime",RowIndex); 
}
public MemberOfRL Datetime() throws Exception 
{ 
return sfdc.RL(RList,"Datetime"); 
}

public MemberOfRL CallName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Call Name",RowIndex); 
}
public MemberOfRL CallName() throws Exception 
{ 
return sfdc.RL(RList,"Call Name"); 
}

public MemberOfRL ParentCall(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Parent Call",RowIndex); 
}
public MemberOfRL ParentCall() throws Exception 
{ 
return sfdc.RL(RList,"Parent Call"); 
}

public MemberOfRL Status(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Status",RowIndex); 
}
public MemberOfRL Status() throws Exception 
{ 
return sfdc.RL(RList,"Status"); 
}

public MemberOfRL CallType(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Call Type",RowIndex); 
}
public MemberOfRL CallType() throws Exception 
{ 
return sfdc.RL(RList,"Call Type"); 
}

public MemberOfRL LastModifiedByAlias(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Modified By Alias",RowIndex); 
}
public MemberOfRL LastModifiedByAlias() throws Exception 
{ 
return sfdc.RL(RList,"Last Modified By Alias"); 
}

public MemberOfRL LastModifiedDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date",RowIndex); 
}
public MemberOfRL LastModifiedDate() throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date"); 
}

}



 public Columns_CallDiscussionsAccounts RL_CallDiscussionsAccounts() throws Exception{ 
return new Columns_CallDiscussionsAccounts("Call Discussions(Accounts)"); 
} 
public class Columns_CallDiscussionsAccounts{ 
Columns_CallDiscussionsAccounts(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Date(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Date",RowIndex); 
}
public MemberOfRL Date() throws Exception 
{ 
return sfdc.RL(RList,"Date"); 
}

public MemberOfRL Call(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Call",RowIndex); 
}
public MemberOfRL Call() throws Exception 
{ 
return sfdc.RL(RList,"Call"); 
}

public MemberOfRL Product(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Product",RowIndex); 
}
public MemberOfRL Product() throws Exception 
{ 
return sfdc.RL(RList,"Product"); 
}

public MemberOfRL CallDiscussion(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Call Discussion",RowIndex); 
}
public MemberOfRL CallDiscussion() throws Exception 
{ 
return sfdc.RL(RList,"Call Discussion"); 
}

}



 public Columns_CallSamples RL_CallSamples() throws Exception{ 
return new Columns_CallSamples("Call Samples"); 
} 
public class Columns_CallSamples{ 
Columns_CallSamples(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL CallSampleName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Call Sample Name",RowIndex); 
}
public MemberOfRL CallSampleName() throws Exception 
{ 
return sfdc.RL(RList,"Call Sample Name"); 
}

public MemberOfRL Call(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Call",RowIndex); 
}
public MemberOfRL Call() throws Exception 
{ 
return sfdc.RL(RList,"Call"); 
}

public MemberOfRL Date(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Date",RowIndex); 
}
public MemberOfRL Date() throws Exception 
{ 
return sfdc.RL(RList,"Date"); 
}

public MemberOfRL Product(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Product",RowIndex); 
}
public MemberOfRL Product() throws Exception 
{ 
return sfdc.RL(RList,"Product"); 
}

public MemberOfRL Quantity(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Quantity",RowIndex); 
}
public MemberOfRL Quantity() throws Exception 
{ 
return sfdc.RL(RList,"Quantity"); 
}

public MemberOfRL QuantityShipped(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Quantity Shipped",RowIndex); 
}
public MemberOfRL QuantityShipped() throws Exception 
{ 
return sfdc.RL(RList,"Quantity Shipped"); 
}

public MemberOfRL DeliveryStatus(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Delivery Status",RowIndex); 
}
public MemberOfRL DeliveryStatus() throws Exception 
{ 
return sfdc.RL(RList,"Delivery Status"); 
}

public MemberOfRL InvoiceNumber(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Invoice Number",RowIndex); 
}
public MemberOfRL InvoiceNumber() throws Exception 
{ 
return sfdc.RL(RList,"Invoice Number"); 
}

public MemberOfRL SampleDeliveryDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Sample Delivery Date",RowIndex); 
}
public MemberOfRL SampleDeliveryDate() throws Exception 
{ 
return sfdc.RL(RList,"Sample Delivery Date"); 
}

public MemberOfRL LastModifiedDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date",RowIndex); 
}
public MemberOfRL LastModifiedDate() throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date"); 
}

}



 public Columns_CallKeyMessagesAccounts RL_CallKeyMessagesAccounts() throws Exception{ 
return new Columns_CallKeyMessagesAccounts("Call Key Messages(Accounts)"); 
} 
public class Columns_CallKeyMessagesAccounts{ 
Columns_CallKeyMessagesAccounts(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_SampleLimits RL_SampleLimits() throws Exception{ 
return new Columns_SampleLimits("Sample Limits"); 
} 
public class Columns_SampleLimits{ 
Columns_SampleLimits(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL SampleLimitName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Sample Limit Name",RowIndex); 
}
public MemberOfRL SampleLimitName() throws Exception 
{ 
return sfdc.RL(RList,"Sample Limit Name"); 
}

public MemberOfRL StartDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Start Date",RowIndex); 
}
public MemberOfRL StartDate() throws Exception 
{ 
return sfdc.RL(RList,"Start Date"); 
}

public MemberOfRL EndDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"End Date",RowIndex); 
}
public MemberOfRL EndDate() throws Exception 
{ 
return sfdc.RL(RList,"End Date"); 
}

public MemberOfRL LimitQuantity(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Limit Quantity",RowIndex); 
}
public MemberOfRL LimitQuantity() throws Exception 
{ 
return sfdc.RL(RList,"Limit Quantity"); 
}

public MemberOfRL DisbursedQuantity(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Disbursed Quantity",RowIndex); 
}
public MemberOfRL DisbursedQuantity() throws Exception 
{ 
return sfdc.RL(RList,"Disbursed Quantity"); 
}

public MemberOfRL RemainingQuantity(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Remaining Quantity",RowIndex); 
}
public MemberOfRL RemainingQuantity() throws Exception 
{ 
return sfdc.RL(RList,"Remaining Quantity"); 
}

}



 public Columns_MedicalInquiries RL_MedicalInquiries() throws Exception{ 
return new Columns_MedicalInquiries("Medical Inquiries"); 
} 
public class Columns_MedicalInquiries{ 
Columns_MedicalInquiries(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_MultichannelConsents RL_MultichannelConsents() throws Exception{ 
return new Columns_MultichannelConsents("Multichannel Consents"); 
} 
public class Columns_MultichannelConsents{ 
Columns_MultichannelConsents(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL OptNumber(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Opt Number",RowIndex); 
}
public MemberOfRL OptNumber() throws Exception 
{ 
return sfdc.RL(RList,"Opt Number"); 
}

public MemberOfRL RecordType(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Record Type",RowIndex); 
}
public MemberOfRL RecordType() throws Exception 
{ 
return sfdc.RL(RList,"Record Type"); 
}

public MemberOfRL ChannelValue(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Channel Value",RowIndex); 
}
public MemberOfRL ChannelValue() throws Exception 
{ 
return sfdc.RL(RList,"Channel Value"); 
}

public MemberOfRL OptType(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Opt Type",RowIndex); 
}
public MemberOfRL OptType() throws Exception 
{ 
return sfdc.RL(RList,"Opt Type"); 
}

public MemberOfRL CaptureDatetime(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Capture Datetime",RowIndex); 
}
public MemberOfRL CaptureDatetime() throws Exception 
{ 
return sfdc.RL(RList,"Capture Datetime"); 
}

}



 public Columns_MultichannelActivities RL_MultichannelActivities() throws Exception{ 
return new Columns_MultichannelActivities("Multichannel Activities"); 
} 
public class Columns_MultichannelActivities{ 
Columns_MultichannelActivities(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL MultichannelActivityName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Multichannel Activity Name",RowIndex); 
}
public MemberOfRL MultichannelActivityName() throws Exception 
{ 
return sfdc.RL(RList,"Multichannel Activity Name"); 
}

public MemberOfRL SentEmail(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Sent Email",RowIndex); 
}
public MemberOfRL SentEmail() throws Exception 
{ 
return sfdc.RL(RList,"Sent Email"); 
}

public MemberOfRL TotalDuration(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Total Duration",RowIndex); 
}
public MemberOfRL TotalDuration() throws Exception 
{ 
return sfdc.RL(RList,"Total Duration"); 
}

public MemberOfRL CreatedDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Created Date",RowIndex); 
}
public MemberOfRL CreatedDate() throws Exception 
{ 
return sfdc.RL(RList,"Created Date"); 
}

}



 public Columns_NotesAttachments RL_NotesAttachments() throws Exception{ 
return new Columns_NotesAttachments("Notes & Attachments"); 
} 
public class Columns_NotesAttachments{ 
Columns_NotesAttachments(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_EventAttendeesAccount RL_EventAttendeesAccount() throws Exception{ 
return new Columns_EventAttendeesAccount("Event Attendees(Account)"); 
} 
public class Columns_EventAttendeesAccount{ 
Columns_EventAttendeesAccount(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_SurveyTargets RL_SurveyTargets() throws Exception{ 
return new Columns_SurveyTargets("Survey Targets"); 
} 
public class Columns_SurveyTargets{ 
Columns_SurveyTargets(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL SurveyTarget(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Survey Target",RowIndex); 
}
public MemberOfRL SurveyTarget() throws Exception 
{ 
return sfdc.RL(RList,"Survey Target"); 
}

}



 public Columns_CyclePlanTargets RL_CyclePlanTargets() throws Exception{ 
return new Columns_CyclePlanTargets("Cycle Plan Targets"); 
} 
public class Columns_CyclePlanTargets{ 
Columns_CyclePlanTargets(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_DataChangeRequests RL_DataChangeRequests() throws Exception{ 
return new Columns_DataChangeRequests("Data Change Requests"); 
} 
public class Columns_DataChangeRequests{ 
Columns_DataChangeRequests(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL DataChangeRequestName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Data Change Request Name",RowIndex); 
}
public MemberOfRL DataChangeRequestName() throws Exception 
{ 
return sfdc.RL(RList,"Data Change Request Name"); 
}

public MemberOfRL Status(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Status",RowIndex); 
}
public MemberOfRL Status() throws Exception 
{ 
return sfdc.RL(RList,"Status"); 
}

public MemberOfRL CreatedDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Created Date",RowIndex); 
}
public MemberOfRL CreatedDate() throws Exception 
{ 
return sfdc.RL(RList,"Created Date"); 
}

public MemberOfRL ApprovedByManager(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Approved By Manager",RowIndex); 
}
public MemberOfRL ApprovedByManager() throws Exception 
{ 
return sfdc.RL(RList,"Approved By Manager"); 
}

public MemberOfRL Result(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Result",RowIndex); 
}
public MemberOfRL Result() throws Exception 
{ 
return sfdc.RL(RList,"Result"); 
}

public MemberOfRL CreatedBy(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Created By",RowIndex); 
}
public MemberOfRL CreatedBy() throws Exception 
{ 
return sfdc.RL(RList,"Created By"); 
}

public MemberOfRL LastModifiedDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date",RowIndex); 
}
public MemberOfRL LastModifiedDate() throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date"); 
}

public MemberOfRL LastModifiedByAlias(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Modified By Alias",RowIndex); 
}
public MemberOfRL LastModifiedByAlias() throws Exception 
{ 
return sfdc.RL(RList,"Last Modified By Alias"); 
}

}

}

