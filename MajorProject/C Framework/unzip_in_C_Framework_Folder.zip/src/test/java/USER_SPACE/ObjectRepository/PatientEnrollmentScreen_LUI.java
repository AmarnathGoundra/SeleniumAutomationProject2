package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 

import org.openqa.selenium.remote.RemoteWebDriver; 

//import com.mop.qa.test.bvt.$missing$;




import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class PatientEnrollmentScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = "";


public PatientEnrollmentScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver);
System.out.println("Constructor call from OR: PatientEnrollmentScreen_LUI - remoteDriver");
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public PatientEnrollmentScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
System.out.println("Constructor call from OR: PatientEnrollmentScreen_LUI - appiumDriver");
sfdc = new SFDCAutomationFW(appiumDriver); 
}

//************************* Functions for Custom Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Selectanobjecttolimityoursearch_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select an object to limit your search"); 
} 
public MemberOfHealthCloud_LUI Title_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Title"); 
} 
public MemberOfHealthCloud_LUI FirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("First Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI LastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Last Name"); 
} 
public MemberOfHealthCloud_LUI SSNID_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SSN ID"); 
} 
public MemberOfHealthCloud_LUI Gender_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Gender"); 
} 
public MemberOfHealthCloud_LUI BirthDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Birth Date"); 
} 
public MemberOfHealthCloud_LUI MainContact_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Main Contact"); 
} 
public MemberOfHealthCloud_LUI AddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Address Line 1"); 
} 
public MemberOfHealthCloud_LUI AddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Address Line 2"); 
} 
public MemberOfHealthCloud_LUI CityTown_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("City/Town"); 
} 
public MemberOfHealthCloud_LUI Postcode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Postcode"); 
} 
public MemberOfHealthCloud_LUI Email_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Email"); 
} 

public MemberOfHealthCloud_LUI Phone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Phone"); 
} 
public MemberOfHealthCloud_LUI CarerFirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer First Name"); 
} 
public MemberOfHealthCloud_LUI CarerLastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Last Name"); 
} 
public MemberOfHealthCloud_LUI Relationshiptopatient_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Relationship to patient"); 
} 
public MemberOfHealthCloud_LUI CarerAddressline1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Address line1"); 
} 
public MemberOfHealthCloud_LUI CarerAddressline2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Address line2"); 
} 
public MemberOfHealthCloud_LUI CarerCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer City"); 
} 
public MemberOfHealthCloud_LUI CarerPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Postal Code"); 
} 
public MemberOfHealthCloud_LUI CarerEmail_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Email"); 
} 
public MemberOfHealthCloud_LUI CarerPhone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Phone"); 
} 
public MemberOfHealthCloud_LUI Next_HealthCloudButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Next"); 
} 

public MemberOfHealthCloud_LUI Previous_HealthCloudButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Previous"); 
} 

public MemberOfHealthCloud_LUI Submit_HealthCloudButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Submit"); 
} 


public MemberOfHealthCloud_LUI Date_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Date"); 
} 

public MemberOfField_LUI SSNIDField() throws Exception{  
return sfdc.Field_LUI("SSN ID"); 
} 
//************************* Functions for Custom Fields ***************************** // 
 
public MemberOfCustom_LUI SelectanobjecttolimityoursearchCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Select an object to limit your search"); 
} 
public MemberOfCustom_LUI TitleCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Title"); 
} 
public MemberOfCustom_LUI FirstNameCustomField() throws Exception{ 
return sfdc.CustomField_LUI("*First Name"); 
} 
public MemberOfCustom_LUI CustomField() throws Exception{ 
return sfdc.CustomField_LUI("*"); 
} 
public MemberOfCustom_LUI LastNameCustomField() throws Exception{ 
return sfdc.CustomField_LUI("*Last Name"); 
} 
public MemberOfCustom_LUI SSNIDCustomField() throws Exception{ 
return sfdc.CustomField_LUI("*SSN ID"); 
} 
public MemberOfCustom_LUI GenderCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Gender"); 
} 
public MemberOfCustom_LUI BirthDateCustomField() throws Exception{ 
return sfdc.CustomField_LUI("*Birth Date"); 
} 
public MemberOfCustom_LUI MainContactCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Main Contact"); 
} 
public MemberOfCustom_LUI AddressLine1CustomField() throws Exception{ 
return sfdc.CustomField_LUI("Address Line 1"); 
} 
public MemberOfCustom_LUI AddressLine2CustomField() throws Exception{ 
return sfdc.CustomField_LUI("Address Line 2"); 
} 
public MemberOfCustom_LUI CityTownCustomField() throws Exception{ 
return sfdc.CustomField_LUI("City/Town"); 
} 
public MemberOfCustom_LUI PostcodeCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Postcode"); 
} 
public MemberOfCustom_LUI EmailCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Email"); 
} 
public MemberOfCustom_LUI PhoneCustomField() throws Exception{ 
return sfdc.CustomField_LUI("*Phone"); 
} 
public MemberOfCustom_LUI CarerFirstNameCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer First Name"); 
} 
public MemberOfCustom_LUI CarerLastNameCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Last Name"); 
} 
public MemberOfCustom_LUI RelationshiptopatientCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Relationship to patient"); 
} 
public MemberOfCustom_LUI CarerAddressline1CustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Address line1"); 
} 
public MemberOfCustom_LUI CarerAddressline2CustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Address line2"); 
} 
public MemberOfCustom_LUI CarerCityCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer City"); 
} 
public MemberOfCustom_LUI CarerPostalCodeCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Postal Code"); 
} 
public MemberOfCustom_LUI CarerEmailCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Email"); 
} 
public MemberOfCustom_LUI CarerPhoneCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Phone"); 
} 

public MemberOfHealthCloud_LUI TreatingCentreName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Centre Name"); 
} 

//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
