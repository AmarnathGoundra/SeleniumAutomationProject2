package USER_SPACE.ObjectRepository;

import org.openqa.selenium.remote.RemoteWebDriver;
import io.appium.java_client.AppiumDriver;

import SOURCE_CODE.SFDC.*;

public class LeadScreen extends SFDCAutomationFW {

	public SFDCAutomationFW sfdc;
	public String RList = "";
	public String SecName = "";
	
	
	public LeadScreen(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
		sfdc = new SFDCAutomationFW(remoteDriver);
	}
	
	public LeadScreen(AppiumDriver appiumDriver) {
		super(appiumDriver);
		sfdc = new SFDCAutomationFW(appiumDriver);
	}

	

	public MemberOfButton EditButton() throws Exception {
		return sfdc.Button("Edit");
	}
	
	public MemberOfButton SaveButton() throws Exception {
		return sfdc.Button("Save");
	}

	public MemberOfButton NewButton() throws Exception {
		return sfdc.Button("New");
	}
	
	public MemberOfField NameField() throws Exception {
		return sfdc.Field("Name");
	}
	public MemberOfField LeadStatusField() throws Exception {
		return sfdc.Field("Lead Status");
	}
	public MemberOfField CreatedByField() throws Exception {
		return sfdc.Field("Created By");
	}
	public MemberOfField LeadSourceField() throws Exception {
		return sfdc.Field("Lead Source");
	}

	public MemberOfField AssignusingactiveassignmentruleField() throws Exception {
		return sfdc.Field("Assign using active assignment rule");
	}
	public MemberOfField CampaignField() throws Exception {
		return sfdc.Field("Campaign");
	}


	public MemberOfField FirstNameField() throws Exception {
		return sfdc.Field("First Name");
	}

	public MemberOfField LastNameField() throws Exception {
		return sfdc.Field("Last Name");
	}
	
	public MemberOfField CompanyField() throws Exception {
		return sfdc.Field("Company");
	}
	
	
	
	// ************************* Functions for Sections ***************************** // 
	
	public MemberOfSEC SEC_LeadDetail_CompanyField() throws Exception {
		return sfdc.Section("Lead Detail", "Company");
	}

	public MemberOfSEC SEC_LeadDetail_NameField() throws Exception {
		return sfdc.Section("Lead Detail", "Name");
	}
	public MemberOfSEC SEC_LeadDetail_LeadSourceField() throws Exception {
		return sfdc.Section("Lead Detail", "Lead Source");
	}
	public MemberOfSEC SEC_LeadDetail_LeadStatusField() throws Exception {
		return sfdc.Section("Lead Detail", "Lead Status");
	}
	

	// ************************* Functions for RelatedList ***************************** // 
	
	public Columns_CampaignHistory RL_CampaignHistory() throws Exception{ 
		return new Columns_CampaignHistory("Campaign History"); 
		} 
		public class Columns_CampaignHistory{ 
		Columns_CampaignHistory(String RL) 
		{ 
		RList = RL; 
		} 
		
		
		public MemberOfRL Action(Integer RowIndex) throws Exception 
		{ 
		return sfdc.RL(RList,"Action",RowIndex); 
		}
		public MemberOfRL Action() throws Exception 
		{ 
		return sfdc.RL(RList,"Action"); 
		}
		
		
		public MemberOfRL CampaignName(Integer RowIndex) throws Exception 
		{ 
		return sfdc.RL(RList,"Campaign Name",RowIndex); 
		}
		public MemberOfRL CampaignName() throws Exception 
		{ 
		return sfdc.RL(RList,"Campaign Name"); 
		}
		
		public MemberOfRL Type(Integer RowIndex) throws Exception 
		{ 
		return sfdc.RL(RList,"Type",RowIndex); 
		}
		public MemberOfRL Type() throws Exception 
		{ 
		return sfdc.RL(RList,"Type"); 
		}
			
		
		}
	
}
