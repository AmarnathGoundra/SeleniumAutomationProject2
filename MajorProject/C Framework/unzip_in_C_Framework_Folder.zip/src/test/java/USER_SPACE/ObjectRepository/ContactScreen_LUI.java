package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class ContactScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public ContactScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public ContactScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI ContactOwnerField() throws Exception{  
return sfdc.Field_LUI("Contact Owner"); 
} 
 
public MemberOfField_LUI PhoneField() throws Exception{  
return sfdc.Field_LUI("Phone"); 
} 
 
public MemberOfField_LUI NameField() throws Exception{  
return sfdc.Field_LUI("Name"); 
} 
 
public MemberOfField_LUI HomePhoneField() throws Exception{  
return sfdc.Field_LUI("Home Phone"); 
} 
 
public MemberOfField_LUI AccountNameField() throws Exception{  
return sfdc.Field_LUI("Account Name"); 
} 
 
public MemberOfField_LUI MobileField() throws Exception{  
return sfdc.Field_LUI("Mobile"); 
} 
 
public MemberOfField_LUI TitleField() throws Exception{  
return sfdc.Field_LUI("Title"); 
} 
 
public MemberOfField_LUI OtherPhoneField() throws Exception{  
return sfdc.Field_LUI("Other Phone"); 
} 
 
public MemberOfField_LUI DepartmentField() throws Exception{  
return sfdc.Field_LUI("Department"); 
} 
 
public MemberOfField_LUI FaxField() throws Exception{  
return sfdc.Field_LUI("Fax"); 
} 
 
public MemberOfField_LUI BirthdateField() throws Exception{  
return sfdc.Field_LUI("Birthdate"); 
} 
 
public MemberOfField_LUI EmailField() throws Exception{  
return sfdc.Field_LUI("Email"); 
} 
 
public MemberOfField_LUI ReportsToField() throws Exception{  
return sfdc.Field_LUI("Reports To"); 
} 
 
public MemberOfField_LUI AssistantField() throws Exception{  
return sfdc.Field_LUI("Assistant"); 
} 
 
public MemberOfField_LUI LeadSourceField() throws Exception{  
return sfdc.Field_LUI("Lead Source"); 
} 
 
public MemberOfField_LUI AsstPhoneField() throws Exception{  
return sfdc.Field_LUI("Asst. Phone"); 
} 
 
public MemberOfField_LUI MailingAddressField() throws Exception{  
return sfdc.Field_LUI("Mailing Address"); 
} 
 
public MemberOfField_LUI OtherAddressField() throws Exception{  
return sfdc.Field_LUI("Other Address"); 
} 
 
public MemberOfField_LUI LanguagesField() throws Exception{  
return sfdc.Field_LUI("Languages"); 
} 
 
public MemberOfField_LUI LevelField() throws Exception{  
return sfdc.Field_LUI("Level"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
public MemberOfField_LUI SkillsField() throws Exception{  
return sfdc.Field_LUI("Skills"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 // ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewCaseButton() throws Exception{ 
return sfdc.Button_LUI("New Case"); 
}
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
public MemberOfButton_LUI NewNoteButton() throws Exception{ 
return sfdc.Button_LUI("New Note"); 
} 
public MemberOfButton_LUI SubmitforApprovalButton() throws Exception{ 
return sfdc.Button_LUI("Submit for Approval"); 
} 
public MemberOfButton_LUI NewButton() throws Exception{ 
return sfdc.Button_LUI("New"); 
} 
public MemberOfButton_LUI AddtoCampaignButton() throws Exception{ 
return sfdc.Button_LUI("Add to Campaign"); 
} 
public MemberOfButton_LUI UploadFilesButton() throws Exception{ 
return sfdc.Button_LUI("Upload Files"); 
} 
public MemberOfButton_LUI MenuButtonCloneButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Clone"); 
} 
public MemberOfButton_LUI MenuButtonEditButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Edit"); 
} 
public MemberOfButton_LUI MenuButtonDeleteButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Delete"); 
} 
public MemberOfButton_LUI MenuButtonChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Change Owner"); 
} 
public MemberOfButton_LUI MenuButtonCheckforNewDataButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Check for New Data"); 
} 
//************************* Functions for All Apps ***************************** // 
 
//************************* Functions for Tabs List ***************************** // 
 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Searchbyobjecttype_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search by object type"); 
} 
public MemberOfHealthCloud_LUI Search_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search..."); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
