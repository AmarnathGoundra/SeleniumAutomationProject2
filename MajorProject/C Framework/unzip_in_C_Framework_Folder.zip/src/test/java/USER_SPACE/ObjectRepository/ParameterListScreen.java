package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class ParameterListScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public ParameterListScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public ParameterListScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 

//************************* Functions for Buttons***************************** // 
 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton CancelButton() throws Exception{ 
return sfdc.Button("Cancel"); 
} 
public MemberOfButton EditButton() throws Exception{ 
return sfdc.Button("Edit"); 
} 
public MemberOfButton DeleteButton() throws Exception{ 
return sfdc.Button("Delete"); 
} 
public MemberOfButton CloneButton() throws Exception{ 
return sfdc.Button("Clone"); 
} 
public MemberOfButton NewNoteButton() throws Exception{ 
return sfdc.Button("New Note"); 
} 
public MemberOfButton AttachFileButton() throws Exception{ 
return sfdc.Button("Attach File"); 
} 
public MemberOfButton NewParameterButton() throws Exception{ 
return sfdc.Button("New Parameter"); 
} 
public MemberOfButton OKButton() throws Exception{ 
return sfdc.Button("OK"); 
} 
//************************* Functions for Field Names ***************************** // 
 
public MemberOfField ParameterListNameField() throws Exception{ 
	return sfdc.Field("Parameter List Name"); 
} 
public MemberOfField DescriptionField() throws Exception{ 
	return sfdc.Field("Description"); 
} 
public MemberOfField VersionField() throws Exception{ 
	return sfdc.Field("Version"); 
} 
public MemberOfField ExpiredField() throws Exception{ 
	return sfdc.Field("Expired ?"); 
} 
public MemberOfField CreatedByField() throws Exception{ 
	return sfdc.Field("Created By"); 
} 
public MemberOfField LastModifiedByField() throws Exception{ 
	return sfdc.Field("Last Modified By"); 
} 
}

