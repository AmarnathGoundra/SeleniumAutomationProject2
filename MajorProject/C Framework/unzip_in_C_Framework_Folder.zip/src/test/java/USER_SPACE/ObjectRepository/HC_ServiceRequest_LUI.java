package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class HC_ServiceRequest_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public HC_ServiceRequest_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public HC_ServiceRequest_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI PleaseselecttheTypeofreportField() throws Exception{  
return sfdc.Field_LUI("Please select the Type of report"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
  
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI EditButton() throws Exception{ 
return sfdc.Button_LUI("Edit"); 
} 
public MemberOfButton_LUI GenerateAEPQCReportButton() throws Exception{ 
return sfdc.Button_LUI("Generate AE/ PQC Report"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Selectanobjecttolimityoursearch_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select an object to limit your search"); 
} 
public MemberOfHealthCloud_LUI SearchSalesforce_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Salesforce"); 
} 
public MemberOfHealthCloud_LUI PleaseselecttheTypeofreport_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Please select the Type of report"); 
} 
public MemberOfHealthCloud_LUI Eventtype_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Event type"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI AbbVieAEreference_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("AbbVie AE reference #"); 
} 
public MemberOfHealthCloud_LUI AbbViePQCreference_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("AbbVie PQC reference #"); 
} 
public MemberOfHealthCloud_LUI HealthcloudAEPQCcaseID_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Healthcloud AE/PQC case ID #"); 
} 
public MemberOfHealthCloud_LUI Programtype_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Program type"); 
} 
public MemberOfHealthCloud_LUI Otherreference_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Other reference #"); 
} 
public MemberOfHealthCloud_LUI Typeofreport_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Type of report"); 
} 
public MemberOfHealthCloud_LUI NotifyQA_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Notify QA?"); 
} 
public MemberOfHealthCloud_LUI Vendorname_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Vendor name"); 
} 
public MemberOfHealthCloud_LUI Programname_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Program name"); 
} 
public MemberOfHealthCloud_LUI Awarenessdate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Awareness date"); 
} 
public MemberOfHealthCloud_LUI PersonnelreportingeventtoAbbVie_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Personnel reporting event to AbbVie"); 
} 
public MemberOfHealthCloud_LUI Personnelreportingcontactemail_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Personnel reporting contact e-mail"); 
} 
public MemberOfHealthCloud_LUI Personnelreportingcontactphonenumber_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Personnel reporting contact phone number"); 
} 
public MemberOfHealthCloud_LUI DatevendornotifiedAbbVie_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Date vendor notified AbbVie"); 
} 
public MemberOfHealthCloud_LUI Patientinitials_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Patient initials"); 
} 
public MemberOfHealthCloud_LUI PatientID_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Patient ID"); 
} 
public MemberOfHealthCloud_LUI Dateofbirth_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Date of birth"); 
} 
public MemberOfHealthCloud_LUI Age_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Age"); 
} 
public MemberOfHealthCloud_LUI Sex_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Sex"); 
} 
public MemberOfHealthCloud_LUI Ethnicity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Ethnicity"); 
} 
public MemberOfHealthCloud_LUI Heightcm_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Height (cm)"); 
} 
public MemberOfHealthCloud_LUI Weightkg_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Weight (kg)"); 
} 
public MemberOfHealthCloud_LUI Pregnancy_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Pregnancy"); 
} 
public MemberOfHealthCloud_LUI Pregnancyweeks_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Pregnancy (weeks)"); 
} 
public MemberOfHealthCloud_LUI Reportertype_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Reporter type"); 
} 
public MemberOfHealthCloud_LUI Otherreportertype_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Other reporter type"); 
} 
public MemberOfHealthCloud_LUI Reportername_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Reporter name"); 
} 
public MemberOfHealthCloud_LUI Streetaddress_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Street address"); 
} 
public MemberOfHealthCloud_LUI City_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("City"); 
} 
public MemberOfHealthCloud_LUI State_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("State"); 
} 
public MemberOfHealthCloud_LUI Postalcode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Postal code"); 
} 
public MemberOfHealthCloud_LUI Country_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Country"); 
} 
public MemberOfHealthCloud_LUI Phonenumber_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Phone number"); 
} 
public MemberOfHealthCloud_LUI Reporteremail_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Reporter email"); 
} 
public MemberOfHealthCloud_LUI DoespatientconsenttohavephysicianHCPcontacted_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Does patient consent to have physician/HCP contacted?"); 
} 
public MemberOfHealthCloud_LUI Physicianname_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Physician name"); 
} 
public MemberOfHealthCloud_LUI Physicianspecialty_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Physician specialty"); 
} 
public MemberOfHealthCloud_LUI Phoneno_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Phone no"); 
} 
public MemberOfHealthCloud_LUI Emailaddress_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Email address"); 
} 
public MemberOfHealthCloud_LUI Institutename_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Institute name"); 
} 
public MemberOfHealthCloud_LUI Adverseeventsproductcomplaintsdescription_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Adverse event(s)/ product complaint(s) description"); 
} 
public MemberOfHealthCloud_LUI Treatmentmedicationsdiagnosticsandlabvalues_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treatment medications, diagnostics and lab values"); 
} 
public MemberOfHealthCloud_LUI Wereanyconcomitantdrugstaken_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Were any concomitant drugs taken?"); 
} 
public MemberOfHealthCloud_LUI Wastherearelevantmedicalhistory_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Was there a relevant medical history?"); 
} 
public MemberOfHealthCloud_LUI Allergies_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Allergies"); 
} 
//************************* Functions for HC Button ***************************** // 
 
public MemberOfHealthCloud_LUI Save_HealthCloudButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Save"); 
} 
public MemberOfHealthCloud_LUI Submit_HealthCloudButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Submit"); 
} 
public MemberOfHealthCloud_LUI AddRow_HealthCloudButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Add Row"); 
} 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
