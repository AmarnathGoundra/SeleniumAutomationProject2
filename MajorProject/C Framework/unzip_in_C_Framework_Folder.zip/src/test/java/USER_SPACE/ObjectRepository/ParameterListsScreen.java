package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class ParameterListsScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public ParameterListsScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public ParameterListsScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


// ************************ Functions for Fields ************************************** 
 
 
 
// ************************* Functions & Static Classes for Sections ***************************** // 
 

 
 
 // **************** Functions & Static Classes for Related List ******************** 
 

 
 
public MemberOfButton NewButton() throws Exception{ 
return sfdc.Button("New"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
}
