package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class ProductBusketScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public ProductBusketScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public ProductBusketScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI BasketNameField() throws Exception{  
return sfdc.Field_LUI("Basket Name"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI OpportunityField() throws Exception{  
return sfdc.Field_LUI("Opportunity"); 
} 
 
public MemberOfField_LUI SynchronisedWithOpportunityField() throws Exception{  
return sfdc.Field_LUI("Synchronised With Opportunity"); 
} 
 
public MemberOfField_LUI BasketStatusField() throws Exception{  
return sfdc.Field_LUI("Basket Status"); 
} 
 
public MemberOfField_LUI BasketStageField() throws Exception{  
return sfdc.Field_LUI("Basket Stage"); 
} 
 
public MemberOfField_LUI CustomerField() throws Exception{  
return sfdc.Field_LUI("Customer"); 
} 
 
public MemberOfField_LUI TotalContractValueField() throws Exception{  
return sfdc.Field_LUI("Total Contract Value"); 
} 
 
public MemberOfField_LUI ProjectComplexityField() throws Exception{  
return sfdc.Field_LUI("Project Complexity"); 
} 
 
public MemberOfField_LUI PMRequiredField() throws Exception{  
return sfdc.Field_LUI("PM Required"); 
} 
 
public MemberOfField_LUI ProjectManagerContactNumberField() throws Exception{  
return sfdc.Field_LUI("Project Manager Contact Number"); 
} 
 
public MemberOfField_LUI ProjectIDField() throws Exception{  
return sfdc.Field_LUI("Project ID"); 
} 
 
public MemberOfField_LUI ProjectManagerUserIDField() throws Exception{  
return sfdc.Field_LUI("Project Manager User ID"); 
} 
 
public MemberOfField_LUI ProjectManagerEmailField() throws Exception{  
return sfdc.Field_LUI("Project Manager Email"); 
} 
 
public MemberOfField_LUI BillingAccountField() throws Exception{  
return sfdc.Field_LUI("Billing Account"); 
} 
 
public MemberOfField_LUI BillingAddressField() throws Exception{  
return sfdc.Field_LUI("Billing Address"); 
} 
 
public MemberOfField_LUI SiteNameField() throws Exception{  
return sfdc.Field_LUI("Site Name"); 
} 
 
public MemberOfField_LUI ContractTermField() throws Exception{  
return sfdc.Field_LUI("Contract Term"); 
} 
 
public MemberOfField_LUI SiteAddressField() throws Exception{  
return sfdc.Field_LUI("Site Address"); 
} 
 
public MemberOfField_LUI SiteNetworkZoneField() throws Exception{  
return sfdc.Field_LUI("Site Network Zone"); 
} 
 
public MemberOfField_LUI ServiceabilityLocationField() throws Exception{  
return sfdc.Field_LUI("Serviceability Location"); 
} 
 
public MemberOfField_LUI RemainingTermField() throws Exception{  
return sfdc.Field_LUI("Remaining Term"); 
} 
 
public MemberOfField_LUI NBNAvailabilityField() throws Exception{  
return sfdc.Field_LUI("NBN Availability"); 
} 
 
public MemberOfField_LUI ReadyForServiceDateField() throws Exception{  
return sfdc.Field_LUI("Ready For Service Date"); 
} 
 
public MemberOfField_LUI NBNTechnologyTypeField() throws Exception{  
return sfdc.Field_LUI("NBN Technology Type"); 
} 
 
public MemberOfField_LUI VacantCopperPairAvailabilityField() throws Exception{  
return sfdc.Field_LUI("Vacant Copper Pair Availability"); 
} 
 
public MemberOfField_LUI MaxUploadSpeedField() throws Exception{  
return sfdc.Field_LUI("Max Upload Speed"); 
} 
 
public MemberOfField_LUI MaxDownloadSpeedField() throws Exception{  
return sfdc.Field_LUI("Max Download Speed"); 
} 
 
public MemberOfField_LUI NBNCompatibilityField() throws Exception{  
return sfdc.Field_LUI("NBN Compatibility"); 
} 
 
public MemberOfField_LUI TelstraFibreCompatibilityField() throws Exception{  
return sfdc.Field_LUI("Telstra Fibre Compatibility"); 
} 
 
public MemberOfField_LUI AccessTypeField() throws Exception{  
return sfdc.Field_LUI("Access Type"); 
} 
 
public MemberOfField_LUI BandwidthField() throws Exception{  
return sfdc.Field_LUI("Bandwidth"); 
} 
 
public MemberOfField_LUI QuantityField() throws Exception{  
return sfdc.Field_LUI("Quantity"); 
} 
 
public MemberOfField_LUI PatternTypeField() throws Exception{  
return sfdc.Field_LUI("Pattern Type"); 
} 
 
public MemberOfField_LUI SearchPatternField() throws Exception{  
return sfdc.Field_LUI("Search Pattern"); 
} 
 
public MemberOfField_LUI NotBeforeCRDField() throws Exception{  
return sfdc.Field_LUI("Not Before CRD"); 
} 
 
public MemberOfField_LUI PreferredCRDField() throws Exception{  
return sfdc.Field_LUI("Preferred CRD"); 
} 
 
public MemberOfField_LUI NotesField() throws Exception{  
return sfdc.Field_LUI("Notes"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI OrderSimulationButton() throws Exception{ 
return sfdc.Button_LUI("Order Simulation"); 
} 
public MemberOfButton_LUI CloneButton() throws Exception{ 
return sfdc.Button_LUI("Clone"); 
} 
public MemberOfButton_LUI EnrichedButton() throws Exception{ 
return sfdc.Button_LUI("Enriched"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
public MemberOfButton_LUI FinishButton() throws Exception{ 
return sfdc.Button_LUI("Finish"); 
} 
public MemberOfButton_LUI NewUserButton() throws Exception{ 
return sfdc.Button_LUI("New User"); 
} 
public MemberOfButton_LUI NewHandsetandAccessoriesButton() throws Exception{ 
return sfdc.Button_LUI("New Handset and Accessories"); 
} 
public MemberOfButton_LUI NewHuntGroupButton() throws Exception{ 
return sfdc.Button_LUI("New Hunt Group"); 
} 
} 
 
