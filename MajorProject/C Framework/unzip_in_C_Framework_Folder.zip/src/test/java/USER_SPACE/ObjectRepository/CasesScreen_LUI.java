package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class CasesScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public CasesScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public CasesScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI CaseNumberField() throws Exception{  
return sfdc.Field_LUI("Case Number"); 
} 
 
public MemberOfField_LUI CaseOwnerField() throws Exception{  
return sfdc.Field_LUI("Case Owner"); 
} 
 
public MemberOfField_LUI StatusField() throws Exception{  
return sfdc.Field_LUI("Status"); 
} 
 
public MemberOfField_LUI PriorityField() throws Exception{  
return sfdc.Field_LUI("Priority"); 
} 
 
public MemberOfField_LUI SubjectField() throws Exception{  
return sfdc.Field_LUI("Subject"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
public MemberOfField_LUI ContactNameField() throws Exception{  
return sfdc.Field_LUI("Contact Name"); 
} 
 
public MemberOfField_LUI ContactPhoneField() throws Exception{  
return sfdc.Field_LUI("Contact Phone"); 
} 
 
public MemberOfField_LUI AccountNameField() throws Exception{  
return sfdc.Field_LUI("Account Name"); 
} 
 
public MemberOfField_LUI ContactEmailField() throws Exception{  
return sfdc.Field_LUI("Contact Email"); 
} 
 
public MemberOfField_LUI TypeField() throws Exception{  
return sfdc.Field_LUI("Type"); 
} 
 
public MemberOfField_LUI CaseOriginField() throws Exception{  
return sfdc.Field_LUI("Case Origin"); 
} 
 
public MemberOfField_LUI CaseReasonField() throws Exception{  
return sfdc.Field_LUI("Case Reason"); 
} 
 
public MemberOfField_LUI WebEmailField() throws Exception{  
return sfdc.Field_LUI("Web Email"); 
} 
 
public MemberOfField_LUI WebCompanyField() throws Exception{  
return sfdc.Field_LUI("Web Company"); 
} 
 
public MemberOfField_LUI WebNameField() throws Exception{  
return sfdc.Field_LUI("Web Name"); 
} 
 
public MemberOfField_LUI WebPhoneField() throws Exception{  
return sfdc.Field_LUI("Web Phone"); 
} 
 
public MemberOfField_LUI DateTimeOpenedField() throws Exception{  
return sfdc.Field_LUI("Date/Time Opened"); 
} 
 
public MemberOfField_LUI DateTimeClosedField() throws Exception{  
return sfdc.Field_LUI("Date/Time Closed"); 
} 
 
public MemberOfField_LUI ProductField() throws Exception{  
return sfdc.Field_LUI("Product"); 
} 
 
public MemberOfField_LUI EngineeringReqNumberField() throws Exception{  
return sfdc.Field_LUI("Engineering Req Number"); 
} 
 
public MemberOfField_LUI PotentialLiabilityField() throws Exception{  
return sfdc.Field_LUI("Potential Liability"); 
} 
 
public MemberOfField_LUI SLAViolationField() throws Exception{  
return sfdc.Field_LUI("SLA Violation"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
public MemberOfField_LUI InternalCommentsField() throws Exception{  
return sfdc.Field_LUI("Internal Comments"); 
} 
 
public MemberOfField_LUI Field() throws Exception{  
return sfdc.Field_LUI("*"); 
} 
 
public MemberOfField_LUI SendnotificationemailtocontactField() throws Exception{  
return sfdc.Field_LUI("Send notification email to contact"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 public Columns_Cases LV_Cases() throws Exception{ 
return new Columns_Cases("Cases"); 
} 
public class Columns_Cases 
{ 
Columns_Cases(String RL) 
{ 
RList = RL;  
}  
public MemberOfLV_LUI CaseNumber() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Case Number"); 
} 
public MemberOfLV_LUI CaseNumber(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Case Number",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Subject() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Subject"); 
} 
public MemberOfLV_LUI Subject(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Subject",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Status() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Status"); 
} 
public MemberOfLV_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfLV_LUI DateTimeOpened() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Date/Time Opened"); 
} 
public MemberOfLV_LUI DateTimeOpened(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Date/Time Opened",TargetCOlumnValue); 
} 
public MemberOfLV_LUI CaseOwnerAlias() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Case Owner Alias"); 
} 
public MemberOfLV_LUI CaseOwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Case Owner Alias",TargetCOlumnValue); 
} 
public MemberOfLV_LUI NewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"NewButton");  
} 
public MemberOfLV_LUI ChangeOwnerButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Change OwnerButton");  
} 
public MemberOfLV_LUI CancelButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"CancelButton");  
} 
public MemberOfLV_LUI SaveNewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Save & NewButton");  
} 
public MemberOfLV_LUI SaveButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"SaveButton");  
} 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_Attachments RL_Attachments() throws Exception{ 
return new Columns_Attachments("Attachments"); 
} 
public class Columns_Attachments 
{ 
Columns_Attachments(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CreatedBy() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By"); 
} 
public MemberOfRL_LUI CreatedBy(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ContentSize() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Content Size"); 
} 
public MemberOfRL_LUI ContentSize(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Content Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Source() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Source"); 
} 
public MemberOfRL_LUI Source(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Source",TargetCOlumnValue); 
} 
public MemberOfRL_LUI UploadFilesButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Upload FilesButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_ActivityHistory RL_ActivityHistory() throws Exception{ 
return new Columns_ActivityHistory("Activity History"); 
} 
public class Columns_ActivityHistory 
{ 
Columns_ActivityHistory(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Subject() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Subject"); 
} 
public MemberOfRL_LUI Subject(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Subject",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Name() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Name"); 
} 
public MemberOfRL_LUI Name(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Task() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Task"); 
} 
public MemberOfRL_LUI Task(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Task",TargetCOlumnValue); 
} 
public MemberOfRL_LUI DueDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Due Date"); 
} 
public MemberOfRL_LUI DueDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Due Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AssignedTo() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Assigned To"); 
} 
public MemberOfRL_LUI AssignedTo(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Assigned To",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModifiedDateTime() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified Date/Time"); 
} 
public MemberOfRL_LUI LastModifiedDateTime(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified Date/Time",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AssignedFirstName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Assigned First Name"); 
} 
public MemberOfRL_LUI AssignedFirstName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Assigned First Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ViewAllButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"View AllButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_OpenActivities RL_OpenActivities() throws Exception{ 
return new Columns_OpenActivities("Open Activities"); 
} 
public class Columns_OpenActivities 
{ 
Columns_OpenActivities(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Subject() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Subject"); 
} 
public MemberOfRL_LUI Subject(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Subject",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Name() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Name"); 
} 
public MemberOfRL_LUI Name(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Task() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Task"); 
} 
public MemberOfRL_LUI Task(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Task",TargetCOlumnValue); 
} 
public MemberOfRL_LUI DueDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Due Date"); 
} 
public MemberOfRL_LUI DueDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Due Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Priority() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Priority"); 
} 
public MemberOfRL_LUI Priority(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Priority",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AssignedTo() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Assigned To"); 
} 
public MemberOfRL_LUI AssignedTo(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Assigned To",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewTaskButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"New TaskButton");  
} 
public MemberOfRL_LUI NewEventButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"New EventButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewButton() throws Exception{ 
return sfdc.Button_LUI("New"); 
} 
public MemberOfButton_LUI ChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("Change Owner"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveNewButton() throws Exception{ 
return sfdc.Button_LUI("Save & New"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
//************************* Functions for All Apps ***************************** // 
 
//************************* Functions for Tabs List ***************************** // 
 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Searchbyobjecttype_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search by object type"); 
} 
public MemberOfHealthCloud_LUI SearchCasesandmore_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Cases and more"); 
} 
public MemberOfHealthCloud_LUI Searchthislist_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search this list..."); 
} 
public MemberOfHealthCloud_LUI Select4items_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select 4 items"); 
} 
public MemberOfHealthCloud_LUI Selectitem1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 1"); 
} 
public MemberOfHealthCloud_LUI Selectitem2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 2"); 
} 
public MemberOfHealthCloud_LUI Selectitem3_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 3"); 
} 
public MemberOfHealthCloud_LUI Selectitem4_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 4"); 
} 
public MemberOfHealthCloud_LUI Search_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search..."); 
} 
public MemberOfHealthCloud_LUI Searchcontactstolinkarecord_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search contacts to link a record."); 
} 
public MemberOfHealthCloud_LUI Status_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Status"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI ContactName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Contact Name"); 
} 
public MemberOfHealthCloud_LUI AccountName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Account Name"); 
} 
public MemberOfHealthCloud_LUI WebEmail_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Web Email"); 
} 
public MemberOfHealthCloud_LUI WebCompany_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Web Company"); 
} 
public MemberOfHealthCloud_LUI WebName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Web Name"); 
} 
public MemberOfHealthCloud_LUI WebPhone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Web Phone"); 
} 
public MemberOfHealthCloud_LUI EngineeringReqNumber_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Engineering Req Number"); 
} 
public MemberOfHealthCloud_LUI Subject_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Subject"); 
} 
public MemberOfHealthCloud_LUI Description_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Description"); 
} 
public MemberOfHealthCloud_LUI InternalComments_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Internal Comments"); 
} 
public MemberOfHealthCloud_LUI Sendnotificationemailtocontact_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Send notification email to contact"); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
