package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class SolutionsScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public SolutionsScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public SolutionsScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


//************************* Functions for List Views***************************** // 
 
//************************* Functions for Buttons***************************** // 
 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton CancelButton() throws Exception{ 
return sfdc.Button("Cancel"); 
} 
public MemberOfButton EditButton() throws Exception{ 
return sfdc.Button("Edit"); 
} 
public MemberOfButton DeleteButton() throws Exception{ 
return sfdc.Button("Delete"); 
} 
public MemberOfButton AttachFileButton() throws Exception{ 
return sfdc.Button("Attach File"); 
} 
public MemberOfButton OKButton() throws Exception{ 
return sfdc.Button("OK"); 
} 
public MemberOfButton SaveNewButton() throws Exception{ 
return sfdc.Button("Save & New"); 
} 
//************************* Functions for Field Names ***************************** // 
 
public MemberOfField SolutionNumberField() throws Exception{ 
	return sfdc.Field("Solution Number"); 
} 
public MemberOfField PublicField() throws Exception{ 
	return sfdc.Field("Public"); 
} 

public MemberOfField VisibleinPublicKnowledgeBaseField() throws Exception{ 
	return sfdc.Field("Visible in Public Knowledge Base"); 
} 
public MemberOfField CreatedByField() throws Exception{ 
	return sfdc.Field("Created By"); 
} 
public MemberOfField LastModifiedByField() throws Exception{ 
	return sfdc.Field("Last Modified By"); 
} 

public MemberOfField SolutionDetailsField() throws Exception{ 
	return sfdc.Field("Solution Details"); 
} 
//************************* Functions for Section Name***************************** // 
 
public MemberOfSEC SEC_SolutionDetail_SolutionNumberField() throws Exception { 
return sfdc.Section("Solution Detail", "Solution Number"); 
}
public MemberOfSEC SEC_SolutionDetail_PublicField() throws Exception { 
return sfdc.Section("Solution Detail", "Public"); 
}
public MemberOfSEC SEC_SolutionDetail_StatusField() throws Exception { 
return sfdc.Section("Solution Detail", "Status"); 
}
public MemberOfSEC SEC_SolutionDetail_VisibleinPublicKnowledgeBaseField() throws Exception { 
return sfdc.Section("Solution Detail", "Visible in Public Knowledge Base"); 
}
public MemberOfSEC SEC_SolutionDetail_CreatedByField() throws Exception { 
return sfdc.Section("Solution Detail", "Created By"); 
}
public MemberOfSEC SEC_SolutionDetail_LastModifiedByField() throws Exception { 
return sfdc.Section("Solution Detail", "Last Modified By"); 
}
public MemberOfSEC SEC_SolutionDetail_SolutionTitleField() throws Exception { 
return sfdc.Section("Solution Detail", "Solution Title"); 
}
public MemberOfSEC SEC_SolutionDetail_SolutionDetailsField() throws Exception { 
return sfdc.Section("Solution Detail", "Solution Details"); 
}
public MemberOfSEC SEC_SolutionEdit_SolutionNumberField() throws Exception { 
return sfdc.Section("Solution Edit", "Solution Number"); 
}
public MemberOfSEC SEC_SolutionEdit_PublicField() throws Exception { 
return sfdc.Section("Solution Edit", "Public"); 
}

public MemberOfSEC SEC_SolutionEdit_VisibleinPublicKnowledgeBaseField() throws Exception { 
return sfdc.Section("Solution Edit", "Visible in Public Knowledge Base"); 
}

public MemberOfSEC SEC_SolutionEdit_SolutionDetailsField() throws Exception { 
return sfdc.Section("Solution Edit", "Solution Details"); 
}
//************************* Functions for Related List***************************** // 
 


 public Columns_Attachments RL_Attachments() throws Exception{ 
return new Columns_Attachments("Attachments"); 
} 
public class Columns_Attachments{ 
Columns_Attachments(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_Cases RL_Cases() throws Exception{ 
return new Columns_Cases("Cases"); 
} 
public class Columns_Cases{ 
Columns_Cases(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_SolutionHistory RL_SolutionHistory() throws Exception{ 
return new Columns_SolutionHistory("Solution History"); 
} 
public class Columns_SolutionHistory{ 
Columns_SolutionHistory(String RL) 
{ 
RList = RL; 
} 

}

}

