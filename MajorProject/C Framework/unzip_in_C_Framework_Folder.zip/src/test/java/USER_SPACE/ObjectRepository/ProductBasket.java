package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class ProductBasket extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public ProductBasket(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public ProductBasket(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI BasketNameField() throws Exception{  
return sfdc.Field_LUI("Basket Name"); 
} 
 
public CustomMemberOfField_LUI BasketStageField() throws Exception{  
return sfdc.Field_Custom("Basket Stage"); 
} 
 
public MemberOfField_LUI CustomerField() throws Exception{  
return sfdc.Field_LUI("Customer"); 
} 
 
public CustomMemberOfField_LUI PrimaryBasketField() throws Exception{  
return sfdc.Field_Custom("Primary Basket"); 
} 
 
public MemberOfField_LUI IncrementalRevenueField() throws Exception{  
return sfdc.Field_LUI("Incremental Revenue"); 
} 
 
public CustomMemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_Custom("Description"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public CustomMemberOfField_LUI OpportunityField() throws Exception{  
return sfdc.Field_Custom("Opportunity"); 
} 
 
public MemberOfField_LUI TotalContractValueField() throws Exception{  
return sfdc.Field_LUI("Total Contract Value"); 
} 
 
public MemberOfField_LUI SynchronisedWithOpportunityField() throws Exception{  
return sfdc.Field_LUI("Synchronised With Opportunity"); 
} 
 
public CustomMemberOfField_LUI ProjectComplexityField() throws Exception{  
return sfdc.Field_Custom("Project Complexity"); 
} 
 
public CustomMemberOfField_LUI PMRequiredField() throws Exception{  
return sfdc.Field_Custom("PM Required"); 
} 

//Custome field
public CustomMemberOfField_LUI ProjectManagerContactNumberField() throws Exception{  
return sfdc.Field_Custom("Project Manager Contact Number"); 
} 
 
public CustomMemberOfField_LUI ProjectIDField() throws Exception{  
return sfdc.Field_Custom("Project ID"); 
} 
 
public CustomMemberOfField_LUI ProjectManagerUserIDField() throws Exception{  
return sfdc.Field_Custom("Project Manager User ID"); 
} 
 
public CustomMemberOfField_LUI ProjectManagerEmailField() throws Exception{  
return sfdc.Field_Custom("Project Manager Email"); 
} 
 
public MemberOfField_LUI BillingAccountField() throws Exception{  
return sfdc.Field_LUI("Billing Account"); 
} 
 
public MemberOfField_LUI BillingAddressField() throws Exception{  
return sfdc.Field_LUI("Billing Address"); 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_ManageProductsinBasket RL_ManageProductsinBasket() throws Exception{ 
return new Columns_ManageProductsinBasket("Manage Products in Basket"); 
} 
public class Columns_ManageProductsinBasket 
{ 
Columns_ManageProductsinBasket(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI OrderType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Order Type"); 
} 
public MemberOfRL_LUI OrderType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Order Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Domain() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Domain"); 
} 
public MemberOfRL_LUI Domain(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Domain",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Product() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product"); 
} 
public MemberOfRL_LUI Product(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product",TargetCOlumnValue); 
} 
public MemberOfRL_LUI SiteName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Site Name"); 
} 
public MemberOfRL_LUI SiteName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Site Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Quantity() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity"); 
} 
public MemberOfRL_LUI Quantity(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TotalOneoffAmount() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total One off Amount"); 
} 
public MemberOfRL_LUI TotalOneoffAmount(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total One off Amount",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TotalRecurringAmount() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total Recurring Amount"); 
} 
public MemberOfRL_LUI TotalRecurringAmount(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total Recurring Amount",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TotalContractValue() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total Contract Value"); 
} 
public MemberOfRL_LUI TotalContractValue(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total Contract Value",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public CustomMemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_Custom("Save"); 
} 
public MemberOfButton_LUI SyncButton() throws Exception{ 
return sfdc.Button_LUI("Sync"); 
} 
public MemberOfButton_LUI CloneButton() throws Exception{ 
return sfdc.Button_LUI("Clone"); 
} 
public MemberOfButton_LUI AddProductButton() throws Exception{ 
return sfdc.Button_LUI("Add Product"); 
} 
public MemberOfButton_LUI CopyProductButton() throws Exception{ 
return sfdc.Button_LUI("Copy Product"); 
} 
public MemberOfButton_LUI DeleteProductButton() throws Exception{ 
return sfdc.Button_LUI("Delete Product"); 
} 
} 
 
