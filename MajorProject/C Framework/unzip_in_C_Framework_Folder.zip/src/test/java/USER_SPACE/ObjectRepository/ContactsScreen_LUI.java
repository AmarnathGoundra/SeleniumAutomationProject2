package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class ContactsScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public ContactsScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public ContactsScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI ContactOwnerField() throws Exception{  
return sfdc.Field_LUI("Contact Owner"); 
} 
 
public MemberOfField_LUI PhoneField() throws Exception{  
return sfdc.Field_LUI("Phone"); 
} 
 
public MemberOfField_LUI NameField() throws Exception{  
return sfdc.Field_LUI("Name"); 
} 
 
public MemberOfField_LUI HomePhoneField() throws Exception{  
return sfdc.Field_LUI("Home Phone"); 
} 
 
public MemberOfField_LUI AccountNameField() throws Exception{  
return sfdc.Field_LUI("Account Name"); 
} 
 
public MemberOfField_LUI MobileField() throws Exception{  
return sfdc.Field_LUI("Mobile"); 
} 
 
public MemberOfField_LUI TitleField() throws Exception{  
return sfdc.Field_LUI("Title"); 
} 
 
public MemberOfField_LUI OtherPhoneField() throws Exception{  
return sfdc.Field_LUI("Other Phone"); 
} 
 
public MemberOfField_LUI DepartmentField() throws Exception{  
return sfdc.Field_LUI("Department"); 
} 
 
public MemberOfField_LUI FaxField() throws Exception{  
return sfdc.Field_LUI("Fax"); 
} 
 
public MemberOfField_LUI BirthdateField() throws Exception{  
return sfdc.Field_LUI("Birthdate"); 
} 
 
public MemberOfField_LUI EmailField() throws Exception{  
return sfdc.Field_LUI("Email"); 
} 
 
public MemberOfField_LUI ReportsToField() throws Exception{  
return sfdc.Field_LUI("Reports To"); 
} 
 
public MemberOfField_LUI AssistantField() throws Exception{  
return sfdc.Field_LUI("Assistant"); 
} 
 
public MemberOfField_LUI LeadSourceField() throws Exception{  
return sfdc.Field_LUI("Lead Source"); 
} 
 
public MemberOfField_LUI AsstPhoneField() throws Exception{  
return sfdc.Field_LUI("Asst. Phone"); 
} 
 
public MemberOfField_LUI KnownContactField() throws Exception{  
return sfdc.Field_LUI("Known Contact?"); 
} 
 
public MemberOfField_LUI MailingAddressField() throws Exception{  
return sfdc.Field_LUI("Mailing Address"); 
} 
 
public MemberOfField_LUI OtherAddressField() throws Exception{  
return sfdc.Field_LUI("Other Address"); 
} 
 
public MemberOfField_LUI LanguagesField() throws Exception{  
return sfdc.Field_LUI("Languages"); 
} 
 
public MemberOfField_LUI LevelField() throws Exception{  
return sfdc.Field_LUI("Level"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
public MemberOfField_LUI SkillsField() throws Exception{  
return sfdc.Field_LUI("Skills"); 
} 
 
public MemberOfField_LUI UploadFilesField() throws Exception{  
return sfdc.Field_LUI("Upload Files"); 
} 
 
public MemberOfField_LUI OrdropfilesField() throws Exception{  
return sfdc.Field_LUI("Or drop files"); 
} 
 
public MemberOfField_LUI SalutationField() throws Exception{  
return sfdc.Field_LUI("Salutation"); 
} 
 
public MemberOfField_LUI FirstNameField() throws Exception{  
return sfdc.Field_LUI("First Name"); 
} 
 
public MemberOfField_LUI LastNameField() throws Exception{  
return sfdc.Field_LUI("Last Name"); 
} 
 
public MemberOfField_LUI Field() throws Exception{  
return sfdc.Field_LUI("*"); 
} 
 
public MemberOfField_LUI MailingStreetField() throws Exception{  
return sfdc.Field_LUI("Mailing Street"); 
} 
 
public MemberOfField_LUI MailingCityField() throws Exception{  
return sfdc.Field_LUI("Mailing City"); 
} 
 
public MemberOfField_LUI MailingZipPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Mailing Zip/Postal Code"); 
} 
 
public MemberOfField_LUI MailingStateProvinceField() throws Exception{  
return sfdc.Field_LUI("Mailing State/Province"); 
} 
 
public MemberOfField_LUI MailingCountryField() throws Exception{  
return sfdc.Field_LUI("Mailing Country"); 
} 
 
public MemberOfField_LUI OtherStreetField() throws Exception{  
return sfdc.Field_LUI("Other Street"); 
} 
 
public MemberOfField_LUI OtherCityField() throws Exception{  
return sfdc.Field_LUI("Other City"); 
} 
 
public MemberOfField_LUI OtherZipPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Other Zip/Postal Code"); 
} 
 
public MemberOfField_LUI OtherStateProvinceField() throws Exception{  
return sfdc.Field_LUI("Other State/Province"); 
} 
 
public MemberOfField_LUI OtherCountryField() throws Exception{  
return sfdc.Field_LUI("Other Country"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 public Columns_Contacts LV_Contacts() throws Exception{ 
return new Columns_Contacts("Contacts"); 
} 
public class Columns_Contacts 
{ 
Columns_Contacts(String RL) 
{ 
RList = RL;  
}  
public MemberOfLV_LUI Name() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Name"); 
} 
public MemberOfLV_LUI Name(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI AccountName() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Name"); 
} 
public MemberOfLV_LUI AccountName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI AccountSite() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Site"); 
} 
public MemberOfLV_LUI AccountSite(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Site",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Phone() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Phone"); 
} 
public MemberOfLV_LUI Phone(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Phone",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Email() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Email"); 
} 
public MemberOfLV_LUI Email(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Email",TargetCOlumnValue); 
} 
public MemberOfLV_LUI ContactOwnerAlias() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Contact Owner Alias"); 
} 
public MemberOfLV_LUI ContactOwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Contact Owner Alias",TargetCOlumnValue); 
} 
public MemberOfLV_LUI NewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"NewButton");  
} 
public MemberOfLV_LUI IntelligenceViewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Intelligence ViewButton");  
} 
public MemberOfLV_LUI ImportButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"ImportButton");  
} 
public MemberOfLV_LUI AddtoCampaignButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Add to CampaignButton");  
} 
public MemberOfLV_LUI SendListEmailButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Send List EmailButton");  
} 
public MemberOfLV_LUI NewCaseButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New CaseButton");  
} 
public MemberOfLV_LUI NewNoteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New NoteButton");  
} 
public MemberOfLV_LUI SubmitforApprovalButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Submit for ApprovalButton");  
} 
public MemberOfLV_LUI UploadFilesButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Upload FilesButton");  
} 
public MemberOfLV_LUI MenuButtonCloneButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonCloneButton");  
} 
public MemberOfLV_LUI MenuButtonEditButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonEditButton");  
} 
public MemberOfLV_LUI MenuButtonDeleteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonDeleteButton");  
} 
public MemberOfLV_LUI MenuButtonChangeOwnerButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonChange OwnerButton");  
} 
public MemberOfLV_LUI MenuButtonCheckforNewDataButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonCheck for New DataButton");  
} 
public MemberOfLV_LUI CancelButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"CancelButton");  
} 
public MemberOfLV_LUI SaveNewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Save & NewButton");  
} 
public MemberOfLV_LUI SaveButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"SaveButton");  
} 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_Opportunities RL_Opportunities() throws Exception{ 
return new Columns_Opportunities("Opportunities"); 
} 
public class Columns_Opportunities 
{ 
Columns_Opportunities(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI OpportunityName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name"); 
} 
public MemberOfRL_LUI OpportunityName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Stage() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage"); 
} 
public MemberOfRL_LUI Stage(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Amount() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Amount"); 
} 
public MemberOfRL_LUI Amount(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Amount",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_Cases RL_Cases() throws Exception{ 
return new Columns_Cases("Cases"); 
} 
public class Columns_Cases 
{ 
Columns_Cases(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI ChangeOwnerButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Change OwnerButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_CampaignHistory RL_CampaignHistory() throws Exception{ 
return new Columns_CampaignHistory("Campaign History"); 
} 
public class Columns_CampaignHistory 
{ 
Columns_CampaignHistory(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI CampaignName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Campaign Name"); 
} 
public MemberOfRL_LUI CampaignName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Campaign Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI StartDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Start Date"); 
} 
public MemberOfRL_LUI StartDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Start Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Type() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Type"); 
} 
public MemberOfRL_LUI Type(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Responded() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Responded"); 
} 
public MemberOfRL_LUI Responded(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Responded",TargetCOlumnValue); 
} 
public MemberOfRL_LUI MemberStatusUpdated() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Member Status Updated"); 
} 
public MemberOfRL_LUI MemberStatusUpdated(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Member Status Updated",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AddtoCampaignButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Add to CampaignButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_NotesAttachments RL_NotesAttachments() throws Exception{ 
return new Columns_NotesAttachments("Notes & Attachments"); 
} 
public class Columns_NotesAttachments 
{ 
Columns_NotesAttachments(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CreatedBy() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By"); 
} 
public MemberOfRL_LUI CreatedBy(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI UploadFilesButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Upload FilesButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewButton() throws Exception{ 
return sfdc.Button_LUI("New"); 
} 
public MemberOfButton_LUI IntelligenceViewButton() throws Exception{ 
return sfdc.Button_LUI("Intelligence View"); 
} 
public MemberOfButton_LUI ImportButton() throws Exception{ 
return sfdc.Button_LUI("Import"); 
} 
public MemberOfButton_LUI AddtoCampaignButton() throws Exception{ 
return sfdc.Button_LUI("Add to Campaign"); 
} 
public MemberOfButton_LUI SendListEmailButton() throws Exception{ 
return sfdc.Button_LUI("Send List Email"); 
} 
public MemberOfButton_LUI NewCaseButton() throws Exception{ 
return sfdc.Button_LUI("New Case"); 
} 
public MemberOfButton_LUI NewNoteButton() throws Exception{ 
return sfdc.Button_LUI("New Note"); 
} 
public MemberOfButton_LUI SubmitforApprovalButton() throws Exception{ 
return sfdc.Button_LUI("Submit for Approval"); 
} 
public MemberOfButton_LUI UploadFilesButton() throws Exception{ 
return sfdc.Button_LUI("Upload Files"); 
} 
public MemberOfButton_LUI MenuButtonCloneButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Clone"); 
} 
public MemberOfButton_LUI MenuButtonEditButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Edit"); 
} 
public MemberOfButton_LUI MenuButtonDeleteButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Delete"); 
} 
public MemberOfButton_LUI MenuButtonChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Change Owner"); 
} 
public MemberOfButton_LUI MenuButtonCheckforNewDataButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Check for New Data"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveNewButton() throws Exception{ 
return sfdc.Button_LUI("Save & New"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
public MemberOfButton_LUI ApproveButton() throws Exception{ 
return sfdc.Button_LUI("Approve"); 
} 

public MemberOfButton_LUI DeleteButton() throws Exception{ 
return sfdc.Button_LUI("Delete"); 
} 
//************************* Functions for All Apps ***************************** // 
 
//************************* Functions for Tabs List ***************************** // 
 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Searchthislist_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search this list..."); 
} 
public MemberOfHealthCloud_LUI Select6items_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select 6 items"); 
} 
public MemberOfHealthCloud_LUI Selectitem1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 1"); 
} 
public MemberOfHealthCloud_LUI Selectitem2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 2"); 
} 
public MemberOfHealthCloud_LUI Selectitem3_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 3"); 
} 
public MemberOfHealthCloud_LUI Selectitem4_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 4"); 
} 
public MemberOfHealthCloud_LUI Selectitem5_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 5"); 
} 
public MemberOfHealthCloud_LUI Selectitem6_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 6"); 
} 
public MemberOfHealthCloud_LUI KnownContact_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Known Contact?"); 
} 
public MemberOfHealthCloud_LUI Phone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Phone"); 
} 
public MemberOfHealthCloud_LUI Salutation_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Salutation"); 
} 
public MemberOfHealthCloud_LUI FirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("First Name"); 
} 
public MemberOfHealthCloud_LUI LastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Last Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI HomePhone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Home Phone"); 
} 
public MemberOfHealthCloud_LUI AccountName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Account Name"); 
} 
public MemberOfHealthCloud_LUI Mobile_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mobile"); 
} 
public MemberOfHealthCloud_LUI Title_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Title"); 
} 
public MemberOfHealthCloud_LUI OtherPhone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Other Phone"); 
} 
public MemberOfHealthCloud_LUI Department_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Department"); 
} 
public MemberOfHealthCloud_LUI Fax_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Fax"); 
} 
public MemberOfHealthCloud_LUI Birthdate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Birthdate"); 
} 
public MemberOfHealthCloud_LUI Email_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Email"); 
} 
public MemberOfHealthCloud_LUI ReportsTo_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Reports To"); 
} 
public MemberOfHealthCloud_LUI Assistant_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Assistant"); 
} 
public MemberOfHealthCloud_LUI LeadSource_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Lead Source"); 
} 
public MemberOfHealthCloud_LUI AsstPhone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Asst. Phone"); 
} 
public MemberOfHealthCloud_LUI MailingStreet_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mailing Street"); 
} 
public MemberOfHealthCloud_LUI MailingCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mailing City"); 
} 
public MemberOfHealthCloud_LUI MailingZipPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mailing Zip/Postal Code"); 
} 
public MemberOfHealthCloud_LUI MailingStateProvince_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mailing State/Province"); 
} 
public MemberOfHealthCloud_LUI MailingCountry_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mailing Country"); 
} 
public MemberOfHealthCloud_LUI OtherStreet_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Other Street"); 
} 
public MemberOfHealthCloud_LUI OtherCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Other City"); 
} 
public MemberOfHealthCloud_LUI OtherZipPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Other Zip/Postal Code"); 
} 
public MemberOfHealthCloud_LUI OtherStateProvince_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Other State/Province"); 
} 
public MemberOfHealthCloud_LUI OtherCountry_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Other Country"); 
} 
public MemberOfHealthCloud_LUI Languages_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Languages"); 
} 
public MemberOfHealthCloud_LUI Level_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Level"); 
} 
public MemberOfHealthCloud_LUI Description_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Description"); 
} 
//************************* Functions for HC Button ***************************** // 
 
public MemberOfHealthCloud_LUI Save_HealthCloudButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Save"); 
} 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
