package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class ParametersScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public ParametersScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public ParametersScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI ParameterNameField() throws Exception{  
return sfdc.Field_LUI("Parameter Name"); 
} 
 
public MemberOfField_LUI OwnerField() throws Exception{  
return sfdc.Field_LUI("Owner"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
public MemberOfField_LUI ParameterListField() throws Exception{  
return sfdc.Field_LUI("Parameter List"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 public Columns_Parameters LV_Parameters() throws Exception{ 
return new Columns_Parameters("Parameters"); 
} 
public class Columns_Parameters 
{ 
Columns_Parameters(String RL) 
{ 
RList = RL;  
}  
public MemberOfLV_LUI ParameterName() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Parameter Name"); 
} 
public MemberOfLV_LUI ParameterName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Parameter Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI NewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"NewButton");  
} 
public MemberOfLV_LUI ImportButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"ImportButton");  
} 
public MemberOfLV_LUI EditButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"EditButton");  
} 
public MemberOfLV_LUI DeleteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"DeleteButton");  
} 
public MemberOfLV_LUI CloneButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"CloneButton");  
} 
public MemberOfLV_LUI MenuButtonChangeOwnerButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonChange OwnerButton");  
} 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewButton() throws Exception{ 
return sfdc.Button_LUI("New"); 
} 
public MemberOfButton_LUI ImportButton() throws Exception{ 
return sfdc.Button_LUI("Import"); 
} 
public MemberOfButton_LUI EditButton() throws Exception{ 
return sfdc.Button_LUI("Edit"); 
} 
public MemberOfButton_LUI DeleteButton() throws Exception{ 
return sfdc.Button_LUI("Delete"); 
} 
public MemberOfButton_LUI CloneButton() throws Exception{ 
return sfdc.Button_LUI("Clone"); 
} 
public MemberOfButton_LUI MenuButtonChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Change Owner"); 
} 
} 
 
