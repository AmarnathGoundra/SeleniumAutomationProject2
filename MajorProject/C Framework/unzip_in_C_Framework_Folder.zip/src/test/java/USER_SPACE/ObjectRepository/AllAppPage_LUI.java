package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class AllAppPage_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public AllAppPage_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public AllAppPage_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 // ************************ Functions and Classes for List Views ************************************** 
 
 // ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
//************************* Functions for All Apps ***************************** // 
 
public MemberOfAllApps_LUI ServiceApp() throws Exception{ 
return sfdc.AllApps_LUI("Service"); 
} 
public MemberOfAllApps_LUI MarketingApp() throws Exception{ 
return sfdc.AllApps_LUI("Marketing"); 
} 
public MemberOfAllApps_LUI CommunityApp() throws Exception{ 
return sfdc.AllApps_LUI("Community"); 
} 
public MemberOfAllApps_LUI SalesforceChatterApp() throws Exception{ 
return sfdc.AllApps_LUI("Salesforce Chatter"); 
} 
public MemberOfAllApps_LUI ContentApp() throws Exception{ 
return sfdc.AllApps_LUI("Content"); 
} 
public MemberOfAllApps_LUI SalesConsoleApp() throws Exception{ 
return sfdc.AllApps_LUI("Sales Console"); 
} 
public MemberOfAllApps_LUI ServiceConsoleApp() throws Exception{ 
return sfdc.AllApps_LUI("Service Console"); 
} 
public MemberOfAllApps_LUI SalesApp() throws Exception{ 
return sfdc.AllApps_LUI("Sales"); 
} 
public MemberOfAllApps_LUI LightningUsageAppApp() throws Exception{ 
return sfdc.AllApps_LUI("Lightning Usage App"); 
} 
public MemberOfAllApps_LUI BoltSolutionsApp() throws Exception{ 
return sfdc.AllApps_LUI("Bolt Solutions"); 
} 
public MemberOfAllApps_LUI CommerceApp() throws Exception{ 
return sfdc.AllApps_LUI("Commerce"); 
} 
public MemberOfAllApps_LUI SFDCNextTestResultsApp() throws Exception{ 
return sfdc.AllApps_LUI("SFDC.Next Test Results"); 
} 
//************************* Functions for Tabs List ***************************** // 
 
public MemberOfTab_LUI AccountsTab() throws Exception{ 
return sfdc.Tab_LUI("Accounts"); 
} 
public MemberOfTab_LUI AppLauncherTab() throws Exception{ 
return sfdc.Tab_LUI("App Launcher"); 
} 
public MemberOfTab_LUI ApprovalRequestsTab() throws Exception{ 
return sfdc.Tab_LUI("Approval Requests"); 
} 
public MemberOfTab_LUI AssetActionSourcesTab() throws Exception{ 
return sfdc.Tab_LUI("Asset Action Sources"); 
} 
public MemberOfTab_LUI AssetActionsTab() throws Exception{ 
return sfdc.Tab_LUI("Asset Actions"); 
} 
public MemberOfTab_LUI AssetStatePeriodsTab() throws Exception{ 
return sfdc.Tab_LUI("Asset State Periods"); 
} 
public MemberOfTab_LUI AssetsTab() throws Exception{ 
return sfdc.Tab_LUI("Assets"); 
} 
public MemberOfTab_LUI AuthorizationFormTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form"); 
} 
public MemberOfTab_LUI AuthorizationFormConsentTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form Consent"); 
} 
public MemberOfTab_LUI AuthorizationFormDataUseTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form Data Use"); 
} 
public MemberOfTab_LUI AuthorizationFormTextTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form Text"); 
} 
public MemberOfTab_LUI CMSHomeTab() throws Exception{ 
return sfdc.Tab_LUI("CMS Home"); 
} 
public MemberOfTab_LUI CalendarTab() throws Exception{ 
return sfdc.Tab_LUI("Calendar"); 
} 
public MemberOfTab_LUI CampaignsTab() throws Exception{ 
return sfdc.Tab_LUI("Campaigns"); 
} 
public MemberOfTab_LUI CardPaymentMethodsTab() throws Exception{ 
return sfdc.Tab_LUI("Card Payment Methods"); 
} 
public MemberOfTab_LUI CasesTab() throws Exception{ 
return sfdc.Tab_LUI("Cases"); 
} 
public MemberOfTab_LUI ChatterTab() throws Exception{ 
return sfdc.Tab_LUI("Chatter"); 
} 
public MemberOfTab_LUI ConsumptionSchedulesTab() throws Exception{ 
return sfdc.Tab_LUI("Consumption Schedules"); 
} 
public MemberOfTab_LUI ContactPointConsentTab() throws Exception{ 
return sfdc.Tab_LUI("Contact Point Consent"); 
} 
public MemberOfTab_LUI ContactPointTypeConsentTab() throws Exception{ 
return sfdc.Tab_LUI("Contact Point Type Consent"); 
} 
public MemberOfTab_LUI ContactRequestsTab() throws Exception{ 
return sfdc.Tab_LUI("Contact Requests"); 
} 
public MemberOfTab_LUI ContactsTab() throws Exception{ 
return sfdc.Tab_LUI("Contacts"); 
} 
public MemberOfTab_LUI ContractsTab() throws Exception{ 
return sfdc.Tab_LUI("Contracts"); 
} 
public MemberOfTab_LUI DashboardsTab() throws Exception{ 
return sfdc.Tab_LUI("Dashboards"); 
} 
public MemberOfTab_LUI DataUseLegalBasisTab() throws Exception{ 
return sfdc.Tab_LUI("Data Use Legal Basis"); 
} 
public MemberOfTab_LUI DataUsePurposeTab() throws Exception{ 
return sfdc.Tab_LUI("Data Use Purpose"); 
} 
public MemberOfTab_LUI DigitalWalletsTab() throws Exception{ 
return sfdc.Tab_LUI("Digital Wallets"); 
} 
public MemberOfTab_LUI DuplicateRecordSetsTab() throws Exception{ 
return sfdc.Tab_LUI("Duplicate Record Sets"); 
} 
public MemberOfTab_LUI EmailTemplatesTab() throws Exception{ 
return sfdc.Tab_LUI("Email Templates"); 
} 
public MemberOfTab_LUI EnhancedLetterheadsTab() throws Exception{ 
return sfdc.Tab_LUI("Enhanced Letterheads"); 
} 
public MemberOfTab_LUI FilesTab() throws Exception{ 
return sfdc.Tab_LUI("Files"); 
} 
public MemberOfTab_LUI FinanceBalanceSnapshotsTab() throws Exception{ 
return sfdc.Tab_LUI("Finance Balance Snapshots"); 
} 
public MemberOfTab_LUI FinanceTransactionsTab() throws Exception{ 
return sfdc.Tab_LUI("Finance Transactions"); 
} 
public MemberOfTab_LUI ForecastsTab() throws Exception{ 
return sfdc.Tab_LUI("Forecasts"); 
} 
public MemberOfTab_LUI GroupsTab() throws Exception{ 
return sfdc.Tab_LUI("Groups"); 
} 
public MemberOfTab_LUI HomeTab() throws Exception{ 
return sfdc.Tab_LUI("Home"); 
} 
public MemberOfTab_LUI ImagesTab() throws Exception{ 
return sfdc.Tab_LUI("Images"); 
} 
public MemberOfTab_LUI LeadsTab() throws Exception{ 
return sfdc.Tab_LUI("Leads"); 
} 
public MemberOfTab_LUI LearningTab() throws Exception{ 
return sfdc.Tab_LUI("Learning"); 
} 
public MemberOfTab_LUI LegalEntitiesTab() throws Exception{ 
return sfdc.Tab_LUI("Legal Entities"); 
} 
public MemberOfTab_LUI LightningBoltSolutionsTab() throws Exception{ 
return sfdc.Tab_LUI("Lightning Bolt Solutions"); 
} 
public MemberOfTab_LUI LightningUsageTab() throws Exception{ 
return sfdc.Tab_LUI("Lightning Usage"); 
} 
public MemberOfTab_LUI ListEmailsTab() throws Exception{ 
return sfdc.Tab_LUI("List Emails"); 
} 
public MemberOfTab_LUI MacrosTab() throws Exception{ 
return sfdc.Tab_LUI("Macros"); 
} 
public MemberOfTab_LUI OpportunitiesTab() throws Exception{ 
return sfdc.Tab_LUI("Opportunities"); 
} 
public MemberOfTab_LUI OrdersTab() throws Exception{ 
return sfdc.Tab_LUI("Orders"); 
} 
public MemberOfTab_LUI OrgMetricsTab() throws Exception{ 
return sfdc.Tab_LUI("Org Metrics"); 
} 
public MemberOfTab_LUI PaymentAuthorizationsTab() throws Exception{ 
return sfdc.Tab_LUI("Payment Authorizations"); 
} 
public MemberOfTab_LUI PaymentGatewayLogsTab() throws Exception{ 
return sfdc.Tab_LUI("Payment Gateway Logs"); 
} 
public MemberOfTab_LUI PaymentGatewaysTab() throws Exception{ 
return sfdc.Tab_LUI("Payment Gateways"); 
} 
public MemberOfTab_LUI PaymentsTab() throws Exception{ 
return sfdc.Tab_LUI("Payments"); 
} 
public MemberOfTab_LUI PeopleTab() throws Exception{ 
return sfdc.Tab_LUI("People"); 
} 
public MemberOfTab_LUI PriceBooksTab() throws Exception{ 
return sfdc.Tab_LUI("Price Books"); 
} 
public MemberOfTab_LUI ProcessExceptionsTab() throws Exception{ 
return sfdc.Tab_LUI("Process Exceptions"); 
} 
public MemberOfTab_LUI ProductsTab() throws Exception{ 
return sfdc.Tab_LUI("Products"); 
} 
public MemberOfTab_LUI QuickTextTab() throws Exception{ 
return sfdc.Tab_LUI("Quick Text"); 
} 
public MemberOfTab_LUI RecommendationsTab() throws Exception{ 
return sfdc.Tab_LUI("Recommendations"); 
} 
public MemberOfTab_LUI RecycleBinTab() throws Exception{ 
return sfdc.Tab_LUI("Recycle Bin"); 
} 
public MemberOfTab_LUI RefundLinePaymentsTab() throws Exception{ 
return sfdc.Tab_LUI("Refund Line Payments"); 
} 
public MemberOfTab_LUI RefundsTab() throws Exception{ 
return sfdc.Tab_LUI("Refunds"); 
} 
public MemberOfTab_LUI ReportsTab() throws Exception{ 
return sfdc.Tab_LUI("Reports"); 
} 
public MemberOfTab_LUI ScorecardsTab() throws Exception{ 
return sfdc.Tab_LUI("Scorecards"); 
} 
public MemberOfTab_LUI StreamingChannelsTab() throws Exception{ 
return sfdc.Tab_LUI("Streaming Channels"); 
} 
public MemberOfTab_LUI TasksTab() throws Exception{ 
return sfdc.Tab_LUI("Tasks"); 
} 
public MemberOfTab_LUI TestCaseExecutionsTab() throws Exception{ 
return sfdc.Tab_LUI("Test Case Executions"); 
} 
public MemberOfTab_LUI TestSuiteAggregationsTab() throws Exception{ 
return sfdc.Tab_LUI("Test Suite Aggregations"); 
} 
public MemberOfTab_LUI TestSuiteExecutionsTab() throws Exception{ 
return sfdc.Tab_LUI("Test Suite Executions"); 
} 
public MemberOfTab_LUI UserProvisioningRequestsTab() throws Exception{ 
return sfdc.Tab_LUI("User Provisioning Requests"); 
} 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI SearchSetup_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Setup"); 
} 
public MemberOfHealthCloud_LUI Searchappsoritems_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search apps or items..."); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
