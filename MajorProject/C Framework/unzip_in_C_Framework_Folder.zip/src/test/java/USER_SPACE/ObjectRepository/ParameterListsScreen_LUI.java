package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class ParameterListsScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public ParameterListsScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public ParameterListsScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI ParameterListNameField() throws Exception{  
return sfdc.Field_LUI("Parameter List Name"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
public MemberOfField_LUI VersionField() throws Exception{  
return sfdc.Field_LUI("Version"); 
} 
 
public MemberOfField_LUI ExpiredField() throws Exception{  
return sfdc.Field_LUI("Expired ?"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 public Columns_ParameterLists LV_ParameterLists() throws Exception{ 
return new Columns_ParameterLists("Parameter Lists"); 
} 
public class Columns_ParameterLists 
{ 
Columns_ParameterLists(String RL) 
{ 
RList = RL;  
}  
public MemberOfLV_LUI ParameterListName() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Parameter List Name"); 
} 
public MemberOfLV_LUI ParameterListName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Parameter List Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Expired() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Expired ?"); 
} 
public MemberOfLV_LUI Expired(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Expired ?",TargetCOlumnValue); 
} 
public MemberOfLV_LUI CreatedBy() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Created By"); 
} 
public MemberOfLV_LUI CreatedBy(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Created By",TargetCOlumnValue); 
} 
public MemberOfLV_LUI CreatedByAlias() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Created By Alias"); 
} 
public MemberOfLV_LUI CreatedByAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Created By Alias",TargetCOlumnValue); 
} 
public MemberOfLV_LUI CreatedDate() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Created Date"); 
} 
public MemberOfLV_LUI CreatedDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Created Date",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Description() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Description"); 
} 
public MemberOfLV_LUI Description(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Description",TargetCOlumnValue); 
} 
public MemberOfLV_LUI LastModifiedBy() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Last Modified By"); 
} 
public MemberOfLV_LUI LastModifiedBy(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Last Modified By",TargetCOlumnValue); 
} 
public MemberOfLV_LUI LastModifiedByAlias() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Last Modified By Alias"); 
} 
public MemberOfLV_LUI LastModifiedByAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Last Modified By Alias",TargetCOlumnValue); 
} 
public MemberOfLV_LUI LastModifiedDate() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Last Modified Date"); 
} 
public MemberOfLV_LUI LastModifiedDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Last Modified Date",TargetCOlumnValue); 
} 
public MemberOfLV_LUI OwnerAlias() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner Alias"); 
} 
public MemberOfLV_LUI OwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner Alias",TargetCOlumnValue); 
} 
public MemberOfLV_LUI OwnerFirstName() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner First Name"); 
} 
public MemberOfLV_LUI OwnerFirstName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner First Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI OwnerLastName() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner Last Name"); 
} 
public MemberOfLV_LUI OwnerLastName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner Last Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI RecordID() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Record ID"); 
} 
public MemberOfLV_LUI RecordID(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Record ID",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Version() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Version"); 
} 
public MemberOfLV_LUI Version(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Version",TargetCOlumnValue); 
} 
public MemberOfLV_LUI NewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"NewButton");  
} 
public MemberOfLV_LUI ImportButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"ImportButton");  
} 
public MemberOfLV_LUI EditButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"EditButton");  
} 
public MemberOfLV_LUI DeleteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"DeleteButton");  
} 
public MemberOfLV_LUI CloneButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"CloneButton");  
} 
public MemberOfLV_LUI MenuButtonChangeOwnerButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonChange OwnerButton");  
} 
public MemberOfLV_LUI UploadFilesButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Upload FilesButton");  
} 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_NotesAttachments RL_NotesAttachments() throws Exception{ 
return new Columns_NotesAttachments("Notes & Attachments"); 
} 
public class Columns_NotesAttachments 
{ 
Columns_NotesAttachments(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI ParameterListName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Parameter List Name"); 
} 
public MemberOfRL_LUI ParameterListName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Parameter List Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Expired() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Expired ?"); 
} 
public MemberOfRL_LUI Expired(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Expired ?",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CreatedBy() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By"); 
} 
public MemberOfRL_LUI CreatedBy(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CreatedByAlias() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By Alias"); 
} 
public MemberOfRL_LUI CreatedByAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By Alias",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CreatedDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created Date"); 
} 
public MemberOfRL_LUI CreatedDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Description() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Description"); 
} 
public MemberOfRL_LUI Description(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Description",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModifiedBy() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified By"); 
} 
public MemberOfRL_LUI LastModifiedBy(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified By",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModifiedByAlias() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified By Alias"); 
} 
public MemberOfRL_LUI LastModifiedByAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified By Alias",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModifiedDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified Date"); 
} 
public MemberOfRL_LUI LastModifiedDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI OwnerAlias() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner Alias"); 
} 
public MemberOfRL_LUI OwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner Alias",TargetCOlumnValue); 
} 
public MemberOfRL_LUI OwnerFirstName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner First Name"); 
} 
public MemberOfRL_LUI OwnerFirstName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner First Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI OwnerLastName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner Last Name"); 
} 
public MemberOfRL_LUI OwnerLastName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner Last Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RecordID() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record ID"); 
} 
public MemberOfRL_LUI RecordID(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record ID",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Version() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Version"); 
} 
public MemberOfRL_LUI Version(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Version",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI UploadFilesButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Upload FilesButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_Parameters RL_Parameters() throws Exception{ 
return new Columns_Parameters("Parameters"); 
} 
public class Columns_Parameters 
{ 
Columns_Parameters(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI ParameterListName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Parameter List Name"); 
} 
public MemberOfRL_LUI ParameterListName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Parameter List Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Expired() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Expired ?"); 
} 
public MemberOfRL_LUI Expired(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Expired ?",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CreatedBy() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By"); 
} 
public MemberOfRL_LUI CreatedBy(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CreatedByAlias() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By Alias"); 
} 
public MemberOfRL_LUI CreatedByAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By Alias",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CreatedDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created Date"); 
} 
public MemberOfRL_LUI CreatedDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Description() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Description"); 
} 
public MemberOfRL_LUI Description(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Description",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModifiedBy() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified By"); 
} 
public MemberOfRL_LUI LastModifiedBy(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified By",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModifiedByAlias() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified By Alias"); 
} 
public MemberOfRL_LUI LastModifiedByAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified By Alias",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModifiedDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified Date"); 
} 
public MemberOfRL_LUI LastModifiedDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI OwnerAlias() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner Alias"); 
} 
public MemberOfRL_LUI OwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner Alias",TargetCOlumnValue); 
} 
public MemberOfRL_LUI OwnerFirstName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner First Name"); 
} 
public MemberOfRL_LUI OwnerFirstName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner First Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI OwnerLastName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner Last Name"); 
} 
public MemberOfRL_LUI OwnerLastName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner Last Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RecordID() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record ID"); 
} 
public MemberOfRL_LUI RecordID(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record ID",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Version() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Version"); 
} 
public MemberOfRL_LUI Version(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Version",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ParameterName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Parameter Name"); 
} 
public MemberOfRL_LUI ParameterName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Parameter Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewButton() throws Exception{ 
return sfdc.Button_LUI("New"); 
} 
public MemberOfButton_LUI ImportButton() throws Exception{ 
return sfdc.Button_LUI("Import"); 
} 
public MemberOfButton_LUI EditButton() throws Exception{ 
return sfdc.Button_LUI("Edit"); 
} 
public MemberOfButton_LUI DeleteButton() throws Exception{ 
return sfdc.Button_LUI("Delete"); 
} 
public MemberOfButton_LUI CloneButton() throws Exception{ 
return sfdc.Button_LUI("Clone"); 
} 
public MemberOfButton_LUI MenuButtonChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Change Owner"); 
} 
public MemberOfButton_LUI UploadFilesButton() throws Exception{ 
return sfdc.Button_LUI("Upload Files"); 
} 
} 
 
