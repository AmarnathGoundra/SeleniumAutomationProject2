package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class ContractScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public ContractScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public ContractScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


// ************************ Functions for Fields ************************************** 
 
 public MemberOfField ContractOwnerField() throws Exception{ 
	return sfdc.Field("Contract Owner"); 
} 
public MemberOfField StatusField() throws Exception{ 
	return sfdc.Field("Status"); 
} 
public MemberOfField ContractNumberField() throws Exception{ 
	return sfdc.Field("Contract Number"); 
} 
public MemberOfField ContractStartDateField() throws Exception{ 
	return sfdc.Field("Contract Start Date"); 
} 
public MemberOfField AccountNameField() throws Exception{ 
	return sfdc.Field("Account Name"); 
} 
public MemberOfField ContractEndDateField() throws Exception{ 
	return sfdc.Field("Contract End Date"); 
} 
public MemberOfField CustomerSignedByField() throws Exception{ 
	return sfdc.Field("Customer Signed By"); 
} 
public MemberOfField ContractTermmonthsField() throws Exception{ 
	return sfdc.Field("Contract Term (months)"); 
} 
public MemberOfField CustomerSignedTitleField() throws Exception{ 
	return sfdc.Field("Customer Signed Title"); 
} 
public MemberOfField OwnerExpirationNoticeField() throws Exception{ 
	return sfdc.Field("Owner Expiration Notice"); 
} 
public MemberOfField CustomerSignedDateField() throws Exception{ 
	return sfdc.Field("Customer Signed Date"); 
} 
public MemberOfField CompanySignedByField() throws Exception{ 
	return sfdc.Field("Company Signed By"); 
} 
public MemberOfField CompanySignedDateField() throws Exception{ 
	return sfdc.Field("Company Signed Date"); 
} 
public MemberOfField BillingAddressField() throws Exception{ 
	return sfdc.Field("Billing Address"); 
} 
public MemberOfField ActivatedByField() throws Exception{ 
	return sfdc.Field("Activated By"); 
} 
public MemberOfField ActivatedDateField() throws Exception{ 
	return sfdc.Field("Activated Date"); 
} 
public MemberOfField CreatedByField() throws Exception{ 
	return sfdc.Field("Created By"); 
} 
public MemberOfField LastModifiedByField() throws Exception{ 
	return sfdc.Field("Last Modified By"); 
} 
public MemberOfField SpecialTermsField() throws Exception{ 
	return sfdc.Field("Special Terms"); 
} 
public MemberOfField DescriptionField() throws Exception{ 
	return sfdc.Field("Description"); 
} 

 


// ************************* Functions & Static Classes for Sections ***************************** // 
 
public MemberOfSEC SEC_ContractDetail_ContractOwnerField() throws Exception { 
return sfdc.Section("Contract Detail", "Contract Owner"); 
}
public MemberOfSEC SEC_ContractDetail_StatusField() throws Exception { 
return sfdc.Section("Contract Detail", "Status"); 
}
public MemberOfSEC SEC_ContractDetail_ContractNumberField() throws Exception { 
return sfdc.Section("Contract Detail", "Contract Number"); 
}
public MemberOfSEC SEC_ContractDetail_ContractStartDateField() throws Exception { 
return sfdc.Section("Contract Detail", "Contract Start Date"); 
}
public MemberOfSEC SEC_ContractDetail_AccountNameField() throws Exception { 
return sfdc.Section("Contract Detail", "Account Name"); 
}
public MemberOfSEC SEC_ContractDetail_ContractEndDateField() throws Exception { 
return sfdc.Section("Contract Detail", "Contract End Date"); 
}
public MemberOfSEC SEC_ContractDetail_CustomerSignedByField() throws Exception { 
return sfdc.Section("Contract Detail", "Customer Signed By"); 
}
public MemberOfSEC SEC_ContractDetail_ContractTermmonthsField() throws Exception { 
return sfdc.Section("Contract Detail", "Contract Term (months)"); 
}
public MemberOfSEC SEC_ContractDetail_CustomerSignedTitleField() throws Exception { 
return sfdc.Section("Contract Detail", "Customer Signed Title"); 
}
public MemberOfSEC SEC_ContractDetail_OwnerExpirationNoticeField() throws Exception { 
return sfdc.Section("Contract Detail", "Owner Expiration Notice"); 
}
public MemberOfSEC SEC_ContractDetail_CustomerSignedDateField() throws Exception { 
return sfdc.Section("Contract Detail", "Customer Signed Date"); 
}
public MemberOfSEC SEC_ContractDetail_CompanySignedByField() throws Exception { 
return sfdc.Section("Contract Detail", "Company Signed By"); 
}
public MemberOfSEC SEC_ContractDetail_CompanySignedDateField() throws Exception { 
return sfdc.Section("Contract Detail", "Company Signed Date"); 
}
public MemberOfSEC SEC_ContractDetail_BillingAddressField() throws Exception { 
return sfdc.Section("Contract Detail", "Billing Address"); 
}
public MemberOfSEC SEC_ContractDetail_ActivatedByField() throws Exception { 
return sfdc.Section("Contract Detail", "Activated By"); 
}
public MemberOfSEC SEC_ContractDetail_ActivatedDateField() throws Exception { 
return sfdc.Section("Contract Detail", "Activated Date"); 
}
public MemberOfSEC SEC_ContractDetail_CreatedByField() throws Exception { 
return sfdc.Section("Contract Detail", "Created By"); 
}
public MemberOfSEC SEC_ContractDetail_LastModifiedByField() throws Exception { 
return sfdc.Section("Contract Detail", "Last Modified By"); 
}
public MemberOfSEC SEC_ContractDetail_SpecialTermsField() throws Exception { 
return sfdc.Section("Contract Detail", "Special Terms"); 
}
public MemberOfSEC SEC_ContractDetail_DescriptionField() throws Exception { 
return sfdc.Section("Contract Detail", "Description"); 
}

 
 
 // **************** Functions & Static Classes for Related List ******************** 
 


 public Columns_ItemstoApprove RL_ItemstoApprove() throws Exception{ 
return new Columns_ItemstoApprove("Items to Approve"); 
} 
public class Columns_ItemstoApprove{ 
Columns_ItemstoApprove(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Noapprovalrequestspecified(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"No approval request specified",RowIndex); 
}
public MemberOfRL Noapprovalrequestspecified() throws Exception 
{ 
return sfdc.RL(RList,"No approval request specified"); 
}

}


 public Columns_ContractHistory RL_ContractHistory() throws Exception{ 
return new Columns_ContractHistory("Contract History"); 
} 
public class Columns_ContractHistory{ 
Columns_ContractHistory(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Date(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Date",RowIndex); 
}
public MemberOfRL Date() throws Exception 
{ 
return sfdc.RL(RList,"Date"); 
}

public MemberOfRL User(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"User",RowIndex); 
}
public MemberOfRL User() throws Exception 
{ 
return sfdc.RL(RList,"User"); 
}

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

}


 public Columns_OpenActivities RL_OpenActivities() throws Exception{ 
return new Columns_OpenActivities("Open Activities"); 
} 
public class Columns_OpenActivities{ 
Columns_OpenActivities(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Subject(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Subject",RowIndex); 
}
public MemberOfRL Subject() throws Exception 
{ 
return sfdc.RL(RList,"Subject"); 
}

public MemberOfRL Name(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Name",RowIndex); 
}
public MemberOfRL Name() throws Exception 
{ 
return sfdc.RL(RList,"Name"); 
}

public MemberOfRL Task(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Task",RowIndex); 
}
public MemberOfRL Task() throws Exception 
{ 
return sfdc.RL(RList,"Task"); 
}

public MemberOfRL DueDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Due Date",RowIndex); 
}
public MemberOfRL DueDate() throws Exception 
{ 
return sfdc.RL(RList,"Due Date"); 
}

public MemberOfRL Status(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Status",RowIndex); 
}
public MemberOfRL Status() throws Exception 
{ 
return sfdc.RL(RList,"Status"); 
}

public MemberOfRL Priority(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Priority",RowIndex); 
}
public MemberOfRL Priority() throws Exception 
{ 
return sfdc.RL(RList,"Priority"); 
}

public MemberOfRL AssignedTo(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Assigned To",RowIndex); 
}
public MemberOfRL AssignedTo() throws Exception 
{ 
return sfdc.RL(RList,"Assigned To"); 
}

}


 public Columns_ActivityHistory RL_ActivityHistory() throws Exception{ 
return new Columns_ActivityHistory("Activity History"); 
} 
public class Columns_ActivityHistory{ 
Columns_ActivityHistory(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Subject(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Subject",RowIndex); 
}
public MemberOfRL Subject() throws Exception 
{ 
return sfdc.RL(RList,"Subject"); 
}

public MemberOfRL Name(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Name",RowIndex); 
}
public MemberOfRL Name() throws Exception 
{ 
return sfdc.RL(RList,"Name"); 
}

public MemberOfRL Task(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Task",RowIndex); 
}
public MemberOfRL Task() throws Exception 
{ 
return sfdc.RL(RList,"Task"); 
}

public MemberOfRL DueDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Due Date",RowIndex); 
}
public MemberOfRL DueDate() throws Exception 
{ 
return sfdc.RL(RList,"Due Date"); 
}

public MemberOfRL AssignedTo(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Assigned To",RowIndex); 
}
public MemberOfRL AssignedTo() throws Exception 
{ 
return sfdc.RL(RList,"Assigned To"); 
}

public MemberOfRL LastModifiedDateTime(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date/Time",RowIndex); 
}
public MemberOfRL LastModifiedDateTime() throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date/Time"); 
}

}


 public Columns_NotesAttachments RL_NotesAttachments() throws Exception{ 
return new Columns_NotesAttachments("Notes & Attachments"); 
} 
public class Columns_NotesAttachments{ 
Columns_NotesAttachments(String RL) 
{ 
RList = RL; 
} 

}

 
 
public MemberOfButton DeleteButton() throws Exception{ 
return sfdc.Button("Delete"); 
} 
public MemberOfButton CancelButton() throws Exception{ 
return sfdc.Button("Cancel"); 
} 
public MemberOfButton AttachFileButton() throws Exception{ 
return sfdc.Button("Attach File"); 
} 
public MemberOfButton MailMergeButton() throws Exception{ 
return sfdc.Button("Mail Merge"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton NewTaskButton() throws Exception{ 
return sfdc.Button("New Task"); 
} 
public MemberOfButton EditButton() throws Exception{ 
return sfdc.Button("Edit"); 
} 
public MemberOfButton NewEventButton() throws Exception{ 
return sfdc.Button("New Event"); 
} 
public MemberOfButton SendanEmailButton() throws Exception{ 
return sfdc.Button("Send an Email"); 
} 
public MemberOfButton ViewAllButton() throws Exception{ 
return sfdc.Button("View All"); 
} 
public MemberOfButton ActivateButton() throws Exception{ 
return sfdc.Button("Activate"); 
} 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton LogaCallButton() throws Exception{ 
return sfdc.Button("Log a Call"); 
} 
public MemberOfButton NewNoteButton() throws Exception{ 
return sfdc.Button("New Note"); 
} 
public MemberOfButton OKButton() throws Exception{ 
return sfdc.Button("OK"); 
} 
public MemberOfButton CloneButton() throws Exception{ 
return sfdc.Button("Clone"); 
} 
}
