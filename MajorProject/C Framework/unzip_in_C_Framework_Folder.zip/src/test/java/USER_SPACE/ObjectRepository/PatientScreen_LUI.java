package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class PatientScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public PatientScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public PatientScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI PatientOwnerField() throws Exception{  
return sfdc.Field_LUI("Patient Owner"); 
} 
 
public MemberOfField_LUI PatientRecordTypeField() throws Exception{  
return sfdc.Field_LUI("Patient Record Type"); 
} 
 
public MemberOfField_LUI AccountNameField() throws Exception{  
return sfdc.Field_LUI("Account Name"); 
} 
 
public MemberOfField_LUI SSNIDField() throws Exception{  
return sfdc.Field_LUI("SSN ID"); 
} 
 
public MemberOfField_LUI NameField() throws Exception{  
return sfdc.Field_LUI("Name"); 
} 
 
public MemberOfField_LUI StatusField() throws Exception{  
return sfdc.Field_LUI("Status"); 
} 
 
public MemberOfField_LUI BirthDateField() throws Exception{  
return sfdc.Field_LUI("Birth Date"); 
} 
 
public MemberOfField_LUI PatientTreatmentstatusField() throws Exception{  
return sfdc.Field_LUI("Patient Treatment status"); 
} 
 
public MemberOfField_LUI GenderField() throws Exception{  
return sfdc.Field_LUI("Gender"); 
} 
 
public MemberOfField_LUI ActionField() throws Exception{  
return sfdc.Field_LUI("Action"); 
} 
 
public MemberOfField_LUI EthnicityField() throws Exception{  
return sfdc.Field_LUI("Ethnicity"); 
} 
 
public MemberOfField_LUI PatientIdField() throws Exception{  
return sfdc.Field_LUI("Patient Id"); 
} 
 
public MemberOfField_LUI HeightcmField() throws Exception{  
return sfdc.Field_LUI("Height (cm)"); 
} 
 
public MemberOfField_LUI PreviouspatientIDField() throws Exception{  
return sfdc.Field_LUI("Previous patient ID"); 
} 
 
public MemberOfField_LUI WeightkgField() throws Exception{  
return sfdc.Field_LUI("Weight (kg)"); 
} 
 
public MemberOfField_LUI BrandField() throws Exception{  
return sfdc.Field_LUI("Brand"); 
} 
 
public MemberOfField_LUI PregnancyField() throws Exception{  
return sfdc.Field_LUI("Pregnancy"); 
} 
 
public MemberOfField_LUI TherapeuticAreaField() throws Exception{  
return sfdc.Field_LUI("Therapeutic Area"); 
} 
 
public MemberOfField_LUI PregnancyWeeksField() throws Exception{  
return sfdc.Field_LUI("Pregnancy (Weeks)"); 
} 
 
public MemberOfField_LUI OwnerChangedField() throws Exception{  
return sfdc.Field_LUI("OwnerChanged"); 
} 
 
public MemberOfField_LUI PatientUpdatedTreatmentStatusField() throws Exception{  
return sfdc.Field_LUI("Patient Updated Treatment Status"); 
} 
 
public MemberOfField_LUI AddressLine1Field() throws Exception{  
return sfdc.Field_LUI("Address Line1"); 
} 
 
public MemberOfField_LUI MailingaddresssameasmainaddressField() throws Exception{  
return sfdc.Field_LUI("Mailing address same as main address?"); 
} 
 
public MemberOfField_LUI AddressLine2Field() throws Exception{  
return sfdc.Field_LUI("Address Line2"); 
} 
 
public MemberOfField_LUI MailingAddressField() throws Exception{  
return sfdc.Field_LUI("Mailing Address"); 
} 
 
public MemberOfField_LUI AddressTypeField() throws Exception{  
return sfdc.Field_LUI("Address Type"); 
} 
 
public MemberOfField_LUI AddressClassificationField() throws Exception{  
return sfdc.Field_LUI("Address Classification"); 
} 
 
public MemberOfField_LUI CityTownField() throws Exception{  
return sfdc.Field_LUI("City/Town"); 
} 
 
public MemberOfField_LUI CountryCodeField() throws Exception{  
return sfdc.Field_LUI("Country Code"); 
} 
 
public MemberOfField_LUI PatientZipPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Patient Zip / Postal Code"); 
} 
 
public MemberOfField_LUI AlternativeAddressLine1Field() throws Exception{  
return sfdc.Field_LUI("Alternative Address Line 1"); 
} 
 
public MemberOfField_LUI AlternativeAddressLine2Field() throws Exception{  
return sfdc.Field_LUI("Alternative Address Line 2"); 
} 
 
public MemberOfField_LUI AlternativeAddressTypeField() throws Exception{  
return sfdc.Field_LUI("Alternative Address Type"); 
} 
 
public MemberOfField_LUI AlternativeAddressClassificationField() throws Exception{  
return sfdc.Field_LUI("Alternative Address Classification"); 
} 
 
public MemberOfField_LUI AlternativeAddressPostcodeField() throws Exception{  
return sfdc.Field_LUI("Alternative Address Postcode"); 
} 
 
public MemberOfField_LUI MainContactField() throws Exception{  
return sfdc.Field_LUI("Main Contact"); 
} 
 
public MemberOfField_LUI PhoneField() throws Exception{  
return sfdc.Field_LUI("Phone"); 
} 
 
public MemberOfField_LUI PatientscommunicationchannelField() throws Exception{  
return sfdc.Field_LUI("Patient's communication channel"); 
} 
 
public MemberOfField_LUI EmailField() throws Exception{  
return sfdc.Field_LUI("Email"); 
} 
 
public MemberOfField_LUI BestdaytocontactyouField() throws Exception{  
return sfdc.Field_LUI("Best day to contact you"); 
} 
 
public MemberOfField_LUI BesttimetocontactyouField() throws Exception{  
return sfdc.Field_LUI("Best time to contact you"); 
} 
 
public MemberOfField_LUI CarerTitleField() throws Exception{  
return sfdc.Field_LUI("Carer Title"); 
} 
 
public MemberOfField_LUI CarerAddressLine1Field() throws Exception{  
return sfdc.Field_LUI("Carer Address Line1"); 
} 
 
public MemberOfField_LUI CarerFirstNameField() throws Exception{  
return sfdc.Field_LUI("Carer First Name"); 
} 
 
public MemberOfField_LUI CarerAddressLine2Field() throws Exception{  
return sfdc.Field_LUI("Carer Address Line2"); 
} 
 
public MemberOfField_LUI CarerLastNameField() throws Exception{  
return sfdc.Field_LUI("Carer Last Name"); 
} 
 
public MemberOfField_LUI CarerCityField() throws Exception{  
return sfdc.Field_LUI("Carer City"); 
} 
 
public MemberOfField_LUI CarerPhoneField() throws Exception{  
return sfdc.Field_LUI("Carer Phone"); 
} 
 
public MemberOfField_LUI CarerPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Carer Postal Code"); 
} 
 
public MemberOfField_LUI CarerEmailField() throws Exception{  
return sfdc.Field_LUI("Carer Email"); 
} 
 
public MemberOfField_LUI RelationshiptopatientField() throws Exception{  
return sfdc.Field_LUI("Relationship to patient"); 
} 
 
public MemberOfField_LUI DuodopastartdateField() throws Exception{  
return sfdc.Field_LUI("Duodopa start date"); 
} 
 
public MemberOfField_LUI ProceduretobeperformedField() throws Exception{  
return sfdc.Field_LUI("Procedure to be performed"); 
} 
 
public MemberOfField_LUI ReasonfortheLateTitrationField() throws Exception{  
return sfdc.Field_LUI("Reason for the Late Titration"); 
} 
 
public MemberOfField_LUI HospitaladmissiondateField() throws Exception{  
return sfdc.Field_LUI("Hospital admission date"); 
} 
 
public MemberOfField_LUI HospitaladmissiondateconfirmedField() throws Exception{  
return sfdc.Field_LUI("Hospital admission date confirmed?"); 
} 
 
public MemberOfField_LUI NJPlacementDateField() throws Exception{  
return sfdc.Field_LUI("NJ Placement Date"); 
} 
 
public MemberOfField_LUI NJPlacementDateConfirmedField() throws Exception{  
return sfdc.Field_LUI("NJ Placement Date Confirmed ?"); 
} 
 
public MemberOfField_LUI PEGJPEJTPortPlacementDateField() throws Exception{  
return sfdc.Field_LUI("PEG-J/PEJ/T-Port Placement Date"); 
} 
 
public MemberOfField_LUI PEGJPEJTPortPlacementDateConfirmField() throws Exception{  
return sfdc.Field_LUI("PEG-J/ PEJ/T-Port Placement Date Confirm"); 
} 
 
public MemberOfField_LUI NJProceduretypeField() throws Exception{  
return sfdc.Field_LUI("NJ Procedure type"); 
} 
 
public MemberOfField_LUI NJReplacementDateField() throws Exception{  
return sfdc.Field_LUI("NJ Replacement Date"); 
} 
 
public MemberOfField_LUI PEGJPEJTPortProceduretypeField() throws Exception{  
return sfdc.Field_LUI("PEG-J/PEJ/T-Port Procedure type"); 
} 
 
public MemberOfField_LUI PEGJPEJTPortReplacementDateField() throws Exception{  
return sfdc.Field_LUI("PEG-J/PEJ/T-Port Replacement Date"); 
} 
 
public MemberOfField_LUI PatientDischargeDateField() throws Exception{  
return sfdc.Field_LUI("Patient Discharge Date"); 
} 
 
public MemberOfField_LUI TitrationassistancerequiredField() throws Exception{  
return sfdc.Field_LUI("Titration assistance required?"); 
} 
 
public MemberOfField_LUI PatientMonitoringField() throws Exception{  
return sfdc.Field_LUI("Patient Monitoring"); 
} 
 
public MemberOfField_LUI EducationField() throws Exception{  
return sfdc.Field_LUI("Education"); 
} 
 
public MemberOfField_LUI ProcedureAssistanceField() throws Exception{  
return sfdc.Field_LUI("Procedure Assistance"); 
} 
 
public MemberOfField_LUI TypeofFollowuptreatmentField() throws Exception{  
return sfdc.Field_LUI("Type of Follow up treatment"); 
} 
 
public MemberOfField_LUI ScheduleFirstContactField() throws Exception{  
return sfdc.Field_LUI("Schedule First Contact"); 
} 
 
public MemberOfField_LUI CurrentPatientJourneyNameField() throws Exception{  
return sfdc.Field_LUI("Current Patient Journey Name"); 
} 
 
public MemberOfField_LUI PatientReinstatedField() throws Exception{  
return sfdc.Field_LUI("Patient Re-instated?"); 
} 
 
public MemberOfField_LUI JourneyStartDateField() throws Exception{  
return sfdc.Field_LUI("Journey Start Date"); 
} 
 
public MemberOfField_LUI ReInstateDateField() throws Exception{  
return sfdc.Field_LUI("Re-Instate Date"); 
} 
 
public MemberOfField_LUI PatientJourneyCreatedField() throws Exception{  
return sfdc.Field_LUI("Patient Journey Created?"); 
} 
 
public MemberOfField_LUI IndicativetreatmentrestartDateField() throws Exception{  
return sfdc.Field_LUI("Indicative treatment restart Date"); 
} 
 
public MemberOfField_LUI TreatingCentreNameField() throws Exception{  
return sfdc.Field_LUI("Treating Centre Name"); 
} 
 
public MemberOfField_LUI DoctorNameField() throws Exception{  
return sfdc.Field_LUI("Doctor Name"); 
} 
 
public MemberOfField_LUI HCPEmailField() throws Exception{  
return sfdc.Field_LUI("HCP Email"); 
} 
 
public MemberOfField_LUI TreatingPDNurseField() throws Exception{  
return sfdc.Field_LUI("Treating PD Nurse"); 
} 
 
public MemberOfField_LUI ReferringCentreNameField() throws Exception{  
return sfdc.Field_LUI("Referring Centre Name"); 
} 
 
public MemberOfField_LUI ReferringSpecialistField() throws Exception{  
return sfdc.Field_LUI("Referring Specialist"); 
} 
 
public MemberOfField_LUI FreelanceNurseField() throws Exception{  
return sfdc.Field_LUI("Freelance Nurse"); 
} 
 
public MemberOfField_LUI HomeCareNameField() throws Exception{  
return sfdc.Field_LUI("Home Care Name"); 
} 
 
public MemberOfField_LUI HomeCareTypeField() throws Exception{  
return sfdc.Field_LUI("Home Care Type"); 
} 
 
public MemberOfField_LUI HomeCareAddressLine1Field() throws Exception{  
return sfdc.Field_LUI("Home Care Address Line 1"); 
} 
 
public MemberOfField_LUI HomeCareAddressLine2Field() throws Exception{  
return sfdc.Field_LUI("Home Care Address Line 2"); 
} 
 
public MemberOfField_LUI HomeCareCityField() throws Exception{  
return sfdc.Field_LUI("Home Care City"); 
} 
 
public MemberOfField_LUI HomeCarePostcodeField() throws Exception{  
return sfdc.Field_LUI("Home Care Postcode"); 
} 
 
public MemberOfField_LUI ContactNumberField() throws Exception{  
return sfdc.Field_LUI("Contact Number"); 
} 
 
public MemberOfField_LUI HomeCareKeyContactNumberField() throws Exception{  
return sfdc.Field_LUI("Home Care Key Contact Number"); 
} 
 
public MemberOfField_LUI HCPprivacystmtAlcuracancontactField() throws Exception{  
return sfdc.Field_LUI("HCP privacy stmt - Alcura can contact"); 
} 
 
public MemberOfField_LUI FullPSPconsentField() throws Exception{  
return sfdc.Field_LUI("Full PSP consent"); 
} 
 
public MemberOfField_LUI MedicaldatacanberetrievedfromHCPField() throws Exception{  
return sfdc.Field_LUI("Medical data can be retrieved from HCP"); 
} 
 
public MemberOfField_LUI LSPconsentField() throws Exception{  
return sfdc.Field_LUI("LSP consent"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
  
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_OtherRelevantInformations RL_OtherRelevantInformations() throws Exception{ 
return new Columns_OtherRelevantInformations("Other Relevant Informations"); 
} 
public class Columns_OtherRelevantInformations 
{ 
Columns_OtherRelevantInformations(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI OtherRelevantInformationName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Other Relevant Information Name"); 
} 
public MemberOfRL_LUI OtherRelevantInformationName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Other Relevant Information Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Catagory() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Catagory"); 
} 
public MemberOfRL_LUI Catagory(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Catagory",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Description() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Description"); 
} 
public MemberOfRL_LUI Description(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Description",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ActivityID() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Activity ID"); 
} 
public MemberOfRL_LUI ActivityID(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Activity ID",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CreatedDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created Date"); 
} 
public MemberOfRL_LUI CreatedDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_Cases RL_Cases() throws Exception{ 
return new Columns_Cases("Cases"); 
} 
public class Columns_Cases 
{ 
Columns_Cases(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Case() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Case"); 
} 
public MemberOfRL_LUI Case(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Case",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Subject() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Subject"); 
} 
public MemberOfRL_LUI Subject(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Subject",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Priority() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Priority"); 
} 
public MemberOfRL_LUI Priority(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Priority",TargetCOlumnValue); 
} 
public MemberOfRL_LUI DateTimeOpened() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date/Time Opened"); 
} 
public MemberOfRL_LUI DateTimeOpened(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date/Time Opened",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Eventtype() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Event type"); 
} 
public MemberOfRL_LUI Eventtype(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Event type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI HealthcloudAEPQCcaseID() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Healthcloud AE/PQC case ID #"); 
} 
public MemberOfRL_LUI HealthcloudAEPQCcaseID(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Healthcloud AE/PQC case ID #",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI ChangeOwnerButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Change OwnerButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_Files RL_Files() throws Exception{ 
return new Columns_Files("Files"); 
} 
public class Columns_Files 
{ 
Columns_Files(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AddFilesButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Add FilesButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_PatientHistory RL_PatientHistory() throws Exception{ 
return new Columns_PatientHistory("Patient History"); 
} 
public class Columns_PatientHistory 
{ 
Columns_PatientHistory(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Date() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date"); 
} 
public MemberOfRL_LUI Date(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Field() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Field"); 
} 
public MemberOfRL_LUI Field(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Field",TargetCOlumnValue); 
} 
public MemberOfRL_LUI User() throws Exception 
{ 
return sfdc.RL_LUI(RList,"User"); 
} 
public MemberOfRL_LUI User(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"User",TargetCOlumnValue); 
} 
public MemberOfRL_LUI OriginalValue() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Original Value"); 
} 
public MemberOfRL_LUI OriginalValue(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Original Value",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewValue() throws Exception 
{ 
return sfdc.RL_LUI(RList,"New Value"); 
} 
public MemberOfRL_LUI NewValue(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"New Value",TargetCOlumnValue); 
} 
/*public MemberOfRL_LUI 5820191353() throws Exception 
{ 
return sfdc.RL_LUI(RList,"5-8-2019 13:53"); 
} 
public MemberOfRL_LUI 5820191353(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"5-8-2019 13:53",TargetCOlumnValue); 
} 
public MemberOfRL_LUI 2122019619() throws Exception 
{ 
return sfdc.RL_LUI(RList,"21-2-2019 6:19"); 
} 
public MemberOfRL_LUI 2122019619(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"21-2-2019 6:19",TargetCOlumnValue); 
} 
public MemberOfRL_LUI 712019828() throws Exception 
{ 
return sfdc.RL_LUI(RList,"7-1-2019 8:28"); 
} 
public MemberOfRL_LUI 712019828(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"7-1-2019 8:28",TargetCOlumnValue); 
} 
public MemberOfRL_LUI 712019804() throws Exception 
{ 
return sfdc.RL_LUI(RList,"7-1-2019 8:04"); 
} 
public MemberOfRL_LUI 712019804(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"7-1-2019 8:04",TargetCOlumnValue); 
} 
public MemberOfRL_LUI 4120191214() throws Exception 
{ 
return sfdc.RL_LUI(RList,"4-1-2019 12:14"); 
} 
public MemberOfRL_LUI 4120191214(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"4-1-2019 12:14",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  */
} 

//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI EditButton() throws Exception{ 
return sfdc.Button_LUI("Edit"); 
} 
public MemberOfButton_LUI GeneratePatientJourneyButton() throws Exception{ 
return sfdc.Button_LUI("Generate Patient Journey"); 
} 
public MemberOfButton_LUI MenuButtonNEWTASKButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:NEW TASK"); 
} 
public MemberOfButton_LUI MenuButtonQuickCaseandTaskButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Quick Case and Task"); 
} 
public MemberOfButton_LUI MenuButtonViewlatestotherdevicesreportButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:View latest other devices report"); 
} 
public MemberOfButton_LUI MenuButtonFileUploadButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:File Upload"); 
} 
public MemberOfButton_LUI MenuButtonChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Change Owner"); 
} 
public MemberOfButton_LUI MenuButtonViewlatestpumpreportButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:View latest pump report"); 
} 
public MemberOfButton_LUI MenuButtonViewLatesttubeconnectorreportButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:View Latest tube & connector report"); 
} 
public MemberOfButton_LUI MenuButtonViewlatestassessoriesreportButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:View latest assessories report"); 
} 
public MemberOfButton_LUI MenuButtonViewlatestcassettesreportButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:View latest cassettes report"); 
} 
public MemberOfButton_LUI MenuButtonViewLatestDrugandDeviceButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:View Latest Drug and Device"); 
} 
public MemberOfButton_LUI MenuButtonViewHistoricalDrugandDeviceButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:View Historical Drug and Device"); 
} 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Selectanobjecttolimityoursearch_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select an object to limit your search"); 
} 
public MemberOfHealthCloud_LUI SearchSalesforce_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Salesforce"); 
} 
public MemberOfHealthCloud_LUI DuodopaProcedurePEGJ_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Duodopa Procedure - PEG-J"); 
} 
public MemberOfHealthCloud_LUI IntakeCall_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Intake Call"); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
