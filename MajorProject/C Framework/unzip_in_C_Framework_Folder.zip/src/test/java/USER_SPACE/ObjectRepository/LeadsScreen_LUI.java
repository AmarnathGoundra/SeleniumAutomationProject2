package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class LeadsScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public LeadsScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public LeadsScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI LeadOwnerField() throws Exception{  
return sfdc.Field_LUI("Lead Owner"); 
} 
 
public MemberOfField_LUI PhoneField() throws Exception{  
return sfdc.Field_LUI("Phone"); 
} 
 
public MemberOfField_LUI NameField() throws Exception{  
return sfdc.Field_LUI("Name"); 
} 
 
public MemberOfField_LUI MobileField() throws Exception{  
return sfdc.Field_LUI("Mobile"); 
} 
 
public MemberOfField_LUI CompanyField() throws Exception{  
return sfdc.Field_LUI("Company"); 
} 
 
public MemberOfField_LUI FaxField() throws Exception{  
return sfdc.Field_LUI("Fax"); 
} 
 
public MemberOfField_LUI TitleField() throws Exception{  
return sfdc.Field_LUI("Title"); 
} 
 
public MemberOfField_LUI EmailField() throws Exception{  
return sfdc.Field_LUI("Email"); 
} 
 
public MemberOfField_LUI LeadSourceField() throws Exception{  
return sfdc.Field_LUI("Lead Source"); 
} 
 
public MemberOfField_LUI WebsiteField() throws Exception{  
return sfdc.Field_LUI("Website"); 
} 
 
public MemberOfField_LUI IndustryField() throws Exception{  
return sfdc.Field_LUI("Industry"); 
} 
 
public MemberOfField_LUI LeadStatusField() throws Exception{  
return sfdc.Field_LUI("Lead Status"); 
} 
 
public MemberOfField_LUI AnnualRevenueField() throws Exception{  
return sfdc.Field_LUI("Annual Revenue"); 
} 
 
public MemberOfField_LUI RatingField() throws Exception{  
return sfdc.Field_LUI("Rating"); 
} 
 
public MemberOfField_LUI NoofEmployeesField() throws Exception{  
return sfdc.Field_LUI("No. of Employees"); 
} 
 
public MemberOfField_LUI AddressField() throws Exception{  
return sfdc.Field_LUI("Address"); 
} 
 
public MemberOfField_LUI ProductInterestField() throws Exception{  
return sfdc.Field_LUI("Product Interest"); 
} 
 
public MemberOfField_LUI CurrentGeneratorsField() throws Exception{  
return sfdc.Field_LUI("Current Generator(s)"); 
} 
 
public MemberOfField_LUI SICCodeField() throws Exception{  
return sfdc.Field_LUI("SIC Code"); 
} 
 
public MemberOfField_LUI PrimaryField() throws Exception{  
return sfdc.Field_LUI("Primary"); 
} 
 
public MemberOfField_LUI NumberofLocationsField() throws Exception{  
return sfdc.Field_LUI("Number of Locations"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
public MemberOfField_LUI SalutationField() throws Exception{  
return sfdc.Field_LUI("Salutation"); 
} 
 
public MemberOfField_LUI FirstNameField() throws Exception{  
return sfdc.Field_LUI("First Name"); 
} 
 
public MemberOfField_LUI LastNameField() throws Exception{  
return sfdc.Field_LUI("Last Name"); 
} 
 
public MemberOfField_LUI StreetField() throws Exception{  
return sfdc.Field_LUI("Street"); 
} 
 
public MemberOfField_LUI CityField() throws Exception{  
return sfdc.Field_LUI("City"); 
} 
 
public MemberOfField_LUI StateProvinceField() throws Exception{  
return sfdc.Field_LUI("State/Province"); 
} 
 
public MemberOfField_LUI ZipPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Zip/Postal Code"); 
} 
 
public MemberOfField_LUI CountryField() throws Exception{  
return sfdc.Field_LUI("Country"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 public Columns_Leads LV_Leads() throws Exception{ 
return new Columns_Leads("Leads"); 
} 
public class Columns_Leads 
{ 
Columns_Leads(String RL) 
{ 
RList = RL;  
}  
public MemberOfLV_LUI Name() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Name"); 
} 
public MemberOfLV_LUI Name(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Title() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Title"); 
} 
public MemberOfLV_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Company() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Company"); 
} 
public MemberOfLV_LUI Company(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Company",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Phone() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Phone"); 
} 
public MemberOfLV_LUI Phone(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Phone",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Mobile() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Mobile"); 
} 
public MemberOfLV_LUI Mobile(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Mobile",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Email() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Email"); 
} 
public MemberOfLV_LUI Email(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Email",TargetCOlumnValue); 
} 
public MemberOfLV_LUI LeadStatus() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Lead Status"); 
} 
public MemberOfLV_LUI LeadStatus(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Lead Status",TargetCOlumnValue); 
} 
public MemberOfLV_LUI OwnerAlias() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner Alias"); 
} 
public MemberOfLV_LUI OwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner Alias",TargetCOlumnValue); 
} 
public MemberOfLV_LUI NewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"NewButton");  
} 
public MemberOfLV_LUI ImportButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"ImportButton");  
} 
public MemberOfLV_LUI AddtoCampaignButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Add to CampaignButton");  
} 
public MemberOfLV_LUI ChangeStatusButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Change StatusButton");  
} 
public MemberOfLV_LUI ChangeOwnerButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Change OwnerButton");  
} 
public MemberOfLV_LUI MenuButtonSendListEmailButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonSend List EmailButton");  
} 
public MemberOfLV_LUI ConvertButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"ConvertButton");  
} 
public MemberOfLV_LUI EditButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"EditButton");  
} 
public MemberOfLV_LUI NewCaseButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New CaseButton");  
} 
public MemberOfLV_LUI MenuButtonNewNoteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonNew NoteButton");  
} 
public MemberOfLV_LUI MenuButtonDeleteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonDeleteButton");  
} 
public MemberOfLV_LUI MenuButtonChangeOwnerButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonChange OwnerButton");  
} 
public MemberOfLV_LUI MenuButtonCloneButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonCloneButton");  
} 
public MemberOfLV_LUI MenuButtonCheckforNewDataButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonCheck for New DataButton");  
} 
public MemberOfLV_LUI MenuButtonPrintableViewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonPrintable ViewButton");  
} 
public MemberOfLV_LUI CancelButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"CancelButton");  
} 
public MemberOfLV_LUI SaveNewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Save & NewButton");  
} 
public MemberOfLV_LUI SaveButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"SaveButton");  
} 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_CampaignHistory RL_CampaignHistory() throws Exception{ 
return new Columns_CampaignHistory("Campaign History"); 
} 
public class Columns_CampaignHistory 
{ 
Columns_CampaignHistory(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI CampaignName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Campaign Name"); 
} 
public MemberOfRL_LUI CampaignName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Campaign Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI StartDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Start Date"); 
} 
public MemberOfRL_LUI StartDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Start Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Type() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Type"); 
} 
public MemberOfRL_LUI Type(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Responded() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Responded"); 
} 
public MemberOfRL_LUI Responded(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Responded",TargetCOlumnValue); 
} 
public MemberOfRL_LUI MemberStatusUpdated() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Member Status Updated"); 
} 
public MemberOfRL_LUI MemberStatusUpdated(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Member Status Updated",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AddtoCampaignButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Add to CampaignButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewButton() throws Exception{ 
return sfdc.Button_LUI("New"); 
} 
public MemberOfButton_LUI ImportButton() throws Exception{ 
return sfdc.Button_LUI("Import"); 
} 
public MemberOfButton_LUI AddtoCampaignButton() throws Exception{ 
return sfdc.Button_LUI("Add to Campaign"); 
} 
public MemberOfButton_LUI ChangeStatusButton() throws Exception{ 
return sfdc.Button_LUI("Change Status"); 
} 
public MemberOfButton_LUI ChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("Change Owner"); 
} 
public MemberOfButton_LUI MenuButtonSendListEmailButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Send List Email"); 
} 
public MemberOfButton_LUI ConvertButton() throws Exception{ 
return sfdc.Button_LUI("Convert"); 
} 
public MemberOfButton_LUI EditButton() throws Exception{ 
return sfdc.Button_LUI("Edit"); 
} 
public MemberOfButton_LUI DeleteButton() throws Exception{ 
return sfdc.Button_LUI("Delete"); 
} 
public MemberOfButton_LUI NewCaseButton() throws Exception{ 
return sfdc.Button_LUI("New Case"); 
} 
public MemberOfButton_LUI MenuButtonNewNoteButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:New Note"); 
} 
public MemberOfButton_LUI MenuButtonDeleteButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Delete"); 
} 
public MemberOfButton_LUI MenuButtonConvertButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Convert"); 
}
public MemberOfButton_LUI MenuButtonChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Change Owner"); 
} 
public MemberOfButton_LUI MenuButtonCloneButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Clone"); 
} 
public MemberOfButton_LUI MenuButtonEditButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Edit"); 
} 
public MemberOfButton_LUI MenuButtonCheckforNewDataButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Check for New Data"); 
} 
public MemberOfButton_LUI MenuButtonPrintableViewButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Printable View"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveNewButton() throws Exception{ 
return sfdc.Button_LUI("Save & New"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
public MemberOfButton_LUI GotoLeadsButton() throws Exception{ 
return sfdc.Button_LUI("Go to Leads"); 
} 
//************************* Functions for All Apps ***************************** // 
 
//************************* Functions for Tabs List ***************************** // 
 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Searchbyobjecttype_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search by object type"); 
} 
public MemberOfHealthCloud_LUI SearchLeadsandmore_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Leads and more"); 
} 
public MemberOfHealthCloud_LUI Searchthislist_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search this list..."); 
} 
public MemberOfHealthCloud_LUI Select7items_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select 7 items"); 
} 
public MemberOfHealthCloud_LUI Selectitem1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 1"); 
} 
public MemberOfHealthCloud_LUI Selectitem2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 2"); 
} 
public MemberOfHealthCloud_LUI Selectitem3_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 3"); 
} 
public MemberOfHealthCloud_LUI Selectitem4_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 4"); 
} 
public MemberOfHealthCloud_LUI Selectitem5_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 5"); 
} 
public MemberOfHealthCloud_LUI Selectitem6_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 6"); 
} 
public MemberOfHealthCloud_LUI Selectitem7_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 7"); 
} 
public MemberOfHealthCloud_LUI SearchSalesforce_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Salesforce"); 
} 
public MemberOfHealthCloud_LUI Phone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Phone"); 
} 
public MemberOfHealthCloud_LUI FirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("First Name"); 
} 
public MemberOfHealthCloud_LUI LastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Last Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI Mobile_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mobile"); 
} 
public MemberOfHealthCloud_LUI Company_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Company"); 
} 
public MemberOfHealthCloud_LUI Fax_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Fax"); 
} 
public MemberOfHealthCloud_LUI Title_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Title"); 
} 
public MemberOfHealthCloud_LUI Email_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Email"); 
} 
public MemberOfHealthCloud_LUI Website_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Website"); 
} 
public MemberOfHealthCloud_LUI AnnualRevenue_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Annual Revenue"); 
} 
public MemberOfHealthCloud_LUI NoofEmployees_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("No. of Employees"); 
} 
public MemberOfHealthCloud_LUI Street_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Street"); 
} 
public MemberOfHealthCloud_LUI City_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("City"); 
} 
public MemberOfHealthCloud_LUI StateProvince_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("State/Province"); 
} 
public MemberOfHealthCloud_LUI ZipPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Zip/Postal Code"); 
} 
public MemberOfHealthCloud_LUI Country_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Country"); 
} 
public MemberOfHealthCloud_LUI CurrentGenerators_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Current Generator(s)"); 
} 
public MemberOfHealthCloud_LUI SICCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SIC Code"); 
} 
public MemberOfHealthCloud_LUI NumberofLocations_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Number of Locations"); 
} 
public MemberOfHealthCloud_LUI Description_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Description"); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
