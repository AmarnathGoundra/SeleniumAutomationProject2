package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class ProductsScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public ProductsScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public ProductsScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI SearchthislistField() throws Exception{  
return sfdc.Field_LUI("Search this list..."); 
} 
 
public MemberOfField_LUI ProductNameField() throws Exception{  
return sfdc.Field_LUI("Product Name"); 
} 
 
public MemberOfField_LUI ActiveField() throws Exception{  
return sfdc.Field_LUI("Active"); 
} 
 
public MemberOfField_LUI ProductCodeField() throws Exception{  
return sfdc.Field_LUI("Product Code"); 
} 
 
public MemberOfField_LUI ProductFamilyField() throws Exception{  
return sfdc.Field_LUI("Product Family"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
public MemberOfField_LUI ProductDescriptionField() throws Exception{  
return sfdc.Field_LUI("Product Description"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 public Columns_Products LV_Products() throws Exception{ 
return new Columns_Products("Products"); 
} 
public class Columns_Products 
{ 
Columns_Products(String RL) 
{ 
RList = RL;  
}  
public MemberOfLV_LUI ProductName() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Product Name"); 
} 
public MemberOfLV_LUI ProductName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Product Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI ProductCode() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Product Code"); 
} 
public MemberOfLV_LUI ProductCode(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Product Code",TargetCOlumnValue); 
} 
public MemberOfLV_LUI ProductDescription() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Product Description"); 
} 
public MemberOfLV_LUI ProductDescription(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Product Description",TargetCOlumnValue); 
} 
public MemberOfLV_LUI ProductFamily() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Product Family"); 
} 
public MemberOfLV_LUI ProductFamily(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Product Family",TargetCOlumnValue); 
} 
public MemberOfLV_LUI NewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"NewButton");  
} 
public MemberOfLV_LUI CancelButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"CancelButton");  
} 
public MemberOfLV_LUI SaveNewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Save & NewButton");  
} 
public MemberOfLV_LUI SaveButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"SaveButton");  
} 
public MemberOfLV_LUI NewContactButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New ContactButton");  
} 
public MemberOfLV_LUI NewOpportunityButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New OpportunityButton");  
} 
public MemberOfLV_LUI NewCaseButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New CaseButton");  
} 
public MemberOfLV_LUI MenuButtonNewLeadButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonNew LeadButton");  
} 
public MemberOfLV_LUI MenuButtonEditButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonEditButton");  
} 
public MemberOfLV_LUI MenuButtonDeleteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonDeleteButton");  
} 
public MemberOfLV_LUI MenuButtonCloneButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonCloneButton");  
} 
public MemberOfLV_LUI AddtoPriceBookButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Add to Price BookButton");  
} 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_PriceBooks RL_PriceBooks() throws Exception{ 
return new Columns_PriceBooks("Price Books"); 
} 
public class Columns_PriceBooks 
{ 
Columns_PriceBooks(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI PriceBookName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Price Book Name"); 
} 
public MemberOfRL_LUI PriceBookName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Price Book Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ListPrice() throws Exception 
{ 
return sfdc.RL_LUI(RList,"List Price"); 
} 
public MemberOfRL_LUI ListPrice(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"List Price",TargetCOlumnValue); 
} 
public MemberOfRL_LUI UseStandardPrice() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Use Standard Price"); 
} 
public MemberOfRL_LUI UseStandardPrice(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Use Standard Price",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Active() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Active"); 
} 
public MemberOfRL_LUI Active(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Active",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AddtoPriceBookButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Add to Price BookButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewButton() throws Exception{ 
return sfdc.Button_LUI("New"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveNewButton() throws Exception{ 
return sfdc.Button_LUI("Save & New"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
public MemberOfButton_LUI NewContactButton() throws Exception{ 
return sfdc.Button_LUI("New Contact"); 
} 
public MemberOfButton_LUI NewOpportunityButton() throws Exception{ 
return sfdc.Button_LUI("New Opportunity"); 
} 
public MemberOfButton_LUI NewCaseButton() throws Exception{ 
return sfdc.Button_LUI("New Case"); 
} 
public MemberOfButton_LUI MenuButtonNewLeadButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:New Lead"); 
} 
public MemberOfButton_LUI MenuButtonEditButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Edit"); 
} 
public MemberOfButton_LUI MenuButtonDeleteButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Delete"); 
} 
public MemberOfButton_LUI MenuButtonCloneButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Clone"); 
} 
public MemberOfButton_LUI AddtoPriceBookButton() throws Exception{ 
return sfdc.Button_LUI("Add to Price Book"); 
} 
//************************* Functions for All Apps ***************************** // 
 
//************************* Functions for Tabs List ***************************** // 
 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Searchthislist_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search this list..."); 
} 
public MemberOfHealthCloud_LUI Select3items_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select 3 items"); 
} 
public MemberOfHealthCloud_LUI Selectitem1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 1"); 
} 
public MemberOfHealthCloud_LUI Selectitem2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 2"); 
} 
public MemberOfHealthCloud_LUI Selectitem3_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 3"); 
} 
public MemberOfHealthCloud_LUI ProductName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Product Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI Active_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Active"); 
} 
public MemberOfHealthCloud_LUI ProductCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Product Code"); 
} 
public MemberOfHealthCloud_LUI ProductDescription_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Product Description"); 
} 
//************************* Functions for HC Button ***************************** // 


public MemberOfField_LUI ProductFamily() throws Exception {
	// TODO Auto-generated method stub
	return sfdc.Field_LUI("Product Family"); 
}


public MemberOfField_LUI ProductName() throws Exception {
	// TODO Auto-generated method stub
	return sfdc.Field_LUI("Product Name");
}

 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
