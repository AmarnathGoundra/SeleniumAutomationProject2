package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class OpportunityScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public OpportunityScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public OpportunityScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


//************************* Functions for List Views***************************** // 
 


 public Columns_ListView ListView() throws Exception{ 
return new Columns_ListView(); 
} 
public class Columns_ListView{ 
public MemberOfLV Action(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Action",RowIndex); 
}
public MemberOfLV Action() throws Exception 
{ 
return sfdc.LV("Action"); 
}

public MemberOfLV OpportunityName(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Opportunity Name",RowIndex); 
}
public MemberOfLV OpportunityName() throws Exception 
{ 
return sfdc.LV("Opportunity Name"); 
}

public MemberOfLV AccountName(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Account Name",RowIndex); 
}
public MemberOfLV AccountName() throws Exception 
{ 
return sfdc.LV("Account Name"); 
}

public MemberOfLV Amount(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Amount",RowIndex); 
}
public MemberOfLV Amount() throws Exception 
{ 
return sfdc.LV("Amount"); 
}

public MemberOfLV CloseDate(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Close Date",RowIndex); 
}
public MemberOfLV CloseDate() throws Exception 
{ 
return sfdc.LV("Close Date"); 
}

public MemberOfLV Stage(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Stage",RowIndex); 
}
public MemberOfLV Stage() throws Exception 
{ 
return sfdc.LV("Stage"); 
}

public MemberOfLV OpportunityOwnerAlias(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Opportunity Owner Alias",RowIndex); 
}
public MemberOfLV OpportunityOwnerAlias() throws Exception 
{ 
return sfdc.LV("Opportunity Owner Alias"); 
}

}

//************************* Functions for Buttons***************************** // 
 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton NewButton() throws Exception{ 
return sfdc.Button("New"); 
} 
public MemberOfButton RunReportButton() throws Exception{ 
return sfdc.Button("Run Report"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton NewOpportunityButton() throws Exception{ 
return sfdc.Button("New Opportunity"); 
} 
public MemberOfButton Button() throws Exception{ 
return sfdc.Button(""); 
} 
public MemberOfButton CancelButton() throws Exception{ 
return sfdc.Button("Cancel"); 
} 
public MemberOfButton EditButton() throws Exception{ 
return sfdc.Button("Edit"); 
} 
public MemberOfButton DeleteButton() throws Exception{ 
return sfdc.Button("Delete"); 
} 
public MemberOfButton CloneButton() throws Exception{ 
return sfdc.Button("Clone"); 
} 
public MemberOfButton AddProductButton() throws Exception{ 
return sfdc.Button("Add Product"); 
} 
public MemberOfButton EditAllButton() throws Exception{ 
return sfdc.Button("Edit All"); 
} 
public MemberOfButton ChoosePriceBookButton() throws Exception{ 
return sfdc.Button("Choose Price Book"); 
} 
public MemberOfButton SortButton() throws Exception{ 
return sfdc.Button("Sort"); 
} 
public MemberOfButton NewTaskButton() throws Exception{ 
return sfdc.Button("New Task"); 
} 
public MemberOfButton NewEventButton() throws Exception{ 
return sfdc.Button("New Event"); 
} 
public MemberOfButton LogaCallButton() throws Exception{ 
return sfdc.Button("Log a Call"); 
} 
public MemberOfButton MailMergeButton() throws Exception{ 
return sfdc.Button("Mail Merge"); 
} 
public MemberOfButton SendanEmailButton() throws Exception{ 
return sfdc.Button("Send an Email"); 
} 
public MemberOfButton ViewAllButton() throws Exception{ 
return sfdc.Button("View All"); 
} 
public MemberOfButton NewNoteButton() throws Exception{ 
return sfdc.Button("New Note"); 
} 
public MemberOfButton AttachFileButton() throws Exception{ 
return sfdc.Button("Attach File"); 
} 
public MemberOfButton OKButton() throws Exception{ 
return sfdc.Button("OK"); 
} 
//************************* Functions for Field Names ***************************** // 
 
public MemberOfField OpportunityOwnerField() throws Exception{ 
	return sfdc.Field("Opportunity Owner"); 
} 
public MemberOfField AmountField() throws Exception{ 
	return sfdc.Field("Amount"); 
} 
public MemberOfField PrivateField() throws Exception{ 
	return sfdc.Field("Private"); 
} 
public MemberOfField ExpectedRevenueField() throws Exception{ 
	return sfdc.Field("Expected Revenue"); 
} 
public MemberOfField OpportunityNameField() throws Exception{ 
	return sfdc.Field("Opportunity Name"); 
} 
public MemberOfField CloseDateField() throws Exception{ 
	return sfdc.Field("Close Date"); 
} 
public MemberOfField AccountNameField() throws Exception{ 
	return sfdc.Field("Account Name"); 
} 
public MemberOfField NextStepField() throws Exception{ 
	return sfdc.Field("Next Step"); 
} 
public MemberOfField TypeField() throws Exception{ 
	return sfdc.Field("Type"); 
} 
public MemberOfField StageField() throws Exception{ 
	return sfdc.Field("Stage"); 
} 
public MemberOfField LeadSourceField() throws Exception{ 
	return sfdc.Field("Lead Source"); 
} 
public MemberOfField ProbabilityField() throws Exception{ 
	return sfdc.Field("Probability (%)"); 
} 
public MemberOfField GeoLocationTestField() throws Exception{ 
	return sfdc.Field("GeoLocationTest"); 
} 
public MemberOfField PrimaryCampaignSourceField() throws Exception{ 
	return sfdc.Field("Primary Campaign Source"); 
} 
public MemberOfField OrderNumberField() throws Exception{ 
	return sfdc.Field("Order Number"); 
} 
public MemberOfField MainCompetitorsField() throws Exception{ 
	return sfdc.Field("Main Competitor(s)"); 
} 
public MemberOfField CurrentGeneratorsField() throws Exception{ 
	return sfdc.Field("Current Generator(s)"); 
} 
public MemberOfField DeliveryInstallationStatusField() throws Exception{ 
	return sfdc.Field("Delivery/Installation Status"); 
} 
public MemberOfField TrackingNumberField() throws Exception{ 
	return sfdc.Field("Tracking Number"); 
} 
public MemberOfField CreatedByField() throws Exception{ 
	return sfdc.Field("Created By"); 
} 
public MemberOfField LastModifiedByField() throws Exception{ 
	return sfdc.Field("Last Modified By"); 
} 
public MemberOfField DescriptionField() throws Exception{ 
	return sfdc.Field("Description"); 
} 
public MemberOfField Multi_Opp_TestField() throws Exception{ 
	return sfdc.Field("Multi_Opp_Test"); 
} 
public MemberOfField CustomLinksField() throws Exception{ 
	return sfdc.Field("Custom Links"); 
} 
//************************* Functions for Section Name***************************** // 
 
public MemberOfSEC SEC_OpportunityDetail_OpportunityOwnerField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Opportunity Owner"); 
}
public MemberOfSEC SEC_OpportunityDetail_AmountField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Amount"); 
}
public MemberOfSEC SEC_OpportunityDetail_PrivateField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Private"); 
}
public MemberOfSEC SEC_OpportunityDetail_ExpectedRevenueField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Expected Revenue"); 
}
public MemberOfSEC SEC_OpportunityDetail_OpportunityNameField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Opportunity Name"); 
}
public MemberOfSEC SEC_OpportunityDetail_CloseDateField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Close Date"); 
}
public MemberOfSEC SEC_OpportunityDetail_AccountNameField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Account Name"); 
}
public MemberOfSEC SEC_OpportunityDetail_NextStepField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Next Step"); 
}
public MemberOfSEC SEC_OpportunityDetail_TypeField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Type"); 
}
public MemberOfSEC SEC_OpportunityDetail_StageField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Stage"); 
}
public MemberOfSEC SEC_OpportunityDetail_LeadSourceField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Lead Source"); 
}
public MemberOfSEC SEC_OpportunityDetail_ProbabilityField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Probability (%)"); 
}
public MemberOfSEC SEC_OpportunityDetail_GeoLocationTestField() throws Exception { 
return sfdc.Section("Opportunity Detail", "GeoLocationTest"); 
}
public MemberOfSEC SEC_OpportunityDetail_PrimaryCampaignSourceField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Primary Campaign Source"); 
}
public MemberOfSEC SEC_OpportunityDetail_OrderNumberField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Order Number"); 
}
public MemberOfSEC SEC_OpportunityDetail_MainCompetitorsField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Main Competitor(s)"); 
}
public MemberOfSEC SEC_OpportunityDetail_CurrentGeneratorsField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Current Generator(s)"); 
}
public MemberOfSEC SEC_OpportunityDetail_DeliveryInstallationStatusField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Delivery/Installation Status"); 
}
public MemberOfSEC SEC_OpportunityDetail_TrackingNumberField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Tracking Number"); 
}
public MemberOfSEC SEC_OpportunityDetail_CreatedByField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Created By"); 
}
public MemberOfSEC SEC_OpportunityDetail_LastModifiedByField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Last Modified By"); 
}
public MemberOfSEC SEC_OpportunityDetail_DescriptionField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Description"); 
}
public MemberOfSEC SEC_OpportunityDetail_Multi_Opp_TestField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Multi_Opp_Test"); 
}
public MemberOfSEC SEC_OpportunityDetail_CustomLinksField() throws Exception { 
return sfdc.Section("Opportunity Detail", "Custom Links"); 
}
//************************* Functions for Related List***************************** // 
 


 public Columns_ProductsStandard RL_ProductsStandard() throws Exception{ 
return new Columns_ProductsStandard("Products (Standard)"); 
} 
public class Columns_ProductsStandard{ 
Columns_ProductsStandard(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Product(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Product",RowIndex); 
}
public MemberOfRL Product() throws Exception 
{ 
return sfdc.RL(RList,"Product"); 
}

public MemberOfRL Quantity(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Quantity",RowIndex); 
}
public MemberOfRL Quantity() throws Exception 
{ 
return sfdc.RL(RList,"Quantity"); 
}

public MemberOfRL SalesPrice(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Sales Price",RowIndex); 
}
public MemberOfRL SalesPrice() throws Exception 
{ 
return sfdc.RL(RList,"Sales Price"); 
}

public MemberOfRL Date(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Date",RowIndex); 
}
public MemberOfRL Date() throws Exception 
{ 
return sfdc.RL(RList,"Date"); 
}

public MemberOfRL LineDescription(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Line Description",RowIndex); 
}
public MemberOfRL LineDescription() throws Exception 
{ 
return sfdc.RL(RList,"Line Description"); 
}

}



 public Columns_OpenActivities RL_OpenActivities() throws Exception{ 
return new Columns_OpenActivities("Open Activities"); 
} 
public class Columns_OpenActivities{ 
Columns_OpenActivities(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Subject(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Subject",RowIndex); 
}
public MemberOfRL Subject() throws Exception 
{ 
return sfdc.RL(RList,"Subject"); 
}

public MemberOfRL Name(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Name",RowIndex); 
}
public MemberOfRL Name() throws Exception 
{ 
return sfdc.RL(RList,"Name"); 
}

public MemberOfRL Task(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Task",RowIndex); 
}
public MemberOfRL Task() throws Exception 
{ 
return sfdc.RL(RList,"Task"); 
}

public MemberOfRL DueDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Due Date",RowIndex); 
}
public MemberOfRL DueDate() throws Exception 
{ 
return sfdc.RL(RList,"Due Date"); 
}

public MemberOfRL Status(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Status",RowIndex); 
}
public MemberOfRL Status() throws Exception 
{ 
return sfdc.RL(RList,"Status"); 
}

public MemberOfRL Priority(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Priority",RowIndex); 
}
public MemberOfRL Priority() throws Exception 
{ 
return sfdc.RL(RList,"Priority"); 
}

public MemberOfRL AssignedTo(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Assigned To",RowIndex); 
}
public MemberOfRL AssignedTo() throws Exception 
{ 
return sfdc.RL(RList,"Assigned To"); 
}

}



 public Columns_ActivityHistory RL_ActivityHistory() throws Exception{ 
return new Columns_ActivityHistory("Activity History"); 
} 
public class Columns_ActivityHistory{ 
Columns_ActivityHistory(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Subject(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Subject",RowIndex); 
}
public MemberOfRL Subject() throws Exception 
{ 
return sfdc.RL(RList,"Subject"); 
}

public MemberOfRL Name(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Name",RowIndex); 
}
public MemberOfRL Name() throws Exception 
{ 
return sfdc.RL(RList,"Name"); 
}

public MemberOfRL Task(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Task",RowIndex); 
}
public MemberOfRL Task() throws Exception 
{ 
return sfdc.RL(RList,"Task"); 
}

public MemberOfRL DueDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Due Date",RowIndex); 
}
public MemberOfRL DueDate() throws Exception 
{ 
return sfdc.RL(RList,"Due Date"); 
}

public MemberOfRL AssignedTo(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Assigned To",RowIndex); 
}
public MemberOfRL AssignedTo() throws Exception 
{ 
return sfdc.RL(RList,"Assigned To"); 
}

public MemberOfRL LastModifiedDateTime(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date/Time",RowIndex); 
}
public MemberOfRL LastModifiedDateTime() throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date/Time"); 
}

}



 public Columns_NotesAttachments RL_NotesAttachments() throws Exception{ 
return new Columns_NotesAttachments("Notes & Attachments"); 
} 
public class Columns_NotesAttachments{ 
Columns_NotesAttachments(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Type(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Type",RowIndex); 
}
public MemberOfRL Type() throws Exception 
{ 
return sfdc.RL(RList,"Type"); 
}

public MemberOfRL Title(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Title",RowIndex); 
}
public MemberOfRL Title() throws Exception 
{ 
return sfdc.RL(RList,"Title"); 
}

public MemberOfRL LastModified(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Modified",RowIndex); 
}
public MemberOfRL LastModified() throws Exception 
{ 
return sfdc.RL(RList,"Last Modified"); 
}

public MemberOfRL CreatedBy(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Created By",RowIndex); 
}
public MemberOfRL CreatedBy() throws Exception 
{ 
return sfdc.RL(RList,"Created By"); 
}

}



 public Columns_ContactRoles RL_ContactRoles() throws Exception{ 
return new Columns_ContactRoles("Contact Roles"); 
} 
public class Columns_ContactRoles{ 
Columns_ContactRoles(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL ContactName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Contact Name",RowIndex); 
}
public MemberOfRL ContactName() throws Exception 
{ 
return sfdc.RL(RList,"Contact Name"); 
}

public MemberOfRL AccountName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Account Name",RowIndex); 
}
public MemberOfRL AccountName() throws Exception 
{ 
return sfdc.RL(RList,"Account Name"); 
}

public MemberOfRL Email(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Email",RowIndex); 
}
public MemberOfRL Email() throws Exception 
{ 
return sfdc.RL(RList,"Email"); 
}

public MemberOfRL Phone(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Phone",RowIndex); 
}
public MemberOfRL Phone() throws Exception 
{ 
return sfdc.RL(RList,"Phone"); 
}

public MemberOfRL Role(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Role",RowIndex); 
}
public MemberOfRL Role() throws Exception 
{ 
return sfdc.RL(RList,"Role"); 
}

public MemberOfRL Primary(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Primary",RowIndex); 
}
public MemberOfRL Primary() throws Exception 
{ 
return sfdc.RL(RList,"Primary"); 
}

}



 public Columns_Partners RL_Partners() throws Exception{ 
return new Columns_Partners("Partners"); 
} 
public class Columns_Partners{ 
Columns_Partners(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_Competitors RL_Competitors() throws Exception{ 
return new Columns_Competitors("Competitors"); 
} 
public class Columns_Competitors{ 
Columns_Competitors(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL CompetitorName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Competitor Name",RowIndex); 
}
public MemberOfRL CompetitorName() throws Exception 
{ 
return sfdc.RL(RList,"Competitor Name"); 
}

public MemberOfRL Strengths(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Strengths",RowIndex); 
}
public MemberOfRL Strengths() throws Exception 
{ 
return sfdc.RL(RList,"Strengths"); 
}

public MemberOfRL Weaknesses(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Weaknesses",RowIndex); 
}
public MemberOfRL Weaknesses() throws Exception 
{ 
return sfdc.RL(RList,"Weaknesses"); 
}

}



 public Columns_StageHistory RL_StageHistory() throws Exception{ 
return new Columns_StageHistory("Stage History"); 
} 
public class Columns_StageHistory{ 
Columns_StageHistory(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Stage(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Stage",RowIndex); 
}
public MemberOfRL Stage() throws Exception 
{ 
return sfdc.RL(RList,"Stage"); 
}

public MemberOfRL Amount(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Amount",RowIndex); 
}
public MemberOfRL Amount() throws Exception 
{ 
return sfdc.RL(RList,"Amount"); 
}

public MemberOfRL Probability(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Probability (%)",RowIndex); 
}
public MemberOfRL Probability() throws Exception 
{ 
return sfdc.RL(RList,"Probability (%)"); 
}

public MemberOfRL ExpectedRevenue(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Expected Revenue",RowIndex); 
}
public MemberOfRL ExpectedRevenue() throws Exception 
{ 
return sfdc.RL(RList,"Expected Revenue"); 
}

public MemberOfRL CloseDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Close Date",RowIndex); 
}
public MemberOfRL CloseDate() throws Exception 
{ 
return sfdc.RL(RList,"Close Date"); 
}

public MemberOfRL LastModified(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Modified",RowIndex); 
}
public MemberOfRL LastModified() throws Exception 
{ 
return sfdc.RL(RList,"Last Modified"); 
}

}

}

