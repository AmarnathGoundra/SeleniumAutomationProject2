package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class TaskScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public TaskScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public TaskScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI SubjectField() throws Exception{  
return sfdc.Field_LUI("Subject"); 
} 
 
public MemberOfField_LUI DueDateField() throws Exception{  
return sfdc.Field_LUI("Due Date"); 
} 
 
public MemberOfField_LUI StatusField() throws Exception{  
return sfdc.Field_LUI("Status"); 
} 
 
public MemberOfField_LUI StartDateTimeField() throws Exception{  
return sfdc.Field_LUI("Start Date & Time"); 
} 
 
public MemberOfField_LUI RelatedToField() throws Exception{  
return sfdc.Field_LUI("Related To"); 
} 
 
public MemberOfField_LUI EndDateTimeField() throws Exception{  
return sfdc.Field_LUI("End Date & Time"); 
} 
 
public MemberOfField_LUI PriorityField() throws Exception{  
return sfdc.Field_LUI("Priority"); 
} 
 
public MemberOfField_LUI ActiveField() throws Exception{  
return sfdc.Field_LUI("Active"); 
} 
 
public MemberOfField_LUI AssignedToField() throws Exception{  
return sfdc.Field_LUI("Assigned To"); 
} 
 
public MemberOfField_LUI NameField() throws Exception{  
return sfdc.Field_LUI("Name"); 
} 
 
public MemberOfField_LUI ActivityExtensionField() throws Exception{  
return sfdc.Field_LUI("Activity Extension"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
public MemberOfField_LUI TaskStatusField() throws Exception{  
return sfdc.Field_LUI("Task Status"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
  
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI EditButton() throws Exception{ 
return sfdc.Button_LUI("Edit"); 
} 
public MemberOfButton_LUI GenerateAEPQCReportButton() throws Exception{ 
return sfdc.Button_LUI("Generate AE/ PQC Report"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveNewButton() throws Exception{ 
return sfdc.Button_LUI("Save & New"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Selectanobjecttolimityoursearch_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select an object to limit your search"); 
} 
public MemberOfHealthCloud_LUI SearchSalesforce_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Salesforce"); 
} 
public MemberOfHealthCloud_LUI AdditionalDetails_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Additional Details"); 
} 
public MemberOfHealthCloud_LUI AdditionalInformation_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Additional Information"); 
} 
public MemberOfHealthCloud_LUI Date_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Date"); 
} 
public MemberOfHealthCloud_LUI Time_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Time"); 
} 
public MemberOfHealthCloud_LUI AssignedTo_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Assigned To"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI Name_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Name"); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
