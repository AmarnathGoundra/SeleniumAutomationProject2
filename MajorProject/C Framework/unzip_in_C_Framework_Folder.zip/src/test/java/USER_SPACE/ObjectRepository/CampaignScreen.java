package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class CampaignScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public CampaignScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public CampaignScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


// ************************ Functions for Fields ************************************** 
 
 public MemberOfField CampaignOwnerField() throws Exception{ 
	return sfdc.Field("Campaign Owner"); 
} 
public MemberOfField LeadsinCampaignField() throws Exception{ 
	return sfdc.Field("Leads in Campaign"); 
} 
public MemberOfField CampaignNameField() throws Exception{ 
	return sfdc.Field("Campaign Name"); 
} 
public MemberOfField ConvertedLeadsinCampaignField() throws Exception{ 
	return sfdc.Field("Converted Leads in Campaign"); 
} 
public MemberOfField ActiveField() throws Exception{ 
	return sfdc.Field("Active"); 
} 
public MemberOfField ContactsinCampaignField() throws Exception{ 
	return sfdc.Field("Contacts in Campaign"); 
} 
public MemberOfField TypeField() throws Exception{ 
	return sfdc.Field("Type"); 
} 
public MemberOfField ResponsesinCampaignField() throws Exception{ 
	return sfdc.Field("Responses in Campaign"); 
} 
public MemberOfField StatusField() throws Exception{ 
	return sfdc.Field("Status"); 
} 
public MemberOfField OpportunitiesinCampaignField() throws Exception{ 
	return sfdc.Field("Opportunities in Campaign"); 
} 
public MemberOfField StartDateField() throws Exception{ 
	return sfdc.Field("Start Date"); 
} 
public MemberOfField WonOpportunitiesinCampaignField() throws Exception{ 
	return sfdc.Field("Won Opportunities in Campaign"); 
} 
public MemberOfField EndDateField() throws Exception{ 
	return sfdc.Field("End Date"); 
} 
public MemberOfField ValueOpportunitiesinCampaignField() throws Exception{ 
	return sfdc.Field("Value Opportunities in Campaign"); 
} 
public MemberOfField ExpectedRevenueinCampaignField() throws Exception{ 
	return sfdc.Field("Expected Revenue in Campaign"); 
} 
public MemberOfField ValueWonOpportunitiesinCampaignField() throws Exception{ 
	return sfdc.Field("Value Won Opportunities in Campaign"); 
} 
public MemberOfField BudgetedCostinCampaignField() throws Exception{ 
	return sfdc.Field("Budgeted Cost in Campaign"); 
} 
public MemberOfField ActualCostinCampaignField() throws Exception{ 
	return sfdc.Field("Actual Cost in Campaign"); 
} 
public MemberOfField ExpectedResponseField() throws Exception{ 
	return sfdc.Field("Expected Response (%)"); 
} 
public MemberOfField NumSentinCampaignField() throws Exception{ 
	return sfdc.Field("Num Sent in Campaign"); 
} 
public MemberOfField ParentCampaignField() throws Exception{ 
	return sfdc.Field("Parent Campaign"); 
} 
public MemberOfField CreatedByField() throws Exception{ 
	return sfdc.Field("Created By"); 
} 
public MemberOfField LastModifiedByField() throws Exception{ 
	return sfdc.Field("Last Modified By"); 
} 
public MemberOfField DescriptionField() throws Exception{ 
	return sfdc.Field("Description"); 
} 
public MemberOfField CustomLinksField() throws Exception{ 
	return sfdc.Field("Custom Links"); 
} 

 
// ************************* Functions & Static Classes for Sections ***************************** // 
 
public MemberOfSEC SEC_CampaignDetail_CampaignOwnerField() throws Exception { 
return sfdc.Section("Campaign Detail", "Campaign Owner"); 
}
public MemberOfSEC SEC_CampaignDetail_LeadsinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Leads in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_CampaignNameField() throws Exception { 
return sfdc.Section("Campaign Detail", "Campaign Name"); 
}
public MemberOfSEC SEC_CampaignDetail_ConvertedLeadsinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Converted Leads in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_ActiveField() throws Exception { 
return sfdc.Section("Campaign Detail", "Active"); 
}
public MemberOfSEC SEC_CampaignDetail_ContactsinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Contacts in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_TypeField() throws Exception { 
return sfdc.Section("Campaign Detail", "Type"); 
}
public MemberOfSEC SEC_CampaignDetail_ResponsesinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Responses in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_StatusField() throws Exception { 
return sfdc.Section("Campaign Detail", "Status"); 
}
public MemberOfSEC SEC_CampaignDetail_OpportunitiesinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Opportunities in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_StartDateField() throws Exception { 
return sfdc.Section("Campaign Detail", "Start Date"); 
}
public MemberOfSEC SEC_CampaignDetail_WonOpportunitiesinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Won Opportunities in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_EndDateField() throws Exception { 
return sfdc.Section("Campaign Detail", "End Date"); 
}
public MemberOfSEC SEC_CampaignDetail_ValueOpportunitiesinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Value Opportunities in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_ExpectedRevenueinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Expected Revenue in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_ValueWonOpportunitiesinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Value Won Opportunities in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_BudgetedCostinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Budgeted Cost in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_ActualCostinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Actual Cost in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_ExpectedResponseField() throws Exception { 
return sfdc.Section("Campaign Detail", "Expected Response (%)"); 
}
public MemberOfSEC SEC_CampaignDetail_NumSentinCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Num Sent in Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_ParentCampaignField() throws Exception { 
return sfdc.Section("Campaign Detail", "Parent Campaign"); 
}
public MemberOfSEC SEC_CampaignDetail_CreatedByField() throws Exception { 
return sfdc.Section("Campaign Detail", "Created By"); 
}
public MemberOfSEC SEC_CampaignDetail_LastModifiedByField() throws Exception { 
return sfdc.Section("Campaign Detail", "Last Modified By"); 
}
public MemberOfSEC SEC_CampaignDetail_DescriptionField() throws Exception { 
return sfdc.Section("Campaign Detail", "Description"); 
}
public MemberOfSEC SEC_CampaignDetail_CustomLinksField() throws Exception { 
return sfdc.Section("Campaign Detail", "Custom Links"); 
}

 
 
 // **************** Functions & Static Classes for Related List ******************** 
 


 public Columns_CampaignHierarchy RL_CampaignHierarchy() throws Exception{ 
return new Columns_CampaignHierarchy("Campaign Hierarchy"); 
} 
public class Columns_CampaignHierarchy{ 
Columns_CampaignHierarchy(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL CampaignName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Campaign Name",RowIndex); 
}
public MemberOfRL CampaignName() throws Exception 
{ 
return sfdc.RL(RList,"Campaign Name"); 
}

}


 public Columns_OpenActivities RL_OpenActivities() throws Exception{ 
return new Columns_OpenActivities("Open Activities"); 
} 
public class Columns_OpenActivities{ 
Columns_OpenActivities(String RL) 
{ 
RList = RL; 
} 

}


 public Columns_ActivityHistory RL_ActivityHistory() throws Exception{ 
return new Columns_ActivityHistory("Activity History"); 
} 
public class Columns_ActivityHistory{ 
Columns_ActivityHistory(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Subject(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Subject",RowIndex); 
}
public MemberOfRL Subject() throws Exception 
{ 
return sfdc.RL(RList,"Subject"); 
}

public MemberOfRL Name(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Name",RowIndex); 
}
public MemberOfRL Name() throws Exception 
{ 
return sfdc.RL(RList,"Name"); 
}

public MemberOfRL Task(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Task",RowIndex); 
}
public MemberOfRL Task() throws Exception 
{ 
return sfdc.RL(RList,"Task"); 
}

public MemberOfRL DueDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Due Date",RowIndex); 
}
public MemberOfRL DueDate() throws Exception 
{ 
return sfdc.RL(RList,"Due Date"); 
}

public MemberOfRL AssignedTo(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Assigned To",RowIndex); 
}
public MemberOfRL AssignedTo() throws Exception 
{ 
return sfdc.RL(RList,"Assigned To"); 
}

public MemberOfRL LastModifiedDateTime(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date/Time",RowIndex); 
}
public MemberOfRL LastModifiedDateTime() throws Exception 
{ 
return sfdc.RL(RList,"Last Modified Date/Time"); 
}

}


 public Columns_Attachments RL_Attachments() throws Exception{ 
return new Columns_Attachments("Attachments"); 
} 
public class Columns_Attachments{ 
Columns_Attachments(String RL) 
{ 
RList = RL; 
} 

}


 public Columns_Opportunities RL_Opportunities() throws Exception{ 
return new Columns_Opportunities("Opportunities"); 
} 
public class Columns_Opportunities{ 
Columns_Opportunities(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL OpportunityName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Opportunity Name",RowIndex); 
}
public MemberOfRL OpportunityName() throws Exception 
{ 
return sfdc.RL(RList,"Opportunity Name"); 
}

public MemberOfRL Stage(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Stage",RowIndex); 
}
public MemberOfRL Stage() throws Exception 
{ 
return sfdc.RL(RList,"Stage"); 
}

public MemberOfRL Amount(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Amount",RowIndex); 
}
public MemberOfRL Amount() throws Exception 
{ 
return sfdc.RL(RList,"Amount"); 
}

public MemberOfRL CloseDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Close Date",RowIndex); 
}
public MemberOfRL CloseDate() throws Exception 
{ 
return sfdc.RL(RList,"Close Date"); 
}

}


 public Columns_CampaignMembers RL_CampaignMembers() throws Exception{ 
return new Columns_CampaignMembers("Campaign Members"); 
} 
public class Columns_CampaignMembers{ 
Columns_CampaignMembers(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL Type(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Type",RowIndex); 
}
public MemberOfRL Type() throws Exception 
{ 
return sfdc.RL(RList,"Type"); 
}

public MemberOfRL Status(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Status",RowIndex); 
}
public MemberOfRL Status() throws Exception 
{ 
return sfdc.RL(RList,"Status"); 
}

public MemberOfRL FirstName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"First Name",RowIndex); 
}
public MemberOfRL FirstName() throws Exception 
{ 
return sfdc.RL(RList,"First Name"); 
}

public MemberOfRL LastName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Last Name",RowIndex); 
}
public MemberOfRL LastName() throws Exception 
{ 
return sfdc.RL(RList,"Last Name"); 
}

public MemberOfRL Title(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Title",RowIndex); 
}
public MemberOfRL Title() throws Exception 
{ 
return sfdc.RL(RList,"Title"); 
}

public MemberOfRL Company(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Company",RowIndex); 
}
public MemberOfRL Company() throws Exception 
{ 
return sfdc.RL(RList,"Company"); 
}

}

 
 
public MemberOfButton DeleteButton() throws Exception{ 
return sfdc.Button("Delete"); 
} 
public MemberOfButton CancelButton() throws Exception{ 
return sfdc.Button("Cancel"); 
} 
public MemberOfButton AttachFileButton() throws Exception{ 
return sfdc.Button("Attach File"); 
} 
public MemberOfButton MailMergeButton() throws Exception{ 
return sfdc.Button("Mail Merge"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton NewTaskButton() throws Exception{ 
return sfdc.Button("New Task"); 
} 
public MemberOfButton EditButton() throws Exception{ 
return sfdc.Button("Edit"); 
} 
public MemberOfButton NewEventButton() throws Exception{ 
return sfdc.Button("New Event"); 
} 
public MemberOfButton ManageMembersButton() throws Exception{ 
return sfdc.Button("Manage Members"); 
} 
public MemberOfButton AdvancedSetupButton() throws Exception{ 
return sfdc.Button("Advanced Setup"); 
} 
public MemberOfButton SendanEmailButton() throws Exception{ 
return sfdc.Button("Send an Email"); 
} 
public MemberOfButton ViewAllButton() throws Exception{ 
return sfdc.Button("View All"); 
} 
public MemberOfButton NewOpportunityButton() throws Exception{ 
return sfdc.Button("New Opportunity"); 
} 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton LogaCallButton() throws Exception{ 
return sfdc.Button("Log a Call"); 
} 
public MemberOfButton OKButton() throws Exception{ 
return sfdc.Button("OK"); 
} 
public MemberOfButton CloneButton() throws Exception{ 
return sfdc.Button("Clone"); 
} 
}
