package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class LeadsScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public LeadsScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public LeadsScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


public MemberOfTab AccountsTab() throws Exception{ 
	return sfdc.Tab("Accounts"); 
} 
public MemberOfTab OpportunitiesTab() throws Exception{ 
	return sfdc.Tab("Opportunities"); 
} 
public MemberOfTab CampaignsTab() throws Exception{ 
	return sfdc.Tab("Campaigns"); 
} 
public MemberOfTab TellmemoreTab() throws Exception{ 
	return sfdc.Tab("Tell me more!"); 
} 
public MemberOfTab ParameterListsTab() throws Exception{ 
	return sfdc.Tab("Parameter Lists"); 
} 
public MemberOfTab CasesTab() throws Exception{ 
	return sfdc.Tab("Cases"); 
} 
public MemberOfTab ParametersTab() throws Exception{ 
	return sfdc.Tab("Parameters"); 
} 
public MemberOfTab ChangeManagementIntegrationsTab() throws Exception{ 
	return sfdc.Tab("Change Management Integrations"); 
} 
public MemberOfTab PriceBooksTab() throws Exception{ 
	return sfdc.Tab("Price Books"); 
} 
public MemberOfTab ContactsTab() throws Exception{ 
	return sfdc.Tab("Contacts"); 
} 
public MemberOfTab ProductsTab() throws Exception{ 
	return sfdc.Tab("Products"); 
} 
public MemberOfTab ContentTab() throws Exception{ 
	return sfdc.Tab("Content"); 
} 
public MemberOfTab ContractsTab() throws Exception{ 
	return sfdc.Tab("Contracts"); 
} 
public MemberOfTab QuickLoginTab() throws Exception{ 
	return sfdc.Tab("Quick Login"); 
} 
public MemberOfTab DashboardsTab() throws Exception{ 
	return sfdc.Tab("Dashboards"); 
} 
public MemberOfTab ReportsTab() throws Exception{ 
	return sfdc.Tab("Reports"); 
} 
public MemberOfTab DocumentsTab() throws Exception{ 
	return sfdc.Tab("Documents"); 
} 
public MemberOfTab SitecomTab() throws Exception{ 
	return sfdc.Tab("Site.com"); 
} 
public MemberOfTab DuplicateRecordSetsTab() throws Exception{ 
	return sfdc.Tab("Duplicate Record Sets"); 
} 
public MemberOfTab SolutionsTab() throws Exception{ 
	return sfdc.Tab("Solutions"); 
} 
public MemberOfTab HomeTab() throws Exception{ 
	return sfdc.Tab("Home"); 
} 
public MemberOfTab StartHereTab() throws Exception{ 
	return sfdc.Tab("Start Here"); 
} 
public MemberOfTab IdeasTab() throws Exception{ 
	return sfdc.Tab("Ideas"); 
} 
public MemberOfTab StreamingChannelsTab() throws Exception{ 
	return sfdc.Tab("Streaming Channels"); 
} 
public MemberOfTab LeadsTab() throws Exception{ 
	return sfdc.Tab("Leads"); 
} 
public MemberOfTab SubscriptionsTab() throws Exception{ 
	return sfdc.Tab("Subscriptions"); 
} 
public MemberOfTab LibrariesTab() throws Exception{ 
	return sfdc.Tab("Libraries"); 
} 
public MemberOfTab TestCloudSettingsTab() throws Exception{ 
	return sfdc.Tab("Test Cloud Settings"); 
} 
public MemberOfTab ListEmailsTab() throws Exception{ 
	return sfdc.Tab("List Emails"); 
} 
public MemberOfTab TestMethodsTab() throws Exception{ 
	return sfdc.Tab("Test Methods"); 
} 
public MemberOfTab MacrosTab() throws Exception{ 
	return sfdc.Tab("Macros"); 
} 
public MemberOfTab TestsTab() throws Exception{ 
	return sfdc.Tab("Tests"); 
} 
//************************* Functions for List Views***************************** // 
 


 public Columns_ListView ListView() throws Exception{ 
return new Columns_ListView(); 
} 
public class Columns_ListView{ 
public MemberOfLV Action(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Action",RowIndex); 
}
public MemberOfLV Action() throws Exception 
{ 
return sfdc.LV("Action"); 
}

public MemberOfLV AccountName(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Account Name",RowIndex); 
}
public MemberOfLV AccountName() throws Exception 
{ 
return sfdc.LV("Account Name"); 
}

public MemberOfLV AccountSite(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Account Site",RowIndex); 
}
public MemberOfLV AccountSite() throws Exception 
{ 
return sfdc.LV("Account Site"); 
}

public MemberOfLV BillingStateProvince(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Billing State/Province",RowIndex); 
}
public MemberOfLV BillingStateProvince() throws Exception 
{ 
return sfdc.LV("Billing State/Province"); 
}

public MemberOfLV Phone(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Phone",RowIndex); 
}
public MemberOfLV Phone() throws Exception 
{ 
return sfdc.LV("Phone"); 
}

public MemberOfLV Type(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Type",RowIndex); 
}
public MemberOfLV Type() throws Exception 
{ 
return sfdc.LV("Type"); 
}

public MemberOfLV AccountOwnerAlias(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Account Owner Alias",RowIndex); 
}
public MemberOfLV AccountOwnerAlias() throws Exception 
{ 
return sfdc.LV("Account Owner Alias"); 
}

}

//************************* Functions for Buttons***************************** // 
 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton NewAccountButton() throws Exception{ 
return sfdc.Button("New Account"); 
} 
public MemberOfButton Button() throws Exception{ 
return sfdc.Button(""); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton NewButton() throws Exception{ 
return sfdc.Button("New"); 
} 
public MemberOfButton RunReportButton() throws Exception{ 
return sfdc.Button("Run Report"); 
} 
//************************* Functions for Field Names ***************************** // 
 
//************************* Functions for Section Name***************************** // 
 
//************************* Functions for Related List***************************** // 
 
}

