package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class CasesScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public CasesScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public CasesScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


//************************* Functions for List Views***************************** // 
 


 public Columns_ListView ListView() throws Exception{ 
return new Columns_ListView(); 
} 
public class Columns_ListView{ 
public MemberOfLV Action(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Action",RowIndex); 
}
public MemberOfLV Action() throws Exception 
{ 
return sfdc.LV("Action"); 
}

public MemberOfLV CaseNumber(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Case Number",RowIndex); 
}
public MemberOfLV CaseNumber() throws Exception 
{ 
return sfdc.LV("Case Number"); 
}

public MemberOfLV ContactName(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Contact Name",RowIndex); 
}
public MemberOfLV ContactName() throws Exception 
{ 
return sfdc.LV("Contact Name"); 
}

public MemberOfLV Subject(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Subject",RowIndex); 
}
public MemberOfLV Subject() throws Exception 
{ 
return sfdc.LV("Subject"); 
}

public MemberOfLV Status(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Status",RowIndex); 
}
public MemberOfLV Status() throws Exception 
{ 
return sfdc.LV("Status"); 
}

public MemberOfLV Priority(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Priority",RowIndex); 
}
public MemberOfLV Priority() throws Exception 
{ 
return sfdc.LV("Priority"); 
}

public MemberOfLV DateTimeOpened(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Date/Time Opened",RowIndex); 
}
public MemberOfLV DateTimeOpened() throws Exception 
{ 
return sfdc.LV("Date/Time Opened"); 
}

public MemberOfLV CaseOwnerAlias(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Case Owner Alias",RowIndex); 
}
public MemberOfLV CaseOwnerAlias() throws Exception 
{ 
return sfdc.LV("Case Owner Alias"); 
}

}

//************************* Functions for Buttons***************************** // 
 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton NewCaseButton() throws Exception{ 
return sfdc.Button("New Case"); 
} 
public MemberOfButton CloseButton() throws Exception{ 
return sfdc.Button("Close"); 
} 
public MemberOfButton ChangeOwnerButton() throws Exception{ 
return sfdc.Button("Change Owner"); 
} 
public MemberOfButton ChangeStatusButton() throws Exception{ 
return sfdc.Button("Change Status"); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton CancelButton() throws Exception{ 
return sfdc.Button("Cancel"); 
} 
public MemberOfButton EditButton() throws Exception{ 
return sfdc.Button("Edit"); 
} 
public MemberOfButton DeleteButton() throws Exception{ 
return sfdc.Button("Delete"); 
} 
public MemberOfButton CloseCaseButton() throws Exception{ 
return sfdc.Button("Close Case"); 
} 
public MemberOfButton CloneButton() throws Exception{ 
return sfdc.Button("Clone"); 
} 
public MemberOfButton ViewSuggestedSolutionsButton() throws Exception{ 
return sfdc.Button("View Suggested Solutions"); 
} 
public MemberOfButton FindSolutionButton() throws Exception{ 
return sfdc.Button("Find Solution"); 
} 
public MemberOfButton NewTaskButton() throws Exception{ 
return sfdc.Button("New Task"); 
} 
public MemberOfButton NewEventButton() throws Exception{ 
return sfdc.Button("New Event"); 
} 
public MemberOfButton LogaCallButton() throws Exception{ 
return sfdc.Button("Log a Call"); 
} 
public MemberOfButton MailMergeButton() throws Exception{ 
return sfdc.Button("Mail Merge"); 
} 
public MemberOfButton SendanEmailButton() throws Exception{ 
return sfdc.Button("Send an Email"); 
} 
public MemberOfButton NewButton() throws Exception{ 
return sfdc.Button("New"); 
} 
public MemberOfButton AttachFileButton() throws Exception{ 
return sfdc.Button("Attach File"); 
} 
public MemberOfButton ShareButton() throws Exception{ 
return sfdc.Button("Share"); 
} 
public MemberOfButton OKButton() throws Exception{ 
return sfdc.Button("OK"); 
} 
public MemberOfButton SaveCloseButton() throws Exception{ 
return sfdc.Button("Save & Close"); 
} 
public MemberOfButton SaveNewButton() throws Exception{ 
return sfdc.Button("Save & New"); 
} 
//************************* Functions for Field Names ***************************** // 
 
public MemberOfField CaseOwnerField() throws Exception{ 
	return sfdc.Field("Case Owner"); 
} 
public MemberOfField StatusField() throws Exception{ 
	return sfdc.Field("Status"); 
} 
public MemberOfField CaseNumberField() throws Exception{ 
	return sfdc.Field("Case Number"); 
} 
public MemberOfField PriorityField() throws Exception{ 
	return sfdc.Field("Priority"); 
} 
public MemberOfField ContactNameField() throws Exception{ 
	return sfdc.Field("Contact Name"); 
} 
public MemberOfField ContactPhoneField() throws Exception{ 
	return sfdc.Field("Contact Phone"); 
} 
public MemberOfField AccountNameField() throws Exception{ 
	return sfdc.Field("Account Name"); 
} 
public MemberOfField ContactEmailField() throws Exception{ 
	return sfdc.Field("Contact Email"); 
} 
public MemberOfField TypeField() throws Exception{ 
	return sfdc.Field("Type"); 
} 
public MemberOfField CaseOriginField() throws Exception{ 
	return sfdc.Field("Case Origin"); 
} 
public MemberOfField CaseReasonField() throws Exception{ 
	return sfdc.Field("Case Reason"); 
} 
public MemberOfField DateTimeOpenedField() throws Exception{ 
	return sfdc.Field("Date/Time Opened"); 
} 
public MemberOfField DateTimeClosedField() throws Exception{ 
	return sfdc.Field("Date/Time Closed"); 
} 
public MemberOfField ProductField() throws Exception{ 
	return sfdc.Field("Product"); 
} 
public MemberOfField EngineeringReqNumberField() throws Exception{ 
	return sfdc.Field("Engineering Req Number"); 
} 
public MemberOfField PotentialLiabilityField() throws Exception{ 
	return sfdc.Field("Potential Liability"); 
} 
public MemberOfField SLAViolationField() throws Exception{ 
	return sfdc.Field("SLA Violation"); 
} 
public MemberOfField CreatedByField() throws Exception{ 
	return sfdc.Field("Created By"); 
} 
public MemberOfField LastModifiedByField() throws Exception{ 
	return sfdc.Field("Last Modified By"); 
} 
public MemberOfField SubjectField() throws Exception{ 
	return sfdc.Field("Subject"); 
} 
public MemberOfField DescriptionField() throws Exception{ 
	return sfdc.Field("Description"); 
} 
public MemberOfField CustomLinksField() throws Exception{ 
	return sfdc.Field("Custom Links"); 
} 
public MemberOfField InternalCommentsField() throws Exception{ 
	return sfdc.Field("Internal Comments"); 
} 
//************************* Functions for Section Name***************************** // 
 
public MemberOfSEC SEC_CaseDetail_CaseOwnerField() throws Exception { 
return sfdc.Section("Case Detail", "Case Owner"); 
}
public MemberOfSEC SEC_CaseDetail_StatusField() throws Exception { 
return sfdc.Section("Case Detail", "Status"); 
}
public MemberOfSEC SEC_CaseDetail_CaseNumberField() throws Exception { 
return sfdc.Section("Case Detail", "Case Number"); 
}
public MemberOfSEC SEC_CaseDetail_PriorityField() throws Exception { 
return sfdc.Section("Case Detail", "Priority"); 
}
public MemberOfSEC SEC_CaseDetail_ContactNameField() throws Exception { 
return sfdc.Section("Case Detail", "Contact Name"); 
}
public MemberOfSEC SEC_CaseDetail_ContactPhoneField() throws Exception { 
return sfdc.Section("Case Detail", "Contact Phone"); 
}
public MemberOfSEC SEC_CaseDetail_AccountNameField() throws Exception { 
return sfdc.Section("Case Detail", "Account Name"); 
}
public MemberOfSEC SEC_CaseDetail_ContactEmailField() throws Exception { 
return sfdc.Section("Case Detail", "Contact Email"); 
}
public MemberOfSEC SEC_CaseDetail_TypeField() throws Exception { 
return sfdc.Section("Case Detail", "Type"); 
}
public MemberOfSEC SEC_CaseDetail_CaseOriginField() throws Exception { 
return sfdc.Section("Case Detail", "Case Origin"); 
}
public MemberOfSEC SEC_CaseDetail_CaseReasonField() throws Exception { 
return sfdc.Section("Case Detail", "Case Reason"); 
}
public MemberOfSEC SEC_CaseDetail_DateTimeOpenedField() throws Exception { 
return sfdc.Section("Case Detail", "Date/Time Opened"); 
}
public MemberOfSEC SEC_CaseDetail_DateTimeClosedField() throws Exception { 
return sfdc.Section("Case Detail", "Date/Time Closed"); 
}
public MemberOfSEC SEC_CaseDetail_ProductField() throws Exception { 
return sfdc.Section("Case Detail", "Product"); 
}
public MemberOfSEC SEC_CaseDetail_EngineeringReqNumberField() throws Exception { 
return sfdc.Section("Case Detail", "Engineering Req Number"); 
}
public MemberOfSEC SEC_CaseDetail_PotentialLiabilityField() throws Exception { 
return sfdc.Section("Case Detail", "Potential Liability"); 
}
public MemberOfSEC SEC_CaseDetail_SLAViolationField() throws Exception { 
return sfdc.Section("Case Detail", "SLA Violation"); 
}
public MemberOfSEC SEC_CaseDetail_CreatedByField() throws Exception { 
return sfdc.Section("Case Detail", "Created By"); 
}
public MemberOfSEC SEC_CaseDetail_LastModifiedByField() throws Exception { 
return sfdc.Section("Case Detail", "Last Modified By"); 
}
public MemberOfSEC SEC_CaseDetail_SubjectField() throws Exception { 
return sfdc.Section("Case Detail", "Subject"); 
}
public MemberOfSEC SEC_CaseDetail_DescriptionField() throws Exception { 
return sfdc.Section("Case Detail", "Description"); 
}
public MemberOfSEC SEC_CaseDetail_CustomLinksField() throws Exception { 
return sfdc.Section("Case Detail", "Custom Links"); 
}
//************************* Functions for Related List***************************** // 
 


 public Columns_Solutions RL_Solutions() throws Exception{ 
return new Columns_Solutions("Solutions"); 
} 
public class Columns_Solutions{ 
Columns_Solutions(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL NoSolutionsAttached(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"No Solutions Attached",RowIndex); 
}
public MemberOfRL NoSolutionsAttached() throws Exception 
{ 
return sfdc.RL(RList,"No Solutions Attached"); 
}

}



 public Columns_OpenActivities RL_OpenActivities() throws Exception{ 
return new Columns_OpenActivities("Open Activities"); 
} 
public class Columns_OpenActivities{ 
Columns_OpenActivities(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_ActivityHistory RL_ActivityHistory() throws Exception{ 
return new Columns_ActivityHistory("Activity History"); 
} 
public class Columns_ActivityHistory{ 
Columns_ActivityHistory(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_CaseComments RL_CaseComments() throws Exception{ 
return new Columns_CaseComments("Case Comments"); 
} 
public class Columns_CaseComments{ 
Columns_CaseComments(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_Attachments RL_Attachments() throws Exception{ 
return new Columns_Attachments("Attachments"); 
} 
public class Columns_Attachments{ 
Columns_Attachments(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_CaseHistory RL_CaseHistory() throws Exception{ 
return new Columns_CaseHistory("Case History"); 
} 
public class Columns_CaseHistory{ 
Columns_CaseHistory(String RL) 
{ 
RList = RL; 
} 

}

}

