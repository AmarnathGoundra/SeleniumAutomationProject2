package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class AddProdBasketConfigScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public AddProdBasketConfigScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public AddProdBasketConfigScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 // ************************ Functions and Classes for List Views ************************************** 
 
 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
public MemberOfCustom_LUI BasketNameCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Basket Name"); 
} 
public MemberOfCustom_LUI BasketStageCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Basket Stage"); 
} 
public MemberOfCustom_LUI CustomerCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Customer"); 
} 
public MemberOfCustom_LUI PrimaryBasketCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Primary Basket"); 
} 
public MemberOfCustom_LUI SynchronisedWithOpportunityCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Synchronised With Opportunity"); 
} 
public MemberOfCustom_LUI DescriptionCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Description"); 
} 
public MemberOfCustom_LUI CreatedByCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Created By"); 
} 
public MemberOfCustom_LUI OpportunityCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Opportunity"); 
} 
public MemberOfCustom_LUI TotalContractValueCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Total Contract Value"); 
} 
public MemberOfCustom_LUI ProjectComplexityCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Project Complexity"); 
} 
public MemberOfCustom_LUI PMRequiredCustomField() throws Exception{ 
return sfdc.CustomField_LUI("PM Required"); 
} 
public MemberOfCustom_LUI ProjectManagerContactNumberCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Project Manager Contact Number"); 
} 
public MemberOfCustom_LUI ProjectIDCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Project ID"); 
} 
public MemberOfCustom_LUI ProjectManagerUserIDCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Project Manager User ID"); 
} 
public MemberOfCustom_LUI ProjectManagerEmailCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Project Manager Email"); 
} 
public MemberOfCustom_LUI BillingAccountCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Billing Account"); 
} 
public MemberOfCustom_LUI BillingAddressCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Billing Address"); 
} 
public MemberOfCustom_LUI UserTypeCustomField() throws Exception{ 
return sfdc.CustomField_LUI("User Type"); 
} 
public MemberOfCustom_LUI ZoneCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Zone"); 
} 
public MemberOfCustom_LUI QuantityCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Quantity"); 
} 
public MemberOfCustom_LUI UnitPriceCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Unit Price"); 
} 
public MemberOfCustom_LUI TotalRecurringAmountCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Total Recurring Amount"); 
} 
public MemberOfCustom_LUI FrequencyCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Frequency"); 
} 
public MemberOfCustom_LUI RemainingTermCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Remaining Term"); 
} 
public MemberOfCustom_LUI TypeCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Type"); 
} 
public MemberOfCustom_LUI ModelCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Model"); 
} 
public MemberOfCustom_LUI ContractTypeCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Contract Type"); 
} 
public MemberOfCustom_LUI ContractTermCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Contract Term"); 
} 
public MemberOfCustom_LUI IADModelCustomField() throws Exception{ 
return sfdc.CustomField_LUI("IAD Model"); 
} 
public MemberOfCustom_LUI AvailablePortsCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Available Ports"); 
} 
public MemberOfCustom_LUI TotalOneoffAmountCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Total One off Amount"); 
} 
public MemberOfCustom_LUI SiteNameCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Site Name"); 
} 
public MemberOfCustom_LUI SiteAddressCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Site Address"); 
} 
public MemberOfCustom_LUI WidefeasCodeCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Widefeas Code"); 
} 
public MemberOfCustom_LUI SiteNetworkZoneCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Site Network Zone"); 
} 
public MemberOfCustom_LUI ServiceabilityLocationCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Serviceability Location"); 
} 
public MemberOfCustom_LUI AccessTypeCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Access Type"); 
} 
public MemberOfCustom_LUI BandwidthCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Bandwidth"); 
} 
public MemberOfCustom_LUI PatternTypeCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Pattern Type"); 
} 
public MemberOfCustom_LUI SearchPatternCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Search Pattern"); 
} 
public MemberOfCustom_LUI PrimarySiteContactCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Primary Site Contact"); 
} 
public MemberOfCustom_LUI TechnicalContactCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Technical Contact"); 
} 
public MemberOfCustom_LUI ProjectContactCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Project Contact"); 
} 
public MemberOfCustom_LUI AfterHoursSiteContactCustomField() throws Exception{ 
return sfdc.CustomField_LUI("After Hours Site Contact"); 
} 
public MemberOfCustom_LUI NotBeforeCRDCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Not Before CRD"); 
} 
public MemberOfCustom_LUI PreferredCRDCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Preferred CRD"); 
} 
public MemberOfCustom_LUI NotesCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Notes"); 
} 

public MemberOfHealthCloud_LUI FirstNameHealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Basket Name"); 
} 

//************************* Functions for Custom Button ***************************** // 
 
public MemberOfCustom_LUI CancelCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Cancel"); 
} 
public MemberOfCustom_LUI SaveCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Save"); 
} 
public MemberOfCustom_LUI AddProductCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Add Product"); 
} 
public MemberOfCustom_LUI AddCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Add"); 
} 
public MemberOfCustom_LUI AddtoBasketCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Add to Basket"); 
} 
public MemberOfCustom_LUI SearchCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Search"); 
} 
public MemberOfCustom_LUI SelectCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Select"); 
} 
public MemberOfCustom_LUI MakePrimaryBasketCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Make Primary Basket"); 
} 
public MemberOfCustom_LUI OrderSimulationCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Order Simulation"); 
} 
public MemberOfCustom_LUI CloneCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Clone"); 
} 
public MemberOfCustom_LUI QuoteCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Quote"); 
} 
public MemberOfCustom_LUI ContractCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Contract"); 
} 
public MemberOfCustom_LUI CheckpointCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Checkpoint"); 
} 
public MemberOfCustom_LUI CopyProductCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Copy Product"); 
} 
public MemberOfCustom_LUI DeleteProductCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Delete Product"); 
} 
public MemberOfCustom_LUI ContinueCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Continue"); 
} 
public MemberOfCustom_LUI FinishCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Finish"); 
} 
public MemberOfCustom_LUI NewUserCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("New User"); 
} 
public MemberOfCustom_LUI NewHandsetandAccessoriesCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("New Handset and Accessories"); 
} 
public MemberOfCustom_LUI NewHuntGroupCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("New Hunt Group"); 
} 
public MemberOfCustom_LUI NewIADDeviceCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("New IAD Device"); 
} 
public MemberOfCustom_LUI SavewithoutValidationCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Save without Validation"); 
} 
public MemberOfCustom_LUI ValidateandSaveCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Validate and Save"); 
} 
public MemberOfCustom_LUI EnrichedCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Enriched"); 
} 
public MemberOfCustom_LUI ReserveCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Reserve"); 
} 
public MemberOfCustom_LUI ClearandSearchAgainCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Clear and Search Again"); 
} 
//************************* Functions for Custom Related List ***************************** // 
 
public MemberOfCustom_LUI User_ActionCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("User_Action"); 
} 
public MemberOfCustom_LUI User_QuantityCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("User_Quantity"); 
} 
public MemberOfCustom_LUI User_StatusCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("User_Status"); 
} 
public MemberOfCustom_LUI User_NameCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("User_Name"); 
} 
public MemberOfCustom_LUI User_RemainingTermCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("User_Remaining Term"); 
} 
public MemberOfCustom_LUI User_FrequencyCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("User_Frequency"); 
} 
public MemberOfCustom_LUI User_TotalOneOffAmountCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("User_Total One Off Amount"); 
} 
public MemberOfCustom_LUI User_TotalRecurringAmountCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("User_Total Recurring Amount"); 
} 
public MemberOfCustom_LUI User_StateCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("User_State"); 
} 
public MemberOfCustom_LUI HandsetandAccessories_ActionCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Handset and Accessories_Action"); 
} 
public MemberOfCustom_LUI HandsetandAccessories_QuantityCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Handset and Accessories_Quantity"); 
} 
public MemberOfCustom_LUI HandsetandAccessories_StatusCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Handset and Accessories_Status"); 
} 
public MemberOfCustom_LUI HandsetandAccessories_NameCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Handset and Accessories_Name"); 
} 
public MemberOfCustom_LUI HandsetandAccessories_RemainingTermCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Handset and Accessories_Remaining Term"); 
} 
public MemberOfCustom_LUI HandsetandAccessories_FrequencyCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Handset and Accessories_Frequency"); 
} 
public MemberOfCustom_LUI HandsetandAccessories_TotalOneoffAmountCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Handset and Accessories_Total One off Amount"); 
} 
public MemberOfCustom_LUI HandsetandAccessories_TotalRecurringAmountCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Handset and Accessories_Total Recurring Amount"); 
} 
public MemberOfCustom_LUI HuntGroup_ActionCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Hunt Group_Action"); 
} 
public MemberOfCustom_LUI HuntGroup_QuantityCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Hunt Group_Quantity"); 
} 
public MemberOfCustom_LUI HuntGroup_StatusCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Hunt Group_Status"); 
} 
public MemberOfCustom_LUI HuntGroup_NameCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Hunt Group_Name"); 
} 
public MemberOfCustom_LUI HuntGroup_RemainingTermCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Hunt Group_Remaining Term"); 
} 
public MemberOfCustom_LUI HuntGroup_FrequencyCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Hunt Group_Frequency"); 
} 
public MemberOfCustom_LUI HuntGroup_TotalOneoffAmountCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Hunt Group_Total One off Amount"); 
} 
public MemberOfCustom_LUI HuntGroup_TotalRecurringAmountCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Hunt Group_Total Recurring Amount"); 
} 
public MemberOfCustom_LUI HuntGroup_StateCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("Hunt Group_State"); 
} 
public MemberOfCustom_LUI IADDevice_ActionCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("IAD Device_Action"); 
} 
public MemberOfCustom_LUI IADDevice_QuantityCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("IAD Device_Quantity"); 
} 
public MemberOfCustom_LUI IADDevice_StatusCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("IAD Device_Status"); 
} 
public MemberOfCustom_LUI IADDevice_NameCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("IAD Device_Name"); 
} 
public MemberOfCustom_LUI IADDevice_RemainingTermCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("IAD Device_Remaining Term"); 
} 
public MemberOfCustom_LUI IADDevice_FrequencyCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("IAD Device_Frequency"); 
} 
public MemberOfCustom_LUI IADDevice_TotalOneoffAmountCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("IAD Device_Total One off Amount"); 
} 
public MemberOfCustom_LUI IADDevice_TotalRecurringAmountCustomRelatedList() throws Exception{ 
return sfdc.CustomRelatedList_LUI("IAD Device_Total Recurring Amount"); 
} 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
public MemberOfCustom_LUI OrderTypeCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Order Type"); 
} 
public MemberOfCustom_LUI DomainCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Domain"); 
} 
public MemberOfCustom_LUI ProductCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Product"); 
} 
public MemberOfCustom_LUI SiteNameServiceIdCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Site Name/Service Id"); 
} 
public MemberOfCustom_LUI QuantityCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Quantity"); 
} 
public MemberOfCustom_LUI TotalOneoffAmountCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Total One off Amount"); 
} 
public MemberOfCustom_LUI TotalRecurringAmountCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Total Recurring Amount"); 
} 
public MemberOfCustom_LUI TotalContractValueCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Total Contract Value"); 
} 
public MemberOfCustom_LUI StatusCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Status"); 
} 
public MemberOfCustom_LUI LegacySiteCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Legacy Site"); 
} 
public MemberOfCustom_LUI SiteAddressCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Site Address"); 
} 
public MemberOfCustom_LUI SiteNameCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Site Name"); 
} 
public MemberOfCustom_LUI FixedSeatsCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Fixed Seats"); 
} 
public MemberOfCustom_LUI FaxSeatsCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Fax Seats"); 
} 
public MemberOfCustom_LUI HuntGroupCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Hunt Group"); 
} 
public MemberOfCustom_LUI TotalCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Total"); 
} 
//************************* Functions for JTree Text ***************************** // 
 
public MemberOfCustom_LUI ModularProductsCustomJTreeText() throws Exception{ 
return sfdc.CustomJTree_LUI("Modular Products"); 
} 
public MemberOfCustom_LUI SiteSpecificCustomJTreeText() throws Exception{ 
return sfdc.CustomJTree_LUI("Site Specific"); 
} 
public MemberOfCustom_LUI ConnectedWorkplacePackageCustomJTreeText() throws Exception{ 
return sfdc.CustomJTree_LUI("Connected Workplace Package"); 
} 
public MemberOfCustom_LUI ReserveNumbersCustomJTreeText() throws Exception{ 
return sfdc.CustomJTree_LUI("Reserve Numbers"); 
} 
public MemberOfCustom_LUI SiteDetailsCustomJTreeText() throws Exception{ 
return sfdc.CustomJTree_LUI("Site Details"); 
} 
public MemberOfCustom_LUI CustomerRequestedDatesCustomJTreeText() throws Exception{ 
return sfdc.CustomJTree_LUI("Customer Requested Dates"); 
} 
} 
 
