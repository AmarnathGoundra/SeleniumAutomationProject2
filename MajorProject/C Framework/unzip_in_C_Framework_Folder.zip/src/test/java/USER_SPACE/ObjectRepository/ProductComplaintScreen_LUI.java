package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class ProductComplaintScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public ProductComplaintScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public ProductComplaintScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI RecordTypeField() throws Exception{  
return sfdc.Field_LUI("Record Type"); 
} 
 
public MemberOfField_LUI ProcessingStatusField() throws Exception{  
return sfdc.Field_LUI("Processing Status"); 
} 
 
public MemberOfField_LUI AccountNameField() throws Exception{  
return sfdc.Field_LUI("Account Name"); 
} 
 
public MemberOfField_LUI AssociatedField() throws Exception{  
return sfdc.Field_LUI("Associated"); 
} 
 
public MemberOfField_LUI ContactField() throws Exception{  
return sfdc.Field_LUI("Contact"); 
} 
 
public MemberOfField_LUI DefaultResponseTimeIndaysField() throws Exception{  
return sfdc.Field_LUI("Default Response Time(In days)"); 
} 
 
public MemberOfField_LUI IncidentField() throws Exception{  
return sfdc.Field_LUI("Incident"); 
} 
 
public MemberOfField_LUI DateofVoidField() throws Exception{  
return sfdc.Field_LUI("Date of Void"); 
} 
 
public MemberOfField_LUI ServiceRequestField() throws Exception{  
return sfdc.Field_LUI("Service Request"); 
} 
 
public MemberOfField_LUI IsEscalatedField() throws Exception{  
return sfdc.Field_LUI("IsEscalated"); 
} 
 
public MemberOfField_LUI ComplaintClosureDateField() throws Exception{  
return sfdc.Field_LUI("Complaint Closure Date"); 
} 
 
public MemberOfField_LUI InvalidComplaintField() throws Exception{  
return sfdc.Field_LUI("Invalid Complaint"); 
} 
 
public MemberOfField_LUI SecondaryAccountField() throws Exception{  
return sfdc.Field_LUI("Secondary Account"); 
} 
 
public MemberOfField_LUI BusinessUnitField() throws Exception{  
return sfdc.Field_LUI("Business Unit"); 
} 
 
public MemberOfField_LUI RelatedInquiryField() throws Exception{  
return sfdc.Field_LUI("Related Inquiry"); 
} 
 
public MemberOfField_LUI OwnerField() throws Exception{  
return sfdc.Field_LUI("Owner"); 
} 
 
public MemberOfField_LUI TypeOfComplaintField() throws Exception{  
return sfdc.Field_LUI("Type Of Complaint"); 
} 
 
public MemberOfField_LUI ReportSourceField() throws Exception{  
return sfdc.Field_LUI("Report Source"); 
} 
 
public MemberOfField_LUI ReportSourceOthersField() throws Exception{  
return sfdc.Field_LUI("Report Source Others"); 
} 
 
public MemberOfField_LUI IncidentHappenedDueToField() throws Exception{  
return sfdc.Field_LUI("Incident Happened Due To"); 
} 
 
public MemberOfField_LUI ReportDateTimeField() throws Exception{  
return sfdc.Field_LUI("Report Date/Time"); 
} 
 
public MemberOfField_LUI ReportDateField() throws Exception{  
return sfdc.Field_LUI("Report Date"); 
} 
 
public MemberOfField_LUI EventDescriptionEnglishField() throws Exception{  
return sfdc.Field_LUI("Event Description(English)"); 
} 
 
public MemberOfField_LUI DateofDeathField() throws Exception{  
return sfdc.Field_LUI("Date of Death"); 
} 
 
public MemberOfField_LUI CountryofEventField() throws Exception{  
return sfdc.Field_LUI("Country of Event"); 
} 
 
public MemberOfField_LUI MedicalHistoryField() throws Exception{  
return sfdc.Field_LUI("Medical History"); 
} 
 
public MemberOfField_LUI DateofEventField() throws Exception{  
return sfdc.Field_LUI("Date of Event"); 
} 
 
public MemberOfField_LUI IncidentrepresentseriouspublicthreatField() throws Exception{  
return sfdc.Field_LUI("Incident represent serious public threat"); 
} 
 
public MemberOfField_LUI DateofEncounterField() throws Exception{  
return sfdc.Field_LUI("Date of Encounter"); 
} 
 
public MemberOfField_LUI NumberofaffectedPatientsField() throws Exception{  
return sfdc.Field_LUI("Number of affected Patients"); 
} 
 
public MemberOfField_LUI EventClassificationField() throws Exception{  
return sfdc.Field_LUI("Event Classification"); 
} 
 
public MemberOfField_LUI NumberofMedicalDevicesField() throws Exception{  
return sfdc.Field_LUI("Number of Medical Devices"); 
} 
 
public MemberOfField_LUI OutcomeonthePatientField() throws Exception{  
return sfdc.Field_LUI("Outcome on the Patient"); 
} 
 
public MemberOfField_LUI ReceivedDateField() throws Exception{  
return sfdc.Field_LUI("Received Date"); 
} 
 
public MemberOfField_LUI PatientOutcomeDescriptionField() throws Exception{  
return sfdc.Field_LUI("Patient Outcome Description"); 
} 
 
public MemberOfField_LUI EventMonthField() throws Exception{  
return sfdc.Field_LUI("Event Month"); 
} 
 
public MemberOfField_LUI EventYearField() throws Exception{  
return sfdc.Field_LUI("Event Year"); 
} 
 
public MemberOfField_LUI InjuryOccuredField() throws Exception{  
return sfdc.Field_LUI("Injury Occured"); 
} 
 
public MemberOfField_LUI AlertDateField() throws Exception{  
return sfdc.Field_LUI("Alert Date"); 
} 
 
public MemberOfField_LUI InjuryDateField() throws Exception{  
return sfdc.Field_LUI("Injury Date"); 
} 
 
public MemberOfField_LUI EventDescriptionLocalLanguageField() throws Exception{  
return sfdc.Field_LUI("Event Description (Local Language)"); 
} 
 
public MemberOfField_LUI PreventiveActionField() throws Exception{  
return sfdc.Field_LUI("Preventive Action"); 
} 
 
public MemberOfField_LUI CorrectiveActionField() throws Exception{  
return sfdc.Field_LUI("Corrective Action"); 
} 
 
public MemberOfField_LUI CodesDocumentationCompletedField() throws Exception{  
return sfdc.Field_LUI("Codes Documentation Completed ?"); 
} 
 
public MemberOfField_LUI RegulatoryReportsCompletedField() throws Exception{  
return sfdc.Field_LUI("Regulatory Reports Completed ?"); 
} 
 
public MemberOfField_LUI Attemptscomplete3Field() throws Exception{  
return sfdc.Field_LUI("3 Attempts complete?"); 
} 
 
public MemberOfField_LUI InvestigationCompleteField() throws Exception{  
return sfdc.Field_LUI("Investigation Complete?"); 
} 
 
public MemberOfField_LUI RefundCompleteField() throws Exception{  
return sfdc.Field_LUI("Refund Complete?"); 
} 
 
public MemberOfField_LUI AdditionalInformationsentField() throws Exception{  
return sfdc.Field_LUI("Additional Information sent?"); 
} 
 
public MemberOfField_LUI ReplacementCompleteField() throws Exception{  
return sfdc.Field_LUI("Replacement Complete ?"); 
} 
 
public MemberOfField_LUI FirstRemedialActionField() throws Exception{  
return sfdc.Field_LUI("First Remedial Action"); 
} 
 
public MemberOfField_LUI SecondRemedialActionField() throws Exception{  
return sfdc.Field_LUI("Second Remedial Action"); 
} 
 
public MemberOfField_LUI PatientIdentifierField() throws Exception{  
return sfdc.Field_LUI("Patient Identifier"); 
} 
 
public MemberOfField_LUI PatientDOBField() throws Exception{  
return sfdc.Field_LUI("Patient DOB"); 
} 
 
public MemberOfField_LUI PatientageatthetimeofeventField() throws Exception{  
return sfdc.Field_LUI("Patient age at the time of event"); 
} 
 
public MemberOfField_LUI AgeUnitField() throws Exception{  
return sfdc.Field_LUI("Age Unit"); 
} 
 
public MemberOfField_LUI WeightofthepatientField() throws Exception{  
return sfdc.Field_LUI("Weight of the patient"); 
} 
 
public MemberOfField_LUI WeightUnitField() throws Exception{  
return sfdc.Field_LUI("Weight Unit"); 
} 
 
public MemberOfField_LUI HeightofthepatientField() throws Exception{  
return sfdc.Field_LUI("Height of the patient"); 
} 
 
public MemberOfField_LUI HeightUnitField() throws Exception{  
return sfdc.Field_LUI("Height Unit"); 
} 
 
public MemberOfField_LUI SexField() throws Exception{  
return sfdc.Field_LUI("Sex"); 
} 
 
public MemberOfField_LUI ReporterTitleField() throws Exception{  
return sfdc.Field_LUI("Reporter Title"); 
} 
 
public MemberOfField_LUI ReporterFirstNameField() throws Exception{  
return sfdc.Field_LUI("Reporter First Name"); 
} 
 
public MemberOfField_LUI ReporterMiddleNameField() throws Exception{  
return sfdc.Field_LUI("Reporter Middle Name"); 
} 
 
public MemberOfField_LUI ReporterLastNameField() throws Exception{  
return sfdc.Field_LUI("Reporter Last Name"); 
} 
 
public MemberOfField_LUI ReporterStreetField() throws Exception{  
return sfdc.Field_LUI("Reporter Street"); 
} 
 
public MemberOfField_LUI ReporterEmailField() throws Exception{  
return sfdc.Field_LUI("Reporter Email"); 
} 
 
public MemberOfField_LUI ReporterCityField() throws Exception{  
return sfdc.Field_LUI("Reporter City"); 
} 
 
public MemberOfField_LUI ReporterPhoneNoField() throws Exception{  
return sfdc.Field_LUI("Reporter Phone No"); 
} 
 
public MemberOfField_LUI ReporterStateField() throws Exception{  
return sfdc.Field_LUI("Reporter State"); 
} 
 
public MemberOfField_LUI ReporterFaxField() throws Exception{  
return sfdc.Field_LUI("Reporter Fax"); 
} 
 
public MemberOfField_LUI ReporterCountryField() throws Exception{  
return sfdc.Field_LUI("Reporter Country"); 
} 
 
public MemberOfField_LUI ReporterOccupationField() throws Exception{  
return sfdc.Field_LUI("Reporter Occupation"); 
} 
 
public MemberOfField_LUI ReporterZipCodeField() throws Exception{  
return sfdc.Field_LUI("Reporter Zip Code"); 
} 
 
public MemberOfField_LUI HealthProfessionalField() throws Exception{  
return sfdc.Field_LUI("Health Professional?"); 
} 
 
public MemberOfField_LUI ReasonforChangeField() throws Exception{  
return sfdc.Field_LUI("Reason for Change"); 
} 
 
public MemberOfField_LUI LastReasonForChangeField() throws Exception{  
return sfdc.Field_LUI("Last Reason For Change"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 

 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_AssociatedContacts RL_AssociatedContacts() throws Exception{ 
return new Columns_AssociatedContacts("Associated Contacts"); 
} 
public class Columns_AssociatedContacts 
{ 
Columns_AssociatedContacts(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI AssociatedContactID() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Associated Contact ID"); 
} 
public MemberOfRL_LUI AssociatedContactID(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Associated Contact ID",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ContactName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name"); 
} 
public MemberOfRL_LUI ContactName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Role() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role"); 
} 
public MemberOfRL_LUI Role(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Department() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Department"); 
} 
public MemberOfRL_LUI Department(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Department",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReturnKit() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Return Kit"); 
} 
public MemberOfRL_LUI ReturnKit(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Return Kit",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TherapeuticArea() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Therapeutic Area"); 
} 
public MemberOfRL_LUI TherapeuticArea(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Therapeutic Area",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Phone() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone"); 
} 
public MemberOfRL_LUI Phone(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Email() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email"); 
} 
public MemberOfRL_LUI Email(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Specialty() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Specialty"); 
} 
public MemberOfRL_LUI Specialty(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Specialty",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_RelatedProducts RL_RelatedProducts() throws Exception{ 
return new Columns_RelatedProducts("Related Products"); 
} 
public class Columns_RelatedProducts 
{ 
Columns_RelatedProducts(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI AssociatedContactID() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Associated Contact ID"); 
} 
public MemberOfRL_LUI AssociatedContactID(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Associated Contact ID",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ContactName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name"); 
} 
public MemberOfRL_LUI ContactName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Role() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role"); 
} 
public MemberOfRL_LUI Role(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Department() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Department"); 
} 
public MemberOfRL_LUI Department(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Department",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReturnKit() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Return Kit"); 
} 
public MemberOfRL_LUI ReturnKit(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Return Kit",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TherapeuticArea() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Therapeutic Area"); 
} 
public MemberOfRL_LUI TherapeuticArea(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Therapeutic Area",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Phone() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone"); 
} 
public MemberOfRL_LUI Phone(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Email() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email"); 
} 
public MemberOfRL_LUI Email(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Specialty() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Specialty"); 
} 
public MemberOfRL_LUI Specialty(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Specialty",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RelatedProductName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Related Product Name"); 
} 
public MemberOfRL_LUI RelatedProductName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Related Product Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_NotesAttachments RL_NotesAttachments() throws Exception{ 
return new Columns_NotesAttachments("Notes & Attachments"); 
} 
public class Columns_NotesAttachments 
{ 
Columns_NotesAttachments(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI AssociatedContactID() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Associated Contact ID"); 
} 
public MemberOfRL_LUI AssociatedContactID(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Associated Contact ID",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ContactName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name"); 
} 
public MemberOfRL_LUI ContactName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Role() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role"); 
} 
public MemberOfRL_LUI Role(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Department() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Department"); 
} 
public MemberOfRL_LUI Department(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Department",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReturnKit() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Return Kit"); 
} 
public MemberOfRL_LUI ReturnKit(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Return Kit",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TherapeuticArea() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Therapeutic Area"); 
} 
public MemberOfRL_LUI TherapeuticArea(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Therapeutic Area",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Phone() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone"); 
} 
public MemberOfRL_LUI Phone(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Email() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email"); 
} 
public MemberOfRL_LUI Email(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Specialty() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Specialty"); 
} 
public MemberOfRL_LUI Specialty(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Specialty",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RelatedProductName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Related Product Name"); 
} 
public MemberOfRL_LUI RelatedProductName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Related Product Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI UploadFilesButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Upload FilesButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_ProductInvestigations RL_ProductInvestigations() throws Exception{ 
return new Columns_ProductInvestigations("Product Investigations"); 
} 
public class Columns_ProductInvestigations 
{ 
Columns_ProductInvestigations(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI AssociatedContactID() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Associated Contact ID"); 
} 
public MemberOfRL_LUI AssociatedContactID(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Associated Contact ID",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ContactName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name"); 
} 
public MemberOfRL_LUI ContactName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Role() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role"); 
} 
public MemberOfRL_LUI Role(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Department() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Department"); 
} 
public MemberOfRL_LUI Department(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Department",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReturnKit() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Return Kit"); 
} 
public MemberOfRL_LUI ReturnKit(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Return Kit",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TherapeuticArea() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Therapeutic Area"); 
} 
public MemberOfRL_LUI TherapeuticArea(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Therapeutic Area",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Phone() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone"); 
} 
public MemberOfRL_LUI Phone(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Email() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email"); 
} 
public MemberOfRL_LUI Email(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Specialty() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Specialty"); 
} 
public MemberOfRL_LUI Specialty(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Specialty",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RelatedProductName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Related Product Name"); 
} 
public MemberOfRL_LUI RelatedProductName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Related Product Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ProductInvestigationName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product Investigation Name"); 
} 
public MemberOfRL_LUI ProductInvestigationName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product Investigation Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ImpactedProduct() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product"); 
} 
public MemberOfRL_LUI ImpactedProduct(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RecordType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record Type"); 
} 
public MemberOfRL_LUI RecordType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ImpactedProductName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product Name"); 
} 
public MemberOfRL_LUI ImpactedProductName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI InvestigatorName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigator Name"); 
} 
public MemberOfRL_LUI InvestigatorName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigator Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TechniqueType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Technique Type"); 
} 
public MemberOfRL_LUI TechniqueType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Technique Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI InvestigationStartDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigation Start Date"); 
} 
public MemberOfRL_LUI InvestigationStartDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigation Start Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_ReportableAuthorities RL_ReportableAuthorities() throws Exception{ 
return new Columns_ReportableAuthorities("Reportable Authorities"); 
} 
public class Columns_ReportableAuthorities 
{ 
Columns_ReportableAuthorities(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI RelatedProductName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Related Product Name"); 
} 
public MemberOfRL_LUI RelatedProductName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Related Product Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ProductInvestigationName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product Investigation Name"); 
} 
public MemberOfRL_LUI ProductInvestigationName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product Investigation Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ImpactedProduct() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product"); 
} 
public MemberOfRL_LUI ImpactedProduct(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RecordType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record Type"); 
} 
public MemberOfRL_LUI RecordType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ImpactedProductName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product Name"); 
} 
public MemberOfRL_LUI ImpactedProductName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI InvestigatorName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigator Name"); 
} 
public MemberOfRL_LUI InvestigatorName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigator Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TechniqueType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Technique Type"); 
} 
public MemberOfRL_LUI TechniqueType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Technique Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI InvestigationStartDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigation Start Date"); 
} 
public MemberOfRL_LUI InvestigationStartDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigation Start Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReportableAuthorityName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reportable Authority Name"); 
} 
public MemberOfRL_LUI ReportableAuthorityName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reportable Authority Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RegulatoryAuthority() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Regulatory Authority"); 
} 
public MemberOfRL_LUI RegulatoryAuthority(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Regulatory Authority",TargetCOlumnValue); 
} 
public MemberOfRL_LUI DecisionTree() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Decision Tree"); 
} 
public MemberOfRL_LUI DecisionTree(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Decision Tree",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReportingPeriod() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period"); 
} 
public MemberOfRL_LUI ReportingPeriod(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReportingPeriodType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period Type"); 
} 
public MemberOfRL_LUI ReportingPeriodType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI IsReportable() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Is Reportable"); 
} 
public MemberOfRL_LUI IsReportable(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Is Reportable",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AutoReportability() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Auto-Reportability"); 
} 
public MemberOfRL_LUI AutoReportability(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Auto-Reportability",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CreateReportableAuthorityButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Create Reportable AuthorityButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_PatientDetails RL_PatientDetails() throws Exception{ 
return new Columns_PatientDetails("Patient Details"); 
} 
public class Columns_PatientDetails 
{ 
Columns_PatientDetails(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ProductInvestigationName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product Investigation Name"); 
} 
public MemberOfRL_LUI ProductInvestigationName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product Investigation Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ImpactedProduct() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product"); 
} 
public MemberOfRL_LUI ImpactedProduct(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RecordType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record Type"); 
} 
public MemberOfRL_LUI RecordType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ImpactedProductName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product Name"); 
} 
public MemberOfRL_LUI ImpactedProductName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI InvestigatorName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigator Name"); 
} 
public MemberOfRL_LUI InvestigatorName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigator Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TechniqueType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Technique Type"); 
} 
public MemberOfRL_LUI TechniqueType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Technique Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI InvestigationStartDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigation Start Date"); 
} 
public MemberOfRL_LUI InvestigationStartDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigation Start Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReportableAuthorityName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reportable Authority Name"); 
} 
public MemberOfRL_LUI ReportableAuthorityName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reportable Authority Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RegulatoryAuthority() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Regulatory Authority"); 
} 
public MemberOfRL_LUI RegulatoryAuthority(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Regulatory Authority",TargetCOlumnValue); 
} 
public MemberOfRL_LUI DecisionTree() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Decision Tree"); 
} 
public MemberOfRL_LUI DecisionTree(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Decision Tree",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReportingPeriod() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period"); 
} 
public MemberOfRL_LUI ReportingPeriod(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReportingPeriodType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period Type"); 
} 
public MemberOfRL_LUI ReportingPeriodType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI IsReportable() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Is Reportable"); 
} 
public MemberOfRL_LUI IsReportable(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Is Reportable",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AutoReportability() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Auto-Reportability"); 
} 
public MemberOfRL_LUI AutoReportability(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Auto-Reportability",TargetCOlumnValue); 
} 
public MemberOfRL_LUI PatientDetailsName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient Details Name"); 
} 
public MemberOfRL_LUI PatientDetailsName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient Details Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI PatientDOB() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient DOB"); 
} 
public MemberOfRL_LUI PatientDOB(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient DOB",TargetCOlumnValue); 
} 
public MemberOfRL_LUI PatientIdentifier() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient Identifier"); 
} 
public MemberOfRL_LUI PatientIdentifier(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient Identifier",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Heightofthepatient() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Height of the patient"); 
} 
public MemberOfRL_LUI Heightofthepatient(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Height of the patient",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Weightofthepatient() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Weight of the patient"); 
} 
public MemberOfRL_LUI Weightofthepatient(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Weight of the patient",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Sex() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sex"); 
} 
public MemberOfRL_LUI Sex(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sex",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_RMAOrders RL_RMAOrders() throws Exception{ 
return new Columns_RMAOrders("RMA Orders"); 
} 
public class Columns_RMAOrders 
{ 
Columns_RMAOrders(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI ProductInvestigationName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product Investigation Name"); 
} 
public MemberOfRL_LUI ProductInvestigationName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product Investigation Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ImpactedProduct() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product"); 
} 
public MemberOfRL_LUI ImpactedProduct(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RecordType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record Type"); 
} 
public MemberOfRL_LUI RecordType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Record Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ImpactedProductName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product Name"); 
} 
public MemberOfRL_LUI ImpactedProductName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Impacted Product Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI InvestigatorName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigator Name"); 
} 
public MemberOfRL_LUI InvestigatorName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigator Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TechniqueType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Technique Type"); 
} 
public MemberOfRL_LUI TechniqueType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Technique Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI InvestigationStartDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigation Start Date"); 
} 
public MemberOfRL_LUI InvestigationStartDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Investigation Start Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReportableAuthorityName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reportable Authority Name"); 
} 
public MemberOfRL_LUI ReportableAuthorityName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reportable Authority Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RegulatoryAuthority() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Regulatory Authority"); 
} 
public MemberOfRL_LUI RegulatoryAuthority(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Regulatory Authority",TargetCOlumnValue); 
} 
public MemberOfRL_LUI DecisionTree() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Decision Tree"); 
} 
public MemberOfRL_LUI DecisionTree(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Decision Tree",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReportingPeriod() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period"); 
} 
public MemberOfRL_LUI ReportingPeriod(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReportingPeriodType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period Type"); 
} 
public MemberOfRL_LUI ReportingPeriodType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reporting Period Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI IsReportable() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Is Reportable"); 
} 
public MemberOfRL_LUI IsReportable(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Is Reportable",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AutoReportability() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Auto-Reportability"); 
} 
public MemberOfRL_LUI AutoReportability(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Auto-Reportability",TargetCOlumnValue); 
} 
public MemberOfRL_LUI PatientDetailsName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient Details Name"); 
} 
public MemberOfRL_LUI PatientDetailsName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient Details Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI PatientDOB() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient DOB"); 
} 
public MemberOfRL_LUI PatientDOB(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient DOB",TargetCOlumnValue); 
} 
public MemberOfRL_LUI PatientIdentifier() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient Identifier"); 
} 
public MemberOfRL_LUI PatientIdentifier(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Patient Identifier",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Heightofthepatient() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Height of the patient"); 
} 
public MemberOfRL_LUI Heightofthepatient(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Height of the patient",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Weightofthepatient() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Weight of the patient"); 
} 
public MemberOfRL_LUI Weightofthepatient(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Weight of the patient",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Sex() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sex"); 
} 
public MemberOfRL_LUI Sex(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sex",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RMAOrderName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"RMA Order Name"); 
} 
public MemberOfRL_LUI RMAOrderName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"RMA Order Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Contact() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact"); 
} 
public MemberOfRL_LUI Contact(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ReasonforReturn() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reason for Return"); 
} 
public MemberOfRL_LUI ReasonforReturn(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Reason for Return",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Account() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account"); 
} 
public MemberOfRL_LUI Account(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RMAOrderStatus() throws Exception 
{ 
return sfdc.RL_LUI(RList,"RMA Order Status"); 
} 
public MemberOfRL_LUI RMAOrderStatus(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"RMA Order Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI EditButton() throws Exception{ 
return sfdc.Button_LUI("Edit"); 
} 
public MemberOfButton_LUI ChangeProcessingStatusButton() throws Exception{ 
return sfdc.Button_LUI("Change Processing Status"); 
} 
public MemberOfButton_LUI ESignatureHistoryButton() throws Exception{ 
return sfdc.Button_LUI("ESignature History"); 
} 
public MemberOfButton_LUI MenuButtonSubmitforApprovalButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Submit for Approval"); 
} 
} 
 
