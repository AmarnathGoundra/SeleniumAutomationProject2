package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 

import org.openqa.selenium.remote.RemoteWebDriver; 

import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class HC_LeadsScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public HC_LeadsScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public HC_LeadsScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI LeadOwnerField() throws Exception{  
return sfdc.Field_LUI("Lead Owner"); 
} 
 
public MemberOfField_LUI LeadStatusField() throws Exception{  
return sfdc.Field_LUI("Lead Status"); 
} 
 
public MemberOfField_LUI SSNIDField() throws Exception{  
return sfdc.Field_LUI("SSN ID"); 
} 
 
public MemberOfField_LUI VerifiedField() throws Exception{  
return sfdc.Field_LUI("Verified"); 
} 
 
public MemberOfField_LUI PatientcreationdateField() throws Exception{  
return sfdc.Field_LUI("Patient creation date"); 
} 
 
public MemberOfField_LUI NameField() throws Exception{  
return sfdc.Field_LUI("Name"); 
} 
 
public MemberOfField_LUI BirthDateField() throws Exception{  
return sfdc.Field_LUI("Birth Date"); 
} 
 
public MemberOfField_LUI GenderField() throws Exception{  
return sfdc.Field_LUI("Gender"); 
} 
 
public MemberOfField_LUI AddressLine1Field() throws Exception{  
return sfdc.Field_LUI("Address Line 1"); 
} 
 
public MemberOfField_LUI AddressLine2Field() throws Exception{  
return sfdc.Field_LUI("Address Line 2"); 
} 
 
public MemberOfField_LUI CityTownField() throws Exception{  
return sfdc.Field_LUI("City/Town"); 
} 
 
public MemberOfField_LUI PostcodeField() throws Exception{  
return sfdc.Field_LUI("Postcode"); 
} 
 
public MemberOfField_LUI CountryCodeField() throws Exception{  
return sfdc.Field_LUI("Country Code"); 
} 
 
public MemberOfField_LUI MainContactField() throws Exception{  
return sfdc.Field_LUI("Main Contact"); 
} 
 
public MemberOfField_LUI PhoneField() throws Exception{  
return sfdc.Field_LUI("Phone"); 
} 
 
public MemberOfField_LUI EmailField() throws Exception{  
return sfdc.Field_LUI("Email"); 
} 
 
public MemberOfField_LUI TitleField() throws Exception{  
return sfdc.Field_LUI("Title"); 
} 
 
public MemberOfField_LUI CarerAddressline1Field() throws Exception{  
return sfdc.Field_LUI("Carer Address line1"); 
} 
 
public MemberOfField_LUI CarerFirstNameField() throws Exception{  
return sfdc.Field_LUI("Carer First Name"); 
} 
 
public MemberOfField_LUI CarerAddressline2Field() throws Exception{  
return sfdc.Field_LUI("Carer Address line2"); 
} 
 
public MemberOfField_LUI CarerLastNameField() throws Exception{  
return sfdc.Field_LUI("Carer Last Name"); 
} 
 
public MemberOfField_LUI CarerCityField() throws Exception{  
return sfdc.Field_LUI("Carer City"); 
} 
 
public MemberOfField_LUI RelationshiptopatientField() throws Exception{  
return sfdc.Field_LUI("Relationship to patient"); 
} 
 
public MemberOfField_LUI CarerPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Carer Postal Code"); 
} 
 
public MemberOfField_LUI CarerPhoneField() throws Exception{  
return sfdc.Field_LUI("Carer Phone"); 
} 
 
public MemberOfField_LUI CarerEmailField() throws Exception{  
return sfdc.Field_LUI("Carer Email"); 
} 
 
public MemberOfField_LUI TreatingCentreNameField() throws Exception{  
return sfdc.Field_LUI("Treating Centre Name"); 
} 
 
public MemberOfField_LUI ReferringCentreNameField() throws Exception{  
return sfdc.Field_LUI("Referring Centre Name"); 
} 
 
public MemberOfField_LUI TreatingSpecialistNameField() throws Exception{  
return sfdc.Field_LUI("Treating Specialist Name"); 
} 
 
public MemberOfField_LUI TreatingSpecialistEmailField() throws Exception{  
return sfdc.Field_LUI("Treating Specialist Email"); 
} 
 
public MemberOfField_LUI ReferringSpecialistNameField() throws Exception{  
return sfdc.Field_LUI("Referring Specialist Name"); 
} 
 
public MemberOfField_LUI DuodopastartdateField() throws Exception{  
return sfdc.Field_LUI("Duodopa start date"); 
} 
 
public MemberOfField_LUI TheurapeticAreaField() throws Exception{  
return sfdc.Field_LUI("Theurapetic Area"); 
} 
 
public MemberOfField_LUI PlannedproceduresField() throws Exception{  
return sfdc.Field_LUI("Planned procedure/s"); 
} 
 
public MemberOfField_LUI BrandField() throws Exception{  
return sfdc.Field_LUI("Brand"); 
} 
 
public MemberOfField_LUI HospitalAdmissionDateTimeField() throws Exception{  
return sfdc.Field_LUI("Hospital Admission Date & Time"); 
} 
 
public MemberOfField_LUI HospitaladmissiondateconfirmedField() throws Exception{  
return sfdc.Field_LUI("Hospital admission date confirmed?"); 
} 
 
public MemberOfField_LUI NJPlacementDateTimeField() throws Exception{  
return sfdc.Field_LUI("NJ Placement Date & Time"); 
} 
 
public MemberOfField_LUI NJStartDateConfirmedField() throws Exception{  
return sfdc.Field_LUI("NJ Start Date Confirmed ?"); 
} 
 
public MemberOfField_LUI PEGJPEJTPortPlacementDateTimeField() throws Exception{  
return sfdc.Field_LUI("PEG-J/PEJ/ T-Port Placement Date & Time"); 
} 
 
public MemberOfField_LUI PEGJStartDateConfirmedField() throws Exception{  
return sfdc.Field_LUI("PEG-J Start Date Confirmed ?"); 
} 
 
public MemberOfField_LUI ReasonfortheLateTitrationField() throws Exception{  
return sfdc.Field_LUI("Reason for the Late Titration"); 
} 
 
public MemberOfField_LUI TypeofFollowuptreatmentField() throws Exception{  
return sfdc.Field_LUI("Type of Follow up treatment"); 
} 
 
public MemberOfField_LUI HCPprivacystmtAlcuracancontactField() throws Exception{  
return sfdc.Field_LUI("HCP privacy stmt - Alcura can contact"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
public MemberOfField_LUI CompanyField() throws Exception{  
return sfdc.Field_LUI("Company"); 
} 
 
public MemberOfField_LUI SalutationField() throws Exception{  
return sfdc.Field_LUI("Salutation"); 
} 
 
public MemberOfField_LUI FirstNameField() throws Exception{  
return sfdc.Field_LUI("First Name"); 
} 
 
public MemberOfField_LUI MiddleNameField() throws Exception{  
return sfdc.Field_LUI("Middle Name"); 
} 
 
public MemberOfField_LUI LastNameField() throws Exception{  
return sfdc.Field_LUI("Last Name"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 public Columns_Leads LV_Leads() throws Exception{ 
return new Columns_Leads("Leads"); 
} 
public class Columns_Leads 
{ 
Columns_Leads(String RL) 
{ 
RList = RL;  
}  
public MemberOfLV_LUI Name() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Name"); 
} 
public MemberOfLV_LUI Name(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Title() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Title"); 
} 
public MemberOfLV_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Company() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Company"); 
} 
public MemberOfLV_LUI Company(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Company",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Phone() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Phone"); 
} 
public MemberOfLV_LUI Phone(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Phone",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Email() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Email"); 
} 
public MemberOfLV_LUI Email(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Email",TargetCOlumnValue); 
} 
public MemberOfLV_LUI LeadStatus() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Lead Status"); 
} 
public MemberOfLV_LUI LeadStatus(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Lead Status",TargetCOlumnValue); 
} 
public MemberOfLV_LUI OwnerAlias() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner Alias"); 
} 
public MemberOfLV_LUI OwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner Alias",TargetCOlumnValue); 
} 
public MemberOfLV_LUI CreatedDate() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Created Date"); 
} 
public MemberOfLV_LUI CreatedDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Created Date",TargetCOlumnValue); 
} 
public MemberOfLV_LUI NewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"NewButton");  
} 
public MemberOfLV_LUI ChangeStatusButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Change StatusButton");  
} 
public MemberOfLV_LUI ChangeOwnerButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Change OwnerButton");  
} 
public MemberOfLV_LUI MenuButtonSendListEmailButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonSend List EmailButton");  
} 
public MemberOfLV_LUI EditButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"EditButton");  
} 
public MemberOfLV_LUI DeleteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"DeleteButton");  
} 
public MemberOfLV_LUI CancelButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"CancelButton");  
} 
public MemberOfLV_LUI SaveNewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Save & NewButton");  
} 
public MemberOfLV_LUI SaveButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"SaveButton");  
} 
public MemberOfLV_LUI ConverttoPatientButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Convert to PatientButton");  
} 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewButton() throws Exception{ 
return sfdc.Button_LUI("New"); 
} 
public MemberOfButton_LUI ChangeStatusButton() throws Exception{ 
return sfdc.Button_LUI("Change Status"); 
} 
public MemberOfButton_LUI ChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("Change Owner"); 
} 
public MemberOfButton_LUI MenuButtonSendListEmailButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Send List Email"); 
} 
public MemberOfButton_LUI EditButton1() throws Exception{ 
return sfdc.Button_LUI("Edit"); 
} 
public MemberOfButton_LUI DeleteButton() throws Exception{ 
return sfdc.Button_LUI("Delete"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveNewButton() throws Exception{ 
return sfdc.Button_LUI("Save & New"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
public MemberOfHealthCloud_LUI ConverttoPatientButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Convert to Patient"); 
} 
//************************* Functions for Health cloud Fields ***************************** // 

public MemberOfHealthCloud_LUI EditButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Edit"); 
}
public MemberOfHealthCloud_LUI Selectanobjecttolimityoursearch_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select an object to limit your search"); 
} 
public MemberOfHealthCloud_LUI SearchSalesforce_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Salesforce"); 
} 
public MemberOfHealthCloud_LUI Searchthislist_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search this list..."); 
} 
public MemberOfHealthCloud_LUI Select17items_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select 17 items"); 
} 
public MemberOfHealthCloud_LUI Selectitem1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 1"); 
} 
public MemberOfHealthCloud_LUI Selectitem2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 2"); 
} 
public MemberOfHealthCloud_LUI Selectitem3_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 3"); 
} 
public MemberOfHealthCloud_LUI Selectitem4_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 4"); 
} 
public MemberOfHealthCloud_LUI Selectitem5_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 5"); 
} 
public MemberOfHealthCloud_LUI Selectitem6_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 6"); 
} 
public MemberOfHealthCloud_LUI Selectitem7_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 7"); 
} 
public MemberOfHealthCloud_LUI Selectitem8_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 8"); 
} 
public MemberOfHealthCloud_LUI Selectitem9_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 9"); 
} 
public MemberOfHealthCloud_LUI Selectitem10_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 10"); 
} 
public MemberOfHealthCloud_LUI Selectitem11_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 11"); 
} 
public MemberOfHealthCloud_LUI Selectitem12_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 12"); 
} 
public MemberOfHealthCloud_LUI Selectitem13_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 13"); 
} 
public MemberOfHealthCloud_LUI IntakeCall_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Intake Call"); 
} 
public MemberOfHealthCloud_LUI SSNID_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SSN ID"); 
} 
public MemberOfHealthCloud_LUI Verified_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Verified"); 
} 
public MemberOfHealthCloud_LUI Date_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Date"); 
} 
public MemberOfHealthCloud_LUI Time_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Time"); 
} 
public MemberOfHealthCloud_LUI FirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("First Name"); 
} 
public MemberOfHealthCloud_LUI MiddleName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Middle Name"); 
} 
public MemberOfHealthCloud_LUI LastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Last Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI BirthDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Birth Date"); 
} 
public MemberOfHealthCloud_LUI AddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Address Line 1"); 
} 
public MemberOfHealthCloud_LUI AddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Address Line 2"); 
} 
public MemberOfHealthCloud_LUI CityTown_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("City/Town"); 
} 
public MemberOfHealthCloud_LUI Postcode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Postcode"); 
} 
public MemberOfHealthCloud_LUI Phone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Phone"); 
} 
public MemberOfHealthCloud_LUI Email_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Email"); 
} 
public MemberOfHealthCloud_LUI CarerAddressline1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Address line1"); 
} 
public MemberOfHealthCloud_LUI CarerFirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer First Name"); 
} 
public MemberOfHealthCloud_LUI CarerAddressline2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Address line2"); 
} 
public MemberOfHealthCloud_LUI CarerLastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Last Name"); 
} 
public MemberOfHealthCloud_LUI CarerCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer City"); 
} 
public MemberOfHealthCloud_LUI CarerPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Postal Code"); 
} 
public MemberOfHealthCloud_LUI CarerPhone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Phone"); 
} 
public MemberOfHealthCloud_LUI CarerEmail_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Email"); 
} 
public MemberOfHealthCloud_LUI TreatingCentreName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Centre Name"); 
} 
public MemberOfHealthCloud_LUI ReferringCentreName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Centre Name"); 
} 
public MemberOfHealthCloud_LUI TreatingSpecialistName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Specialist Name"); 
} 
public MemberOfHealthCloud_LUI TreatingSpecialistEmail_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Specialist Email"); 
} 
public MemberOfHealthCloud_LUI ReferringSpecialistName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Specialist Name"); 
} 
public MemberOfHealthCloud_LUI Duodopastartdate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Duodopa start date"); 
} 
public MemberOfHealthCloud_LUI Hospitaladmissiondateconfirmed_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Hospital admission date confirmed?"); 
} 
public MemberOfHealthCloud_LUI NJStartDateConfirmed_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("NJ Start Date Confirmed ?"); 
} 
public MemberOfHealthCloud_LUI PEGJStartDateConfirmed_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("PEG-J Start Date Confirmed ?"); 
} 
public MemberOfHealthCloud_LUI HCPprivacystmtAlcuracancontact_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("HCP privacy stmt - Alcura can contact"); 
} 
public MemberOfHealthCloud_LUI HCPprivacystatementAlcuracancontactpatient_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("HCP privacy statement - Alcura can contact patient"); 
} 
public MemberOfHealthCloud_LUI Company_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Company"); 
} 
public MemberOfHealthCloud_LUI SearchLeadsandmore_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Leads and more"); 
} 
public MemberOfHealthCloud_LUI Select3items_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select 3 items"); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//public MemberOfCustom_LUI CancelCustomButton() throws Exception{ 
// sfdc.CustomButton_LUI("Cancel"); 
//} 
//public MemberOfCustom_LUI NextCustomButton() throws Exception{ 
//return sfdc.CustomButton_LUI("Next"); 
//} 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
public MemberOfCustom_LUI VIEWVALIDATIONSCustomJTreeText() throws Exception{ 
return sfdc.CustomJTree_LUI("1. VIEW VALIDATIONS"); 
} 
public MemberOfCustom_LUI ASSIGNCareCoordinatorCustomJTreeText() throws Exception{ 
return sfdc.CustomJTree_LUI("2. ASSIGN Care Coordinator"); 
} 
public MemberOfCustom_LUI REVIEWCustomJTreeText() throws Exception{ 
return sfdc.CustomJTree_LUI("3. REVIEW"); 
} 

 
//************************* Functions for Custom Button ***************************** // 

public MemberOfCustom_LUI CancelCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Cancel"); 
} 
public MemberOfCustom_LUI NextCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Next"); 
} 
public MemberOfCustom_LUI BackCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Back"); 
} 
}
