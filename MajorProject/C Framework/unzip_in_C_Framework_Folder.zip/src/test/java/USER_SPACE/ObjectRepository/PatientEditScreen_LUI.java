package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class PatientEditScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public PatientEditScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public PatientEditScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI PatientOwnerField() throws Exception{  
return sfdc.Field_LUI("Patient Owner"); 
} 
 
public MemberOfField_LUI PatientRecordTypeField() throws Exception{  
return sfdc.Field_LUI("Patient Record Type"); 
} 
 
public MemberOfField_LUI AccountNameField() throws Exception{  
return sfdc.Field_LUI("Account Name"); 
} 
 
public MemberOfField_LUI SSNIDField() throws Exception{  
return sfdc.Field_LUI("SSN ID"); 
} 
 
public MemberOfField_LUI SalutationField() throws Exception{  
return sfdc.Field_LUI("Salutation"); 
} 
 
public MemberOfField_LUI FirstNameField() throws Exception{  
return sfdc.Field_LUI("First Name"); 
} 
 
public MemberOfField_LUI MiddleNameField() throws Exception{  
return sfdc.Field_LUI("Middle Name"); 
} 
 
public MemberOfField_LUI LastNameField() throws Exception{  
return sfdc.Field_LUI("Last Name"); 
} 
 
public MemberOfField_LUI StatusField() throws Exception{  
return sfdc.Field_LUI("Status"); 
} 
 
public MemberOfField_LUI BirthDateField() throws Exception{  
return sfdc.Field_LUI("Birth Date"); 
} 
 
public MemberOfField_LUI PatientTreatmentstatusField() throws Exception{  
return sfdc.Field_LUI("Patient Treatment status"); 
} 
 
public MemberOfField_LUI GenderField() throws Exception{  
return sfdc.Field_LUI("Gender"); 
} 
 
public MemberOfField_LUI ActionField() throws Exception{  
return sfdc.Field_LUI("Action"); 
} 
 
public MemberOfField_LUI EthnicityField() throws Exception{  
return sfdc.Field_LUI("Ethnicity"); 
} 
 
public MemberOfField_LUI PatientIdField() throws Exception{  
return sfdc.Field_LUI("Patient Id"); 
} 
 
public MemberOfField_LUI HeightcmField() throws Exception{  
return sfdc.Field_LUI("Height (cm)"); 
} 
 
public MemberOfField_LUI PreviouspatientIDField() throws Exception{  
return sfdc.Field_LUI("Previous patient ID"); 
} 
 
public MemberOfField_LUI WeightkgField() throws Exception{  
return sfdc.Field_LUI("Weight (kg)"); 
} 
 
public MemberOfField_LUI BrandField() throws Exception{  
return sfdc.Field_LUI("Brand"); 
} 
 
public MemberOfField_LUI PregnancyField() throws Exception{  
return sfdc.Field_LUI("Pregnancy"); 
} 
 
public MemberOfField_LUI TherapeuticAreaField() throws Exception{  
return sfdc.Field_LUI("Therapeutic Area"); 
} 
 
public MemberOfField_LUI PregnancyWeeksField() throws Exception{  
return sfdc.Field_LUI("Pregnancy (Weeks)"); 
} 
 
public MemberOfField_LUI OwnerChangedField() throws Exception{  
return sfdc.Field_LUI("OwnerChanged"); 
} 
 
public MemberOfField_LUI PatientUpdatedTreatmentStatusField() throws Exception{  
return sfdc.Field_LUI("Patient Updated Treatment Status"); 
} 
 
public MemberOfField_LUI AddressLine1Field() throws Exception{  
return sfdc.Field_LUI("Address Line1"); 
} 
 
public MemberOfField_LUI MailingaddresssameasmainaddressField() throws Exception{  
return sfdc.Field_LUI("Mailing address same as main address?"); 
} 
 
public MemberOfField_LUI AddressLine2Field() throws Exception{  
return sfdc.Field_LUI("Address Line2"); 
} 
 
public MemberOfField_LUI MailingStreetField() throws Exception{  
return sfdc.Field_LUI("Mailing Street"); 
} 
 
public MemberOfField_LUI MailingZipPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Mailing Zip/Postal Code"); 
} 
 
public MemberOfField_LUI MailingCityField() throws Exception{  
return sfdc.Field_LUI("Mailing City"); 
} 
 
public MemberOfField_LUI MailingStateProvinceField() throws Exception{  
return sfdc.Field_LUI("Mailing State/Province"); 
} 
 
public MemberOfField_LUI MailingCountryField() throws Exception{  
return sfdc.Field_LUI("Mailing Country"); 
} 
 
public MemberOfField_LUI AddressTypeField() throws Exception{  
return sfdc.Field_LUI("Address Type"); 
} 
 
public MemberOfField_LUI AddressClassificationField() throws Exception{  
return sfdc.Field_LUI("Address Classification"); 
} 
 
public MemberOfField_LUI CityTownField() throws Exception{  
return sfdc.Field_LUI("City/Town"); 
} 
 
public MemberOfField_LUI CountryCodeField() throws Exception{  
return sfdc.Field_LUI("Country Code"); 
} 
 
public MemberOfField_LUI PatientZipPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Patient Zip / Postal Code"); 
} 
 
public MemberOfField_LUI AlternativeAddressLine1Field() throws Exception{  
return sfdc.Field_LUI("Alternative Address Line 1"); 
} 
 
public MemberOfField_LUI AlternativeAddressLine2Field() throws Exception{  
return sfdc.Field_LUI("Alternative Address Line 2"); 
} 
 
public MemberOfField_LUI AlternativeAddressTypeField() throws Exception{  
return sfdc.Field_LUI("Alternative Address Type"); 
} 
 
public MemberOfField_LUI AlternativeAddressClassificationField() throws Exception{  
return sfdc.Field_LUI("Alternative Address Classification"); 
} 
 
public MemberOfField_LUI AlternativeAddressPostcodeField() throws Exception{  
return sfdc.Field_LUI("Alternative Address Postcode"); 
} 
 
public MemberOfField_LUI MainContactField() throws Exception{  
return sfdc.Field_LUI("Main Contact"); 
} 
 
public MemberOfField_LUI PhoneField() throws Exception{  
return sfdc.Field_LUI("Phone"); 
} 
 
public MemberOfField_LUI PatientscommunicationchannelField() throws Exception{  
return sfdc.Field_LUI("Patient's communication channel"); 
} 
 
public MemberOfField_LUI EmailField() throws Exception{  
return sfdc.Field_LUI("Email"); 
} 
 
public MemberOfField_LUI BestdaytocontactyouField() throws Exception{  
return sfdc.Field_LUI("Best day to contact you"); 
} 
 
public MemberOfField_LUI BesttimetocontactyouField() throws Exception{  
return sfdc.Field_LUI("Best time to contact you"); 
} 
 
public MemberOfField_LUI CarerTitleField() throws Exception{  
return sfdc.Field_LUI("Carer Title"); 
} 
 
public MemberOfField_LUI CarerAddressLine1Field() throws Exception{  
return sfdc.Field_LUI("Carer Address Line1"); 
} 
 
public MemberOfField_LUI CarerFirstNameField() throws Exception{  
return sfdc.Field_LUI("Carer First Name"); 
} 
 
public MemberOfField_LUI CarerAddressLine2Field() throws Exception{  
return sfdc.Field_LUI("Carer Address Line2"); 
} 
 
public MemberOfField_LUI CarerLastNameField() throws Exception{  
return sfdc.Field_LUI("Carer Last Name"); 
} 
 
public MemberOfField_LUI CarerCityField() throws Exception{  
return sfdc.Field_LUI("Carer City"); 
} 
 
public MemberOfField_LUI CarerPhoneField() throws Exception{  
return sfdc.Field_LUI("Carer Phone"); 
} 
 
public MemberOfField_LUI CarerPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Carer Postal Code"); 
} 
 
public MemberOfField_LUI CarerEmailField() throws Exception{  
return sfdc.Field_LUI("Carer Email"); 
} 
 
public MemberOfField_LUI RelationshiptopatientField() throws Exception{  
return sfdc.Field_LUI("Relationship to patient"); 
} 
 
public MemberOfField_LUI DuodopastartdateField() throws Exception{  
return sfdc.Field_LUI("Duodopa start date"); 
} 
 
public MemberOfField_LUI ProceduretobeperformedField() throws Exception{  
return sfdc.Field_LUI("Procedure to be performed"); 
} 
 
public MemberOfField_LUI ReasonfortheLateTitrationField() throws Exception{  
return sfdc.Field_LUI("Reason for the Late Titration"); 
} 
 
public MemberOfField_LUI HospitaladmissiondateconfirmedField() throws Exception{  
return sfdc.Field_LUI("Hospital admission date confirmed?"); 
} 
 
public MemberOfField_LUI NJPlacementDateConfirmedField() throws Exception{  
return sfdc.Field_LUI("NJ Placement Date Confirmed ?"); 
} 
 
public MemberOfField_LUI PEGJPEJTPortPlacementDateConfirmField() throws Exception{  
return sfdc.Field_LUI("PEG-J/ PEJ/T-Port Placement Date Confirm"); 
} 
 
public MemberOfField_LUI NJProceduretypeField() throws Exception{  
return sfdc.Field_LUI("NJ Procedure type"); 
} 
 
public MemberOfField_LUI PEGJPEJTPortProceduretypeField() throws Exception{  
return sfdc.Field_LUI("PEG-J/PEJ/T-Port Procedure type"); 
} 
 
public MemberOfField_LUI PatientDischargeDateField() throws Exception{  
return sfdc.Field_LUI("Patient Discharge Date"); 
} 
 
public MemberOfField_LUI TitrationassistancerequiredField() throws Exception{  
return sfdc.Field_LUI("Titration assistance required?"); 
} 
 
public MemberOfField_LUI PatientMonitoringField() throws Exception{  
return sfdc.Field_LUI("Patient Monitoring"); 
} 
 
public MemberOfField_LUI EducationField() throws Exception{  
return sfdc.Field_LUI("Education"); 
} 
 
public MemberOfField_LUI ProcedureAssistanceField() throws Exception{  
return sfdc.Field_LUI("Procedure Assistance"); 
} 
 
public MemberOfField_LUI TypeofFollowuptreatmentField() throws Exception{  
return sfdc.Field_LUI("Type of Follow up treatment"); 
} 
 
public MemberOfField_LUI ScheduleFirstContactField() throws Exception{  
return sfdc.Field_LUI("Schedule First Contact"); 
} 
 
public MemberOfField_LUI CurrentPatientJourneyNameField() throws Exception{  
return sfdc.Field_LUI("Current Patient Journey Name"); 
} 
 
public MemberOfField_LUI PatientReinstatedField() throws Exception{  
return sfdc.Field_LUI("Patient Re-instated?"); 
} 
 
public MemberOfField_LUI JourneyStartDateField() throws Exception{  
return sfdc.Field_LUI("Journey Start Date"); 
} 
 
public MemberOfField_LUI ReInstateDateField() throws Exception{  
return sfdc.Field_LUI("Re-Instate Date"); 
} 
 
public MemberOfField_LUI PatientJourneyCreatedField() throws Exception{  
return sfdc.Field_LUI("Patient Journey Created?"); 
} 
 
public MemberOfField_LUI IndicativetreatmentrestartDateField() throws Exception{  
return sfdc.Field_LUI("Indicative treatment restart Date"); 
} 
 
public MemberOfField_LUI TreatingCentreNameField() throws Exception{  
return sfdc.Field_LUI("Treating Centre Name"); 
} 
 
public MemberOfField_LUI DoctorNameField() throws Exception{  
return sfdc.Field_LUI("Doctor Name"); 
} 
 
public MemberOfField_LUI HCPEmailField() throws Exception{  
return sfdc.Field_LUI("HCP Email"); 
} 
 
public MemberOfField_LUI TreatingPDNurseField() throws Exception{  
return sfdc.Field_LUI("Treating PD Nurse"); 
} 
 
public MemberOfField_LUI ReferringCentreNameField() throws Exception{  
return sfdc.Field_LUI("Referring Centre Name"); 
} 
 
public MemberOfField_LUI ReferringSpecialistField() throws Exception{  
return sfdc.Field_LUI("Referring Specialist"); 
} 
 
public MemberOfField_LUI GeneralPractionerField() throws Exception{  
return sfdc.Field_LUI("General Practioner"); 
} 
 
public MemberOfField_LUI FreelanceNurseField() throws Exception{  
return sfdc.Field_LUI("Freelance Nurse"); 
} 
 
public MemberOfField_LUI HomeCareNameField() throws Exception{  
return sfdc.Field_LUI("Home Care Name"); 
} 
 
public MemberOfField_LUI HomeCareTypeField() throws Exception{  
return sfdc.Field_LUI("Home Care Type"); 
} 
 
public MemberOfField_LUI HomeCareAddressLine1Field() throws Exception{  
return sfdc.Field_LUI("Home Care Address Line 1"); 
} 
 
public MemberOfField_LUI HomeCareAddressLine2Field() throws Exception{  
return sfdc.Field_LUI("Home Care Address Line 2"); 
} 
 
public MemberOfField_LUI HomeCareCityField() throws Exception{  
return sfdc.Field_LUI("Home Care City"); 
} 
 
public MemberOfField_LUI HomeCarePostcodeField() throws Exception{  
return sfdc.Field_LUI("Home Care Postcode"); 
} 
 
public MemberOfField_LUI ContactNumberField() throws Exception{  
return sfdc.Field_LUI("Contact Number"); 
} 
 
public MemberOfField_LUI HomeCareKeyContactNumberField() throws Exception{  
return sfdc.Field_LUI("Home Care Key Contact Number"); 
} 
 
public MemberOfField_LUI HCPprivacystmtAlcuracancontactField() throws Exception{  
return sfdc.Field_LUI("HCP privacy stmt - Alcura can contact"); 
} 
 
public MemberOfField_LUI FullPSPconsentField() throws Exception{  
return sfdc.Field_LUI("Full PSP consent"); 
} 
 
public MemberOfField_LUI MedicaldatacanberetrievedfromHCPField() throws Exception{  
return sfdc.Field_LUI("Medical data can be retrieved from HCP"); 
} 
 
public MemberOfField_LUI LSPconsentField() throws Exception{  
return sfdc.Field_LUI("LSP consent"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
  
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI EditButton() throws Exception{ 
return sfdc.Button_LUI("Edit"); 
} 
public MemberOfButton_LUI GeneratePatientJourneyButton() throws Exception{ 
return sfdc.Button_LUI("Generate Patient Journey"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveNewButton() throws Exception{ 
return sfdc.Button_LUI("Save & New"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Selectanobjecttolimityoursearch_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select an object to limit your search"); 
} 
public MemberOfHealthCloud_LUI SearchPatientsandmore_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Patients and more"); 
} 
public MemberOfHealthCloud_LUI IntakeCall_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Intake Call"); 
} 
public MemberOfHealthCloud_LUI Bedsideinservice_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Bedside in-service"); 
} 
public MemberOfHealthCloud_LUI AccountName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Account Name"); 
} 
public MemberOfHealthCloud_LUI SSNID_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SSN ID"); 
} 
public MemberOfHealthCloud_LUI FirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("First Name"); 
} 
public MemberOfHealthCloud_LUI MiddleName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Middle Name"); 
} 
public MemberOfHealthCloud_LUI LastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Last Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI BirthDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Birth Date"); 
} 
public MemberOfHealthCloud_LUI Ethnicity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Ethnicity"); 
} 
public MemberOfHealthCloud_LUI Heightcm_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Height (cm)"); 
} 
public MemberOfHealthCloud_LUI PreviouspatientID_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Previous patient ID"); 
} 
public MemberOfHealthCloud_LUI Weightkg_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Weight (kg)"); 
} 
public MemberOfHealthCloud_LUI PregnancyWeeks_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Pregnancy (Weeks)"); 
} 
public MemberOfHealthCloud_LUI OwnerChanged_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("OwnerChanged"); 
} 
public MemberOfHealthCloud_LUI AddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Address Line1"); 
} 
public MemberOfHealthCloud_LUI Mailingaddresssameasmainaddress_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mailing address same as main address?"); 
} 
public MemberOfHealthCloud_LUI AddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Address Line2"); 
} 
public MemberOfHealthCloud_LUI MailingStreet_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mailing Street"); 
} 
public MemberOfHealthCloud_LUI MailingZipPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mailing Zip/Postal Code"); 
} 
public MemberOfHealthCloud_LUI MailingCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mailing City"); 
} 
public MemberOfHealthCloud_LUI MailingStateProvince_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mailing State/Province"); 
} 
public MemberOfHealthCloud_LUI MailingCountry_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Mailing Country"); 
} 
public MemberOfHealthCloud_LUI CityTown_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("City/Town"); 
} 
public MemberOfHealthCloud_LUI PatientZipPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Patient Zip / Postal Code"); 
} 
public MemberOfHealthCloud_LUI AlternativeAddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Alternative Address Line 1"); 
} 
public MemberOfHealthCloud_LUI AlternativeAddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Alternative Address Line 2"); 
} 
public MemberOfHealthCloud_LUI AlternativeAddressPostcode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Alternative Address Postcode"); 
} 
public MemberOfHealthCloud_LUI Phone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Phone"); 
} 
public MemberOfHealthCloud_LUI Email_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Email"); 
} 
public MemberOfHealthCloud_LUI CarerAddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Address Line1"); 
} 
public MemberOfHealthCloud_LUI CarerFirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer First Name"); 
} 
public MemberOfHealthCloud_LUI CarerAddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Address Line2"); 
} 
public MemberOfHealthCloud_LUI CarerLastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Last Name"); 
} 
public MemberOfHealthCloud_LUI CarerCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer City"); 
} 
public MemberOfHealthCloud_LUI CarerPhone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Phone"); 
} 
public MemberOfHealthCloud_LUI CarerPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Postal Code"); 
} 
public MemberOfHealthCloud_LUI CarerEmail_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Carer Email"); 
} 
public MemberOfHealthCloud_LUI Duodopastartdate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Duodopa start date"); 
} 
public MemberOfHealthCloud_LUI Date_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Date"); 
} 
public MemberOfHealthCloud_LUI Time_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Time"); 
} 
public MemberOfHealthCloud_LUI Hospitaladmissiondateconfirmed_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Hospital admission date confirmed?"); 
} 
public MemberOfHealthCloud_LUI NJPlacementDateConfirmed_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("NJ Placement Date Confirmed ?"); 
} 
public MemberOfHealthCloud_LUI PEGJPEJTPortPlacementDateConfirm_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("PEG-J/ PEJ/T-Port Placement Date Confirm"); 
} 
public MemberOfHealthCloud_LUI PEGJPEJTPortPlacementDateConfirmed_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("PEG-J/ PEJ/T-Port Placement Date Confirmed ?"); 
} 
public MemberOfHealthCloud_LUI PatientDischargeDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Patient Discharge Date"); 
} 
public MemberOfHealthCloud_LUI PatientMonitoring_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Patient Monitoring"); 
} 
public MemberOfHealthCloud_LUI Education_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Education"); 
} 
public MemberOfHealthCloud_LUI ProcedureAssistance_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Procedure Assistance"); 
} 
public MemberOfHealthCloud_LUI ScheduleFirstContact_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Schedule First Contact"); 
} 
public MemberOfHealthCloud_LUI CurrentPatientJourneyName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Current Patient Journey Name"); 
} 
public MemberOfHealthCloud_LUI PatientReinstated_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Patient Re-instated?"); 
} 
public MemberOfHealthCloud_LUI JourneyStartDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Journey Start Date"); 
} 
public MemberOfHealthCloud_LUI ReInstateDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Re-Instate Date"); 
} 
public MemberOfHealthCloud_LUI PatientJourneyCreated_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Patient Journey Created?"); 
} 
public MemberOfHealthCloud_LUI IndicativetreatmentrestartDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Indicative treatment restart Date"); 
} 
public MemberOfHealthCloud_LUI UpdatedwhenthePatientisTemporaryStop_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Updated when the Patient is Temporary Stop"); 
} 
public MemberOfHealthCloud_LUI TreatingCentreName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Centre Name"); 
} 
public MemberOfHealthCloud_LUI DoctorName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Doctor Name"); 
} 
public MemberOfHealthCloud_LUI HCPEmail_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("HCP Email"); 
} 
public MemberOfHealthCloud_LUI TreatingPDNurse_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating PD Nurse"); 
} 
public MemberOfHealthCloud_LUI ReferringCentreName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Centre Name"); 
} 
public MemberOfHealthCloud_LUI ReferringSpecialist_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Specialist"); 
} 
public MemberOfHealthCloud_LUI GeneralPractioner_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("General Practioner"); 
} 
public MemberOfHealthCloud_LUI FreelanceNurse_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Freelance Nurse"); 
} 
public MemberOfHealthCloud_LUI HomeCareName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Home Care Name"); 
} 
public MemberOfHealthCloud_LUI HomeCareAddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Home Care Address Line 1"); 
} 
public MemberOfHealthCloud_LUI HomeCareAddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Home Care Address Line 2"); 
} 
public MemberOfHealthCloud_LUI HomeCareCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Home Care City"); 
} 
public MemberOfHealthCloud_LUI HomeCarePostcode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Home Care Postcode"); 
} 
public MemberOfHealthCloud_LUI ContactNumber_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Contact Number"); 
} 
public MemberOfHealthCloud_LUI HomeCareKeyContactNumber_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Home Care Key Contact Number"); 
} 
public MemberOfHealthCloud_LUI HCPprivacystmtAlcuracancontact_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("HCP privacy stmt - Alcura can contact"); 
} 
public MemberOfHealthCloud_LUI HCPprivacystatementAlcuracancontactpatient_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("HCP privacy statement - Alcura can contact patient"); 
} 
public MemberOfHealthCloud_LUI FullPSPconsent_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Full PSP consent"); 
} 
public MemberOfHealthCloud_LUI MedicaldatacanberetrievedfromHCP_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Medical data can be retrieved from HCP"); 
} 
public MemberOfHealthCloud_LUI LSPconsent_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("LSP consent"); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
