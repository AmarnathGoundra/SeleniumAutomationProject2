package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class OpportunitiesScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public OpportunitiesScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public OpportunitiesScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


//************************* Functions for List Views***************************** // 
 


 public Columns_ListView ListView() throws Exception{ 
return new Columns_ListView(); 
} 
public class Columns_ListView{ 
public MemberOfLV Action(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Action",RowIndex); 
}
public MemberOfLV Action() throws Exception 
{ 
return sfdc.LV("Action"); 
}

public MemberOfLV OpportunityName(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Opportunity Name",RowIndex); 
}
public MemberOfLV OpportunityName() throws Exception 
{ 
return sfdc.LV("Opportunity Name"); 
}

public MemberOfLV AccountName(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Account Name",RowIndex); 
}
public MemberOfLV AccountName() throws Exception 
{ 
return sfdc.LV("Account Name"); 
}

public MemberOfLV Amount(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Amount",RowIndex); 
}
public MemberOfLV Amount() throws Exception 
{ 
return sfdc.LV("Amount"); 
}

public MemberOfLV CloseDate(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Close Date",RowIndex); 
}
public MemberOfLV CloseDate() throws Exception 
{ 
return sfdc.LV("Close Date"); 
}

public MemberOfLV Stage(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Stage",RowIndex); 
}
public MemberOfLV Stage() throws Exception 
{ 
return sfdc.LV("Stage"); 
}

public MemberOfLV OpportunityOwnerAlias(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Opportunity Owner Alias",RowIndex); 
}
public MemberOfLV OpportunityOwnerAlias() throws Exception 
{ 
return sfdc.LV("Opportunity Owner Alias"); 
}

}

//************************* Functions for Buttons***************************** // 
 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton NewButton() throws Exception{ 
return sfdc.Button("New"); 
} 
public MemberOfButton RunReportButton() throws Exception{ 
return sfdc.Button("Run Report"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton NewOpportunityButton() throws Exception{ 
return sfdc.Button("New Opportunity"); 
} 
public MemberOfButton Button() throws Exception{ 
return sfdc.Button(""); 
} 
//************************* Functions for Field Names ***************************** // 
 
//************************* Functions for Section Name***************************** // 
 
//************************* Functions for Related List***************************** // 
 
}

