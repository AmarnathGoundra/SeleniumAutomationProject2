package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class AccountsScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public AccountsScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public AccountsScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI AccountOwnerField() throws Exception{  
return sfdc.Field_LUI("Account Owner"); 
} 
 
public MemberOfField_LUI RatingField() throws Exception{  
return sfdc.Field_LUI("Rating"); 
} 
 
public MemberOfField_LUI AccountNameField() throws Exception{  
return sfdc.Field_LUI("Account Name"); 
} 
 
public MemberOfField_LUI PhoneField() throws Exception{  
return sfdc.Field_LUI("Phone"); 
} 
 
public MemberOfField_LUI ParentAccountField() throws Exception{  
return sfdc.Field_LUI("Parent Account"); 
} 
 
public MemberOfField_LUI FaxField() throws Exception{  
return sfdc.Field_LUI("Fax"); 
} 
public MemberOfField_LUI TestIndustryField() throws Exception{  
return sfdc.Field_LUI("TestIndustry"); 
} 
public MemberOfField_LUI TestRevenueField() throws Exception{  
return sfdc.Field_LUI("TestRevenue"); 
} 
 
public MemberOfField_LUI AccountNumberField() throws Exception{  
return sfdc.Field_LUI("Account Number"); 
} 
 
public MemberOfField_LUI WebsiteField() throws Exception{  
return sfdc.Field_LUI("Website"); 
} 
 
public MemberOfField_LUI AccountSiteField() throws Exception{  
return sfdc.Field_LUI("Account Site"); 
} 
 
public MemberOfField_LUI TickerSymbolField() throws Exception{  
return sfdc.Field_LUI("Ticker Symbol"); 
} 
 
public MemberOfField_LUI TypeField() throws Exception{  
return sfdc.Field_LUI("Type"); 
} 
 
public MemberOfField_LUI OwnershipField() throws Exception{  
return sfdc.Field_LUI("Ownership"); 
} 
 
public MemberOfField_LUI IndustryField() throws Exception{  
return sfdc.Field_LUI("Industry"); 
} 


public MemberOfField_LUI HospitalsField() throws Exception{  
return sfdc.Field_LUI("Hospitals"); 
} 

 
public MemberOfField_LUI EmployeesField() throws Exception{  
return sfdc.Field_LUI("Employees"); 
} 
 
public MemberOfField_LUI AnnualRevenueField() throws Exception{  
return sfdc.Field_LUI("Annual Revenue"); 
} 
 
public MemberOfField_LUI SICCodeField() throws Exception{  
return sfdc.Field_LUI("SIC Code"); 
} 
 
public MemberOfField_LUI BillingAddressField() throws Exception{  
return sfdc.Field_LUI("Billing Address"); 
} 
 
public MemberOfField_LUI ShippingAddressField() throws Exception{  
return sfdc.Field_LUI("Shipping Address"); 
} 
 
public MemberOfField_LUI CustomerPriorityField() throws Exception{  
return sfdc.Field_LUI("Customer Priority"); 
} 
 
public MemberOfField_LUI SLAField() throws Exception{  
return sfdc.Field_LUI("SLA"); 
} 
 
public MemberOfField_LUI SLAExpirationDateField() throws Exception{  
return sfdc.Field_LUI("SLA Expiration Date"); 
} 
 
public MemberOfField_LUI SLASerialNumberField() throws Exception{  
return sfdc.Field_LUI("SLA Serial Number"); 
} 
 
public MemberOfField_LUI NumberofLocationsField() throws Exception{  
return sfdc.Field_LUI("Number of Locations"); 
} 
 
public MemberOfField_LUI UpsellOpportunityField() throws Exception{  
return sfdc.Field_LUI("Upsell Opportunity"); 
} 
 
public MemberOfField_LUI ActiveField() throws Exception{  
return sfdc.Field_LUI("Active"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
public MemberOfField_LUI BillingStreetField() throws Exception{  
return sfdc.Field_LUI("Billing Street"); 
} 
 
public MemberOfField_LUI BillingCityField() throws Exception{  
return sfdc.Field_LUI("Billing City"); 
} 
 
public MemberOfField_LUI BillingStateProvinceField() throws Exception{  
return sfdc.Field_LUI("Billing State/Province"); 
} 
 
public MemberOfField_LUI BillingZipPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Billing Zip/Postal Code"); 
} 
 
public MemberOfField_LUI BillingCountryField() throws Exception{  
return sfdc.Field_LUI("Billing Country"); 
} 
 
public MemberOfField_LUI ShippingStreetField() throws Exception{  
return sfdc.Field_LUI("Shipping Street"); 
} 
 
public MemberOfField_LUI ShippingCityField() throws Exception{  
return sfdc.Field_LUI("Shipping City"); 
} 
 
public MemberOfField_LUI ShippingStateProvinceField() throws Exception{  
return sfdc.Field_LUI("Shipping State/Province"); 
} 
 
public MemberOfField_LUI ShippingZipPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Shipping Zip/Postal Code"); 
} 
 
public MemberOfField_LUI ShippingCountryField() throws Exception{  
return sfdc.Field_LUI("Shipping Country"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 public Columns_Accounts LV_Accounts() throws Exception{ 
return new Columns_Accounts("Accounts"); 
} 
public class Columns_Accounts 
{ 
Columns_Accounts(String RL) 
{ 
RList = RL;  
}  
public MemberOfLV_LUI AccountName() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Name"); 
} 
public MemberOfLV_LUI AccountName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI AccountSite() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Site"); 
} 
public MemberOfLV_LUI AccountSite(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Site",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Phone() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Phone"); 
} 
public MemberOfLV_LUI Phone(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Phone",TargetCOlumnValue); 
} 
public MemberOfLV_LUI AccountOwnerAlias() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Owner Alias"); 
} 
public MemberOfLV_LUI AccountOwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Owner Alias",TargetCOlumnValue); 
} 
public MemberOfLV_LUI NewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"NewButton");  
} 
public MemberOfLV_LUI ImportButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"ImportButton");  
} 
public MemberOfLV_LUI NewContactButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New ContactButton");  
} 
public MemberOfLV_LUI NewCaseButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New CaseButton");  
} 
public MemberOfLV_LUI NewNoteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New NoteButton");  
} 
public MemberOfLV_LUI UploadFilesButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Upload FilesButton");  
} 
public MemberOfLV_LUI MenuButtonNewOpportunityButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonNew OpportunityButton");  
} 
public MemberOfLV_LUI MenuButtonChangeOwnerButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonChange OwnerButton");  
} 
public MemberOfLV_LUI MenuButtonCheckforNewDataButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonCheck for New DataButton");  
} 
public MemberOfLV_LUI MenuButtonSubmitforApprovalButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonSubmit for ApprovalButton");  
} 
public MemberOfLV_LUI MenuButtonEditButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonEditButton");  
} 
public MemberOfLV_LUI MenuButtonDeleteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonDeleteButton");  
} 
public MemberOfLV_LUI MenuButtonViewAccountHierarchyButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonView Account HierarchyButton");  
} 
public MemberOfLV_LUI CancelButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"CancelButton");  
} 
public MemberOfLV_LUI SaveNewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Save & NewButton");  
} 
public MemberOfLV_LUI SaveButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"SaveButton");  
} 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_Contacts RL_Contacts() throws Exception{ 
return new Columns_Contacts("Contacts"); 
} 
public class Columns_Contacts 
{ 
Columns_Contacts(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI ContactName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name"); 
} 
public MemberOfRL_LUI ContactName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Email() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email"); 
} 
public MemberOfRL_LUI Email(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Phone() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone"); 
} 
public MemberOfRL_LUI Phone(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI AddtoCampaignButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Add to CampaignButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_Opportunities RL_Opportunities() throws Exception{ 
return new Columns_Opportunities("Opportunities"); 
} 
public class Columns_Opportunities 
{ 
Columns_Opportunities(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI OpportunityName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name"); 
} 
public MemberOfRL_LUI OpportunityName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Stage() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage"); 
} 
public MemberOfRL_LUI Stage(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Amount() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Amount"); 
} 
public MemberOfRL_LUI Amount(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Amount",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CloseDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date"); 
} 
public MemberOfRL_LUI CloseDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_Cases RL_Cases() throws Exception{ 
return new Columns_Cases("Cases"); 
} 
public class Columns_Cases 
{ 
Columns_Cases(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Case() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Case"); 
} 
public MemberOfRL_LUI Case(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Case",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ContactName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name"); 
} 
public MemberOfRL_LUI ContactName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Subject() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Subject"); 
} 
public MemberOfRL_LUI Subject(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Subject",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Priority() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Priority"); 
} 
public MemberOfRL_LUI Priority(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Priority",TargetCOlumnValue); 
} 
public MemberOfRL_LUI DateOpened() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date Opened"); 
} 
public MemberOfRL_LUI DateOpened(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date Opened",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI ChangeOwnerButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Change OwnerButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_NotesAttachments RL_NotesAttachments() throws Exception{ 
return new Columns_NotesAttachments("Notes & Attachments"); 
} 
public class Columns_NotesAttachments 
{ 
Columns_NotesAttachments(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI UploadFilesButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Upload FilesButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_Partners RL_Partners() throws Exception{ 
return new Columns_Partners("Partners"); 
} 
public class Columns_Partners 
{ 
Columns_Partners(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Partner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Partner"); 
} 
public MemberOfRL_LUI Partner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Partner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Opportunity() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity"); 
} 
public MemberOfRL_LUI Opportunity(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Role() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role"); 
} 
public MemberOfRL_LUI Role(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewButton() throws Exception{ 
return sfdc.Button_LUI("New"); 
} 
public MemberOfButton_LUI ImportButton() throws Exception{ 
return sfdc.Button_LUI("Import"); 
} 
public MemberOfButton_LUI NewContactButton() throws Exception{ 
return sfdc.Button_LUI("New Contact"); 
} 
public MemberOfButton_LUI NewCaseButton() throws Exception{ 
return sfdc.Button_LUI("New Case"); 
} 
public MemberOfButton_LUI NewNoteButton() throws Exception{ 
return sfdc.Button_LUI("New Note"); 
} 
public MemberOfButton_LUI UploadFilesButton() throws Exception{ 
return sfdc.Button_LUI("Upload Files"); 
} 
public MemberOfButton_LUI MenuButtonNewOpportunityButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:New Opportunity"); 
} 
public MemberOfButton_LUI MenuButtonChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Change Owner"); 
} 
public MemberOfButton_LUI MenuButtonCheckforNewDataButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Check for New Data"); 
} 
public MemberOfButton_LUI MenuButtonSubmitforApprovalButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Submit for Approval"); 
} 
public MemberOfButton_LUI MenuButtonEditButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Edit"); 
} 
public MemberOfButton_LUI MenuButtonDeleteButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Delete"); 
} 
public MemberOfButton_LUI MenuButtonViewAccountHierarchyButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:View Account Hierarchy"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveNewButton() throws Exception{ 
return sfdc.Button_LUI("Save & New"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
//************************* Functions for All Apps ***************************** // 
 
//************************* Functions for Tabs List ***************************** // 
 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Searchbyobjecttype_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search by object type"); 
} 
public MemberOfHealthCloud_LUI SearchAccountsandmore_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Accounts and more"); 
} 
public MemberOfHealthCloud_LUI Searchthislist_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search this list..."); 
} 
public MemberOfHealthCloud_LUI Select8items_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select 8 items"); 
} 
public MemberOfHealthCloud_LUI Selectitem1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 1"); 
} 
public MemberOfHealthCloud_LUI Selectitem2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 2"); 
} 
public MemberOfHealthCloud_LUI Selectitem3_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 3"); 
} 
public MemberOfHealthCloud_LUI Selectitem4_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 4"); 
} 
public MemberOfHealthCloud_LUI Selectitem5_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 5"); 
} 
public MemberOfHealthCloud_LUI Selectitem6_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 6"); 
} 
public MemberOfHealthCloud_LUI Selectitem7_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 7"); 
} 
public MemberOfHealthCloud_LUI Selectitem8_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select item 8"); 
} 
public MemberOfHealthCloud_LUI Search_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search..."); 
} 
public MemberOfHealthCloud_LUI AccountName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Account Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI Phone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Phone"); 
} 
public MemberOfHealthCloud_LUI ParentAccount_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Parent Account"); 
} 
public MemberOfHealthCloud_LUI Fax_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Fax"); 
} 
public MemberOfHealthCloud_LUI AccountNumber_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Account Number"); 
} 
public MemberOfHealthCloud_LUI Website_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Website"); 
} 
public MemberOfHealthCloud_LUI AccountSite_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Account Site"); 
} 
public MemberOfHealthCloud_LUI TickerSymbol_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Ticker Symbol"); 
} 
public MemberOfHealthCloud_LUI Employees_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Employees"); 
} 
public MemberOfHealthCloud_LUI AnnualRevenue_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Annual Revenue"); 
} 
public MemberOfHealthCloud_LUI SICCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SIC Code"); 
} 
public MemberOfHealthCloud_LUI BillingStreet_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Billing Street"); 
} 
public MemberOfHealthCloud_LUI BillingCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Billing City"); 
} 
public MemberOfHealthCloud_LUI BillingStateProvince_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Billing State/Province"); 
} 
public MemberOfHealthCloud_LUI BillingZipPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Billing Zip/Postal Code"); 
} 
public MemberOfHealthCloud_LUI BillingCountry_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Billing Country"); 
} 
public MemberOfHealthCloud_LUI ShippingStreet_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Shipping Street"); 
} 
public MemberOfHealthCloud_LUI ShippingCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Shipping City"); 
} 
public MemberOfHealthCloud_LUI ShippingStateProvince_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Shipping State/Province"); 
} 
public MemberOfHealthCloud_LUI ShippingZipPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Shipping Zip/Postal Code"); 
} 
public MemberOfHealthCloud_LUI ShippingCountry_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Shipping Country"); 
} 
public MemberOfHealthCloud_LUI SLAExpirationDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SLA Expiration Date"); 
} 
public MemberOfHealthCloud_LUI SLASerialNumber_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SLA Serial Number"); 
} 
public MemberOfHealthCloud_LUI NumberofLocations_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Number of Locations"); 
} 
public MemberOfHealthCloud_LUI Description_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Description"); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
