package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class SurveyDetailScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public SurveyDetailScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public SurveyDetailScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


//************************* Functions for List Views***************************** // 
 


 public Columns_ListView ListView() throws Exception{ 
return new Columns_ListView(); 
} 
public class Columns_ListView{ 
public MemberOfLV Action(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Action",RowIndex); 
}
public MemberOfLV Action() throws Exception 
{ 
return sfdc.LV("Action"); 
}

public MemberOfLV SurveyName(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Survey Name",RowIndex); 
}
public MemberOfLV SurveyName() throws Exception 
{ 
return sfdc.LV("Survey Name"); 
}

public MemberOfLV StartDate(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Start Date",RowIndex); 
}
public MemberOfLV StartDate() throws Exception 
{ 
return sfdc.LV("Start Date"); 
}

public MemberOfLV EndDate(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("End Date",RowIndex); 
}
public MemberOfLV EndDate() throws Exception 
{ 
return sfdc.LV("End Date"); 
}

public MemberOfLV Status(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Status",RowIndex); 
}
public MemberOfLV Status() throws Exception 
{ 
return sfdc.LV("Status"); 
}

public MemberOfLV RecordType(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Record Type",RowIndex); 
}
public MemberOfLV RecordType() throws Exception 
{ 
return sfdc.LV("Record Type"); 
}

public MemberOfLV CountryCode(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Country Code",RowIndex); 
}
public MemberOfLV CountryCode() throws Exception 
{ 
return sfdc.LV("Country Code"); 
}

}

//************************* Functions for Buttons***************************** // 
 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton NewSurveyButton() throws Exception{ 
return sfdc.Button("New Survey"); 
}
public MemberOfButton NewButton() throws Exception{ 
return sfdc.Button("New"); 
} 
public MemberOfButton UnlockButton() throws Exception{ 
return sfdc.Button("Unlock"); 
} 
public MemberOfButton CloneButton() throws Exception{ 
return sfdc.Button("Clone"); 
} 
public MemberOfButton TranslateButton() throws Exception{ 
return sfdc.Button("Translate"); 
} 
public MemberOfButton PublishtoNewTargetsButton() throws Exception{ 
return sfdc.Button("Publish to New Targets"); 
} 
public MemberOfButton NewSurveyTargetButton() throws Exception{ 
return sfdc.Button("New Survey Target"); 
} 
public MemberOfButton DeleteSelected0Button() throws Exception{ 
return sfdc.Button("Delete Selected (0)"); 
} 
public MemberOfButton OKButton() throws Exception{ 
return sfdc.Button("OK"); 
} 
public MemberOfButton CancelButton() throws Exception{ 
return sfdc.Button("Cancel"); 
} 
public MemberOfButton AddSelected0Button() throws Exception{ 
return sfdc.Button("Add Selected (0)"); 
}
public MemberOfButton ContinueButton() throws Exception{ 
return sfdc.Button("Continue"); 
} 
public MemberOfButton SelectTerritoriesButton() throws Exception{ 
return sfdc.Button("Select Territories"); 
} 
public MemberOfButton InsertSelectedButton() throws Exception{ 
return sfdc.Button("Insert Selected"); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton NewSurveyQuestionButton() throws Exception{ 
return sfdc.Button("New Survey Question"); 
} 
//************************* Functions for Field Names ***************************** // 
 
public MemberOfField SurveyNameField() throws Exception{ 
	return sfdc.Field("Survey Name"); 
} 
public MemberOfField StatusField() throws Exception{ 
	return sfdc.Field("Status"); 
} 
public MemberOfField ExternalIDField() throws Exception{ 
	return sfdc.Field("External ID"); 
} 
public MemberOfField OwnerField() throws Exception{ 
	return sfdc.Field("Owner"); 
} 
public MemberOfField RecordTypeField() throws Exception{ 
	return sfdc.Field("Record Type"); 
} 
public MemberOfField ChannelsField() throws Exception{ 
	return sfdc.Field("Channels"); 
} 
public MemberOfField RecordTypeofnewrecordField() throws Exception{ 
	return sfdc.Field("Record Type of new record"); 
}
public MemberOfField StartDateField() throws Exception{ 
	return sfdc.Field("Start Date"); 
} 
public MemberOfField LanguageField() throws Exception{ 
	return sfdc.Field("Language"); 
} 
public MemberOfField EndDateField() throws Exception{ 
	return sfdc.Field("End Date"); 
} 
public MemberOfField CountryCodeField() throws Exception{ 
	return sfdc.Field("Country Code"); 
} 
public MemberOfField COISurveyField() throws Exception{ 
	return sfdc.Field("COI Survey"); 
} 
public MemberOfField FCPASurveyField() throws Exception{ 
	return sfdc.Field("FCPA Survey"); 
} 
public MemberOfField AssignmentTypeField() throws Exception{ 
	return sfdc.Field("Assignment Type"); 
} 
public MemberOfField AllowuserstochoosetargetsField() throws Exception{ 
	return sfdc.Field("Allow users to choose targets?"); 
} 
public MemberOfField ProductField() throws Exception{ 
	return sfdc.Field("Product"); 
} 
public MemberOfField IncludeduserterritoriesField() throws Exception{ 
	return sfdc.Field("Included user territories:"); 
} 
public MemberOfField AccountTypesField() throws Exception{ 
	return sfdc.Field("Account Types"); 
} 
public MemberOfField CreatedByField() throws Exception{ 
	return sfdc.Field("Created By"); 
} 
public MemberOfField LastModifiedByField() throws Exception{ 
	return sfdc.Field("Last Modified By"); 
} 


//************************* Functions for Section Name***************************** // 
 
//************************* Functions for Related List***************************** // 
 


 public Columns_SurveyDetail RL_SurveyDetail() throws Exception{ 
return new Columns_SurveyDetail("Survey Detail"); 
} 
public class Columns_SurveyDetail{ 
Columns_SurveyDetail(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_Information RL_Information() throws Exception{ 
return new Columns_Information("Information"); 
} 
public class Columns_Information{ 
Columns_Information(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_AssignmentRules RL_AssignmentRules() throws Exception{ 
return new Columns_AssignmentRules("Assignment Rules"); 
} 
public class Columns_AssignmentRules{ 
Columns_AssignmentRules(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_SystemInformation RL_SystemInformation() throws Exception{ 
return new Columns_SystemInformation("System Information"); 
} 
public class Columns_SystemInformation{ 
Columns_SystemInformation(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_SurveyQuestions RL_SurveyQuestions() throws Exception{ 
return new Columns_SurveyQuestions("Survey Questions"); 
} 
public class Columns_SurveyQuestions{ 
Columns_SurveyQuestions(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_Segment010 RL_Segment010() throws Exception{ 
return new Columns_Segment010("Segment (0/10)"); 
} 
public class Columns_Segment010{ 
Columns_Segment010(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_SurveyTargets RL_SurveyTargets() throws Exception{ 
return new Columns_SurveyTargets("Survey Targets"); 
} 
public class Columns_SurveyTargets{ 
Columns_SurveyTargets(String RL) 
{ 
RList = RL; 
} 

}

}

