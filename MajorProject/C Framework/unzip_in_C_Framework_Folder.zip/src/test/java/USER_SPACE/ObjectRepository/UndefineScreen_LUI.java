package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class UndefineScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public UndefineScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public UndefineScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI SearchappsoritemsField() throws Exception{  
return sfdc.Field_LUI("Search apps or items..."); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 // ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveNewButton() throws Exception{ 
return sfdc.Button_LUI("Save & New"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
//************************* Functions for All Apps ***************************** // 
 
public MemberOfAllApps_LUI ServiceApp() throws Exception{ 
return sfdc.AllApps_LUI("Service"); 
} 
public MemberOfAllApps_LUI MarketingCRMClassicApp() throws Exception{ 
return sfdc.AllApps_LUI("Marketing CRM Classic"); 
} 
public MemberOfAllApps_LUI CommunityApp() throws Exception{ 
return sfdc.AllApps_LUI("Community"); 
} 
public MemberOfAllApps_LUI SalesforceChatterApp() throws Exception{ 
return sfdc.AllApps_LUI("Salesforce Chatter"); 
} 
public MemberOfAllApps_LUI ContentApp() throws Exception{ 
return sfdc.AllApps_LUI("Content"); 
} 
public MemberOfAllApps_LUI SalesConsoleApp() throws Exception{ 
return sfdc.AllApps_LUI("Sales Console"); 
} 
public MemberOfAllApps_LUI ServiceConsoleApp() throws Exception{ 
return sfdc.AllApps_LUI("Service Console"); 
} 
public MemberOfAllApps_LUI SalesApp() throws Exception{ 
return sfdc.AllApps_LUI("Sales"); 
} 
public MemberOfAllApps_LUI LightningUsageAppApp() throws Exception{ 
return sfdc.AllApps_LUI("Lightning Usage App"); 
} 
public MemberOfAllApps_LUI DigitalExperiencesApp() throws Exception{ 
return sfdc.AllApps_LUI("Digital Experiences"); 
} 
public MemberOfAllApps_LUI SalesforceSchedulerSetupApp() throws Exception{ 
return sfdc.AllApps_LUI("Salesforce Scheduler Setup"); 
} 
public MemberOfAllApps_LUI BoltSolutionsApp() throws Exception{ 
return sfdc.AllApps_LUI("Bolt Solutions"); 
} 
public MemberOfAllApps_LUI GenCLearningMyAppApp() throws Exception{ 
return sfdc.AllApps_LUI("GenC Learning MyApp"); 
} 
public MemberOfAllApps_LUI CommerceApp() throws Exception{ 
return sfdc.AllApps_LUI("Commerce"); 
} 
//************************* Functions for Tabs List ***************************** // 
 
public MemberOfTab_LUI AccountsTab() throws Exception{ 
return sfdc.Tab_LUI("Accounts"); 
} 
public MemberOfTab_LUI AlternativePaymentMethodsTab() throws Exception{ 
return sfdc.Tab_LUI("Alternative Payment Methods"); 
} 
public MemberOfTab_LUI AnalyticsTab() throws Exception{ 
return sfdc.Tab_LUI("Analytics"); 
} 
public MemberOfTab_LUI AppLauncherTab() throws Exception{ 
return sfdc.Tab_LUI("App Launcher"); 
} 
public MemberOfTab_LUI AppointmentCategoriesTab() throws Exception{ 
return sfdc.Tab_LUI("Appointment Categories"); 
} 
public MemberOfTab_LUI AppointmentInvitationsTab() throws Exception{ 
return sfdc.Tab_LUI("Appointment Invitations"); 
} 
public MemberOfTab_LUI ApprovalRequestsTab() throws Exception{ 
return sfdc.Tab_LUI("Approval Requests"); 
} 
public MemberOfTab_LUI AssetActionSourcesTab() throws Exception{ 
return sfdc.Tab_LUI("Asset Action Sources"); 
} 
public MemberOfTab_LUI AssetActionsTab() throws Exception{ 
return sfdc.Tab_LUI("Asset Actions"); 
} 
public MemberOfTab_LUI AssetStatePeriodsTab() throws Exception{ 
return sfdc.Tab_LUI("Asset State Periods"); 
} 
public MemberOfTab_LUI AssetsTab() throws Exception{ 
return sfdc.Tab_LUI("Assets"); 
} 
public MemberOfTab_LUI AsyncOperationLogsTab() throws Exception{ 
return sfdc.Tab_LUI("Async Operation Logs"); 
} 
public MemberOfTab_LUI AuthorizationFormTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form"); 
} 
public MemberOfTab_LUI AuthorizationFormConsentTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form Consent"); 
} 
public MemberOfTab_LUI AuthorizationFormDataUseTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form Data Use"); 
} 
public MemberOfTab_LUI AuthorizationFormTextTab() throws Exception{ 
return sfdc.Tab_LUI("Authorization Form Text"); 
} 
public MemberOfTab_LUI BackgroundOperationsTab() throws Exception{ 
return sfdc.Tab_LUI("Background Operations"); 
} 
public MemberOfTab_LUI BusinessBrandsTab() throws Exception{ 
return sfdc.Tab_LUI("Business Brands"); 
} 
public MemberOfTab_LUI CalendarTab() throws Exception{ 
return sfdc.Tab_LUI("Calendar"); 
} 
public MemberOfTab_LUI CampaignsTab() throws Exception{ 
return sfdc.Tab_LUI("Campaigns"); 
} 
public MemberOfTab_LUI CardPaymentMethodsTab() throws Exception{ 
return sfdc.Tab_LUI("Card Payment Methods"); 
} 
public MemberOfTab_LUI CasesTab() throws Exception{ 
return sfdc.Tab_LUI("Cases"); 
} 
public MemberOfTab_LUI CatalogsTab() throws Exception{ 
return sfdc.Tab_LUI("Catalogs"); 
} 
public MemberOfTab_LUI CategoriesTab() throws Exception{ 
return sfdc.Tab_LUI("Categories"); 
} 
public MemberOfTab_LUI ChangeRequestsTab() throws Exception{ 
return sfdc.Tab_LUI("Change Requests"); 
} 
public MemberOfTab_LUI ChatterTab() throws Exception{ 
return sfdc.Tab_LUI("Chatter"); 
} 
public MemberOfTab_LUI CommunicationSubscriptionChannelTypesTab() throws Exception{ 
return sfdc.Tab_LUI("Communication Subscription Channel Types"); 
} 
public MemberOfTab_LUI CommunicationSubscriptionConsentsTab() throws Exception{ 
return sfdc.Tab_LUI("Communication Subscription Consents"); 
} 
public MemberOfTab_LUI CommunicationSubscriptionTimingsTab() throws Exception{ 
return sfdc.Tab_LUI("Communication Subscription Timings"); 
} 
public MemberOfTab_LUI CommunicationSubscriptionsTab() throws Exception{ 
return sfdc.Tab_LUI("Communication Subscriptions"); 
} 
public MemberOfTab_LUI ConsumptionSchedulesTab() throws Exception{ 
return sfdc.Tab_LUI("Consumption Schedules"); 
} 
public MemberOfTab_LUI ContactPointConsentTab() throws Exception{ 
return sfdc.Tab_LUI("Contact Point Consent"); 
} 
public MemberOfTab_LUI ContactPointTypeConsentTab() throws Exception{ 
return sfdc.Tab_LUI("Contact Point Type Consent"); 
} 
public MemberOfTab_LUI ContactRequestsTab() throws Exception{ 
return sfdc.Tab_LUI("Contact Requests"); 
} 
public MemberOfTab_LUI ContactsTab() throws Exception{ 
return sfdc.Tab_LUI("Contacts"); 
} 
public MemberOfTab_LUI ContentTab() throws Exception{ 
return sfdc.Tab_LUI("Content"); 
} 
public MemberOfTab_LUI ContractLineItemsTab() throws Exception{ 
return sfdc.Tab_LUI("Contract Line Items"); 
} 
public MemberOfTab_LUI ContractsTab() throws Exception{ 
return sfdc.Tab_LUI("Contracts"); 
} 
public MemberOfTab_LUI CouponsTab() throws Exception{ 
return sfdc.Tab_LUI("Coupons"); 
} 
public MemberOfTab_LUI CreditMemosTab() throws Exception{ 
return sfdc.Tab_LUI("Credit Memos"); 
} 
public MemberOfTab_LUI CustomersTab() throws Exception{ 
return sfdc.Tab_LUI("Customers"); 
} 
public MemberOfTab_LUI DashboardsTab() throws Exception{ 
return sfdc.Tab_LUI("Dashboards"); 
} 
public MemberOfTab_LUI DataUseLegalBasisTab() throws Exception{ 
return sfdc.Tab_LUI("Data Use Legal Basis"); 
} 
public MemberOfTab_LUI DataUsePurposeTab() throws Exception{ 
return sfdc.Tab_LUI("Data Use Purpose"); 
} 
public MemberOfTab_LUI DigitalExperiencesHomeTab() throws Exception{ 
return sfdc.Tab_LUI("Digital Experiences Home"); 
} 
public MemberOfTab_LUI DigitalWalletsTab() throws Exception{ 
return sfdc.Tab_LUI("Digital Wallets"); 
} 
public MemberOfTab_LUI DuplicateRecordSetsTab() throws Exception{ 
return sfdc.Tab_LUI("Duplicate Record Sets"); 
} 
public MemberOfTab_LUI EmailTemplatesTab() throws Exception{ 
return sfdc.Tab_LUI("Email Templates"); 
} 
public MemberOfTab_LUI EngagementChannelTypesTab() throws Exception{ 
return sfdc.Tab_LUI("Engagement Channel Types"); 
} 
public MemberOfTab_LUI EnhancedLetterheadsTab() throws Exception{ 
return sfdc.Tab_LUI("Enhanced Letterheads"); 
} 
public MemberOfTab_LUI EntitlementsTab() throws Exception{ 
return sfdc.Tab_LUI("Entitlements"); 
} 
public MemberOfTab_LUI FilesTab() throws Exception{ 
return sfdc.Tab_LUI("Files"); 
} 
public MemberOfTab_LUI FinanceBalanceSnapshotsTab() throws Exception{ 
return sfdc.Tab_LUI("Finance Balance Snapshots"); 
} 
public MemberOfTab_LUI FinanceTransactionsTab() throws Exception{ 
return sfdc.Tab_LUI("Finance Transactions"); 
} 
public MemberOfTab_LUI ForecastsTab() throws Exception{ 
return sfdc.Tab_LUI("Forecasts"); 
} 
public MemberOfTab_LUI FulfillmentOrdersTab() throws Exception{ 
return sfdc.Tab_LUI("Fulfillment Orders"); 
} 
public MemberOfTab_LUI GroupsTab() throws Exception{ 
return sfdc.Tab_LUI("Groups"); 
} 
public MemberOfTab_LUI HomeTab() throws Exception{ 
return sfdc.Tab_LUI("Home"); 
} 
public MemberOfTab_LUI ImagesTab() throws Exception{ 
return sfdc.Tab_LUI("Images"); 
} 
public MemberOfTab_LUI IncidentsTab() throws Exception{ 
return sfdc.Tab_LUI("Incidents"); 
} 
public MemberOfTab_LUI IndividualsTab() throws Exception{ 
return sfdc.Tab_LUI("Individuals"); 
} 
public MemberOfTab_LUI InventoryItemReservationsTab() throws Exception{ 
return sfdc.Tab_LUI("Inventory Item Reservations"); 
} 
public MemberOfTab_LUI InventoryReservationsTab() throws Exception{ 
return sfdc.Tab_LUI("Inventory Reservations"); 
} 
public MemberOfTab_LUI InvoicesTab() throws Exception{ 
return sfdc.Tab_LUI("Invoices"); 
} 
public MemberOfTab_LUI KnowledgeTab() throws Exception{ 
return sfdc.Tab_LUI("Knowledge"); 
} 
public MemberOfTab_LUI LeadsTab() throws Exception{ 
return sfdc.Tab_LUI("Leads"); 
} 
public MemberOfTab_LUI LearningTab() throws Exception{ 
return sfdc.Tab_LUI("Learning"); 
} 
public MemberOfTab_LUI LegalEntitiesTab() throws Exception{ 
return sfdc.Tab_LUI("Legal Entities"); 
} 
public MemberOfTab_LUI LightningBoltSolutionsTab() throws Exception{ 
return sfdc.Tab_LUI("Lightning Bolt Solutions"); 
} 
public MemberOfTab_LUI LightningUsageTab() throws Exception{ 
return sfdc.Tab_LUI("Lightning Usage"); 
} 
public MemberOfTab_LUI ListEmailsTab() throws Exception{ 
return sfdc.Tab_LUI("List Emails"); 
} 
public MemberOfTab_LUI LocationGroupsTab() throws Exception{ 
return sfdc.Tab_LUI("Location Groups"); 
} 
public MemberOfTab_LUI LocationsTab() throws Exception{ 
return sfdc.Tab_LUI("Locations"); 
} 
public MemberOfTab_LUI MacrosTab() throws Exception{ 
return sfdc.Tab_LUI("Macros"); 
} 
public MemberOfTab_LUI MessagingSessionsTab() throws Exception{ 
return sfdc.Tab_LUI("Messaging Sessions"); 
} 
public MemberOfTab_LUI MessagingUsersTab() throws Exception{ 
return sfdc.Tab_LUI("Messaging Users"); 
} 
public MemberOfTab_LUI MyLightningPageTab() throws Exception{ 
return sfdc.Tab_LUI("MyLightningPage"); 
} 
public MemberOfTab_LUI MyObjectsTab() throws Exception{ 
return sfdc.Tab_LUI("MyObjects"); 
} 
public MemberOfTab_LUI OperatingHoursTab() throws Exception{ 
return sfdc.Tab_LUI("Operating Hours"); 
} 
public MemberOfTab_LUI OpportunitiesTab() throws Exception{ 
return sfdc.Tab_LUI("Opportunities"); 
} 
public MemberOfTab_LUI OrchestrationRunsTab() throws Exception{ 
return sfdc.Tab_LUI("Orchestration Runs"); 
} 
public MemberOfTab_LUI OrchestrationWorkItemsTab() throws Exception{ 
return sfdc.Tab_LUI("Orchestration Work Items"); 
} 
public MemberOfTab_LUI OrdersTab() throws Exception{ 
return sfdc.Tab_LUI("Orders"); 
} 
public MemberOfTab_LUI OrgMetricsTab() throws Exception{ 
return sfdc.Tab_LUI("Org Metrics"); 
} 
public MemberOfTab_LUI PartyConsentTab() throws Exception{ 
return sfdc.Tab_LUI("Party Consent"); 
} 
public MemberOfTab_LUI PaymentAuthorizationAdjustmentsTab() throws Exception{ 
return sfdc.Tab_LUI("Payment Authorization Adjustments"); 
} 
public MemberOfTab_LUI PaymentAuthorizationsTab() throws Exception{ 
return sfdc.Tab_LUI("Payment Authorizations"); 
} 
public MemberOfTab_LUI PaymentGatewayLogsTab() throws Exception{ 
return sfdc.Tab_LUI("Payment Gateway Logs"); 
} 
public MemberOfTab_LUI PaymentGatewaysTab() throws Exception{ 
return sfdc.Tab_LUI("Payment Gateways"); 
} 
public MemberOfTab_LUI PaymentLineInvoicesTab() throws Exception{ 
return sfdc.Tab_LUI("Payment Line Invoices"); 
} 
public MemberOfTab_LUI PaymentsTab() throws Exception{ 
return sfdc.Tab_LUI("Payments"); 
} 
public MemberOfTab_LUI PeopleTab() throws Exception{ 
return sfdc.Tab_LUI("People"); 
} 
public MemberOfTab_LUI PriceBooksTab() throws Exception{ 
return sfdc.Tab_LUI("Price Books"); 
} 
public MemberOfTab_LUI ProblemsTab() throws Exception{ 
return sfdc.Tab_LUI("Problems"); 
} 
public MemberOfTab_LUI ProcessExceptionsTab() throws Exception{ 
return sfdc.Tab_LUI("Process Exceptions"); 
} 
public MemberOfTab_LUI ProductsTab() throws Exception{ 
return sfdc.Tab_LUI("Products"); 
} 
public MemberOfTab_LUI PromotionSegmentsTab() throws Exception{ 
return sfdc.Tab_LUI("Promotion Segments"); 
} 
public MemberOfTab_LUI PromotionWorkspaceTab() throws Exception{ 
return sfdc.Tab_LUI("Promotion Workspace"); 
} 
public MemberOfTab_LUI QuickTextTab() throws Exception{ 
return sfdc.Tab_LUI("Quick Text"); 
} 
public MemberOfTab_LUI QuotesTab() throws Exception{ 
return sfdc.Tab_LUI("Quotes"); 
} 
public MemberOfTab_LUI RecommendationsTab() throws Exception{ 
return sfdc.Tab_LUI("Recommendations"); 
} 
public MemberOfTab_LUI RecycleBinTab() throws Exception{ 
return sfdc.Tab_LUI("Recycle Bin"); 
} 
public MemberOfTab_LUI RefundLinePaymentsTab() throws Exception{ 
return sfdc.Tab_LUI("Refund Line Payments"); 
} 
public MemberOfTab_LUI RefundsTab() throws Exception{ 
return sfdc.Tab_LUI("Refunds"); 
} 
public MemberOfTab_LUI ReportsTab() throws Exception{ 
return sfdc.Tab_LUI("Reports"); 
} 
public MemberOfTab_LUI ReturnOrdersTab() throws Exception{ 
return sfdc.Tab_LUI("Return Orders"); 
} 
public MemberOfTab_LUI SalesforceSchedulerSetupAssistantTab() throws Exception{ 
return sfdc.Tab_LUI("Salesforce Scheduler Setup Assistant"); 
} 
public MemberOfTab_LUI ScorecardsTab() throws Exception{ 
return sfdc.Tab_LUI("Scorecards"); 
} 
public MemberOfTab_LUI SellersTab() throws Exception{ 
return sfdc.Tab_LUI("Sellers"); 
} 
public MemberOfTab_LUI ServiceAppointmentsTab() throws Exception{ 
return sfdc.Tab_LUI("Service Appointments"); 
} 
public MemberOfTab_LUI ServiceContractsTab() throws Exception{ 
return sfdc.Tab_LUI("Service Contracts"); 
} 
public MemberOfTab_LUI ServiceResourcesTab() throws Exception{ 
return sfdc.Tab_LUI("Service Resources"); 
} 
public MemberOfTab_LUI ServiceTerritoriesTab() throws Exception{ 
return sfdc.Tab_LUI("Service Territories"); 
} 
public MemberOfTab_LUI ShiftsTab() throws Exception{ 
return sfdc.Tab_LUI("Shifts"); 
} 
public MemberOfTab_LUI StreamingChannelsTab() throws Exception{ 
return sfdc.Tab_LUI("Streaming Channels"); 
} 
public MemberOfTab_LUI TasksTab() throws Exception{ 
return sfdc.Tab_LUI("Tasks"); 
} 
public MemberOfTab_LUI UserProvisioningRequestsTab() throws Exception{ 
return sfdc.Tab_LUI("User Provisioning Requests"); 
} 
public MemberOfTab_LUI VoiceCallsTab() throws Exception{ 
return sfdc.Tab_LUI("Voice Calls"); 
} 
public MemberOfTab_LUI WaitlistsTab() throws Exception{ 
return sfdc.Tab_LUI("Waitlists"); 
} 
public MemberOfTab_LUI WebStoreInventorySourcesTab() throws Exception{ 
return sfdc.Tab_LUI("Web Store Inventory Sources"); 
} 
public MemberOfTab_LUI WorkOrdersTab() throws Exception{ 
return sfdc.Tab_LUI("Work Orders"); 
} 
public MemberOfTab_LUI WorkPlanTemplatesTab() throws Exception{ 
return sfdc.Tab_LUI("Work Plan Templates"); 
} 
public MemberOfTab_LUI WorkPlansTab() throws Exception{ 
return sfdc.Tab_LUI("Work Plans"); 
} 
public MemberOfTab_LUI WorkStepTemplatesTab() throws Exception{ 
return sfdc.Tab_LUI("Work Step Templates"); 
} 
public MemberOfTab_LUI WorkTypeGroupsTab() throws Exception{ 
return sfdc.Tab_LUI("Work Type Groups"); 
} 
public MemberOfTab_LUI WorkTypesTab() throws Exception{ 
return sfdc.Tab_LUI("Work Types"); 
} 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI SearchSetup_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Setup"); 
} 
public MemberOfHealthCloud_LUI Searchappsoritems_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search apps or items..."); 
} 
public MemberOfHealthCloud_LUI Searchthislist_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search this list..."); 
} 
public MemberOfHealthCloud_LUI Rating_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Rating"); 
} 
public MemberOfHealthCloud_LUI AccountName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Account Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI Phone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Phone"); 
} 
public MemberOfHealthCloud_LUI ParentAccount_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Parent Account"); 
} 
public MemberOfHealthCloud_LUI Fax_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Fax"); 
} 
public MemberOfHealthCloud_LUI AccountNumber_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Account Number"); 
} 
public MemberOfHealthCloud_LUI Website_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Website"); 
} 
public MemberOfHealthCloud_LUI AccountSite_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Account Site"); 
} 
public MemberOfHealthCloud_LUI TickerSymbol_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Ticker Symbol"); 
} 
public MemberOfHealthCloud_LUI Type_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Type"); 
} 
public MemberOfHealthCloud_LUI Ownership_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Ownership"); 
} 
public MemberOfHealthCloud_LUI Industry_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Industry"); 
} 
public MemberOfHealthCloud_LUI Employees_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Employees"); 
} 
public MemberOfHealthCloud_LUI AnnualRevenue_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Annual Revenue"); 
} 
public MemberOfHealthCloud_LUI SICCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SIC Code"); 
} 
public MemberOfHealthCloud_LUI BillingStreet_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Billing Street"); 
} 
public MemberOfHealthCloud_LUI BillingCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Billing City"); 
} 
public MemberOfHealthCloud_LUI BillingZipPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Billing Zip/Postal Code"); 
} 
public MemberOfHealthCloud_LUI BillingStateProvince_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Billing State/Province"); 
} 
public MemberOfHealthCloud_LUI BillingCountry_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Billing Country"); 
} 
public MemberOfHealthCloud_LUI ShippingStreet_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Shipping Street"); 
} 
public MemberOfHealthCloud_LUI ShippingCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Shipping City"); 
} 
public MemberOfHealthCloud_LUI ShippingZipPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Shipping Zip/Postal Code"); 
} 
public MemberOfHealthCloud_LUI ShippingStateProvince_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Shipping State/Province"); 
} 
public MemberOfHealthCloud_LUI ShippingCountry_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Shipping Country"); 
} 
public MemberOfHealthCloud_LUI CustomerPriority_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Customer Priority"); 
} 
public MemberOfHealthCloud_LUI SLA_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SLA"); 
} 
public MemberOfHealthCloud_LUI SLAExpirationDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SLA Expiration Date"); 
} 
public MemberOfHealthCloud_LUI SLASerialNumber_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SLA Serial Number"); 
} 
public MemberOfHealthCloud_LUI NumberofLocations_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Number of Locations"); 
} 
public MemberOfHealthCloud_LUI UpsellOpportunity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Upsell Opportunity"); 
} 
public MemberOfHealthCloud_LUI Active_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Active"); 
} 
public MemberOfHealthCloud_LUI Description_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Description"); 
} 
//************************* Functions for HC Button ***************************** // 
 
public MemberOfHealthCloud_LUI Save_HealthCloudButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Save"); 
} 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
