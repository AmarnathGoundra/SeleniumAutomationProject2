package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class CampaignsScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public CampaignsScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public CampaignsScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI CampaignOwnerField() throws Exception{  
return sfdc.Field_LUI("Campaign Owner"); 
} 
 
public MemberOfField_LUI LeadsinCampaignField() throws Exception{  
return sfdc.Field_LUI("Leads in Campaign"); 
} 
 
public MemberOfField_LUI CampaignNameField() throws Exception{  
return sfdc.Field_LUI("Campaign Name"); 
} 
 
public MemberOfField_LUI ConvertedLeadsinCampaignField() throws Exception{  
return sfdc.Field_LUI("Converted Leads in Campaign"); 
} 
 
public MemberOfField_LUI ActiveField() throws Exception{  
return sfdc.Field_LUI("Active"); 
} 
 
public MemberOfField_LUI ContactsinCampaignField() throws Exception{  
return sfdc.Field_LUI("Contacts in Campaign"); 
} 
 
public MemberOfField_LUI TypeField() throws Exception{  
return sfdc.Field_LUI("Type"); 
} 
 
public MemberOfField_LUI ResponsesinCampaignField() throws Exception{  
return sfdc.Field_LUI("Responses in Campaign"); 
} 
 
public MemberOfField_LUI StatusField() throws Exception{  
return sfdc.Field_LUI("Status"); 
} 
 
public MemberOfField_LUI OpportunitiesinCampaignField() throws Exception{  
return sfdc.Field_LUI("Opportunities in Campaign"); 
} 
 
public MemberOfField_LUI StartDateField() throws Exception{  
return sfdc.Field_LUI("Start Date"); 
} 
 
public MemberOfField_LUI WonOpportunitiesinCampaignField() throws Exception{  
return sfdc.Field_LUI("Won Opportunities in Campaign"); 
} 
 
public MemberOfField_LUI EndDateField() throws Exception{  
return sfdc.Field_LUI("End Date"); 
} 
 
public MemberOfField_LUI ValueOpportunitiesinCampaignField() throws Exception{  
return sfdc.Field_LUI("Value Opportunities in Campaign"); 
} 
 
public MemberOfField_LUI ExpectedRevenueinCampaignField() throws Exception{  
return sfdc.Field_LUI("Expected Revenue in Campaign"); 
} 
 
public MemberOfField_LUI ValueWonOpportunitiesinCampaignField() throws Exception{  
return sfdc.Field_LUI("Value Won Opportunities in Campaign"); 
} 
 
public MemberOfField_LUI BudgetedCostinCampaignField() throws Exception{  
return sfdc.Field_LUI("Budgeted Cost in Campaign"); 
} 
 
public MemberOfField_LUI ActualCostinCampaignField() throws Exception{  
return sfdc.Field_LUI("Actual Cost in Campaign"); 
} 
 
public MemberOfField_LUI ExpectedResponseField() throws Exception{  
return sfdc.Field_LUI("Expected Response (%)"); 
} 
 
public MemberOfField_LUI NumSentinCampaignField() throws Exception{  
return sfdc.Field_LUI("Num Sent in Campaign"); 
} 
 
public MemberOfField_LUI ParentCampaignField() throws Exception{  
return sfdc.Field_LUI("Parent Campaign"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 public Columns_Campaigns LV_Campaigns() throws Exception{ 
return new Columns_Campaigns("Campaigns"); 
} 
public class Columns_Campaigns 
{ 
Columns_Campaigns(String RL) 
{ 
RList = RL;  
}  
public MemberOfLV_LUI CampaignName() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Campaign Name"); 
} 
public MemberOfLV_LUI CampaignName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Campaign Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI ParentCampaign() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Parent Campaign"); 
} 
public MemberOfLV_LUI ParentCampaign(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Parent Campaign",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Type() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Type"); 
} 
public MemberOfLV_LUI Type(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Type",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Status() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Status"); 
} 
public MemberOfLV_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfLV_LUI StartDate() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Start Date"); 
} 
public MemberOfLV_LUI StartDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Start Date",TargetCOlumnValue); 
} 
public MemberOfLV_LUI EndDate() throws Exception 
{ 
return sfdc.LV_LUI(RList,"End Date"); 
} 
public MemberOfLV_LUI EndDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"End Date",TargetCOlumnValue); 
} 
public MemberOfLV_LUI ResponsesinCampaign() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Responses in Campaign"); 
} 
public MemberOfLV_LUI ResponsesinCampaign(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Responses in Campaign",TargetCOlumnValue); 
} 
public MemberOfLV_LUI OwnerAlias() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner Alias"); 
} 
public MemberOfLV_LUI OwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Owner Alias",TargetCOlumnValue); 
} 
public MemberOfLV_LUI NewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"NewButton");  
} 
public MemberOfLV_LUI NewContactButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New ContactButton");  
} 
public MemberOfLV_LUI NewOpportunityButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New OpportunityButton");  
} 
public MemberOfLV_LUI NewCaseButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"New CaseButton");  
} 
public MemberOfLV_LUI MenuButtonNewLeadButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonNew LeadButton");  
} 
public MemberOfLV_LUI MenuButtonEditButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonEditButton");  
} 
public MemberOfLV_LUI MenuButtonDeleteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonDeleteButton");  
} 
public MemberOfLV_LUI MenuButtonCloneButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonCloneButton");  
} 
public MemberOfLV_LUI MenuButtonSubmitforApprovalButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonSubmit for ApprovalButton");  
} 
public MemberOfLV_LUI MenuButtonChangeOwnerButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonChange OwnerButton");  
} 
public MemberOfLV_LUI MenuButtonViewCampaignHierarchyButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonView Campaign HierarchyButton");  
} 
public MemberOfLV_LUI CancelButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"CancelButton");  
} 
public MemberOfLV_LUI SaveNewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"Save & NewButton");  
} 
public MemberOfLV_LUI SaveButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"SaveButton");  
} 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_CampaignHierarchy RL_CampaignHierarchy() throws Exception{ 
return new Columns_CampaignHierarchy("Campaign Hierarchy"); 
} 
public class Columns_CampaignHierarchy 
{ 
Columns_CampaignHierarchy(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_Attachments RL_Attachments() throws Exception{ 
return new Columns_Attachments("Attachments"); 
} 
public class Columns_Attachments 
{ 
Columns_Attachments(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CreatedBy() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By"); 
} 
public MemberOfRL_LUI CreatedBy(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Created By",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ContentSize() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Content Size"); 
} 
public MemberOfRL_LUI ContentSize(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Content Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI UploadFilesButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Upload FilesButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_Opportunities RL_Opportunities() throws Exception{ 
return new Columns_Opportunities("Opportunities"); 
} 
public class Columns_Opportunities 
{ 
Columns_Opportunities(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI OpportunityName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name"); 
} 
public MemberOfRL_LUI OpportunityName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Stage() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage"); 
} 
public MemberOfRL_LUI Stage(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Amount() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Amount"); 
} 
public MemberOfRL_LUI Amount(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Amount",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CloseDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date"); 
} 
public MemberOfRL_LUI CloseDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI NewButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"NewButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_CampaignMembers RL_CampaignMembers() throws Exception{ 
return new Columns_CampaignMembers("Campaign Members"); 
} 
public class Columns_CampaignMembers 
{ 
Columns_CampaignMembers(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Type() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Type"); 
} 
public MemberOfRL_LUI Type(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI FirstName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"First Name"); 
} 
public MemberOfRL_LUI FirstName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"First Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Name"); 
} 
public MemberOfRL_LUI LastName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Company() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Company"); 
} 
public MemberOfRL_LUI Company(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Company",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AddLeadsButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Add LeadsButton");  
} 
public MemberOfRL_LUI AddContactsButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Add ContactsButton");  
} 
public MemberOfRL_LUI UpdateStatusButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Update StatusButton");  
} 
public MemberOfRL_LUI RemoveButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RemoveButton");  
} 
public MemberOfRL_LUI ManageCampaignMembersButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Manage Campaign MembersButton");  
} 
public MemberOfRL_LUI MenuImportLeadsandContactsButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"MenuImport Leads and ContactsButton");  
} 
public MemberOfRL_LUI MenuSendListEmailButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"MenuSend List EmailButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewButton() throws Exception{ 
return sfdc.Button_LUI("New"); 
} 
public MemberOfButton_LUI NewContactButton() throws Exception{ 
return sfdc.Button_LUI("New Contact"); 
} 
public MemberOfButton_LUI NewOpportunityButton() throws Exception{ 
return sfdc.Button_LUI("New Opportunity"); 
} 
public MemberOfButton_LUI NewCaseButton() throws Exception{ 
return sfdc.Button_LUI("New Case"); 
} 
public MemberOfButton_LUI MenuButtonNewLeadButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:New Lead"); 
} 
public MemberOfButton_LUI MenuButtonEditButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Edit"); 
} 
public MemberOfButton_LUI MenuButtonDeleteButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Delete"); 
} 
public MemberOfButton_LUI MenuButtonCloneButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Clone"); 
} 
public MemberOfButton_LUI MenuButtonSubmitforApprovalButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Submit for Approval"); 
} 
public MemberOfButton_LUI MenuButtonChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Change Owner"); 
} 
public MemberOfButton_LUI MenuButtonViewCampaignHierarchyButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:View Campaign Hierarchy"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveNewButton() throws Exception{ 
return sfdc.Button_LUI("Save & New"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
//************************* Functions for All Apps ***************************** // 
 
//************************* Functions for Tabs List ***************************** // 
 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Searchbyobjecttype_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search by object type"); 
} 
public MemberOfHealthCloud_LUI SearchCampaignsandmore_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Campaigns and more"); 
} 
public MemberOfHealthCloud_LUI Searchthislist_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search this list..."); 
} 
public MemberOfHealthCloud_LUI Search_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search..."); 
} 
public MemberOfHealthCloud_LUI CampaignName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Campaign Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI Active_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Active"); 
} 
public MemberOfHealthCloud_LUI StartDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Start Date"); 
} 
public MemberOfHealthCloud_LUI EndDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("End Date"); 
} 
public MemberOfHealthCloud_LUI ExpectedRevenueinCampaign_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Expected Revenue in Campaign"); 
} 
public MemberOfHealthCloud_LUI BudgetedCostinCampaign_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Budgeted Cost in Campaign"); 
} 
public MemberOfHealthCloud_LUI ActualCostinCampaign_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Actual Cost in Campaign"); 
} 
public MemberOfHealthCloud_LUI ExpectedResponse_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Expected Response (%)"); 
} 
public MemberOfHealthCloud_LUI NumSentinCampaign_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Num Sent in Campaign"); 
} 
public MemberOfHealthCloud_LUI ParentCampaign_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Parent Campaign"); 
} 
public MemberOfHealthCloud_LUI Description_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Description"); 
} 
//************************* Functions for HC Button ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
