package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class CurrentProductCatalog extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public CurrentProductCatalog(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public CurrentProductCatalog(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI BillingAccountField() throws Exception{  
return sfdc.Field_LUI("Billing Account"); 
} 
 
public MemberOfField_LUI BillingAddressField() throws Exception{  
return sfdc.Field_LUI("Billing Address"); 
} 
 
public MemberOfField_LUI QuantityField() throws Exception{  
return sfdc.Field_LUI("Quantity"); 
} 
 
public MemberOfField_LUI OnceOffRevenueField() throws Exception{  
return sfdc.Field_LUI("Once Off Revenue"); 
} 
 
public MemberOfField_LUI ProductField() throws Exception{  
return sfdc.Field_LUI("Product"); 
} 
 
public MemberOfField_LUI NewIncomeRevenueField() throws Exception{  
return sfdc.Field_LUI("New Income Revenue"); 
} 
 
public MemberOfField_LUI TermField() throws Exception{  
return sfdc.Field_LUI("Term"); 
} 
 
public MemberOfField_LUI RenewalRevenueField() throws Exception{  
return sfdc.Field_LUI("Renewal Revenue"); 
} 
 
public MemberOfField_LUI CompetitorField() throws Exception{  
return sfdc.Field_LUI("Competitor"); 
} 
 
public MemberOfField_LUI AcquisitionRevenueField() throws Exception{  
return sfdc.Field_LUI("Acquisition Revenue"); 
} 
 
public MemberOfField_LUI ChannelField() throws Exception{  
return sfdc.Field_LUI("Channel"); 
} 
 
public MemberOfField_LUI AvgAnnualisedRevenueField() throws Exception{  
return sfdc.Field_LUI("Avg Annualised Revenue"); 
} 
 
public MemberOfField_LUI PartnerField() throws Exception{  
return sfdc.Field_LUI("Partner"); 
} 
 
public MemberOfField_LUI IncrementalRevenueField() throws Exception{  
return sfdc.Field_LUI("Incremental Revenue"); 
} 
 
public MemberOfField_LUI WonLostField() throws Exception{  
return sfdc.Field_LUI("Won/Lost"); 
} 
 
public MemberOfField_LUI SRMField() throws Exception{  
return sfdc.Field_LUI("SRM"); 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_ManageProductsinBasket RL_ManageProductsinBasket() throws Exception{ 
return new Columns_ManageProductsinBasket("Manage Products in Basket"); 
} 
public class Columns_ManageProductsinBasket 
{ 
Columns_ManageProductsinBasket(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI OrderType() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Order Type"); 
} 
public MemberOfRL_LUI OrderType(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Order Type",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Domain() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Domain"); 
} 
public MemberOfRL_LUI Domain(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Domain",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Product() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product"); 
} 
public MemberOfRL_LUI Product(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product",TargetCOlumnValue); 
} 
public MemberOfRL_LUI SiteName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Site Name"); 
} 
public MemberOfRL_LUI SiteName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Site Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Quantity() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity"); 
} 
public MemberOfRL_LUI Quantity(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TotalOneoffAmount() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total One off Amount"); 
} 
public MemberOfRL_LUI TotalOneoffAmount(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total One off Amount",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TotalRecurringAmount() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total Recurring Amount"); 
} 
public MemberOfRL_LUI TotalRecurringAmount(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total Recurring Amount",TargetCOlumnValue); 
} 
public MemberOfRL_LUI TotalContractValue() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total Contract Value"); 
} 
public MemberOfRL_LUI TotalContractValue(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Total Contract Value",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Status() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status"); 
} 
public MemberOfRL_LUI Status(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Status",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI AddProductButton() throws Exception{ 
return sfdc.Button_LUI("Add Product"); 
} 
public MemberOfButton_LUI CopyProductButton() throws Exception{ 
return sfdc.Button_LUI("Copy Product"); 
} 
public MemberOfButton_LUI DeleteProductButton() throws Exception{ 
return sfdc.Button_LUI("Delete Product"); 
} 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI FinishButton() throws Exception{ 
return sfdc.Button_LUI("Finish"); 
} 
} 
 
