package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class AllTabsScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public AllTabsScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public AllTabsScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


public MemberOfTab AccountsTab() throws Exception{ 
	return sfdc.Tab("Accounts"); 
} 
public MemberOfTab ForecastsTab() throws Exception{ 
	return sfdc.Tab("Forecasts"); 
} 
public MemberOfTab AnalyticsTab() throws Exception{ 
	return sfdc.Tab("Analytics"); 
} 
public MemberOfTab GroupsTab() throws Exception{ 
	return sfdc.Tab("Groups"); 
} 
public MemberOfTab AppLauncherTab() throws Exception{ 
	return sfdc.Tab("App Launcher"); 
} 
public MemberOfTab HomeTab() throws Exception{ 
	return sfdc.Tab("Home"); 
} 
public MemberOfTab AssetsTab() throws Exception{ 
	return sfdc.Tab("Assets"); 
} 
public MemberOfTab IdeasTab() throws Exception{ 
	return sfdc.Tab("Ideas"); 
} 
public MemberOfTab AuthorizationFormTab() throws Exception{ 
	return sfdc.Tab("Authorization Form"); 
} 
public MemberOfTab ImagesTab() throws Exception{ 
	return sfdc.Tab("Images"); 
} 
public MemberOfTab AuthorizationFormConsentTab() throws Exception{ 
	return sfdc.Tab("Authorization Form Consent"); 
} 
public MemberOfTab LeadsTab() throws Exception{ 
	return sfdc.Tab("Leads"); 
} 
public MemberOfTab AuthorizationFormDataUseTab() throws Exception{ 
	return sfdc.Tab("Authorization Form Data Use"); 
} 
public MemberOfTab LibrariesTab() throws Exception{ 
	return sfdc.Tab("Libraries"); 
} 
public MemberOfTab AuthorizationFormTextTab() throws Exception{ 
	return sfdc.Tab("Authorization Form Text"); 
} 
public MemberOfTab ListEmailsTab() throws Exception{ 
	return sfdc.Tab("List Emails"); 
} 
public MemberOfTab CampaignsTab() throws Exception{ 
	return sfdc.Tab("Campaigns"); 
} 
public MemberOfTab TellmemoreTab() throws Exception{ 
	return sfdc.Tab("Tell me more!"); 
} 
public MemberOfTab MacrosTab() throws Exception{ 
	return sfdc.Tab("Macros"); 
} 
public MemberOfTab CasesTab() throws Exception{ 
	return sfdc.Tab("Cases"); 
} 
public MemberOfTab OpportunitiesTab() throws Exception{ 
	return sfdc.Tab("Opportunities"); 
} 
public MemberOfTab ChatterTab() throws Exception{ 
	return sfdc.Tab("Chatter"); 
} 
public MemberOfTab OrdersTab() throws Exception{ 
	return sfdc.Tab("Orders"); 
} 
public MemberOfTab ConsumptionSchedulesTab() throws Exception{ 
	return sfdc.Tab("Consumption Schedules"); 
} 
public MemberOfTab PeopleTab() throws Exception{ 
	return sfdc.Tab("People"); 
} 
public MemberOfTab ContactPointConsentTab() throws Exception{ 
	return sfdc.Tab("Contact Point Consent"); 
} 
public MemberOfTab PriceBooksTab() throws Exception{ 
	return sfdc.Tab("Price Books"); 
} 
public MemberOfTab ContactPointTypeConsentTab() throws Exception{ 
	return sfdc.Tab("Contact Point Type Consent"); 
} 
public MemberOfTab ProductsTab() throws Exception{ 
	return sfdc.Tab("Products"); 
} 
public MemberOfTab ContactRequestsTab() throws Exception{ 
	return sfdc.Tab("Contact Requests"); 
} 
public MemberOfTab ProfileTab() throws Exception{ 
	return sfdc.Tab("Profile"); 
} 
public MemberOfTab ContactsTab() throws Exception{ 
	return sfdc.Tab("Contacts"); 
} 
public MemberOfTab ProfileFeedTab() throws Exception{ 
	return sfdc.Tab("Profile Feed"); 
} 
public MemberOfTab ContentTab() throws Exception{ 
	return sfdc.Tab("Content"); 
} 
public MemberOfTab ProfileOverviewTab() throws Exception{ 
	return sfdc.Tab("Profile Overview"); 
} 
public MemberOfTab ContractsTab() throws Exception{ 
	return sfdc.Tab("Contracts"); 
} 
public MemberOfTab RecommendationsTab() throws Exception{ 
	return sfdc.Tab("Recommendations"); 
} 
public MemberOfTab DBCompaniesTab() throws Exception{ 
	return sfdc.Tab("D&B Companies"); 
} 
public MemberOfTab ReportsTab() throws Exception{ 
	return sfdc.Tab("Reports"); 
} 
public MemberOfTab DashboardsTab() throws Exception{ 
	return sfdc.Tab("Dashboards"); 
} 
public MemberOfTab ScorecardsTab() throws Exception{ 
	return sfdc.Tab("Scorecards"); 
} 
public MemberOfTab DatacomTab() throws Exception{ 
	return sfdc.Tab("Data.com"); 
} 
public MemberOfTab SitecomTab() throws Exception{ 
	return sfdc.Tab("Site.com"); 
} 
public MemberOfTab DataUseLegalBasisTab() throws Exception{ 
	return sfdc.Tab("Data Use Legal Basis"); 
} 
public MemberOfTab SolutionsTab() throws Exception{ 
	return sfdc.Tab("Solutions"); 
} 
public MemberOfTab DataUsePurposeTab() throws Exception{ 
	return sfdc.Tab("Data Use Purpose"); 
} 
public MemberOfTab StreamingChannelsTab() throws Exception{ 
	return sfdc.Tab("Streaming Channels"); 
} 
public MemberOfTab DocumentsTab() throws Exception{ 
	return sfdc.Tab("Documents"); 
} 
public MemberOfTab SubscriptionsTab() throws Exception{ 
	return sfdc.Tab("Subscriptions"); 
} 
public MemberOfTab DuplicateRecordSetsTab() throws Exception{ 
	return sfdc.Tab("Duplicate Record Sets"); 
} 
public MemberOfTab UserProvisioningRequestsTab() throws Exception{ 
	return sfdc.Tab("User Provisioning Requests"); 
} 
public MemberOfTab FilesTab() throws Exception{ 
	return sfdc.Tab("Files"); 
} 
//************************* Functions for List Views***************************** // 
 
//************************* Functions for Buttons***************************** // 
 
//************************* Functions for Field Names ***************************** // 
 
//************************* Functions for Section Name***************************** // 
 
//************************* Functions for Related List***************************** // 
 
}

