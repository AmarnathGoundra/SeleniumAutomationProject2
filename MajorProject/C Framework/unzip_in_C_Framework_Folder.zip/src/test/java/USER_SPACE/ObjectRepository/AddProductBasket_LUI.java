package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class AddProductBasket_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public AddProductBasket_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public AddProductBasket_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI BasketNameField() throws Exception{  
return sfdc.Field_LUI("Basket Name"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI OpportunityField() throws Exception{  
return sfdc.Field_LUI("Opportunity"); 
} 
 
public MemberOfField_LUI SynchronisedWithOpportunityField() throws Exception{  
return sfdc.Field_LUI("Synchronised With Opportunity"); 
} 
 
public MemberOfField_LUI BasketStatusField() throws Exception{  
return sfdc.Field_LUI("Basket Status"); 
} 
 
public MemberOfField_LUI BasketStageField() throws Exception{  
return sfdc.Field_LUI("Basket Stage"); 
} 
 
public MemberOfField_LUI CustomerField() throws Exception{  
return sfdc.Field_LUI("Customer"); 
} 
 
public MemberOfField_LUI TotalContractValueField() throws Exception{  
return sfdc.Field_LUI("Total Contract Value"); 
} 
 
public MemberOfField_LUI ProjectComplexityField() throws Exception{  
return sfdc.Field_LUI("Project Complexity"); 
} 
 
public MemberOfField_LUI PMRequiredField() throws Exception{  
return sfdc.Field_LUI("PM Required"); 
} 
 
public MemberOfField_LUI ProjectManagerContactNumberField() throws Exception{  
return sfdc.Field_LUI("Project Manager Contact Number"); 
} 
 
public MemberOfField_LUI ProjectIDField() throws Exception{  
return sfdc.Field_LUI("Project ID"); 
} 
 
public MemberOfField_LUI ProjectManagerUserIDField() throws Exception{  
return sfdc.Field_LUI("Project Manager User ID"); 
} 
 
public MemberOfField_LUI ProjectManagerEmailField() throws Exception{  
return sfdc.Field_LUI("Project Manager Email"); 
} 
 
public MemberOfField_LUI BillingAccountField() throws Exception{  
return sfdc.Field_LUI("Billing Account"); 
} 
 
public MemberOfField_LUI BillingAddressField() throws Exception{  
return sfdc.Field_LUI("Billing Address"); 
} 
 

 
 //************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
public MemberOfButton_LUI MultiLineEditorButton() throws Exception{ 
return sfdc.Button_LUI("Multi Line Editor"); 
} 
public MemberOfButton_LUI AddProductButton() throws Exception{ 
return sfdc.Button_LUI("Add Product"); 
} 
public MemberOfButton_LUI AddtoBasketButton() throws Exception{ 
return sfdc.Button_LUI("Add to Basket"); 
} 
public MemberOfButton_LUI SearchButton() throws Exception{ 
return sfdc.Button_LUI("Search"); 
} 
public MemberOfButton_LUI SelectButton() throws Exception{ 
return sfdc.Button_LUI("Select"); 
} 
} 
 
