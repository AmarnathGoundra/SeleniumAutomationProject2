package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver; 

import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class Patient_Enrolment_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public Patient_Enrolment_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
System.out.println("Constructor call from OR: PatientEnrolment - remoteDriver");
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public Patient_Enrolment_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
System.out.println("Constructor call from OR: PatientEnrolment - remoteDriver");
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI LeadOwnerField() throws Exception{  
return sfdc.Field_LUI("Lead Owner"); 
} 
 
public MemberOfField_LUI LeadStatusField() throws Exception{  
return sfdc.Field_LUI("Lead Status"); 
} 
 
public MemberOfField_LUI SSNIDField() throws Exception{  
return sfdc.Field_LUI("SSN ID"); 
} 
 
public MemberOfField_LUI VerifiedField() throws Exception{  
return sfdc.Field_LUI("Verified"); 
} 
 
public MemberOfField_LUI PatientcreationdateField() throws Exception{  
return sfdc.Field_LUI("Patient creation date"); 
} 
 
public MemberOfField_LUI NameField() throws Exception{  
return sfdc.Field_LUI("Name"); 
} 
 
public MemberOfField_LUI BirthDateField() throws Exception{  
return sfdc.Field_LUI("Birth Date"); 
} 
 
public MemberOfField_LUI GenderField() throws Exception{  
return sfdc.Field_LUI("Gender"); 
} 
 
public MemberOfField_LUI AddressLine1Field() throws Exception{  
return sfdc.Field_LUI("Address Line 1"); 
} 
 
public MemberOfField_LUI AddressLine2Field() throws Exception{  
return sfdc.Field_LUI("Address Line 2"); 
} 
 
public MemberOfField_LUI CityTownField() throws Exception{  
return sfdc.Field_LUI("City/Town"); 
} 
 
public MemberOfField_LUI PostcodeField() throws Exception{  
return sfdc.Field_LUI("Postcode"); 
} 
 
public MemberOfField_LUI CountryCodeField() throws Exception{  
return sfdc.Field_LUI("Country Code"); 
} 
 
public MemberOfField_LUI MainContactField() throws Exception{  
return sfdc.Field_LUI("Main Contact"); 
} 
 
public MemberOfField_LUI PhoneField() throws Exception{  
return sfdc.Field_LUI("Phone"); 
} 
 
public MemberOfField_LUI EmailField() throws Exception{  
return sfdc.Field_LUI("Email"); 
} 
 
public MemberOfField_LUI TitleField() throws Exception{  
return sfdc.Field_LUI("Title"); 
} 
 
public MemberOfField_LUI CarerAddressline1Field() throws Exception{  
return sfdc.Field_LUI("Carer Address line1"); 
} 
 
public MemberOfField_LUI CarerFirstNameField() throws Exception{  
return sfdc.Field_LUI("Carer First Name"); 
} 
 
public MemberOfField_LUI CarerAddressline2Field() throws Exception{  
return sfdc.Field_LUI("Carer Address line2"); 
} 
 
public MemberOfField_LUI CarerLastNameField() throws Exception{  
return sfdc.Field_LUI("Carer Last Name"); 
} 
 
public MemberOfField_LUI CarerCityField() throws Exception{  
return sfdc.Field_LUI("Carer City"); 
} 
 
public MemberOfField_LUI RelationshiptopatientField() throws Exception{  
return sfdc.Field_LUI("Relationship to patient"); 
} 
 
public MemberOfField_LUI CarerPostalCodeField() throws Exception{  
return sfdc.Field_LUI("Carer Postal Code"); 
} 
 
public MemberOfField_LUI CarerPhoneField() throws Exception{  
return sfdc.Field_LUI("Carer Phone"); 
} 
 
public MemberOfField_LUI CarerEmailField() throws Exception{  
return sfdc.Field_LUI("Carer Email"); 
} 
 
public MemberOfField_LUI TreatingCentreNameField() throws Exception{  
return sfdc.Field_LUI("Treating Centre Name"); 
} 
 
public MemberOfField_LUI ReferringCentreNameField() throws Exception{  
return sfdc.Field_LUI("Referring Centre Name"); 
} 
 
public MemberOfField_LUI TreatingSpecialistNameField() throws Exception{  
return sfdc.Field_LUI("Treating Specialist Name"); 
} 
 
public MemberOfField_LUI TreatingSpecialistEmailField() throws Exception{  
return sfdc.Field_LUI("Treating Specialist Email"); 
} 
 
public MemberOfField_LUI ReferringSpecialistNameField() throws Exception{  
return sfdc.Field_LUI("Referring Specialist Name"); 
} 
 
public MemberOfField_LUI DuodopastartdateField() throws Exception{  
return sfdc.Field_LUI("Duodopa start date"); 
} 
 
public MemberOfField_LUI TheurapeticAreaField() throws Exception{  
return sfdc.Field_LUI("Theurapetic Area"); 
} 
 
public MemberOfField_LUI PlannedproceduresField() throws Exception{  
return sfdc.Field_LUI("Planned procedure/s"); 
} 
 
public MemberOfField_LUI BrandField() throws Exception{  
return sfdc.Field_LUI("Brand"); 
} 
 
public MemberOfField_LUI HospitalAdmissionDateTimeField() throws Exception{  
return sfdc.Field_LUI("Hospital Admission Date & Time"); 
} 
 
public MemberOfField_LUI HospitaladmissiondateconfirmedField() throws Exception{  
return sfdc.Field_LUI("Hospital admission date confirmed?"); 
} 
 
public MemberOfField_LUI NJPlacementDateTimeField() throws Exception{  
return sfdc.Field_LUI("NJ Placement Date & Time"); 
} 
 
public MemberOfField_LUI NJStartDateConfirmedField() throws Exception{  
return sfdc.Field_LUI("NJ Start Date Confirmed ?"); 
} 
 
public MemberOfField_LUI PEGJPEJTPortPlacementDateTimeField() throws Exception{  
return sfdc.Field_LUI("PEG-J/PEJ/ T-Port Placement Date & Time"); 
} 
 
public MemberOfField_LUI PEGJStartDateConfirmedField() throws Exception{  
return sfdc.Field_LUI("PEG-J Start Date Confirmed ?"); 
} 
 
public MemberOfField_LUI ReasonfortheLateTitrationField() throws Exception{  
return sfdc.Field_LUI("Reason for the Late Titration"); 
} 
 
public MemberOfField_LUI TypeofFollowuptreatmentField() throws Exception{  
return sfdc.Field_LUI("Type of Follow up treatment"); 
} 
 
public MemberOfField_LUI HCPprivacystmtAlcuracancontactField() throws Exception{  
return sfdc.Field_LUI("HCP privacy stmt - Alcura can contact"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
public MemberOfField_LUI CompanyField() throws Exception{  
return sfdc.Field_LUI("Company"); 
} 
 
//Selection of Treatment center from dropdown
//public WebElement Treatment_Center = remoteDriver.findElement(By.xpath("//span[@id='listbox-option-unique-id-01']"));
// ************************ Functions and Classes for List Views ************************************** 
 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 

 
public MemberOfButton_LUI EditButton() throws Exception{ 
return sfdc.Button_LUI("Edit"); 
} 
public MemberOfButton_LUI DeleteButton() throws Exception{ 
return sfdc.Button_LUI("Delete"); 
} 
public MemberOfButton_LUI ChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("Change Owner"); 
} 
//************************* Functions for Health cloud Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Selectanobjecttolimityoursearch_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Select an object to limit your search"); 
} 
public MemberOfHealthCloud_LUI SearchSalesforce_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Search Salesforce"); 
} 
public MemberOfHealthCloud_LUI TreatingCentreName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Centre Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI TreatingCentreAddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Centre Address Line1"); 
} 
public MemberOfHealthCloud_LUI TreatingCentreAddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Centre Address Line2"); 
} 
public MemberOfHealthCloud_LUI TreatingCentreCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Centre City"); 
} 
public MemberOfHealthCloud_LUI TreatingCentrePostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Centre Postal Code"); 
} 
public MemberOfHealthCloud_LUI TreatingSpecialistName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Specialist Name"); 
} 
public MemberOfHealthCloud_LUI Title_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Title"); 
} 
public MemberOfHealthCloud_LUI TreatingSpecialistFirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Specialist First Name"); 
} 
public MemberOfHealthCloud_LUI TreatingSpecialistLastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Specialist Last Name"); 
} 
public MemberOfHealthCloud_LUI TreatingSpecialistAddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Specialist Address Line 1"); 
} 
public MemberOfHealthCloud_LUI TreatingSpecialistAddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Specialist Address Line 2"); 
} 
public MemberOfHealthCloud_LUI TreatingSpecialistCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Specialist City"); 
} 
public MemberOfHealthCloud_LUI TreatingSpecialistPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating Specialist Postal Code"); 
} 
public MemberOfHealthCloud_LUI TreatingPDNurseName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating PD Nurse Name"); 
} 
public MemberOfHealthCloud_LUI TreatingPDNurseFirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating PD Nurse First Name"); 
} 
public MemberOfHealthCloud_LUI TreatingPDNurseLastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating PD Nurse Last Name"); 
} 
public MemberOfHealthCloud_LUI TreatingPDNurseAddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating PD Nurse Address Line 1"); 
} 
public MemberOfHealthCloud_LUI TreatingPDNurseAddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating PD Nurse Address Line 2"); 
} 
public MemberOfHealthCloud_LUI TreatingPDNurseCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating PD Nurse City"); 
} 
public MemberOfHealthCloud_LUI TreatingPDNursePostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Treating PD Nurse Postal Code"); 
} 
public MemberOfHealthCloud_LUI ReferringCentreName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Centre Name"); 
} 
public MemberOfHealthCloud_LUI ReferringCentreAddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Centre Address Line 1"); 
} 
public MemberOfHealthCloud_LUI ReferringCentreAddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Centre Address Line 2"); 
} 
public MemberOfHealthCloud_LUI ReferringCentreCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Centre City"); 
} 
public MemberOfHealthCloud_LUI ReferringCentrePostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Centre Postal Code"); 
} 
public MemberOfHealthCloud_LUI ReferringSpecialistName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Specialist Name"); 
} 
public MemberOfHealthCloud_LUI ReferringSpecialistFirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Specialist First Name"); 
} 
public MemberOfHealthCloud_LUI ReferringSpecialistLastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Specialist Last Name"); 
} 
public MemberOfHealthCloud_LUI ReferringSpecialistAddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Specialist Address Line 1"); 
} 
public MemberOfHealthCloud_LUI ReferringSpecialistAddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Specialist Address Line 2"); 
} 
public MemberOfHealthCloud_LUI ReferringSpecialistCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Specialist City"); 
} 
public MemberOfHealthCloud_LUI ReferringSpecialistPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Referring Specialist Postal Code"); 
} 
public MemberOfHealthCloud_LUI Plannedprocedures_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Planned procedure/s"); 
} 
public MemberOfHealthCloud_LUI DoyourequireDuodopaSpecialistassistanceduringDuodopainitiation_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Do you require Duodopa Specialist assistance during Duodopa initiation?"); 
} 
public MemberOfHealthCloud_LUI TitrationMonitoring_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Titration Monitoring"); 
} 
public MemberOfHealthCloud_LUI PatientEducation_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Patient Education"); 
} 
public MemberOfHealthCloud_LUI ProcedureAssistance_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Procedure Assistance"); 
} 
public MemberOfHealthCloud_LUI Date_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Date"); 
} 
public MemberOfHealthCloud_LUI Time_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Time"); 
} 
public MemberOfHealthCloud_LUI Scheduled_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Scheduled"); 
} 
public MemberOfHealthCloud_LUI ReasonfortheLateTitration_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Reason for the Late Titration"); 
} 
public MemberOfHealthCloud_LUI FullSupport_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Full Support"); 
} 
public MemberOfHealthCloud_LUI NoPlannedAftercare_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("No Planned Aftercare"); 
} 
public MemberOfHealthCloud_LUI HCPprivacystmtAlcuracancontact_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("HCP privacy stmt - Alcura can contact"); 
} 
public MemberOfHealthCloud_LUI IntakeCall_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Intake Call"); 
} 
//************************* Functions for HC Button ***************************** // 
 
public MemberOfHealthCloud_LUI Previous_HealthCloudButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Previous"); 
} 
public MemberOfHealthCloud_LUI Next_HealthCloudButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Next"); 
} 
public MemberOfHealthCloud_LUI Submit_HealthCloudButton() throws Exception{ 
return sfdc.HealthCloudButton_LUI("Submit"); 
} 
//************************* Functions for Custom Fields ***************************** // 
 
//************************* Functions for Custom Button ***************************** // 
 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
