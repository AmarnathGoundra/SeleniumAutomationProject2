package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class HealthCloud_Enroll_Patient_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public HealthCloud_Enroll_Patient_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public HealthCloud_Enroll_Patient_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 // ************************ Functions and Classes for List Views ************************************** 
 
 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 //************************* Functions for Buttons List ***************************** // 
 
//************************* Functions for Custom Fields ***************************** // 
 
public MemberOfHealthCloud_LUI Selectanobjecttolimityoursearch_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Selectanobjecttolimityoursearch"); 
} 
public MemberOfHealthCloud_LUI Title_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Title"); 
} 
public MemberOfHealthCloud_LUI FirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("First Name"); 
} 
public MemberOfHealthCloud_LUI _HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI(""); 
} 
public MemberOfHealthCloud_LUI LastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("LastName"); 
} 
public MemberOfHealthCloud_LUI SSNID_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("SSNID"); 
} 

public MemberOfHealthCloud_LUI Gender_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Gender"); 
} 
public MemberOfHealthCloud_LUI BirthDate_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("BirthDate"); 
} 
public MemberOfHealthCloud_LUI MainContact_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("MainContact"); 
} 
public MemberOfHealthCloud_LUI AddressLine1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("AddressLine1"); 
} 
public MemberOfHealthCloud_LUI AddressLine2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("AddressLine2"); 
} 
public MemberOfHealthCloud_LUI CityTown_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("City/Town"); 
} 
public MemberOfHealthCloud_LUI Postcode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Postcode"); 
} 
public MemberOfHealthCloud_LUI Email_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Email"); 
} 
public MemberOfHealthCloud_LUI Phone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Phone"); 
} 
public MemberOfHealthCloud_LUI CarerFirstName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("CarerFirstName"); 
} 
public MemberOfHealthCloud_LUI CarerLastName_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("CarerLastName"); 
} 
public MemberOfHealthCloud_LUI Relationshiptopatient_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Relationshiptopatient"); 
} 
public MemberOfHealthCloud_LUI CarerAddressline1_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("CarerAddressline1"); 
} 
public MemberOfHealthCloud_LUI CarerAddressline2_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("CarerAddressline2"); 
} 
public MemberOfHealthCloud_LUI CarerCity_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("CarerCity"); 
} 
public MemberOfHealthCloud_LUI CarerPostalCode_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("CarerPostalCode"); 
} 
public MemberOfHealthCloud_LUI CarerEmail_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("CarerEmail"); 
} 
public MemberOfHealthCloud_LUI CarerPhone_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("CarerPhone"); 
} 
//************************* Functions for Custom Fields ***************************** // 
 
public MemberOfCustom_LUI SelectanobjecttolimityoursearchCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Select an object to limit your search"); 
} 
public MemberOfCustom_LUI TitleCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Title"); 
} 
public MemberOfCustom_LUI FirstNameCustomField() throws Exception{ 
return sfdc.CustomField_LUI("*First Name"); 
} 
public MemberOfCustom_LUI CustomField() throws Exception{ 
return sfdc.CustomField_LUI("*"); 
} 
public MemberOfCustom_LUI LastNameCustomField() throws Exception{ 
return sfdc.CustomField_LUI("*Last Name"); 
} 
public MemberOfCustom_LUI SSNIDCustomField() throws Exception{ 
return sfdc.CustomField_LUI("*SSN ID"); 
} 
public MemberOfCustom_LUI GenderCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Gender"); 
} 
public MemberOfCustom_LUI BirthDateCustomField() throws Exception{ 
return sfdc.CustomField_LUI("*Birth Date"); 
} 
public MemberOfCustom_LUI MainContactCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Main Contact"); 
} 
public MemberOfCustom_LUI AddressLine1CustomField() throws Exception{ 
return sfdc.CustomField_LUI("Address Line 1"); 
} 
public MemberOfCustom_LUI AddressLine2CustomField() throws Exception{ 
return sfdc.CustomField_LUI("Address Line 2"); 
} 
public MemberOfCustom_LUI CityTownCustomField() throws Exception{ 
return sfdc.CustomField_LUI("City/Town"); 
} 
public MemberOfCustom_LUI PostcodeCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Postcode"); 
} 
public MemberOfCustom_LUI EmailCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Email"); 
} 
public MemberOfCustom_LUI PhoneCustomField() throws Exception{ 
return sfdc.CustomField_LUI("*Phone"); 
} 
public MemberOfCustom_LUI CarerFirstNameCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer First Name"); 
} 
public MemberOfCustom_LUI CarerLastNameCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Last Name"); 
} 
public MemberOfCustom_LUI RelationshiptopatientCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Relationship to patient"); 
} 
public MemberOfCustom_LUI CarerAddressline1CustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Address line1"); 
} 
public MemberOfCustom_LUI CarerAddressline2CustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Address line2"); 
} 
public MemberOfCustom_LUI CarerCityCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer City"); 
} 
public MemberOfCustom_LUI CarerPostalCodeCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Postal Code"); 
} 
public MemberOfCustom_LUI CarerEmailCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Email"); 
} 
public MemberOfCustom_LUI CarerPhoneCustomField() throws Exception{ 
return sfdc.CustomField_LUI("Carer Phone"); 
} 

//************************* Manually added Functions for all type of object ***************************** // 
public MemberOfHealthCloud_LUI patient_procedure_dates_HealthCloudField() throws Exception{ 
return sfdc.HealthCloudField_LUI("Please select this patient"); 
} 


 
//************************* Functions for Custom Related List ***************************** // 
 
//************************* Functions for Custom Table Cell Name ***************************** // 
 
//************************* Functions for JTree Text ***************************** // 
 
} 
 
