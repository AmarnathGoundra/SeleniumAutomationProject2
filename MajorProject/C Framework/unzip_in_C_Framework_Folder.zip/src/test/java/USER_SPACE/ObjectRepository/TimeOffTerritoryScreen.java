package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class TimeOffTerritoryScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public TimeOffTerritoryScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public TimeOffTerritoryScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


//************************* Functions for List Views***************************** // 
 


 public Columns_ListView ListView() throws Exception{ 
return new Columns_ListView(); 
} 
public class Columns_ListView{ 
public MemberOfLV Action(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Action",RowIndex); 
}
public MemberOfLV Action() throws Exception 
{ 
return sfdc.LV("Action"); 
}

public MemberOfLV TOTID(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("TOT ID",RowIndex); 
}
public MemberOfLV TOTID() throws Exception 
{ 
return sfdc.LV("TOT ID"); 
}

public MemberOfLV Date(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Date",RowIndex); 
}
public MemberOfLV Date() throws Exception 
{ 
return sfdc.LV("Date"); 
}

public MemberOfLV Reason(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Reason",RowIndex); 
}
public MemberOfLV Reason() throws Exception 
{ 
return sfdc.LV("Reason"); 
}

public MemberOfLV Status(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Status",RowIndex); 
}
public MemberOfLV Status() throws Exception 
{ 
return sfdc.LV("Status"); 
}

public MemberOfLV OwnerAlias(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Owner Alias",RowIndex); 
}
public MemberOfLV OwnerAlias() throws Exception 
{ 
return sfdc.LV("Owner Alias"); 
}

}

//************************* Functions for Buttons***************************** // 
 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton NewTimeOffTerritoryButton() throws Exception{ 
return sfdc.Button("New Time Off Territory"); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton CancelButton() throws Exception{ 
return sfdc.Button("Cancel"); 
} 
public MemberOfButton EditButton() throws Exception{ 
return sfdc.Button("Edit"); 
} 
public MemberOfButton CloneButton() throws Exception{ 
return sfdc.Button("Clone"); 
} 
public MemberOfButton OKButton() throws Exception{ 
return sfdc.Button("OK"); 
} 
public MemberOfButton SaveNewButton() throws Exception{ 
return sfdc.Button("Save & New"); 
} 
//************************* Functions for Field Names ***************************** // 
 
public MemberOfField DateField() throws Exception{ 
	return sfdc.Field("Date"); 
} 
public MemberOfField ReasonField() throws Exception{ 
	return sfdc.Field("Reason"); 
} 
public MemberOfField TimeField() throws Exception{ 
	return sfdc.Field("Time"); 
} 
public MemberOfField SubReasonField() throws Exception{ 
	return sfdc.Field("Sub-Reason"); 
} 
public MemberOfField EndDateField() throws Exception{ 
	return sfdc.Field("End Date"); 
} 
public MemberOfField StatusField() throws Exception{ 
	return sfdc.Field("Status"); 
} 
public MemberOfField CreatedByField() throws Exception{ 
	return sfdc.Field("Created By"); 
} 
public MemberOfField LastModifiedByField() throws Exception{ 
	return sfdc.Field("Last Modified By"); 
} 
//************************* Functions for Section Name***************************** // 
 
public MemberOfSEC SEC_TimeOffTerritoryDetail_DateField() throws Exception { 
return sfdc.Section("Time Off Territory Detail", "Date"); 
}
public MemberOfSEC SEC_TimeOffTerritoryDetail_ReasonField() throws Exception { 
return sfdc.Section("Time Off Territory Detail", "Reason"); 
}
public MemberOfSEC SEC_TimeOffTerritoryDetail_TimeField() throws Exception { 
return sfdc.Section("Time Off Territory Detail", "Time"); 
}
public MemberOfSEC SEC_TimeOffTerritoryDetail_SubReasonField() throws Exception { 
return sfdc.Section("Time Off Territory Detail", "Sub-Reason"); 
}
public MemberOfSEC SEC_TimeOffTerritoryDetail_EndDateField() throws Exception { 
return sfdc.Section("Time Off Territory Detail", "End Date"); 
}
public MemberOfSEC SEC_TimeOffTerritoryDetail_StatusField() throws Exception { 
return sfdc.Section("Time Off Territory Detail", "Status"); 
}
public MemberOfSEC SEC_TimeOffTerritoryDetail_CreatedByField() throws Exception { 
return sfdc.Section("Time Off Territory Detail", "Created By"); 
}
public MemberOfSEC SEC_TimeOffTerritoryDetail_LastModifiedByField() throws Exception { 
return sfdc.Section("Time Off Territory Detail", "Last Modified By"); 
}
//************************* Functions for Related List***************************** // 
 


 public Columns_TimeOffTerritoryHistory RL_TimeOffTerritoryHistory() throws Exception{ 
return new Columns_TimeOffTerritoryHistory("Time Off Territory History"); 
} 
public class Columns_TimeOffTerritoryHistory{ 
Columns_TimeOffTerritoryHistory(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Date(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Date",RowIndex); 
}
public MemberOfRL Date() throws Exception 
{ 
return sfdc.RL(RList,"Date"); 
}

public MemberOfRL User(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"User",RowIndex); 
}
public MemberOfRL User() throws Exception 
{ 
return sfdc.RL(RList,"User"); 
}

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

}

}

