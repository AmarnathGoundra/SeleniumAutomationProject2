package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class UndefinedScreen extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public UndefinedScreen(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public UndefinedScreen(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


//************************* Functions for List Views***************************** // 
 


 public Columns_ListView ListView() throws Exception{ 
return new Columns_ListView(); 
} 
public class Columns_ListView{ 
public MemberOfLV Action(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Action",RowIndex); 
}
public MemberOfLV Action() throws Exception 
{ 
return sfdc.LV("Action"); 
}

public MemberOfLV SurveyName(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Survey Name",RowIndex); 
}
public MemberOfLV SurveyName() throws Exception 
{ 
return sfdc.LV("Survey Name"); 
}

public MemberOfLV StartDate(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Start Date",RowIndex); 
}
public MemberOfLV StartDate() throws Exception 
{ 
return sfdc.LV("Start Date"); 
}

public MemberOfLV EndDate(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("End Date",RowIndex); 
}
public MemberOfLV EndDate() throws Exception 
{ 
return sfdc.LV("End Date"); 
}

public MemberOfLV Status(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Status",RowIndex); 
}
public MemberOfLV Status() throws Exception 
{ 
return sfdc.LV("Status"); 
}

public MemberOfLV RecordType(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Record Type",RowIndex); 
}
public MemberOfLV RecordType() throws Exception 
{ 
return sfdc.LV("Record Type"); 
}

}

//************************* Functions for Buttons***************************** // 
 
public MemberOfButton GoButton() throws Exception{ 
return sfdc.Button("Go!"); 
} 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton NewSurveyButton() throws Exception{ 
return sfdc.Button("New Survey"); 
} 
//************************* Functions for Field Names ***************************** // 
 
//************************* Functions for Section Name***************************** // 
 
//************************* Functions for Related List***************************** // 
 
}

