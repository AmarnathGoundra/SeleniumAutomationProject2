package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;
//import USER_SPACE.ObjectRepository.OpportunitiesScreen_LUI.Columns_Cases;
import USER_SPACE.TestPrerequisite.*; 

 
 
public class NewProductBasketScreen_LUI extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public NewProductBasketScreen_LUI(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public NewProductBasketScreen_LUI(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI BasketNameField() throws Exception{  
return sfdc.Field_LUI("Basket Name"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI OpportunityField() throws Exception{  
return sfdc.Field_LUI("Opportunity"); 
} 
 
public MemberOfField_LUI SynchronisedWithOpportunityField() throws Exception{  
return sfdc.Field_LUI("Synchronised With Opportunity"); 
} 
 
public MemberOfField_LUI BasketStatusField() throws Exception{  
return sfdc.Field_LUI("Basket Status"); 
} 
 
public MemberOfField_LUI BasketStageField() throws Exception{  
return sfdc.Field_LUI("Basket Stage"); 
} 
 
public MemberOfField_LUI CustomerField() throws Exception{  
return sfdc.Field_LUI("Customer"); 
} 
 
public MemberOfField_LUI TotalContractValueField() throws Exception{  
return sfdc.Field_LUI("Total Contract Value"); 
} 
 
public MemberOfField_LUI ProjectComplexityField() throws Exception{  
return sfdc.Field_LUI("Project Complexity"); 
} 
 
public MemberOfField_LUI PMRequiredField() throws Exception{  
return sfdc.Field_LUI("PM Required"); 
} 
 
public MemberOfField_LUI ProjectManagerContactNumberField() throws Exception{  
return sfdc.Field_LUI("Project Manager Contact Number"); 
} 
 
public MemberOfField_LUI ProjectIDField() throws Exception{  
return sfdc.Field_LUI("Project ID"); 
} 
 
public MemberOfField_LUI ProjectManagerUserIDField() throws Exception{  
return sfdc.Field_LUI("Project Manager User ID"); 
} 
 
public MemberOfField_LUI ProjectManagerEmailField() throws Exception{  
return sfdc.Field_LUI("Project Manager Email"); 
} 
 
public MemberOfField_LUI BillingAccountField() throws Exception{  
return sfdc.Field_LUI("Billing Account"); 
} 
 

//************************* Functions for Buttons List ***************************** // 

public MemberOfButton_LUI CancelButton() throws Exception{ 
return sfdc.Button_LUI("Cancel"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
public MemberOfButton_LUI AddProductButton() throws Exception{ 
return sfdc.Button_LUI("Add Product"); 
} 

//******************* Custom Fields *********************
public MemberOfCustom_LUI Test1Field() throws Exception{  
return sfdc.CustomField_LUI("Test1"); 
}


//******************* Custom JTree *********************

public MemberOfCustom_LUI ModularProductsJTreeText() throws Exception{  
return sfdc.CustomJTree_LUI("Modular Products"); 
}
public MemberOfCustom_LUI SiteSpecificJTreeText() throws Exception{  
return sfdc.CustomJTree_LUI("Site Specific"); 
}

public MemberOfCustom_LUI ConnectedWorkplacePackageJTreeText() throws Exception{  
return sfdc.CustomJTree_LUI("Connected Workplace Package"); 
}

//******************* Custom Button *********************

public MemberOfCustom_LUI AddCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Add"); 
} 

public MemberOfCustom_LUI SearchCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Search"); 
} 

public MemberOfCustom_LUI SelectCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Select"); 
} 

public MemberOfCustom_LUI AddtoBasketCustomButton() throws Exception{ 
return sfdc.CustomButton_LUI("Add to Basket"); 
} 

//******************* Custom Table Cell List *********************
public MemberOfCustom_LUI OrderTypeCustomTableCellName() throws Exception{ 
return sfdc.CustomTableCell_LUI("Order Type"); 
} 




//******************* Custom Related List *********************
public Columns_Cases RL_Cases() throws Exception{ 
return new Columns_Cases("Cases"); 
} 
public class Columns_Cases 
{ 
Columns_Cases(String RL) 
{ 
RList = RL;  
}  
public MemberOfCustom_LUI Sort() throws Exception 
{ 
return sfdc.RL_Custom_LUI(RList,"Sort"); 
} 
public MemberOfCustom_LUI Sort(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_Custom_LUI(RList,"Sort",TargetCOlumnValue); 
} 
public MemberOfCustom_LUI CaseNumber() throws Exception 
{ 
return sfdc.RL_Custom_LUI(RList,"Case Number"); 
} 
public MemberOfCustom_LUI CaseNumber(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_Custom_LUI(RList,"Case Number",TargetCOlumnValue); 
} 
}
 

} 
 
