package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*; 
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver; 

 
 
public class AccountsScreen1 extends SFDCAutomationFW { 

public SFDCAutomationFW sfdc; 
public String RList = ""; 
public String SecName = ""; 


public AccountsScreen1(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 

public AccountsScreen1(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
} 


//************************* Functions for List Views***************************** // 
 


 public Columns_ListView ListView() throws Exception{ 
return new Columns_ListView(); 
} 
public class Columns_ListView{ 
public MemberOfLV Action(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Action",RowIndex); 
}
public MemberOfLV Action() throws Exception 
{ 
return sfdc.LV("Action"); 
}

public MemberOfLV AccountName(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Account Name",RowIndex); 
}
public MemberOfLV AccountName() throws Exception 
{ 
return sfdc.LV("Account Name"); 
}

public MemberOfLV AccountSite(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Account Site",RowIndex); 
}
public MemberOfLV AccountSite() throws Exception 
{ 
return sfdc.LV("Account Site"); 
}

public MemberOfLV BillingStateProvince(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Billing State/Province",RowIndex); 
}
public MemberOfLV BillingStateProvince() throws Exception 
{ 
return sfdc.LV("Billing State/Province"); 
}

public MemberOfLV Phone(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Phone",RowIndex); 
}
public MemberOfLV Phone() throws Exception 
{ 
return sfdc.LV("Phone"); 
}

public MemberOfLV Type(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Type",RowIndex); 
}
public MemberOfLV Type() throws Exception 
{ 
return sfdc.LV("Type"); 
}

public MemberOfLV AccountOwnerAlias(Integer RowIndex) throws Exception 
{ 
return sfdc.LV("Account Owner Alias",RowIndex); 
}
public MemberOfLV AccountOwnerAlias() throws Exception 
{ 
return sfdc.LV("Account Owner Alias"); 
}

}

//************************* Functions for Buttons***************************** // 
 
public MemberOfButton CreateNewButton() throws Exception{ 
return sfdc.Button("Create New..."); 
} 
public MemberOfButton NewAccountButton() throws Exception{ 
return sfdc.Button("New Account"); 
} 
public MemberOfButton SaveButton() throws Exception{ 
return sfdc.Button("Save"); 
} 
public MemberOfButton CancelButton() throws Exception{ 
return sfdc.Button("Cancel"); 
} 
public MemberOfButton EditButton() throws Exception{ 
return sfdc.Button("Edit"); 
} 
public MemberOfButton DeleteButton() throws Exception{ 
return sfdc.Button("Delete"); 
} 
public MemberOfButton IncludeOfflineButton() throws Exception{ 
return sfdc.Button("Include Offline"); 
} 
public MemberOfButton NewContactButton() throws Exception{ 
return sfdc.Button("New Contact"); 
} 
public MemberOfButton MergeContactsButton() throws Exception{ 
return sfdc.Button("Merge Contacts"); 
} 
public MemberOfButton NewOpportunityButton() throws Exception{ 
return sfdc.Button("New Opportunity"); 
} 
public MemberOfButton NewCaseButton() throws Exception{ 
return sfdc.Button("New Case"); 
} 
public MemberOfButton NewTaskButton() throws Exception{ 
return sfdc.Button("New Task"); 
} 
public MemberOfButton NewEventButton() throws Exception{ 
return sfdc.Button("New Event"); 
} 
public MemberOfButton LogaCallButton() throws Exception{ 
return sfdc.Button("Log a Call"); 
} 
public MemberOfButton MailMergeButton() throws Exception{ 
return sfdc.Button("Mail Merge"); 
} 
public MemberOfButton SendanEmailButton() throws Exception{ 
return sfdc.Button("Send an Email"); 
} 
public MemberOfButton NewNoteButton() throws Exception{ 
return sfdc.Button("New Note"); 
} 
public MemberOfButton AttachFileButton() throws Exception{ 
return sfdc.Button("Attach File"); 
} 
public MemberOfButton NewButton() throws Exception{ 
return sfdc.Button("New"); 
} 
public MemberOfButton OKButton() throws Exception{ 
return sfdc.Button("OK"); 
} 
//************************* Functions for Field Names ***************************** // 
 
public MemberOfField AccountOwnerField() throws Exception{ 
	return sfdc.Field("Account Owner"); 
} 
public MemberOfField RatingField() throws Exception{ 
	return sfdc.Field("Rating"); 
} 
public MemberOfField AccountNameField() throws Exception{ 
	return sfdc.Field("Account Name"); 
} 
public MemberOfField PhoneField() throws Exception{ 
	return sfdc.Field("Phone"); 
} 
public MemberOfField ParentAccountField() throws Exception{ 
	return sfdc.Field("Parent Account"); 
} 
public MemberOfField FaxField() throws Exception{ 
	return sfdc.Field("Fax"); 
} 
public MemberOfField AccountNumberField() throws Exception{ 
	return sfdc.Field("Account Number"); 
} 
public MemberOfField WebsiteField() throws Exception{ 
	return sfdc.Field("Website"); 
} 
public MemberOfField AccountSiteField() throws Exception{ 
	return sfdc.Field("Account Site"); 
} 
public MemberOfField TickerSymbolField() throws Exception{ 
	return sfdc.Field("Ticker Symbol"); 
} 
public MemberOfField TypeField() throws Exception{ 
	return sfdc.Field("Type"); 
} 
public MemberOfField OwnershipField() throws Exception{ 
	return sfdc.Field("Ownership"); 
} 
public MemberOfField IndustryField() throws Exception{ 
	return sfdc.Field("Industry"); 
} 
public MemberOfField EmployeesField() throws Exception{ 
	return sfdc.Field("Employees"); 
} 
public MemberOfField AnnualRevenueField() throws Exception{ 
	return sfdc.Field("Annual Revenue"); 
} 
public MemberOfField SICCodeField() throws Exception{ 
	return sfdc.Field("SIC Code"); 
} 
public MemberOfField BillingAddressField() throws Exception{ 
	return sfdc.Field("Billing Address"); 
} 
public MemberOfField ShippingAddressField() throws Exception{ 
	return sfdc.Field("Shipping Address"); 
} 
public MemberOfField CustomerPriorityField() throws Exception{ 
	return sfdc.Field("Customer Priority"); 
} 
public MemberOfField SLAField() throws Exception{ 
	return sfdc.Field("SLA"); 
} 
public MemberOfField SLAExpirationDateField() throws Exception{ 
	return sfdc.Field("SLA Expiration Date"); 
} 
public MemberOfField SLASerialNumberField() throws Exception{ 
	return sfdc.Field("SLA Serial Number"); 
} 
public MemberOfField NumberofLocationsField() throws Exception{ 
	return sfdc.Field("Number of Locations"); 
} 
public MemberOfField UpsellOpportunityField() throws Exception{ 
	return sfdc.Field("Upsell Opportunity"); 
} 
public MemberOfField ActiveField() throws Exception{ 
	return sfdc.Field("Active"); 
} 
public MemberOfField CreatedByField() throws Exception{ 
	return sfdc.Field("Created By"); 
} 
public MemberOfField LastModifiedByField() throws Exception{ 
	return sfdc.Field("Last Modified By"); 
} 
public MemberOfField DescriptionField() throws Exception{ 
	return sfdc.Field("Description"); 
} 
public MemberOfField CustomLinksField() throws Exception{ 
	return sfdc.Field("Custom Links"); 
} 
//************************* Functions for Section Name***************************** // 
 
public MemberOfSEC SEC_AccountDetail_AccountOwnerField() throws Exception { 
return sfdc.Section("Account Detail", "Account Owner"); 
}
public MemberOfSEC SEC_AccountDetail_RatingField() throws Exception { 
return sfdc.Section("Account Detail", "Rating"); 
}
public MemberOfSEC SEC_AccountDetail_AccountNameField() throws Exception { 
return sfdc.Section("Account Detail", "Account Name"); 
}
public MemberOfSEC SEC_AccountDetail_PhoneField() throws Exception { 
return sfdc.Section("Account Detail", "Phone"); 
}
public MemberOfSEC SEC_AccountDetail_ParentAccountField() throws Exception { 
return sfdc.Section("Account Detail", "Parent Account"); 
}
public MemberOfSEC SEC_AccountDetail_FaxField() throws Exception { 
return sfdc.Section("Account Detail", "Fax"); 
}
public MemberOfSEC SEC_AccountDetail_AccountNumberField() throws Exception { 
return sfdc.Section("Account Detail", "Account Number"); 
}
public MemberOfSEC SEC_AccountDetail_WebsiteField() throws Exception { 
return sfdc.Section("Account Detail", "Website"); 
}
public MemberOfSEC SEC_AccountDetail_AccountSiteField() throws Exception { 
return sfdc.Section("Account Detail", "Account Site"); 
}
public MemberOfSEC SEC_AccountDetail_TickerSymbolField() throws Exception { 
return sfdc.Section("Account Detail", "Ticker Symbol"); 
}
public MemberOfSEC SEC_AccountDetail_TypeField() throws Exception { 
return sfdc.Section("Account Detail", "Type"); 
}
public MemberOfSEC SEC_AccountDetail_OwnershipField() throws Exception { 
return sfdc.Section("Account Detail", "Ownership"); 
}
public MemberOfSEC SEC_AccountDetail_IndustryField() throws Exception { 
return sfdc.Section("Account Detail", "Industry"); 
}
public MemberOfSEC SEC_AccountDetail_EmployeesField() throws Exception { 
return sfdc.Section("Account Detail", "Employees"); 
}
public MemberOfSEC SEC_AccountDetail_AnnualRevenueField() throws Exception { 
return sfdc.Section("Account Detail", "Annual Revenue"); 
}
public MemberOfSEC SEC_AccountDetail_SICCodeField() throws Exception { 
return sfdc.Section("Account Detail", "SIC Code"); 
}
public MemberOfSEC SEC_AccountDetail_BillingAddressField() throws Exception { 
return sfdc.Section("Account Detail", "Billing Address"); 
}
public MemberOfSEC SEC_AccountDetail_ShippingAddressField() throws Exception { 
return sfdc.Section("Account Detail", "Shipping Address"); 
}
public MemberOfSEC SEC_AccountDetail_CustomerPriorityField() throws Exception { 
return sfdc.Section("Account Detail", "Customer Priority"); 
}
public MemberOfSEC SEC_AccountDetail_SLAField() throws Exception { 
return sfdc.Section("Account Detail", "SLA"); 
}
public MemberOfSEC SEC_AccountDetail_SLAExpirationDateField() throws Exception { 
return sfdc.Section("Account Detail", "SLA Expiration Date"); 
}
public MemberOfSEC SEC_AccountDetail_SLASerialNumberField() throws Exception { 
return sfdc.Section("Account Detail", "SLA Serial Number"); 
}
public MemberOfSEC SEC_AccountDetail_NumberofLocationsField() throws Exception { 
return sfdc.Section("Account Detail", "Number of Locations"); 
}
public MemberOfSEC SEC_AccountDetail_UpsellOpportunityField() throws Exception { 
return sfdc.Section("Account Detail", "Upsell Opportunity"); 
}
public MemberOfSEC SEC_AccountDetail_ActiveField() throws Exception { 
return sfdc.Section("Account Detail", "Active"); 
}
public MemberOfSEC SEC_AccountDetail_CreatedByField() throws Exception { 
return sfdc.Section("Account Detail", "Created By"); 
}
public MemberOfSEC SEC_AccountDetail_LastModifiedByField() throws Exception { 
return sfdc.Section("Account Detail", "Last Modified By"); 
}
public MemberOfSEC SEC_AccountDetail_DescriptionField() throws Exception { 
return sfdc.Section("Account Detail", "Description"); 
}
public MemberOfSEC SEC_AccountDetail_CustomLinksField() throws Exception { 
return sfdc.Section("Account Detail", "Custom Links"); 
}
//************************* Functions for Related List***************************** // 
 


 public Columns_Contacts RL_Contacts() throws Exception{ 
return new Columns_Contacts("Contacts"); 
} 
public class Columns_Contacts{ 
Columns_Contacts(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL ContactName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Contact Name",RowIndex); 
}
public MemberOfRL ContactName() throws Exception 
{ 
return sfdc.RL(RList,"Contact Name"); 
}

public MemberOfRL Title(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Title",RowIndex); 
}
public MemberOfRL Title() throws Exception 
{ 
return sfdc.RL(RList,"Title"); 
}

public MemberOfRL Email(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Email",RowIndex); 
}
public MemberOfRL Email() throws Exception 
{ 
return sfdc.RL(RList,"Email"); 
}

public MemberOfRL Phone(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Phone",RowIndex); 
}
public MemberOfRL Phone() throws Exception 
{ 
return sfdc.RL(RList,"Phone"); 
}

}



 public Columns_Opportunities RL_Opportunities() throws Exception{ 
return new Columns_Opportunities("Opportunities"); 
} 
public class Columns_Opportunities{ 
Columns_Opportunities(String RL) 
{ 
RList = RL; 
} 

public MemberOfRL Action(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Action",RowIndex); 
}
public MemberOfRL Action() throws Exception 
{ 
return sfdc.RL(RList,"Action"); 
}

public MemberOfRL OpportunityName(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Opportunity Name",RowIndex); 
}
public MemberOfRL OpportunityName() throws Exception 
{ 
return sfdc.RL(RList,"Opportunity Name"); 
}

public MemberOfRL Stage(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Stage",RowIndex); 
}
public MemberOfRL Stage() throws Exception 
{ 
return sfdc.RL(RList,"Stage"); 
}

public MemberOfRL Amount(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Amount",RowIndex); 
}
public MemberOfRL Amount() throws Exception 
{ 
return sfdc.RL(RList,"Amount"); 
}

public MemberOfRL CloseDate(Integer RowIndex) throws Exception 
{ 
return sfdc.RL(RList,"Close Date",RowIndex); 
}
public MemberOfRL CloseDate() throws Exception 
{ 
return sfdc.RL(RList,"Close Date"); 
}

}



 public Columns_Cases RL_Cases() throws Exception{ 
return new Columns_Cases("Cases"); 
} 
public class Columns_Cases{ 
Columns_Cases(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_OpenActivities RL_OpenActivities() throws Exception{ 
return new Columns_OpenActivities("Open Activities"); 
} 
public class Columns_OpenActivities{ 
Columns_OpenActivities(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_ActivityHistory RL_ActivityHistory() throws Exception{ 
return new Columns_ActivityHistory("Activity History"); 
} 
public class Columns_ActivityHistory{ 
Columns_ActivityHistory(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_NotesAttachments RL_NotesAttachments() throws Exception{ 
return new Columns_NotesAttachments("Notes & Attachments"); 
} 
public class Columns_NotesAttachments{ 
Columns_NotesAttachments(String RL) 
{ 
RList = RL; 
} 

}



 public Columns_Partners RL_Partners() throws Exception{ 
return new Columns_Partners("Partners"); 
} 
public class Columns_Partners{ 
Columns_Partners(String RL) 
{ 
RList = RL; 
} 

}

}

