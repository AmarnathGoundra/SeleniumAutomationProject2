package USER_SPACE.ObjectRepository; 
import SOURCE_CODE.SFDC.*;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver; 
import io.appium.java_client.AppiumDriver;  
import USER_SPACE.TestPrerequisite.*; 

 
 
public class OpportunitiesScreen_LUI_stnd extends SFDCAutomationFW{ 
SFDCAutomationFW sfdc; 
String RList = ""; 



public OpportunitiesScreen_LUI_stnd(RemoteWebDriver remoteDriver) { 
super(remoteDriver); 
sfdc = new SFDCAutomationFW(remoteDriver); 
} 


public OpportunitiesScreen_LUI_stnd(AppiumDriver appiumDriver) { 
super(appiumDriver); 
sfdc = new SFDCAutomationFW(appiumDriver); 
}

// ************************ Functions for Fields ************************************** 
 
 public MemberOfField_LUI OpportunityOwnerField() throws Exception{  
return sfdc.Field_LUI("Opportunity Owner"); 
} 
 
public MemberOfField_LUI AmountField() throws Exception{  
return sfdc.Field_LUI("Amount"); 
} 
 
public MemberOfField_LUI PrivateField() throws Exception{  
return sfdc.Field_LUI("Private"); 
} 
 
public MemberOfField_LUI ExpectedRevenueField() throws Exception{  
return sfdc.Field_LUI("Expected Revenue"); 
} 
 
public MemberOfField_LUI OpportunityNameField() throws Exception{  
return sfdc.Field_LUI("Opportunity Name"); 
} 
 
public MemberOfField_LUI CloseDateField() throws Exception{  
return sfdc.Field_LUI("Close Date"); 
} 
 
public MemberOfField_LUI AccountNameField() throws Exception{  
return sfdc.Field_LUI("Account Name"); 
} 
 
public MemberOfField_LUI NextStepField() throws Exception{  
return sfdc.Field_LUI("Next Step"); 
} 
 
public MemberOfField_LUI TypeField() throws Exception{  
return sfdc.Field_LUI("Type"); 
} 
 
public MemberOfField_LUI StageField() throws Exception{  
return sfdc.Field_LUI("Stage"); 
} 
 
public MemberOfField_LUI LeadSourceField() throws Exception{  
return sfdc.Field_LUI("Lead Source"); 
} 
 
public MemberOfField_LUI ProbabilityField() throws Exception{  
return sfdc.Field_LUI("Probability (%)"); 
} 
 
public MemberOfField_LUI GeoLocationTestField() throws Exception{  
return sfdc.Field_LUI("GeoLocationTest"); 
} 
 
public MemberOfField_LUI PrimaryCampaignSourceField() throws Exception{  
return sfdc.Field_LUI("Primary Campaign Source"); 
} 
 
public MemberOfField_LUI OrderNumberField() throws Exception{  
return sfdc.Field_LUI("Order Number"); 
} 
 
public MemberOfField_LUI MainCompetitorsField() throws Exception{  
return sfdc.Field_LUI("Main Competitor(s)"); 
} 
 
public MemberOfField_LUI CurrentGeneratorsField() throws Exception{  
return sfdc.Field_LUI("Current Generator(s)"); 
} 
 
public MemberOfField_LUI DeliveryInstallationStatusField() throws Exception{  
return sfdc.Field_LUI("Delivery/Installation Status"); 
} 
 
public MemberOfField_LUI TrackingNumberField() throws Exception{  
return sfdc.Field_LUI("Tracking Number"); 
} 
 
public MemberOfField_LUI CreatedByField() throws Exception{  
return sfdc.Field_LUI("Created By"); 
} 
 
public MemberOfField_LUI LastModifiedByField() throws Exception{  
return sfdc.Field_LUI("Last Modified By"); 
} 
 
public MemberOfField_LUI DescriptionField() throws Exception{  
return sfdc.Field_LUI("Description"); 
} 
 
public MemberOfField_LUI Multi_Opp_TestField() throws Exception{  
return sfdc.Field_LUI("Multi_Opp_Test"); 
} 
 
// ************************ Functions and Classes for List Views ************************************** 
 
 public Columns_Opportunities LV_Opportunities() throws Exception{ 
return new Columns_Opportunities("Opportunities"); 
} 
public class Columns_Opportunities 
{ 
Columns_Opportunities(String RL) 
{ 
RList = RL;  
}  
public MemberOfLV_LUI OpportunityName() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Opportunity Name"); 
} 
public MemberOfLV_LUI OpportunityName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Opportunity Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI AccountName() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Name"); 
} 
public MemberOfLV_LUI AccountName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Name",TargetCOlumnValue); 
} 
public MemberOfLV_LUI AccountSite() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Site"); 
} 
public MemberOfLV_LUI AccountSite(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Account Site",TargetCOlumnValue); 
} 
public MemberOfLV_LUI Stage() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Stage"); 
} 
public MemberOfLV_LUI Stage(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Stage",TargetCOlumnValue); 
} 
public MemberOfLV_LUI CloseDate() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Close Date"); 
} 
public MemberOfLV_LUI CloseDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Close Date",TargetCOlumnValue); 
} 
public MemberOfLV_LUI OpportunityOwnerAlias() throws Exception 
{ 
return sfdc.LV_LUI(RList,"Opportunity Owner Alias"); 
} 
public MemberOfLV_LUI OpportunityOwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.LV_LUI(RList,"Opportunity Owner Alias",TargetCOlumnValue); 
} 
public MemberOfLV_LUI NewButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"NewButton");  
} 
public MemberOfLV_LUI EditButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"EditButton");  
} 
public MemberOfLV_LUI DeleteButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"DeleteButton");  
} 
public MemberOfLV_LUI CloneButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"CloneButton");  
} 
public MemberOfLV_LUI MenuButtonChangeOwnerButton() throws Exception  
{ 
return sfdc.LV_LUI(RList,"MenuButtonChange OwnerButton");  
} 
} 
 
// ************************ Functions and Static Classes for Related Lists ************************************** 
 
 public Columns_Products RL_Products() throws Exception{ 
return new Columns_Products("Products"); 
} 
public class Columns_Products 
{ 
Columns_Products(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI OpportunityName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name"); 
} 
public MemberOfRL_LUI OpportunityName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AccountName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Name"); 
} 
public MemberOfRL_LUI AccountName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AccountSite() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Site"); 
} 
public MemberOfRL_LUI AccountSite(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Site",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Stage() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage"); 
} 
public MemberOfRL_LUI Stage(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CloseDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date"); 
} 
public MemberOfRL_LUI CloseDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI OpportunityOwnerAlias() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Owner Alias"); 
} 
public MemberOfRL_LUI OpportunityOwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Owner Alias",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Product() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product"); 
} 
public MemberOfRL_LUI Product(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Quantity() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity"); 
} 
public MemberOfRL_LUI Quantity(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity",TargetCOlumnValue); 
} 
public MemberOfRL_LUI SalesPrice() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sales Price"); 
} 
public MemberOfRL_LUI SalesPrice(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sales Price",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Date() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date"); 
} 
public MemberOfRL_LUI Date(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LineDescription() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Line Description"); 
} 
public MemberOfRL_LUI LineDescription(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Line Description",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AddProductsButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Add ProductsButton");  
} 
public MemberOfRL_LUI ChoosePriceBookButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Choose Price BookButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_NotesAttachments RL_NotesAttachments() throws Exception{ 
return new Columns_NotesAttachments("Notes & Attachments"); 
} 
public class Columns_NotesAttachments 
{ 
Columns_NotesAttachments(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI OpportunityName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name"); 
} 
public MemberOfRL_LUI OpportunityName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AccountName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Name"); 
} 
public MemberOfRL_LUI AccountName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AccountSite() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Site"); 
} 
public MemberOfRL_LUI AccountSite(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Site",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Stage() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage"); 
} 
public MemberOfRL_LUI Stage(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CloseDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date"); 
} 
public MemberOfRL_LUI CloseDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI OpportunityOwnerAlias() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Owner Alias"); 
} 
public MemberOfRL_LUI OpportunityOwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Owner Alias",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Product() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product"); 
} 
public MemberOfRL_LUI Product(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Quantity() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity"); 
} 
public MemberOfRL_LUI Quantity(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity",TargetCOlumnValue); 
} 
public MemberOfRL_LUI SalesPrice() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sales Price"); 
} 
public MemberOfRL_LUI SalesPrice(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sales Price",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Date() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date"); 
} 
public MemberOfRL_LUI Date(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LineDescription() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Line Description"); 
} 
public MemberOfRL_LUI LineDescription(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Line Description",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI UploadFilesButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Upload FilesButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_ContactRoles RL_ContactRoles() throws Exception{ 
return new Columns_ContactRoles("Contact Roles"); 
} 
public class Columns_ContactRoles 
{ 
Columns_ContactRoles(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI OpportunityName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name"); 
} 
public MemberOfRL_LUI OpportunityName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AccountName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Name"); 
} 
public MemberOfRL_LUI AccountName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AccountSite() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Site"); 
} 
public MemberOfRL_LUI AccountSite(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Site",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Stage() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage"); 
} 
public MemberOfRL_LUI Stage(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CloseDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date"); 
} 
public MemberOfRL_LUI CloseDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI OpportunityOwnerAlias() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Owner Alias"); 
} 
public MemberOfRL_LUI OpportunityOwnerAlias(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Opportunity Owner Alias",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Product() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product"); 
} 
public MemberOfRL_LUI Product(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Quantity() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity"); 
} 
public MemberOfRL_LUI Quantity(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity",TargetCOlumnValue); 
} 
public MemberOfRL_LUI SalesPrice() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sales Price"); 
} 
public MemberOfRL_LUI SalesPrice(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sales Price",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Date() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date"); 
} 
public MemberOfRL_LUI Date(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LineDescription() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Line Description"); 
} 
public MemberOfRL_LUI LineDescription(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Line Description",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ContactName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name"); 
} 
public MemberOfRL_LUI ContactName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Role() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role"); 
} 
public MemberOfRL_LUI Role(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Primary() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Primary"); 
} 
public MemberOfRL_LUI Primary(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Primary",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Phone() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone"); 
} 
public MemberOfRL_LUI Phone(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Email() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email"); 
} 
public MemberOfRL_LUI Email(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ManageContactRolesButton() throws Exception  
{ 
return sfdc.RL_LUI(RList,"Manage Contact RolesButton");  
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
public Columns_StageHistory RL_StageHistory() throws Exception{ 
return new Columns_StageHistory("Stage History"); 
} 
public class Columns_StageHistory 
{ 
Columns_StageHistory(String RL) 
{ 
RList = RL;  
}  
public MemberOfRL_LUI Product() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product"); 
} 
public MemberOfRL_LUI Product(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Product",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Quantity() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity"); 
} 
public MemberOfRL_LUI Quantity(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Quantity",TargetCOlumnValue); 
} 
public MemberOfRL_LUI SalesPrice() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sales Price"); 
} 
public MemberOfRL_LUI SalesPrice(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Sales Price",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Date() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date"); 
} 
public MemberOfRL_LUI Date(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LineDescription() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Line Description"); 
} 
public MemberOfRL_LUI LineDescription(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Line Description",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Title() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title"); 
} 
public MemberOfRL_LUI Title(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Title",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Owner() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner"); 
} 
public MemberOfRL_LUI Owner(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Owner",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModified() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified"); 
} 
public MemberOfRL_LUI LastModified(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Size() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size"); 
} 
public MemberOfRL_LUI Size(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Size",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ContactName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name"); 
} 
public MemberOfRL_LUI ContactName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Contact Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Role() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role"); 
} 
public MemberOfRL_LUI Role(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Role",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Primary() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Primary"); 
} 
public MemberOfRL_LUI Primary(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Primary",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Phone() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone"); 
} 
public MemberOfRL_LUI Phone(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Phone",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Email() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email"); 
} 
public MemberOfRL_LUI Email(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Email",TargetCOlumnValue); 
} 
public MemberOfRL_LUI AccountName() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Name"); 
} 
public MemberOfRL_LUI AccountName(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Account Name",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Stage() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage"); 
} 
public MemberOfRL_LUI Stage(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Stage",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Amount() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Amount"); 
} 
public MemberOfRL_LUI Amount(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Amount",TargetCOlumnValue); 
} 
public MemberOfRL_LUI Probability() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Probability (%)"); 
} 
public MemberOfRL_LUI Probability(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Probability (%)",TargetCOlumnValue); 
} 
public MemberOfRL_LUI ExpectedRevenue() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Expected Revenue"); 
} 
public MemberOfRL_LUI ExpectedRevenue(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Expected Revenue",TargetCOlumnValue); 
} 
public MemberOfRL_LUI CloseDate() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date"); 
} 
public MemberOfRL_LUI CloseDate(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Close Date",TargetCOlumnValue); 
} 
public MemberOfRL_LUI LastModifiedBy() throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified By"); 
} 
public MemberOfRL_LUI LastModifiedBy(String TargetCOlumnValue) throws Exception 
{ 
return sfdc.RL_LUI(RList,"Last Modified By",TargetCOlumnValue); 
} 
public MemberOfRL_LUI RelatedListLink() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListLink"); 
} 
public MemberOfRL_LUI RelatedListItem() throws Exception  
{ 
return sfdc.RL_LUI(RList,"RelatedListItem");  
} 
 } 
//************************* Functions for Buttons List ***************************** // 
 
public MemberOfButton_LUI NewButton() throws Exception{ 
return sfdc.Button_LUI("New"); 
} 
public MemberOfButton_LUI SaveButton() throws Exception{ 
return sfdc.Button_LUI("Save"); 
} 
public MemberOfButton_LUI EditButton() throws Exception{ 
return sfdc.Button_LUI("Edit"); 
} 
public MemberOfButton_LUI DeleteButton() throws Exception{ 
return sfdc.Button_LUI("Delete"); 
} 
public MemberOfButton_LUI CloneButton() throws Exception{ 
return sfdc.Button_LUI("Clone"); 
} 
public MemberOfButton_LUI MenuButtonChangeOwnerButton() throws Exception{ 
return sfdc.Button_LUI("MenuButton:Change Owner"); 
} 
} 


 
