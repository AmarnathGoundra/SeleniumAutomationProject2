package USER_SPACE.TestPrerequisite;

import SOURCE_CODE.SFDC.SFDCAutomationFW;

public class DataSetup {
	
	//public String pathOffirefox = "C:/Program Files (x86)/Mozilla Firefox/firefox.exe";
	//public String pathOfsafari = "C:\\Program Files (x86)\\Safari\\Safari.exe";
	//public String pathOfOperaLauncher = "C:\\Program Files (x86)\\Opera\\launcher.exe";
	//public String pathOfOperaBinary = "C:\\Program Files\\Opera x64\\opera.exe";
	//public String pathOfchromedriver = "F:/SCRIPTLESS_16062016/OTHERS/chromedriver.exe";
	//public String pathOfIEDriver = "F:/SCRIPTLESS_16062016/OTHERS/IEDriverServer.exe";
	//public String pathOfProjectHomeDirectory = "F:/SCRIPTLESS_16062016/DEMO_160616";
	//public String pathOfTestLogTemplate = "F:/SCRIPTLESS_16062016/DEMO_160616/src/SOURCE_CODE/SFDC";
	
	public String Browser = "chrome";
	
	public String testuser1 = "Sourav Mukherjee";
	public String testuser2 = "Sankha Sen";
	
	
	public String Logininfo = "DataSheet.xls";
	public String SheetNameofTestUsers = "LoginInfo";
	public String SheetForBC = "TestDataStore\\BusinessComponent\\BC.xls";
	public String PathOfTestLogsExcel = "TestLogs.xls";
	public String SheetNameofTestLogSummary = "Exe_Log";
	public String SheetNameofSetupInfo = "Setup";
	
	
	public String TC_Data_Leads = "TestDataStore\\TestScripts\\TC_Data_Leads.xlsx";
	public String TestData = "TestDataStore\\TestScripts\\TestData.xlsx";
	public String TC_Data_Telstra = "TestDataStore\\TestScripts\\TC_Telstra_TestData.xlsx";
	public String TC_Data_Cases = "TestDataStore\\TestScripts\\TC_Data_Cases.xlsx";
	public String Merck_CornerStone_TestData = "TestDataStore\\TestScripts\\Merck_CornerStone_TestData.xlsx";
	public String Health_Cloud_Lighting = "TestDataStore\\TestScripts\\Health_Cloud_Lighting.xlsx";

	public String DataStore_ScriptLess = "TestDataStore\\ScriptLess\\SetCriteria";
	public String TC_FacilityTerritoryAssociation = "TestDataStore\\TestScripts\\TC_FacilityTerritoryAssociation.xlsx";
	
	
	
	public SFDCAutomationFW sfdc;
	public String SheetNameofTestSuite = "EXE_Leads";
	
	
	
	// ***************** Referring to SendEmailAttachingTestLog function ******************
	/*
	public String Emailid_TO = "";
	public String Emailid_CC1 = "";
	public String Emailid_FROM = "";
	public String Emailid_Username = ""; //no need to mention @gmail.com. Just mention gmail account name 
	public String Emailid_Passsword = ""; //type password
	public String Email_Host = "smtp.gmail.com";
	*/
 
	public String Emailid_TO = "sourav.mukherjee@cognizant.com";
	public String Emailid_CC1 = "sourav.mukherjee@cognizant.com"; 
	public String Emailid_FROM = "sourav.mukherjee@cognizant.com";

	public String Email_Host = "APACSMTP.cts.com";
	//
	 //Setting up Default Values on Object Repository Creation Fields.
    //public String SFDC_LOGIN_URL = "[Please enter the login URL]";
	public String SFDC_LOGIN_URL = "https://test.salesforce.com/";
	//public String SYSTEM_ADMIN_USERNAME = "[System Admin Username]";
    public String SYSTEM_ADMIN_USERNAME = "Sathiyapriya Ekambaram";
    //public String NAME_OF_SFDC_OBJECT = "[SFDC Object Name]";
    public String NAME_OF_SFDC_OBJECT = "Opportunity";
    //public String SFDC_RECORD_URL = "[SFDC record URL to be entered]";
    public String SFDC_RECORD_URL = "https://ap1.salesforce.com/0069000000flGZj";
    
    
    //Test Data to be used inside the test case template
    public String Name_OF_testuser_for_URL = "Sourav Mukherjee";
    public String Name_OF_testuser_for_Login = "Sourav Mukherjee";
    
}
