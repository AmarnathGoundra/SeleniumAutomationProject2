package USER_SPACE.TestPrerequisite;

import org.junit.runner.RunWith;


import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
/*
@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"Features"}
		,
		plugin ={"pretty" , "html:TestLogs/Cucumber"}
		,glue = {"src/USER_SPACE/TestScripts/BDDScripts"}
		,tags = {"@tag1,@tag2"}
		,monochrome = true
		,dryRun = true			
		)
*/


//@ExtendedCucumberOptions(
	//	jsonReport = "TestLogs/Cucumber/BDDReport.json",
		//overviewReport = true,
		//outputFolder = "TestLogs"
	//	)

//@RunWith(Cucumber.class)
/*
@RunWith(ExtendedCucumber.class)
@ExtendedCucumberOptions(
		jsonReport = "TestLogs/Cucumber/cucumber.json",
		overviewReport = true,
		outputFolder = "TestLogs"
		)
@CucumberOptions(
		plugin = { "html:TestLogs/Cucumber/cucumber-html-report",
		"json:TestLogs/Cucumber/cucumber.json",
		"pretty:TestLogs/Cucumber/cucumber-pretty.txt",
		"usage:TestLogs/Cucumber/cucumber-usage.json",
		"junit:TestLogs/Cucumber/cucumber-results.xml" },
		features = {"Features"},
		glue = {"src/USER_SPACE/TestScripts/BDDScripts"},
		tags = {"@tag1,@tag2"},
		monochrome = true,
		dryRun = true			
		)

*/
@RunWith(Cucumber.class)
@CucumberOptions(
		plugin = { "html:TestLogs/Cucumber/cucumber-html-report",
		"json:TestLogs/Cucumber/cucumber.json",
		"pretty:TestLogs/Cucumber/cucumber-pretty.txt",
		"usage:TestLogs/Cucumber/cucumber-usage.json",
		"junit:TestLogs/Cucumber/cucumber-results.xml" },
		features = {"Features"},
		glue = {"src/USER_SPACE/TestScripts/BDDScripts"},
		tags = {"@tag1,@tag2"},
		monochrome = true,
		dryRun = true			
		)

public class TestRunner_working {}
