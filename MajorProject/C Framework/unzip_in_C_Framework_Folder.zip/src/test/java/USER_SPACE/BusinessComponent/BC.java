package USER_SPACE.BusinessComponent;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import SOURCE_CODE.SFDC.*;
import USER_SPACE.ObjectRepository.LeadScreen;
import USER_SPACE.ObjectRepository.HC_LeadsScreen_LUI;
import USER_SPACE.TestPrerequisite.DataSetup;
import io.appium.java_client.AppiumDriver;

public class BC extends SFDCAutomationFW  {

	HC_LeadsScreen_LUI leadScreen = null;
	public BC(AppiumDriver appiumDriver) {
		super(appiumDriver);
	}

	public BC(RemoteWebDriver remoteDriver) {
		super(remoteDriver);
		sfdc = new SFDCAutomationFW(remoteDriver, TCName);
		leadScreen = new HC_LeadsScreen_LUI(remoteDriver);
	}
	
	
	
		
	/**
	 * @author 185584
	 * @return Current datetimestamp 
	 * @Description It generates the current date time stamp at the time it is invoked. This may be used when you want to enter any unique data.
	 * @throws Exception
	 */
/*	public static String GetCurrentDateTimeStamp() throws Exception
	{
        
       	Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyHHmmss");
        return (sdf.format(cal.getTime()));                     
              
    }
	
	public static void SwitchToOracleObjectPageFrame() throws Exception
	{
		try 
		{
			sfdc.GetWebDriver().switchTo().defaultContent();
			sfdc.GetWebDriver().switchTo().frame(sfdc.GetWebDriver().findElement(By.xpath("//iframe[contains(@title,'Canvas IFrame for application Oracle CPQ Cloud.')][1]")));
			sfdc.GetWebDriver().switchTo().frame(sfdc.GetWebDriver().findElement(By.xpath("//iframe[contains(@title,'Oracle CPQ Cloud')][1]")));
		}
		catch(Exception e){e.printStackTrace();}
	}
	
	public static void OracleObjectButtonClick(String ButtonName) throws Exception
	{
		try 
		{
			sfdc.GetWebDriver().findElement(By.xpath("//a[@class='button-text' and normalize-space(text())='"+ButtonName+"']")).click();
			sfdc.AddToXLLogs("Clicked on ("+ButtonName+") button successfully.", "Pass");
		}
		catch(Exception e){
			e.printStackTrace();
			sfdc.AddToXLLogs("Unable to click on button ("+ButtonName+").", "Fail");
			}
	}
	
	public static void OracleObjectAdvancedSearch(String SearchItem) throws Exception
	{
		try 
		{
			sfdc.GetWebDriver().findElement(By.xpath("//input[contains(@placeholder,'Search')]")).clear();
			sfdc.GetWebDriver().findElement(By.xpath("//input[contains(@placeholder,'Search')]")).sendKeys(SearchItem);
			sfdc.PressENTERKeyOnWindowAlert();
			Thread.sleep(2000L);
			if(sfdc.GetWebDriver().findElement(By.xpath("//tr[@class='modelRows'][1]/td[contains(normalize-space(text()),'"+SearchItem+"')][1]")).isDisplayed())
			{
				sfdc.AddToXLLogs("Successfully searched the result in Advanced Search.", "Pass");
			}
			else
			{
				sfdc.AddToXLLogs("The search could not find any result.", "Fail");
			}
					
		}
		catch(Exception e){
			e.printStackTrace();
			sfdc.AddToXLLogs("Unable to search the item ("+SearchItem+") from Advanced Search.", "Fail");
			}
	}
	
	public static void SelectLookupWithMultiSelectOption(String FieldName, String Options) throws Exception
    {
           try 
           {
                  sfdc.GetWebDriver().findElement(By.xpath("//img[@alt='Name Lookup (New Window)'][1]")).click();
                  Thread.sleep(3000L);
                  sfdc.GetWebDriver().findElement(By.xpath("//input[@class='search_text'][1]")).sendKeys(Options);
                  sfdc.GetWebDriver().findElement(By.xpath("//input[@class='btn' and @title='Find' and @type='button'][1]")).click();
                  
                  Thread.sleep(5000L);
                        
                  sfdc.GetWebDriver().findElement(By.xpath("//ul[@class='mw_list' and @unselectable='on' and @role='listbox'][1]/descendant-or-self::span[@class='list_item'][1]/img[1]")).click();
                  sfdc.GetWebDriver().findElement(By.xpath("//ul[@class='mw_list' and @unselectable='on' and @role='listbox'][1]/descendant-or-self::span[@class='list_item'][1]/img[1]")).click();
                  System.out.println("Clicked on option successfully");
                  sfdc.GetWebDriver().findElement(By.xpath("//a[@id='mw_picker_add_button'][1]")).click();
                  sfdc.GetWebDriver().findElement(By.xpath("//input[@id='mw_picker_save_btn'][1]")).click();
                  sfdc.AddToXLLogs("Selected the Name as ("+Options+")", "Pass");
           
           }
           catch(Exception e){
                  e.printStackTrace();
                  
                  }
    }


	public static boolean MIGRATE_DATA_VIA_WORKBENCH(String[] args,String TestCaseName) throws Exception
	{
		try 
		{
			
			DB.Connect(DataSetup.SheetForBC);
			String URL_WORKBENCH = DB.ReadXLData("MIGRATE_DATA_VIA_WORKBENCH", "URL_WORKBENCH", "TESTCASE_NAME", TestCaseName);
			String ENVIRONMENT = DB.ReadXLData("MIGRATE_DATA_VIA_WORKBENCH", "ENVIRONMENT", "TESTCASE_NAME", TestCaseName);
			String API_VERSION = DB.ReadXLData("MIGRATE_DATA_VIA_WORKBENCH", "API_VERSION", "TESTCASE_NAME", TestCaseName);
			String USERNAME = DB.ReadXLData("MIGRATE_DATA_VIA_WORKBENCH", "USERNAME", "TESTCASE_NAME", TestCaseName);
			String PASSWORD = DB.ReadXLData("MIGRATE_DATA_VIA_WORKBENCH", "PASSWORD", "TESTCASE_NAME", TestCaseName);
			String JUMPTO = DB.ReadXLData("MIGRATE_DATA_VIA_WORKBENCH", "JUMPTO", "TESTCASE_NAME", TestCaseName);
			String OBJECT = DB.ReadXLData("MIGRATE_DATA_VIA_WORKBENCH", "OBJECT", "TESTCASE_NAME", TestCaseName);
			String CSV_FILE_PATH = DB.ReadXLData("MIGRATE_DATA_VIA_WORKBENCH", "CSV_FILE_PATH", "TESTCASE_NAME", TestCaseName);
			
			String xpath_UserName = "//input[normalize-space(@type)='email' and normalize-space(@id)='username'][1]";
			String xpath_Password = "//input[normalize-space(@type)='password' and normalize-space(@id)='password'][1]";
			String xpath_LoginButton = "//input[contains(@class,'button') and @type='submit'][1]";
			
			
			DB.Connect(DataSetup.Logininfo);
			sfdc.OpenURL(args, URL_WORKBENCH , DB.ReadXLData("Setup", "Browser", "SL_NO", "Setup1"));
			
			new Select(sfdc.GetWebDriver().findElement(By.xpath("//label[text()='Environment:'][1]/following-sibling::select[1]"))).selectByVisibleText(ENVIRONMENT);
			new Select(sfdc.GetWebDriver().findElement(By.xpath("//label[text()='API Version:'][1]/following-sibling::select[1]"))).selectByVisibleText(API_VERSION);
			Thread.sleep(1000L);
			sfdc.GetWebDriver().findElement(By.xpath("(//input[@type='checkbox'])[2]")).click();
			sfdc.GetWebDriver().findElement(By.xpath("//input[contains(@value,'Login')][1]")).click();
			
			sfdc.GetWebDriver().findElement(By.xpath(xpath_UserName)).clear();
			sfdc.GetWebDriver().findElement(By.xpath(xpath_UserName)).sendKeys(USERNAME);
	        
			sfdc.GetWebDriver().findElement(By.xpath(xpath_Password)).clear();
			sfdc.GetWebDriver().findElement(By.xpath(xpath_Password)).sendKeys(PASSWORD);
			     
			sfdc.GetWebDriver().findElement(By.xpath(xpath_LoginButton)).click();
			Thread.sleep(1000L);
			new Select(sfdc.GetWebDriver().findElement(By.xpath("//strong[contains(normalize-space(text()),'Jump to:')]/../following-sibling::select[1]"))).selectByVisibleText(JUMPTO.trim());
			new Select(sfdc.GetWebDriver().findElement(By.xpath("//strong[contains(normalize-space(text()),'Object:')]/../following-sibling::select[1]"))).selectByVisibleText(OBJECT.trim());
			
			sfdc.GetWebDriver().findElement(By.xpath("//input[@value='Select'][1]")).click();
						
			sfdc.GetWebDriver().findElement(By.xpath("//label[contains(normalize-space(text()),'From File')][1]")).click();
			
			//sfdc.Browse(CSV_FILE_PATH);
			
			Thread.sleep(3000L);
			
			sfdc.GetWebDriver().findElement(By.xpath("//input[@type='submit' and @value='Next']")).click();
			
			Thread.sleep(4000L);
			//Need to add couple of LOC for validating if each of the mandatory fields are prepopulated wiith some mapping column if blank then need to check if there is any matching value in the drop down that should be selected.
			///**************************************************
			
			
			List<WebElement> mandatory_field_elements = sfdc.GetWebDriver().findElements(By.xpath("//tr[contains(@style,'color') and contains(@style,'red']"));
			for(WebElement eachmandatory_field: mandatory_field_elements)
			{
				eachmandatory_field
			}
			
			
			//*************************************************
			
			//For now make sure that the CSV file to be inserted must have the same API name for that destination object
			
			sfdc.GetWebDriver().findElement(By.xpath("//input[@type='submit' and @value='Map Fields'][1]")).click();
			Thread.sleep(3000L);
			sfdc.GetWebDriver().findElement(By.xpath("//input[@type='submit' and @value='Confirm Insert'][1]")).click();
			
			
			
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
	*//**
	 * @author 185584
	 * @param TestCaseName
	 * @return LeadName on successful Creation of Lead record
	 * @StartScreen Salesforce Home page should be displayed
	 * @EndScreen Lead Details page should be displayed
	 * @throws Exception
	 *//*
	public static String CreateLead(String TestCaseName) throws Exception
	{
		try 
		{
			
		String FirstName,LastName,Company,LeadStatus,Phone,Mobile,Email,LeadSource,Campaign,Industry,Street,City,Zip,Country;
		String LeadName = "";
		
		DB.Connect(DataSetup.SheetForBC);
			
		FirstName = DB.ReadXLData("CreateLead", "FirstName", "TestCaseName", TestCaseName);
		LastName = DB.ReadXLData("CreateLead", "LastName", "TestCaseName", TestCaseName);
		Company = DB.ReadXLData("CreateLead", "Company", "TestCaseName", TestCaseName);
		LeadStatus = DB.ReadXLData("CreateLead", "LeadStatus", "TestCaseName", TestCaseName);
		Phone = DB.ReadXLData("CreateLead", "Phone", "TestCaseName", TestCaseName);
		Mobile = DB.ReadXLData("CreateLead", "Mobile", "TestCaseName", TestCaseName);
		Email = DB.ReadXLData("CreateLead", "Email", "TestCaseName", TestCaseName);
		LeadSource = DB.ReadXLData("CreateLead", "LeadSource", "TestCaseName", TestCaseName);
		//Campaign = DB.ReadXLData("CreateLead", "Campaign", "TestCaseName", TestCaseName);
		Industry = DB.ReadXLData("CreateLead", "Industry", "TestCaseName", TestCaseName);
		Street = DB.ReadXLData("CreateLead", "Street", "TestCaseName", TestCaseName);
		City = DB.ReadXLData("CreateLead", "City", "TestCaseName", TestCaseName);
		Zip = DB.ReadXLData("CreateLead", "Zip", "TestCaseName", TestCaseName);
		Country = DB.ReadXLData("CreateLead", "Country", "TestCaseName", TestCaseName);
		
		String datetime = GetCurrentDateTimeStamp();
		
		if (FirstName.trim().equals(""))
		{
			FirstName = datetime;
		}
		
		if (LastName.trim().equals(""))
		{
			LastName = datetime;
		}
		if (Company.trim().equals(""))
		{
			Company = datetime;
		}
						
		if (LeadStatus.trim().equals(""))
		{
			LeadStatus = "Open - Not Contacted";
		}
		if (Email.trim().equals(""))
		{
			Email = FirstName + "." + LastName + "@" + datetime + ".com";
		}
		if (Industry.trim().equals(""))
		{
			Industry = "--None--";
		}
		if (LeadSource.trim().equals(""))
		{
			LeadSource = "Other";
		}
		
		sfdc.Tab("Leads").Click();
		
		LeadScreen.NewButton().Click();
		
		sfdc.WaitForPageToLoad(15);
		
		LeadScreen.FirstNameField().Type(FirstName);
		LeadScreen.LastNameField().Type(LastName);
		LeadScreen.CompanyField().Type(Company);
		LeadScreen.LeadStatusField().SelectPL(LeadStatus);
		LeadScreen.PhoneField().Type(Phone);
		LeadScreen.MobileField().Type(Mobile);
		LeadScreen.EmailField().Type(Email);
		LeadScreen.LeadSourceField().SelectPL(LeadSource);
		//LeadScreen.CampaignField().Type(Campaign);
		LeadScreen.IndustryField().SelectPL(Industry);
		LeadScreen.StateProvinceField().Type(Street);
		LeadScreen.CityField().Type(City);
		LeadScreen.ZipPostalCodeField().Type(Zip);
		LeadScreen.CountryField().Type(Country);
		
		LeadScreen.SaveButton().Click();
		
		if(LeadScreen.EditButton().WaitForElement(30))
		{
			LeadName = LeadScreen.NameField().GetViewOnlyValue();
			
			sfdc.AddToXLLogs("Lead record is created successfully.", "Pass");
			System.out.println("Lead record is created successfully.");
			DB.Connect(DataSetup.SheetForBC);
			DB.UpdateXLCell("CreateLead", LeadName, "LeadName" , "TestCaseName", TestCaseName);
			return LeadName;
		}
		else
		{
			sfdc.AddToXLLogs("Unable to save the Lead record.", "Fail");
			System.out.println("Unable to save the Lead record.");
			return "";
		}

		
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to create Lead record.");
			sfdc.AddToXLLogs("Unable to create Lead record.", "Fail");
			return "";
		}
	}
	
	public static void CreateMultipleLeads() throws Exception
	{
		
		ArrayList<String> al_leadname;
		ArrayList<String> al_company;
		try 
		{
			
		String FirstName,LastName,Company,LeadStatus,Phone,Mobile,Email,LeadSource,Campaign,Industry,Street,City,Zip,Country;
		String LeadName = "";
		al_leadname = new ArrayList<String>();
		al_company = new ArrayList<String>();
		DB.Connect(DataSetup.SheetForBC);
		ResultSet rs = DB.GetAllExcelValues("CreateMultipleLeads");
		while (rs.next()) {
		    
			//System.out.println(rs.getString(1));
						
		    FirstName = rs.getString(1);
		    LastName = rs.getString(2);
			Company = rs.getString(3);
			LeadStatus = rs.getString(4);
			Phone  = rs.getString(5);
			Mobile = rs.getString(6);
			Email = rs.getString(7);
			LeadSource = rs.getString(8);
			Campaign = rs.getString(9);
			Industry= rs.getString(10);
			Street = rs.getString(11);
			City = rs.getString(12);
			Zip = rs.getString(13);
			Country = rs.getString(14);
			
			String datetime = GetCurrentDateTimeStamp();
			
			if (FirstName == null)
			{
				FirstName = datetime;
			}
			
			if (LastName == null)
			{
				LastName = datetime;
			}
			if (Company == null)
			{
				Company = datetime;
			}
							
			if (LeadStatus == null)
			{
				LeadStatus = "Open - Not Contacted";
			}
			if (Phone == null)
			{
				Phone = "";
			}
			if (Mobile == null)
			{
				Mobile = "";
			}
			if (Email == null)
			{
				Email = FirstName + "." + LastName + "@" + datetime + ".com";
			}
			if (LeadSource == null)
			{
				LeadSource = "";
			}
			if (Campaign == null)
			{
				Campaign = "";
			}
			if (Industry == null)
			{
				Industry = "--None--";
			}
			if (Street == null)
			{
				Street = "Other";
			}
			if (City == null)
			{
				City = "Other";
			}
			if (Zip == null)
			{
				Zip = "Other";
			}
			if (Country == null)
			{
				Country = "Other";
			}
			
			sfdc.Tab("Leads").Click();
			
			LeadScreen.NewButton().Click();
			
			sfdc.WaitForPageToLoad(15);
			
			LeadScreen.FirstNameField().Type(FirstName);
			LeadScreen.LastNameField().Type(LastName);
			LeadScreen.CompanyField().Type(Company);
			LeadScreen.LeadStatusField().SelectPL(LeadStatus);
			LeadScreen.PhoneField().Type(Phone);
			LeadScreen.MobileField().Type(Mobile);
			LeadScreen.EmailField().Type(Email);
			LeadScreen.LeadSourceField().SelectPL(LeadSource);
			//LeadScreen.CampaignField().Type(Campaign);
			LeadScreen.IndustryField().SelectPL(Industry);
			LeadScreen.StateProvinceField().Type(Street);
			LeadScreen.CityField().Type(City);
			LeadScreen.ZipPostalCodeField().Type(Zip);
			LeadScreen.CountryField().Type(Country);
			
			LeadScreen.SaveButton().Click();
			
			if(LeadScreen.EditButton().WaitForElement(30))
			{
				al_leadname.add(LeadScreen.NameField().GetViewOnlyValue().toString());
				al_company.add(Company);
				
				sfdc.AddToXLLogs("Lead (LeadName) is created successfully.", "Pass");
				System.out.println("Lead (LeadName) is created successfully.");
				
			}
			else
			{
				sfdc.AddToXLLogs("Unable to save the Lead record.", "Fail");
				System.out.println("Unable to save the Lead record.");
				
			}
		    
			sfdc.Tab("Home").Click();
			
		  }	
		
		
		rs.close();
		
		
		for(int a = 0;a<al_leadname.size();a++)
		{
			DB.Connect(DataSetup.SheetForBC);
			DB.UpdateXLCell("CreateMultipleLeads", al_leadname.get(a), "LeadName" , "Company", al_company.get(a));
		}
		
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to create Lead record.");
			sfdc.AddToXLLogs("Unable to create Lead record.", "Fail");
			
		}
		
	}
	
	public static void ConvertMultipleLeads() throws Exception
	{
		
		ArrayList<String> al_leadname;
		ArrayList<String> al_account;
		ArrayList<String> al_contact;
		ArrayList<String> al_company;
		ArrayList<String> al_opportunity;
		try 
		{
			
			
		//al_leadname = new ArrayList<String>();
		al_account = new ArrayList<String>();
		al_contact = new ArrayList<String>();
		al_company = new ArrayList<String>();
		al_opportunity = new ArrayList<String>();
		
		DB.Connect(DataSetup.SheetForBC);
		ResultSet rs = DB.GetAllExcelValues("CreateMultipleLeads");
		while (rs.next()) {
		    
			//System.out.println(rs.getString(1));
						
		    String LeadName = rs.getString(15);
		    String Company = rs.getString(3);
		    System.out.println(LeadName);

		    if (LeadName != null)
			{
				
				sfdc.SideBarSearch("Leads", LeadName);
				
				//Clicking on Convert button
				ConvertLeadScreen.ConvertButton().Click();
				Thread.sleep(2000L);
				sfdc.GetScreenShotONsuccess();
				//Clicking on Convert button again
				ConvertLeadScreen.AccountNameField().SelectPL_StartsWith("Create");
				ConvertLeadScreen.ConvertButton().Click();
				AccountScreen.ActiveField().VerifyViewOnlyValueEquals("");
				Thread.sleep(3000L);
						
				
				//AccountScreen.AccountNameField().WaitForElement(30);
				String AccountName = AccountScreen.AccountNameField().GetViewOnlyValue();
				if (AccountName.length()>0)
				{
					AccountName = AccountName.substring(0, AccountName.indexOf('[')).trim();
					sfdc.AddToXLLogs("Lead is converted to account and contact successfully", "Pass");
				}
				
				al_account.add(AccountName);
				al_company.add(Company);
				al_contact.add(AccountScreen.RL_Contacts().ContactName(1).toString());
				al_opportunity.add(AccountScreen.RL_Opportunities().OpportunityName(1).toString());
			}
			else
			{
				sfdc.AddToXLLogs("Unable to convert the lead as lead name is missing in the TestData store", "Fail");
				System.out.println("Unable to convert the lead as lead name is missing in the TestData store");
				
			}
			sfdc.Tab("Home").Click();
			
		  }	
		rs.close();
				
		for(int a = 0;a<al_account.size();a++)
		{
			DB.Connect(DataSetup.SheetForBC);
			DB.UpdateXLCell("CreateMultipleLeads", al_account.get(a), "ScriptGeneratedAccountName" , "Company", al_company.get(a));
			DB.UpdateXLCell("CreateMultipleLeads", al_contact.get(a), "ScriptGeneratedContactName" , "Company", al_company.get(a));
			DB.UpdateXLCell("CreateMultipleLeads", al_opportunity.get(a), "ScriptGeneratedOpportunityName" , "Company", al_company.get(a));
		}
		
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to convert the Lead.");
			sfdc.AddToXLLogs("Unable to convert the Lead", "Fail");
			
		}
		
	}
	public static String EnterCreateLeadInfo(String TestCaseName) throws Exception
	{
		String LeadName = "";
		try 
		{
			
			return LeadName;
		}catch(Exception e)
		{
			e.printStackTrace();
			return LeadName;
		}
	}
	
	public void SelectApplication(String ApplicationName) throws Exception
	{
		if (getText("//*[@id='tsidLabel']").trim().equals(ApplicationName.trim()))
		{
			System.out.println("The application ("+ApplicationName+") is selected successfully.");
		}
		else
		{
			click("//*[@id='tsid-arrow']", " Arrow");
			Thread.sleep(1000L);
        	if (getElement("//*[contains(@class,'menuButtonMenuLink') and contains(text(), '"+ApplicationName+"')]").isDisplayed())
        	{
        		click(getElement("//*[contains(@class,'menuButtonMenuLink') and contains(text(), '"+ApplicationName+"')]"), ApplicationName);
    			System.out.println("The application ("+ApplicationName+") is selected successfully.");
    	   	}
        	else
        	{
				System.out.println("Unable to select the application for ("+ApplicationName+"). Please check the related xpaths or application name properly.");
        	}
		
		}

	}
	
	
	*//**
	 * @author Cogniant
	 * @Description This function Waits till the record is saved successfully. It waits till the Feed option is shown. Also sends the message to the log 
	 * @return Returns true if Feed option is found within 20 sec else returns false
	 * @StartupScreen This component should be invoked after clicking on save button for any SFDC object that has Feed/Details option for the record level display.
	 * @ExitScreen no click event in performed in the UI. So no change of screen 
	 * @throws Exception
	 *//*
	public static boolean WaitTillTheRecordIsSaved() throws Exception
	{
		if(sfdc.WebDriverWaitForElement("//ul[normalize-space(@class)='optionContainer']/li[1]/a[1]/span[2][contains(normalize-space(text()),'Feed')]", 20)!=null)
		{
			sfdc.AddToXLLogs("Successfully saved the record.", "Pass");
			System.out.println("Successfully saved the record.");
			return true;
		}
		else
		{
			sfdc.AddToXLLogs("Could not find the Feed option after saving the record.", "Fail");
			System.out.println("Could not find the Feed option after saving the record.");
			return false;
		}
	}
	
	public static boolean LoginAsUser(String UserName) throws Exception
	{
		try
		{
			sfdc.LoginToSFDC(DataSetup.SYSTEM_ADMIN_USERNAME);
			sfdc.GlobalSearch("People", UserName);
			Thread.sleep(2000L);
			sfdc.WaitForPageToLoad(15);
			sfdc.WaitForElement("//a[contains(normalize-space(@class),'zen-trigger') and contains(normalize-space(@title),'User Action Menu')]", 20);
			sfdc.GetWebDriver().findElement(By.xpath("//a[contains(normalize-space(@class),'zen-trigger') and contains(normalize-space(@title),'User Action Menu')]")).click();
//			sfdc.GetWebDriver().findElement(By.xpath("//div[normalize-space(@class)='profileHeader']/div[1]/div[1]/a[1]")).click();
			//sfdc.HighLight(sfdc.WebDriverWaitForElement("//div[normalize-space(@class)='profileHeader']/div[1]/div[1]/a[1]/b[@class='zen-selectArrow']", 10));
			//sfdc.WebDriverWaitForElement("//div[normalize-space(@class)='profileHeader']/div[1]/div[1]/a[1]/b[@class='zen-selectArrow']", 10).click();
			Thread.sleep(1000L);
			sfdc.WaitForElement("//span[normalize-space(text())='User Detail']", 20);			
			sfdc.GetWebDriver().findElement(By.xpath("//span[normalize-space(text())='User Detail']")).click();
			Thread.sleep(2000L);
			sfdc.Button("Login").WaitForElement(10);
			
			sfdc.Button("Login").Click();
			sfdc.WaitForPageToLoad(20);
			sfdc.Tab("Home").Click();
			sfdc.WaitForPageToLoad(20);
			sfdc.AddToXLLogs("The user ("+UserName+") has successfully logged into the application.", "Pass");
			System.out.println("The user ("+UserName+") has successfully logged into the application.");
			return true;
		}
		catch(Exception e)
		{
			sfdc.AddToXLLogs("Unable to login as ("+UserName+"). Please check the xpaths in LoginAsUser function business component.","Fail");
			System.out.println("Unable to login as ("+UserName+"). Please check the xpaths in LoginAsUser function business component.");
			e.printStackTrace();
			return false;
			
		}
    }
	
	
	
	
	*//**
	 * @author Cognizant
	 * @Description Clicks on Details tab
	 * @throws Exception
	 *//*
	public static void ClickONDetailsTab() throws Exception
	{
		try 
		{
			sfdc.GetWebDriver().findElement(By.xpath("//div[@class='mainContent'][1]/div[1]/ul[1]/li[2]/a[1]/span[2]")).click();
			sfdc.AddToXLLogs("Clicked on Details tab.", "Pass");
		}catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Unable to find the Details tab.");
			sfdc.AddToXLLogs("Unable to find the Details tab.", "Fail");
		}
	}
*/	
}
